import argparse
import datetime
import os
import numpy as np
import pandas as pd
import platform
import sys
import time

from occa_Shared import *
from version import version, __version__

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Add_Properties.py",
    description="Add properties in property files to occa sizing files for sizing",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="'Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="'Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + " version: " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
#
# Values for these parameters will be read from the parameter file
#

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
propertiesFilePath = ROOT_DIR + os.sep + "occa_sizing_properties"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("numpy.__version__ : " + np.__version__)
lg("pandas.__version__: " + pd.__version__)

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

# ----------------------------------------------------------------------------------------------------------------------

cwd = os.getcwd().split(os.sep)[-1]
startTime = time.time()
fileTS = (
    datetime.datetime.strftime(
        datetime.datetime.now(datetime.timezone.utc), "%Y%m%d_%H%M%S"
    )
    + "_UTC"
)

lg("Processing files in " + extractFilePath + "...")

if not os.path.exists(extractFilePath):
    lg("Directory " + extractFilePath + " is missing; cannot continue")

    quit()

# ---

propertyFilename = propertiesFilePath + os.sep + "properties_database.csv"

if not os.path.exists(propertyFilename):
    lg(
        "File "
        + propertyFilename
        + " is missing; cannot continue; please be sure to run occa_Create_Property_Files.py before running this script"
    )

    quit()

# ---

drFilename = extractFilePath + os.sep + "emcc_sizing_structure_db_dr.csv"

if not os.path.exists(drFilename):
    lg("File " + drFilename + " is missing; cannot continue")

    quit()

# ----------------------------------------------------------------------------------------------------------------------

try:
    dbPropsDf = pd.read_csv(propertyFilename)
except Exception as fc:
    lg_cannotReadCSVFile(propertyFilename, fc)
    quit()

dbPropsDf.columns = [c.strip() for c in dbPropsDf.columns]

if "target_guid" not in dbPropsDf:
    if (
        "cdb_target_guid" in dbPropsDf
    ):  # needed just in case they have copied the AUDIT spreadsheet to properties
        dbPropsDf.rename(columns={"cdb_target_guid": "target_guid"}, inplace=True)
    else:
        lg(
            "File "
            + propertyFilename
            + ' is missing column "target_guid"; unable to continue'
        )
        quit()

# ---

len0 = len(dbPropsDf)

if len0 == 0:
    lg("File " + propertyFilename + " is empty; cannot contunue")
    quit()

# --

try:
    drDf = pd.read_csv(drFilename)
except Exception as fc:
    lg_cannotReadCSVFile(drFilename, fc)
    quit()

drDf.columns = [c.strip() for c in drDf.columns]

if len(drDf) == 0:
    lg("File " + drFilename + " is empty; cannot contunue")
    quit()

# ---

drDfGb = drDf.groupby("STDBY_TARGET_NAME").count().reset_index()
duplicatesExist = len(drDfGb[drDfGb.STDBY_TARGET_TYPE > 1]) > 0
duplicatesDf = (
    drDf[
        drDf["STDBY_TARGET_NAME"].isin(
            drDfGb[drDfGb.STDBY_TARGET_TYPE > 1]["STDBY_TARGET_NAME"].values.tolist()
        )
    ].copy()
    if duplicatesExist
    else []
)

# ---

storageDf = []

storageFilename = (
    extractFilePath + os.sep + "emcc_sizing_metrics_db_hourly_03_months.csv"
)

if not os.path.exists(storageFilename):
    lg("File " + storageFilename + " does not exit")

else:
    try:
        storageDf = pd.read_csv(storageFilename)
    except Exception as fc:
        lg(str(fc) + " was raised reading file " + storageFilename)

        quit()

if len(storageDf) == 0:
    lg("Unable to establish storage metrics from file " + storageFilename)

    quit()

# ----------------------------------------------------------------------------------------------------------------------

storageDf["metric"] = storageDf["METRIC_NAME"] + "." + storageDf["METRIC_COLUMN"]
storageDf = storageDf[
    storageDf["metric"].isin(["DATABASE_SIZE.ALLOCATED_GB", "DATABASE_SIZE.USED_GB"])
][["TARGET_GUID", "metric", "MAXIMUM"]].drop_duplicates()

storageDf["MAXIMUM_max"] = storageDf.groupby(["TARGET_GUID", "metric"])[
    "MAXIMUM"
].transform("max")
storageDf = storageDf[storageDf["MAXIMUM"] == storageDf["MAXIMUM_max"]]
storageDf.drop(columns=["MAXIMUM_max"], inplace=True)

if len(storageDf) == 0:
    lg("File " + storageFilename + " contains no storage metrics; unable to contunue")
    quit()

try:
    storageDf.drop_duplicates(inplace=True)
    storageDf = storageDf.pivot(index="TARGET_GUID", columns="metric").reset_index()
except Exception as fc:
    lg_notLikelyCSVFile(storageFilename, fc)
    quit()

# ---

storageDf.columns = ["TARGET_GUID_STORAGE", "PRI_ALLOCATED_GB", "PRI_USED_GB"]
storageDf = storageDf[
    ["TARGET_GUID_STORAGE", "PRI_USED_GB", "PRI_ALLOCATED_GB"]
]  # re-order the columns to be consistent with the column ordering in the property file

drDf = pd.merge(
    left=drDf[
        [
            "STDBY_TARGET_GUID",
            "PRI_TARGET_GUID",
            "PRI_TARGET_NAME",
            "PRI_TARGET_TYPE",
            "PROTECTION_MODE",
        ]
    ],
    right=storageDf,
    left_on="PRI_TARGET_GUID",
    right_on="TARGET_GUID_STORAGE",
    how="left",
)
drDf = drDf[(~drDf["PRI_USED_GB"].isnull()) | (~drDf["PRI_ALLOCATED_GB"].isnull())]
drDf.drop(columns=["TARGET_GUID_STORAGE"], inplace=True)

#
# The following logic makes sure we get just one value for each standby
#

drDf["PRI_ALLOCATED_GB_max"] = drDf.groupby("STDBY_TARGET_GUID")[
    "PRI_ALLOCATED_GB"
].transform("max")
drDf = drDf[drDf["PRI_ALLOCATED_GB"] == drDf["PRI_ALLOCATED_GB_max"]]

drDf["PRI_USED_GB_max"] = drDf.groupby("STDBY_TARGET_GUID")["PRI_USED_GB"].transform(
    "max"
)
drDf = drDf[drDf["PRI_USED_GB"] == drDf["PRI_USED_GB_max"]]

drDf["PRI_TARGET_GUID_max"] = drDf.groupby("STDBY_TARGET_GUID")[
    "PRI_TARGET_GUID"
].transform("max")
drDf = drDf[drDf["PRI_TARGET_GUID"] == drDf["PRI_TARGET_GUID_max"]]

drDf.drop(
    columns=["PRI_ALLOCATED_GB_max", "PRI_USED_GB_max", "PRI_TARGET_GUID_max"],
    inplace=True,
)

drDf.drop_duplicates(inplace=True)

# ---

colsToDrop = [
    c
    for c in [
        "STDBY_TARGET_GUID",
        "PRI_TARGET_GUID",
        "PRI_TARGET_NAME",
        "PRI_TARGET_TYPE",
        "PROTECTION_MODE",
        "TARGET_GUID_STORAGE",
        "PRI_ALLOCATED_GB",
        "PRI_USED_GB",
    ]
    if c in dbPropsDf
]

if len(colsToDrop) > 0:
    dbPropsDf.drop(columns=colsToDrop, inplace=True)

dbPropsDf = pd.merge(
    left=dbPropsDf,
    right=drDf,
    left_on="target_guid",
    right_on="STDBY_TARGET_GUID",
    how="left",
)
dbPropsDf.drop(
    columns=[
        "STDBY_TARGET_GUID",
        "PRI_TARGET_GUID",
        "PRI_TARGET_NAME",
        "PRI_TARGET_TYPE",
        "PROTECTION_MODE",
    ],
    inplace=True,
)

if (
    len(dbPropsDf[~dbPropsDf["PRI_ALLOCATED_GB"].isnull()]) == 0
    and len(dbPropsDf[~dbPropsDf["PRI_USED_GB"].isnull()]) == 0
):
    lg("No overriding storage value could be derived")

else:
    dbPropsDf.loc[
        ~dbPropsDf["PRI_ALLOCATED_GB"].isnull(), "Allocated Database Size (GB)"
    ] = dbPropsDf["PRI_ALLOCATED_GB"]
    dbPropsDf.loc[~dbPropsDf["PRI_USED_GB"].isnull(), "Total Database Size (GB)"] = (
        dbPropsDf["PRI_USED_GB"]
    )

# ---

len1 = len(dbPropsDf)

dupPropertyFilename = (
    propertiesFilePath + os.sep + "properties_database-with-duplicates.csv"
)
dupFilename = (
    outputFilePath
    + os.sep
    + "duplicate_tests"
    + os.sep
    + "Copy_Primary_DB_Size_To_Properties.duplicate_standby_db.csv"
)

if len0 != len1:
    lg(
        "Orginal length of file "
        + propertyFilename
        + ": "
        + str(len0)
        + " does not match final length: "
        + str(len1)
    )
    lg("The final file has been written to " + dupPropertyFilename)

    dbPropsDf.to_csv(dupPropertyFilename, index=False)

    if not duplicatesExist:
        if os.path.exists(dupFilename):
            os.remove(dupFilename)

    else:
        os.makedirs(outputFilePath + os.sep + "duplicate_tests", exist_ok=True)
        duplicatesDf.to_csv(dupFilename, index=False)

        lg(
            "\nThere are "
            + str(len(drDfGb[drDfGb.STDBY_TARGET_TYPE > 1]))
            + " standby databases associated with more than one primary datbase; these are the cause for the duplicates in the databases properties file"
        )
        lg("     The duplicate entries have been written to file " + dupFilename)
        lg(
            "\nYou can remove the row(s) you believe to be in error from file "
            + drFilename
            + " and then try re-running this script"
        )

    quit()

else:
    if os.path.exists(dupPropertyFilename):
        os.remove(dupPropertyFilename)

    if os.path.exists(dupFilename):
        os.remove(dupFilename)

# ---

dbPropsDf.drop(columns=["PRI_USED_GB", "PRI_ALLOCATED_GB"], inplace=True)

os.rename(propertyFilename, propertyFilename.rstrip(".csv") + "." + fileTS + ".csv")
dbPropsDf.sort_values(["Database Name"]).to_csv(propertyFilename, index=False)
lg("\nAdded values to file " + propertyFilename)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nThe processing of "
    + str(len(dbPropsDf))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
