DB_METRICS_FILE = "emcc_sizing_metrics_db_hourly_03_months.csv"

CPU_METRIC = "db_inst_cpu_usage.avg_tot_cpu_usage_ps"
CPU_DERIVED_METRIC = "Derived.logical_cores_used-metric-2"
IOPS_METRIC = "instance_throughput.iorequests_ps"
PGA_METRIC = "memory_usage_sga_pga.pga_total"
SGA_METRIC = "memory_usage_sga_pga.sga_total"
SGAPGA_DERIVED_METRIC = "Derived.sga_plus_pga_usage"
STORAGE_ALLOCATED_METRIC = "DATABASE_SIZE.ALLOCATED_GB"
STORAGE_USED_METRIC = "DATABASE_SIZE.USED_GB"

HEIGHT = 1185
WIDTH = 1920

# ----------------------------------------------------------------------------------------------------------------------

import datetime
import math
import numpy as np
import os
import platform
import pandas as pd
import plotly as plt
import plotly.express as px
import plotly.graph_objs as go
import sys
import time

import Duplicate_Tests
import occa_Shared
from version import version, __version__

# ----------------------------------------------------------------------------------------------------------------------


def lg(t: object) -> object:

    print(t)
    logFile.write(t + "\n")


# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

#
# This script depends on a setting for the parameters shown below
# Values for these parameters will be read from the parameter file
#

# CREATE_OBFUSCATED_FILES=True
CREATE_OBFUSCATED_FILES = False

# CREATE_SIMULATOR_FILES_ONLY=True
CREATE_SIMULATOR_FILES_ONLY = False

COHORTS = []

PLOT_INSTANCE_COUNT_LIMIT = 500

PLOT_HTML = True
PLOT_PNG = True
PLOT_SUPPRESSED_COHORTS = []

PRECISION = 3

TIME_PERIODS = ["03", "06", "09", "12"]

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ---

CREATE_OBFUSCATED_FILES = (CREATE_OBFUSCATED_FILES) or (
    "CREATE_OBFUSCATED_FILES" in os.environ
    and os.environ["CREATE_OBFUSCATED_FILES"].upper() == "TRUE"
)
CREATE_SIMULATOR_FILES_ONLY = (CREATE_SIMULATOR_FILES_ONLY) or (
    "CREATE_SIMULATOR_FILES_ONLY" in os.environ
    and os.environ["CREATE_SIMULATOR_FILES_ONLY"].upper() == "TRUE"
)

# ----------------------------------------------------------------------------------------------------------------------


def printDf(lbl, dataFrameToPrint, rows=25, tail=True):
    lg("\n" + lbl + " of len " + str(len(dataFrameToPrint)))
    lg("--------------------------------------------------")
    lg("index")
    lg("=====")

    for c in dataFrameToPrint.index.names:
        if c is None:
            lg("None")
        else:
            lg(str(c).ljust(45))

    lg("\ncolumns")
    lg("========")

    for c in sorted(dataFrameToPrint.columns):
        lg(str(c).ljust(45) + " : " + str(dataFrameToPrint[c].dtype))

    lg("\nhead(" + str(rows) + ")")
    lg(str(dataFrameToPrint.head(rows)))

    if tail:
        lg("\ntail(" + str(rows) + ")")
        lg(str(dataFrameToPrint.tail(rows)))

    lg("--------------------------------------------------")


# ----------------------------------------------------------------------------------------------------------------------


def obfuscateDf(cdbs, hosts, dbs):
    cdbs.replace({"Database Name": cdbDict}, inplace=True)
    dbs.replace({"Database": cdbDict}, inplace=True)

    hosts.replace({"Server Name": hostDict}, inplace=True)
    dbs.replace({"Server": hostDict}, inplace=True)

    if "Original Server" in dbs:
        dbs.replace({"Original Server": hostDict}, inplace=True)

    dbs.replace({"Instance": instanceDict}, inplace=True)

    hosts.replace({"cluster": cdbClusterDict}, inplace=True)
    cdbs.replace({"cluster": cdbClusterDict}, inplace=True)
    dbs.replace({"cluster": cdbClusterDict}, inplace=True)

    cdbs.replace({"cdb_owner": cdbOwnerDict}, inplace=True)
    dbs.replace({"cdb_owner": cdbOwnerDict}, inplace=True)

    hosts.replace({"dbmachine": dbmachineDict}, inplace=True)
    cdbs.replace({"dbmachine": dbmachineDict}, inplace=True)
    dbs.replace({"dbmachine": dbmachineDict}, inplace=True)

    hosts.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    cdbs.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    dbs.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)


# ----------------------------------------------------------------------------------------------------------------------


def writeDfToExcel(excelWriter, df, sheetname, index=False):
    workbook = excelWriter.book
    format4 = workbook.add_format({"align": "left"})
    formatAudit = workbook.add_format(
        {"align": "left", "bg_color": "yellow", "bold": True, "font_color": "black"}
    )
    formatStart = workbook.add_format(
        {"align": "left", "bg_color": "green", "bold": True, "font_color": "white"}
    )
    formatStop = workbook.add_format(
        {"align": "left", "bg_color": "red", "bold": True, "font_color": "white"}
    )

    df.to_excel(excelWriter, sheetname, index=index)
    ws = excelWriter.sheets[sheetname]

    if index:
        for i, c in enumerate(df.index.names):
            colLength = (
                max(len(c), df.index.get_level_values(i).astype(str).str.len().max())
                + 6
            )

            ws.set_column(i, i, colLength, format4)

    # ---

    for i, c in enumerate(df.columns):
        colLength = max(len(c), df[c].astype(str).str.len().max()) + 6

        if c in ["START AUDIT", "STOP AUDIT", "END PROPERTIES"]:

            if index:
                ws.set_column(
                    i + len(df.index.names),
                    i + len(df.index.names),
                    colLength,
                    formatAudit,
                )
            else:
                ws.set_column(i, i, colLength, formatAudit)

        elif c == "START":

            if index:
                ws.set_column(
                    i + len(df.index.names),
                    i + len(df.index.names),
                    colLength,
                    formatStart,
                )
            else:
                ws.set_column(i, i, colLength, formatStart)

        elif c == "STOP":

            if index:
                ws.set_column(
                    i + len(df.index.names),
                    i + len(df.index.names),
                    colLength,
                    formatStop,
                )
            else:
                ws.set_column(i, i, colLength, formatStop)
        else:

            if index:
                ws.set_column(
                    i + len(df.index.names), i + len(df.index.names), colLength, format4
                )
            else:
                ws.set_column(i, i, colLength, format4)

    if index:
        ws.autofilter(0, 0, max(len(df), 1), i + len(df.index.names))
    else:
        ws.autofilter(0, 0, max(len(df), 1), i)

    ws.freeze_panes(1, 0)


# ----------------------------------------------------------------------------------------------------------------------


def format_title(title, subtitle=None, subtitle_font_size=14):
    title = f"<b>{title}</b>"

    if not subtitle:
        return title

    subtitle = f'<span style="font-size: {subtitle_font_size}px;">{subtitle}</span>'

    return f"{title}<br>{subtitle}"


# ----------------------------------------------------------------------------------------------------------------------


def plotMetrics(df):
    lg("\nBeginning plots...")

    customer = os.getcwd().split(os.sep)[-1]

    for cohort in df.cdb_cohort.unique():
        if cohort in PLOT_SUPPRESSED_COHORTS:
            lg("     Skipping plot suppressed cohort " + str(cohort) + "...")

            continue

        lg("     Beginning cohort " + str(cohort) + "...")

        instanceCount = len(df[df["cdb_cohort"] == cohort]["cdb"].unique())

        if instanceCount > PLOT_INSTANCE_COUNT_LIMIT:
            lg(
                "     "
                + str(cohort)
                + "'s instance count "
                + str(instanceCount)
                + " exceeds limit "
                + str(PLOT_INSTANCE_COUNT_LIMIT)
                + " set by parameter PLOT_INSTANCE_COUNT_LIMIT; plotting peak trace only"
            )

        tb = time.time()

        if PLOT_HTML:
            filePathHTML = plotFilePath + os.sep + str(cohort) + os.sep + "html"
            os.makedirs(filePathHTML, exist_ok=True)

        if PLOT_PNG:
            filePathPNG = plotFilePath + os.sep + str(cohort) + os.sep + "png"
            os.makedirs(filePathPNG, exist_ok=True)

        plotCtr = 0

        for metric in sorted(df.metric.unique()):
            if metric == CPU_DERIVED_METRIC:
                uom = "vCPU"
            elif metric == IOPS_METRIC:
                uom = "IOPS"
            elif metric in [PGA_METRIC, SGA_METRIC, SGAPGA_DERIVED_METRIC]:
                uom = "MB"
            elif metric in [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]:
                uom = "GB"
            else:
                uom = "Unknow: " + metric

            lg("        Beginning plot for metric " + metric + "...")

            if PLOT_HTML:
                filenameHTML = (
                    filePathHTML + os.sep + str(cohort) + "_" + metric + ".html"
                )
                dashboard = open(filenameHTML, "w")
                HTMLhead = (
                    customer
                    + " : "
                    + str(cohort)
                    + ", Hourly Average "
                    + metric
                    + " (occa_Create_Spreadsheets, v"
                    + __version__
                    + ")"
                )

                dashboard.write(
                    "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
                )

            if PLOT_PNG:
                filenamePNG = filePathPNG + os.sep + str(cohort) + "_" + metric + ".png"

            aDf = df[(df["cdb_cohort"] == cohort) & (df["metric"] == metric)].copy()

            if len(aDf) == 0:
                lg(
                    "          Skipping 0-length cohort: "
                    + str(cohort)
                    + ", metric: "
                    + metric
                )
                continue

            timeAlignedDf = aDf.groupby(["ROLLUP_TIMESTAMP_UTC"], as_index=False)[
                "AVERAGE"
            ].sum()

            peak = round(timeAlignedDf["AVERAGE"].max(), PRECISION)
            timeAlignedDf["MAX"] = peak
            timeAlignedDf["DIFF"] = peak - timeAlignedDf["AVERAGE"]

            sum_peak_x_hrs = round(timeAlignedDf["MAX"].sum(), PRECISION)
            sum_metric_x_hrs = round(timeAlignedDf["AVERAGE"].sum(), PRECISION)
            sumOfDiff = round(timeAlignedDf["DIFF"].sum(), PRECISION)

            aDf["total"] = aDf.groupby(["cdb"])["AVERAGE"].transform("sum")
            aDf["rank"] = aDf["total"].rank(method="dense").astype(str)
            aDf["sort"] = aDf["rank"].str.zfill(5) + "$$$" + aDf["cdb"]

            aDf.rename(columns={"cdb": " cdb_original", "sort": "cdb"}, inplace=True)

            if metric in [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]:
                #
                #               Storage metrics are captured at the daily level
                #
                sum_peak_x_hrs = round(sum_peak_x_hrs * 24, PRECISION)
                sum_metric_x_hrs = round(sum_metric_x_hrs * 24, PRECISION)
                sumOfDiff = round(sumOfDiff * 24, PRECISION)

            aDf.sort_values(
                ["cdb", "ROLLUP_TIMESTAMP_UTC"], ascending=[False, True], inplace=True
            )

            if 1 == 0:
                filename = (
                    sizingFilePath
                    + os.sep
                    + "aDf_"
                    + str(cohort)
                    + "_"
                    + metric
                    + ".csv"
                )
                aDf.to_csv(filename, index=False)
                lg("Wrote " + filename)

            if instanceCount > PLOT_INSTANCE_COUNT_LIMIT:
                fig = px.line(
                    timeAlignedDf,
                    x="ROLLUP_TIMESTAMP_UTC",
                    y="AVERAGE",
                    labels={
                        "ROLLUP_TIMESTAMP_UTC": "Date (UTC)",
                        "AVERAGE": metric + " (" + uom + ")",
                    },
                    title=format_title(
                        "<b>"
                        + customer
                        + " : "
                        + str(cohort)
                        + "</b> : Hourly Average "
                        + metric
                        + " (v"
                        + __version__
                        + ")",
                        "Peak="
                        + f"{peak:,}"
                        + " "
                        + uom
                        + ", sum_peak_x_hrs="
                        + f"{sum_peak_x_hrs:,}"
                        + " "
                        + uom
                        + "-hrs<br>"
                        + "sum_metric_x_hrs="
                        + f"{sum_metric_x_hrs:,}"
                        + " "
                        + uom
                        + "-hrs (cum. using black solid)"
                        + ", sum_peak_x_hrs - sum_metric_x_hrs="
                        + f"{sumOfDiff:,}"
                        + " "
                        + uom
                        + "-hrs",
                        20,
                    ),
                    template="seaborn",
                    width=WIDTH,
                    height=HEIGHT,
                )
                fig.update_traces(line=dict(color="black", width=6))

            else:
                fig = px.area(
                    aDf,
                    x="ROLLUP_TIMESTAMP_UTC",
                    y="AVERAGE",
                    color="cdb",
                    labels={
                        "ROLLUP_TIMESTAMP_UTC": "Date (UTC)",
                        "AVERAGE": metric + " (" + uom + ")",
                    },
                    title=format_title(
                        "<b>"
                        + customer
                        + " : "
                        + str(cohort)
                        + "</b> : Hourly Average "
                        + metric
                        + " (v"
                        + __version__
                        + ")",
                        "Peak="
                        + f"{peak:,}"
                        + " "
                        + uom
                        + ", sum_peak_x_hrs="
                        + f"{sum_peak_x_hrs:,}"
                        + " "
                        + uom
                        + "-hrs<br>"
                        + "sum_metric_x_hrs="
                        + f"{sum_metric_x_hrs:,}"
                        + " "
                        + uom
                        + "-hrs (cum. using black solid)"
                        + ", sum_peak_x_hrs - sum_metric_x_hrs="
                        + f"{sumOfDiff:,}"
                        + " "
                        + uom
                        + "-hrs",
                        20,
                    ),
                    template="seaborn",
                    width=WIDTH,
                    height=HEIGHT,
                )

                fig.add_trace(
                    go.Scatter(
                        x=timeAlignedDf["ROLLUP_TIMESTAMP_UTC"],
                        y=timeAlignedDf["AVERAGE"],
                        mode="lines",
                        line=dict(color="black", width=6),
                    )
                )

            fig.update_layout(yaxis_range=[0, peak * 1.1])
            fig.add_hline(y=peak, line_width=3, line_color="red")
            fig.update_layout(
                font={"size": 16},
                legend_font_size=12,
                autosize=False,
                width=1900,
                height=1200,
                margin=dict(t=150),
            )

            if instanceCount <= PLOT_INSTANCE_COUNT_LIMIT:
                for idx in range(len(fig.data)):
                    # lg('idx: ' + str(idx) + ', ' + str(fig.data[idx]))

                    cdb = fig.data[idx].name

                    if cdb is None:
                        continue

                    cdb = cdb[cdb.find("$$$") + 3 :]

                    fig.data[idx].name = cdb
                    fig.data[idx].legendgroup = cdb
                    fig.data[idx].hovertemplate = cdb

            if PLOT_HTML:
                inner_html = (
                    fig.to_html(include_plotlyjs=True)
                    .split("<body>")[1]
                    .split("</body>")[0]
                )
                dashboard.write(inner_html)

                dashboard.write("</body></html>" + "\n")
                dashboard.close()

                plotCtr += 1

            if PLOT_PNG:
                fig.write_image(filenamePNG)

                plotCtr += 1

        lg(
            "     Created "
            + str(plotCtr)
            + " plots for "
            + str(cohort)
            + " in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )


# ----------------------------------------------------------------------------------------------------------------------

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"

missingFilePath = outputFilePath + os.sep + "missing"
overrideFilePath = outputFilePath + os.sep + "override"
plotFilePath = outputFilePath + os.sep + "plots"
sizingFilePath = outputFilePath + os.sep + "sizing"

os.makedirs(missingFilePath, exist_ok=True)
os.makedirs(overrideFilePath, exist_ok=True)
os.makedirs(sizingFilePath, exist_ok=True)

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open(logFilename, "a")

lg(
    "\n\n=======================================================================================================\n"
)
lg("Begin @ " + datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S") + " UTC\n")
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("numpy.__version__ : " + np.__version__)
lg("pandas.__version__: " + pd.__version__)
lg("plotly.__version__: " + plt.__version__)

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n=======================================================================================================\n"
)

lg("CREATE_OBFUSCATED_FILES    : " + str(CREATE_OBFUSCATED_FILES))
lg("CREATE_SIMULATOR_FILES_ONLY: " + str(CREATE_SIMULATOR_FILES_ONLY))
lg("COHORTS                    : " + str(COHORTS))
lg("PLOT_INSTANCE_COUNT_LIMIT  : " + str(PLOT_INSTANCE_COUNT_LIMIT))
lg("PLOT_HTML                  : " + str(PLOT_HTML))
lg("PLOT_PNG                   : " + str(PLOT_PNG))
lg("PLOT_SUPPRESSED_COHORTS    : " + str(PLOT_SUPPRESSED_COHORTS))
lg("PRECISION                  : " + str(PRECISION))
lg("TIME_PERIODS               : " + str(TIME_PERIODS))

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

structureFilename = outputFilePath + os.sep + "occa_sizing_structure_db_combined"

if not os.path.exists(structureFilename + ".csv"):
    lg(
        "File "
        + structureFilename
        + ".csv is missing; please run occa_Add_Properties.py before continuing"
    )

    quit()

# ---

resultsFilePrefix = "occa_sizing_spreadsheet"
simulatorFilePrefix = "occa_sizing_simulator"

startTime = time.time()
lg(
    "Processing emcc_sizing extract files in directory "
    + extractFilePath
    + " in working directory "
    + os.getcwd()
)

structureDf = pd.read_csv(structureFilename + ".csv")
structureDf.columns = [c.strip() for c in structureDf.columns]

structureDf["cdb_cohort"].fillna("", inplace=True)
structureDf["cdb_cohort"] = structureDf["cdb_cohort"].str.strip()

structureDf["db_cohort"] = structureDf["cdb_cohort"]

cwd = os.getcwd().split(os.sep)[-1]
extract_dttm_utc = structureDf["extract_dttm_utc"].unique()[0]
now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
platform = platform.system()

structureDf["cwd"] = cwd
structureDf["platform"] = platform
structureDf["dbms_vendor"] = "ORACLE"

structureDf.loc[structureDf["physical_cpu_count"].isnull(), "cores_per_chip"] = 0
structureDf.loc[structureDf["physical_cpu_count"].notnull(), "cores_per_chip"] = (
    structureDf["total_cpu_cores"] / structureDf["physical_cpu_count"]
)
structureDf.loc[structureDf["cores_per_chip"].isnull(), "cores_per_chip"] = 0
structureDf["cores_per_chip"] = structureDf["cores_per_chip"].astype(int)

structureDf["mem_gb"] = round(structureDf["mem_gb"], PRECISION)
structureDf["sga_size_gb"] = structureDf[
    ["init_sga_max_size_gb", "init_sga_target_gb", "sga_total_sga_gb"]
].max(axis=1)
structureDf["sga_size_gb"] = round(structureDf["sga_size_gb"], PRECISION)

structureDf["pga_size_gb"] = structureDf[
    ["init_pga_aggregate_limit_gb", "init_pga_aggregate_target_gb"]
].max(axis=1)
structureDf["pga_size_gb"] = round(structureDf["pga_size_gb"], PRECISION)

structureDf["host_subscr_pct"] = round(
    structureDf["host_db_cpu_count_limit"] / structureDf["logical_cpu_count"] * 100,
    PRECISION,
)
structureDf["db_cpu_count_guarantee_pct"] = round(
    (structureDf["db_cpu_count_guarantee"] / (structureDf["logical_cpu_count"])) * 100,
    PRECISION,
)

structureDf["create_dttm_utc"] = now
structureDf["version"] = __version__

# ----------------------------------------------------------------------------------------------------------------------

duplicateTestResults, structureDf = Duplicate_Tests.duplicateTests(
    structureDf, "Create_Spreadsheets", outputFilePath
)

# ----------------------------------------------------------------------------------------------------------------------
#
# Following logic is needed just in case we are creating spreadsheets from a combined file that also includes new cpu attributes
#
if (
    "ecache_in_mb" in structureDf
    or "impl" in structureDf
    or "revision" in structureDf
    or "is_hyperthread_enabled" in structureDf
):
    try:
        structureDf.drop(
            ["ecache_in_mb", "impl", "revision", "is_hyperthread_enabled"],
            axis=1,
            inplace=True,
        )
    except:
        pass

if os.path.exists(extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"):
    try:
        cpuDf = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"
        )
    except:
        cpuDdf = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv",
            encoding="ISO-8859-1",
        )

    cols = [c.strip() for c in cpuDf.columns]
    cpuDf.columns = cols

    cpuDf = cpuDf[
        ["target_guid", "ecache_in_mb", "impl", "revision", "is_hyperthread_enabled"]
    ]
    cpuDf.columns = [
        "host_target_guid",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
    ]

    structureDf = pd.merge(
        left=structureDf,
        right=cpuDf,
        how="left",
        left_on="host_target_guid",
        right_on="host_target_guid",
    )

else:
    structureDf["ecache_in_mb"] = -1
    structureDf["impl"] = "not_loaded"
    structureDf["revision"] = "not_loaded"
    structureDf["is_hyperthread_enabled"] = -1

# ----------

if "h_total_cpu_cores_ovr" not in structureDf:
    structureDf["h_total_cpu_cores_ovr"] = np.nan
if "cdb_type_version" not in structureDf:
    structureDf["cdb_type_version"] = ""
if "db_type_version" not in structureDf:
    structureDf["db_type_version"] = ""
if "host_type_version" not in structureDf:
    structureDf["host_type_version"] = ""

structureDf["cpu_type"] = structureDf.apply(
    lambda r: occa_Shared.getCPUType(r["ma"], r["impl"]), axis=1
)

# ---

#
# Get simulator hosts now so that we keep hosts not running databases
#

simHostsDf = structureDf.copy()
simHostsDf.loc[simHostsDf["h_cpu_type_ovr"].notnull(), "cpu_type"] = simHostsDf[
    "h_cpu_type_ovr"
]
simHostsDf.loc[
    simHostsDf["h_physical_cpu_count_ovr"].notnull(), "physical_cpu_count"
] = simHostsDf["h_physical_cpu_count_ovr"]
simHostsDf.loc[simHostsDf["h_total_cpu_cores_ovr"].notnull(), "total_cpu_cores"] = (
    simHostsDf["h_total_cpu_cores_ovr"]
)

hostIndexDf = simHostsDf[["dbmachine", "cluster", "host"]].drop_duplicates()
hostIndexDf["dbmachine"] = hostIndexDf["dbmachine"].fillna("none")

#
# Force hosts on a DB machine into a common cluster for the purposes of generating a host index
#
hostIndexDf.loc[hostIndexDf["dbmachine"] != "none", "cluster"] = hostIndexDf[
    "dbmachine"
]
hostIndexDf.loc[hostIndexDf["cluster"] == "none", "cluster"] = hostIndexDf["host"]

hostIndexDf.sort_values(["dbmachine", "cluster", "host"], inplace=True)
hostIndexDf["cluster_host_rn"] = (
    hostIndexDf.groupby(["dbmachine", "cluster"]).cumcount() + 1
)
hostIndexDf.drop(columns=["dbmachine", "cluster"], inplace=True)

simHostsDf = pd.merge(
    left=simHostsDf, right=hostIndexDf, how="left", left_on="host", right_on="host"
)

simHostsDf = simHostsDf[
    [
        "host_num",
        "host",
        "cluster",
        "dbmachine",
        "dbmachine_owner",
        "physical_cpu_count",
        "total_cpu_cores",
        "logical_cpu_count",
        "mem_gb",
        "nr_huge_pages",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "vendor_name",
        "dist_version",
        "host_instance_count",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "host_status",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "host_type_version",
        "cluster_host_rn",
        "host_last_load_time_utc",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()

simHostsDf.columns = [
    "h_num",
    "h",
    "cdb_cluster",
    "dbmachine",
    "dbmachine_owner",
    "h_physical_cpu_count",
    "h_total_cpu_cores",
    "h_logical_cpu_count",
    "h_mem_gb",
    "h_vm_nr_huge_pages",
    "h_ecache_in_mb",
    "h_impl",
    "h_revision",
    "h_is_hyperthread_enabled",
    "h_freq",
    "h_cpu_type",
    "h_ma",
    "h_system_config",
    "h_vendor_name",
    "h_dist_version",
    "h_inst_count",
    "h_cpu_count_total",
    "h_subscr_pct",
    "h_status",
    "h_cost_center",
    "h_department",
    "h_lifecycle_status",
    "h_line_of_bus",
    "h_location",
    "host_type_version",
    "cdb_cluster_host_rn",
    "h_last_load_time_utc",
    "h_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

# ---

#
# Eliminate hosts not running databases; they cannot be part of a sizing scenario
#

structureDf = structureDf[structureDf["db"] != "none"]

# ---

simInstancesDf = structureDf[
    [
        "cdb_num",
        "cdb",
        "cdb_type",
        "cdb_standby_type",
        "cluster",
        "cdb_owner",
        "dbmachine",
        "dbmachine_owner",
        "db_num",
        "db_version",
        "db",
        "db_standby_type",
        "sga_size_gb",
        "pga_size_gb",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "host_subscr_pct",
        "db_status",
        "db_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_cohort",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "cdb_type_version",
        "db_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
]

simInstancesDf.columns = [
    "cdb_num",
    "cdb",
    "cdb_type",
    "cdb_standby_type",
    "cdb_cluster",
    "cdb_owner",
    "dbmachine",
    "dbmachine_owner",
    "inst_num",
    "inst_version",
    "inst",
    "inst_standby_type",
    "inst_sga_size_gb",
    "inst_pga_size_gb",
    "inst_i_use_large_pages",
    "inst_cpu_count_guarantee",
    "inst_cpu_count_limit",
    "h_subscr_pct",
    "inst_status",
    "inst_last_load_time_utc",
    "cdb_cost_center",
    "cdb_department",
    "cdb_cohort",
    "cdb_lifecycle_status",
    "cdb_line_of_bus",
    "cdb_location",
    "db_cost_center",
    "db_department",
    "db_cohort",
    "db_lifecycle_status",
    "db_line_of_bus",
    "db_location",
    "cdb_type_version",
    "db_type_version",
    "cdb_guid",
    "inst_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

simInstancesDf = simInstancesDf[simInstancesDf.inst != "none"]

# ---

simPlacementsDf = structureDf.copy()

if 1 == 0:
    printDf("xxx simPlacementsDf", simPlacementsDf)

simPlacementsDf.loc[simPlacementsDf["h_cpu_type_ovr"].notnull(), "cpu_type"] = (
    simPlacementsDf["h_cpu_type_ovr"]
)
simPlacementsDf.loc[
    simPlacementsDf["h_physical_cpu_count_ovr"].notnull(), "physical_cpu_count"
] = simPlacementsDf["h_physical_cpu_count_ovr"]
simPlacementsDf.loc[
    simPlacementsDf["h_total_cpu_cores_ovr"].notnull(), "total_cpu_cores"
] = simPlacementsDf["h_total_cpu_cores_ovr"]

simPlacementsDf = simPlacementsDf[
    [
        "cdb_num",
        "cdb",
        "cdb_type",
        "cdb_standby_type",
        "cluster",
        "cdb_owner",
        "dbmachine",
        "dbmachine_owner",
        "db_num",
        "db_version",
        "db",
        "db_standby_type",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "db_cpu_count_guarantee_pct",
        "host_num",
        "host",
        "physical_cpu_count",
        "total_cpu_cores",
        "logical_cpu_count",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "mem_gb",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "db_status",
        "db_last_load_time_utc",
        "host_status",
        "host_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_cohort",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_status",
        "cdb_last_load_time_utc",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "db_owner",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
]

simPlacementsDf.columns = [
    "cdb_num",
    "cdb",
    "cdb_type",
    "cdb_standby_type",
    "cdb_cluster",
    "cdb_owner",
    "dbmachine",
    "dbmachine_owner",
    "inst_num",
    "inst_version",
    "inst",
    "inst_standby_type",
    "inst_cpu_count_guarantee",
    "inst_cpu_count_limit",
    "inst_cpu_count_guarantee_pct",
    "h_num",
    "h",
    "h_physical_cpu_count",
    "h_total_cpu_cores",
    "h_logical_cpu_count",
    "h_cpu_count_total",
    "h_subscr_pct",
    "h_mem_gb",
    "h_freq",
    "h_cpu_type",
    "h_ma",
    "h_system_config",
    "inst_status",
    "inst_last_load_time_utc",
    "h_status",
    "h_last_load_time_utc",
    "cdb_cost_center",
    "cdb_department",
    "cdb_cohort",
    "cdb_lifecycle_status",
    "cdb_line_of_bus",
    "cdb_location",
    "cdb_status",
    "cdb_last_load_time_utc",
    "db_cost_center",
    "db_department",
    "db_cohort",
    "db_lifecycle_status",
    "db_line_of_bus",
    "db_location",
    "db_owner",
    "cdb_type_version",
    "db_type_version",
    "host_type_version",
    "cdb_guid",
    "inst_guid",
    "h_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

simPlacementsDf = simPlacementsDf[simPlacementsDf.inst != "none"]

# ----------

hostsDf = structureDf[
    [
        "host",
        "physical_cpu_count",
        "cores_per_chip",
        "mem_gb",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_description_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "host_status",
        "host_last_load_time_utc",
        "logical_cpu_count",
        "total_cpu_cores",
        "nr_huge_pages",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "vendor_name",
        "dist_version",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "host_type_version",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()

cdbsDf = structureDf[
    [
        "cdb_cohort",
        "cdb",
        "cdb_instance_count",
        "dbms_vendor",
        "cdb_version",
        "cdb_version_sizing",
        "clustered",
        "cdb_size_allocated_ovr",
        "cdb_size_used_ovr",
        "cdb_ovr",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_type_version",
        "cdb_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()

dbPlacementsDf = structureDf[
    [
        "cdb",
        "db",
        "host",
        "sga_size_gb",
        "pga_size_gb",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "db_status",
        "db_last_load_time_utc",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "db_vcpu_ovr",
        "db_sga_mb_ovr",
        "db_pga_mb_ovr",
        "db_iops_ovr",
        "host_subscr_pct",
        "host_status",
        "host_last_load_time_utc",
        "physical_cpu_count",
        "cores_per_chip",
        "logical_cpu_count",
        "total_cpu_cores",
        "mem_gb",
        "nr_huge_pages",
        "host_db_cpu_count_limit",
        "vendor_name",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "dist_version",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "cdb_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_cohort",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "init_cpu_count",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()

dbPlacementsDf.loc[dbPlacementsDf["h_cpu_type_ovr"].notnull(), "cpu_type"] = (
    dbPlacementsDf["h_cpu_type_ovr"]
)
dbPlacementsDf.loc[
    dbPlacementsDf["h_cores_per_chip_ovr"].notnull(), "cores_per_chip"
] = dbPlacementsDf["h_total_cpu_cores_ovr"]
dbPlacementsDf.loc[
    dbPlacementsDf["h_physical_cpu_count_ovr"].notnull(), "physical_cpu_count"
] = dbPlacementsDf["h_physical_cpu_count_ovr"]
dbPlacementsDf.loc[
    dbPlacementsDf["h_total_cpu_cores_ovr"].notnull(), "total_cpu_cores"
] = dbPlacementsDf["h_total_cpu_cores_ovr"]

# ---

simulatorFilePath = ROOT_DIR + os.sep + "occa_sizing_output" + os.sep + "simulator"
os.makedirs(simulatorFilePath, exist_ok=True)

if CREATE_OBFUSCATED_FILES:
    os.makedirs(simulatorFilePath + os.sep + "obfuscated", exist_ok=True)

# ---

simHostsDf.to_csv(
    simulatorFilePath + os.sep + simulatorFilePrefix + "_hosts.csv", index=False
)
simInstancesDf.to_csv(
    simulatorFilePath + os.sep + simulatorFilePrefix + "_instances.csv", index=False
)
simPlacementsDf.to_csv(
    simulatorFilePath + os.sep + simulatorFilePrefix + "_placements.csv", index=False
)

lg("\nWrote simulator files to:")
lg("    " + simulatorFilePath + os.sep + simulatorFilePrefix + "_hosts.csv")
lg("    " + simulatorFilePath + os.sep + simulatorFilePrefix + "_instances.csv")
lg("    " + simulatorFilePath + os.sep + simulatorFilePrefix + "_placements.csv")

# ----------------------------------------------------------------------------------------------------------------------

if CREATE_OBFUSCATED_FILES:
    simHostsODf = simHostsDf.copy()
    simInstancesODf = simInstancesDf.copy()
    simPlacementsODf = simPlacementsDf.copy()

    # ---

    cdbDict = (
        simInstancesODf[["cdb", "cdb_num"]].set_index("cdb").drop_duplicates().to_dict()
    )
    cdbDict = cdbDict["cdb_num"]

    for k in cdbDict:
        cdbDict[k] = "cdb-" + str(cdbDict[k]).zfill(3)

    hostDict = simHostsODf[["h", "h_num"]].set_index("h").drop_duplicates().to_dict()
    hostDict = hostDict["h_num"]

    for k in hostDict:
        hostDict[k] = "h-" + str(hostDict[k]).zfill(3)

    instanceDict = (
        simInstancesODf[["inst", "inst_num"]]
        .set_index("inst")
        .drop_duplicates()
        .to_dict()
    )
    instanceDict = instanceDict["inst_num"]

    for k in instanceDict:
        instanceDict[k] = "inst-" + str(instanceDict[k]).zfill(3)

    # ---

    simInstancesODf.replace({"cdb": cdbDict}, inplace=True)
    simPlacementsODf.replace({"cdb": cdbDict}, inplace=True)

    simInstancesODf.replace({"inst": instanceDict}, inplace=True)
    simPlacementsODf.replace({"inst": instanceDict}, inplace=True)

    simHostsODf.replace({"h": hostDict}, inplace=True)
    simPlacementsODf.replace({"h": hostDict}, inplace=True)

    # ---

    ctr, cdbClusterDict = 1, {}
    for i in simPlacementsODf.cdb_cluster.unique():
        if i == "none":
            continue

        cdbClusterDict[i] = "cdb_cluster-" + str(ctr).zfill(3)
        ctr += 1

    simHostsODf.replace({"cdb_cluster": cdbClusterDict}, inplace=True)
    simInstancesODf.replace({"cdb_cluster": cdbClusterDict}, inplace=True)
    simPlacementsODf.replace({"cdb_cluster": cdbClusterDict}, inplace=True)

    # ---

    ctr, cdbOwnerDict = 1, {}
    for i in simPlacementsODf.cdb_owner.unique():
        if i == "none":
            continue

        cdbOwnerDict[i] = "cdb_owner-" + str(ctr).zfill(3)
        ctr += 1

    simInstancesODf.replace({"cdb_owner": cdbOwnerDict}, inplace=True)
    simPlacementsODf.replace({"cdb_owner": cdbOwnerDict}, inplace=True)

    # ---

    ctr, dbmachineDict = 1, {}
    for i in simPlacementsODf.dbmachine.unique():
        if i == "none":
            continue

        dbmachineDict[i] = "dbmachine-" + str(ctr).zfill(3)
        ctr += 1

    simHostsODf.replace({"dbmachine": dbmachineDict}, inplace=True)
    simInstancesODf.replace({"dbmachine": dbmachineDict}, inplace=True)
    simPlacementsODf.replace({"dbmachine": dbmachineDict}, inplace=True)

    # ---

    ctr, dbmachineOwnerDict = 1, {}
    for i in simPlacementsODf.dbmachine_owner.unique():
        if i == "none":
            continue

        dbmachineOwnerDict[i] = "dbmachine_owner-" + str(ctr).zfill(3)
        ctr += 1

    simHostsODf.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    simInstancesODf.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    simPlacementsODf.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)

    # ---

    simHostsODf.to_csv(
        simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_hosts.csv",
        index=False,
    )
    simInstancesODf.to_csv(
        simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_instances.csv",
        index=False,
    )
    simPlacementsODf.to_csv(
        simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_placements.csv",
        index=False,
    )

    lg("\nWrote obfuscated simulator files to:")
    lg(
        "    "
        + simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_hosts.csv"
    )
    lg(
        "    "
        + simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_instances.csv"
    )
    lg(
        "    "
        + simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_placements.csv"
    )

# ----------------------------------------------------------------------------------------------------------------------

if CREATE_SIMULATOR_FILES_ONLY:
    lg(
        "\n\nCREATE_SIMULATOR_FILES_ONLY = True; terminating after creation of simulator files\n\n"
    )

    Duplicate_Tests.emitDuplicateTestResults(duplicateTestResults)

    lg(
        "\n\nAll files written to directories rooted @ "
        + (cwd if ROOT_DIR == "." else ROOT_DIR)
    )
    lg(
        "\nProcessing "
        + str(len(structureDf))
        + " rows completed in "
        + str(round(time.time() - startTime, 3))
        + " s"
    )

    quit()

# ----------------------------------------------------------------------------------------------------------------------


overridenCdbsDf = cdbsDf[cdbsDf["cdb_ovr"].notnull()][
    ["cdb", "cdb_ovr"]
].drop_duplicates()

overridenCdbsDf = pd.merge(
    left=overridenCdbsDf,
    right=cdbsDf[["cdb_cohort", "cdb", "clustered", "cdb_target_guid"]],
    how="left",
    left_on="cdb",
    right_on="cdb",
)
overridenCdbsDf.rename(
    columns={
        "cdb": "cdb_new",
        "cdb_cohort": "cdb_cohort_new",
        "clustered": "cdb_type_new",
        "cdb_target_guid": "cdb_target_guid_new",
    },
    inplace=True,
)
overridenCdbsDf.loc[
    overridenCdbsDf["cdb_type_new"] == "NON-CLUSTERED", "cdb_type_new"
] = "oracle_database"
overridenCdbsDf.loc[overridenCdbsDf["cdb_type_new"] == "CLUSTERED", "cdb_type_new"] = (
    "rac_database"
)

overriddenInstancePropertiesDf = []

df = occa_Shared.getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "h_cpu_type_ovr", "cpu_type"
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

df = occa_Shared.getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "h_cores_per_chip_ovr", "cores_per_chip"
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

df = occa_Shared.getOverrideValues(
    dbPlacementsDf,
    "db_target_guid",
    "db",
    "h_physical_cpu_count_ovr",
    "physical_cpu_count",
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

df = occa_Shared.getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "h_total_cpu_cores_ovr", "total_cpu_cores"
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

filename = outputFilePath + os.sep + "overridden_Instance_Properties.csv"

if len(overriddenInstancePropertiesDf) > 0:
    overriddenInstancePropertiesDf = overriddenInstancePropertiesDf[
        ["db", "name", "value", "db_target_guid"]
    ]

    overriddenInstancePropertiesDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

else:
    lg("There are no overridden instance properties")

    if os.path.exists(filename):
        os.remove(filename)

# ---

overriddenInstanceMetricsDf = []

df = occa_Shared.getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_vcpu_ovr", CPU_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

df = occa_Shared.getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_iops_ovr", IOPS_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

df = occa_Shared.getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_sga_mb_ovr", SGA_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

df = occa_Shared.getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_pga_mb_ovr", PGA_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

filename = overrideFilePath + os.sep + "overridden_Instance_Metrics.csv"

if len(overriddenInstanceMetricsDf) > 0:
    overriddenInstanceMetricsDf.loc[
        overriddenInstanceMetricsDf["name"] == CPU_METRIC, "name"
    ] = CPU_DERIVED_METRIC

    overriddenInstanceMetricsDf["value"] = overriddenInstanceMetricsDf["value"].astype(
        float
    )
    overriddenInstanceMetricsDf = overriddenInstanceMetricsDf[
        ["db", "name", "value", "db_target_guid"]
    ]

    overriddenInstanceMetricsDf[["db", "name", "value", "db_target_guid"]].to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

else:
    lg("There are no overridden instance metrics")

    if os.path.exists(filename):
        os.remove(filename)

# ---

overriddenCDBMetricsDf = []

df = occa_Shared.getOverrideValues(
    cdbsDf, "cdb_target_guid", "cdb", "cdb_size_allocated_ovr", STORAGE_ALLOCATED_METRIC
)
overriddenCDBMetricsDf = (
    overriddenCDBMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenCDBMetricsDf) == 0
        else pd.concat([overriddenCDBMetricsDf, df])
    )
)

df = occa_Shared.getOverrideValues(
    cdbsDf, "cdb_target_guid", "cdb", "cdb_size_used_ovr", STORAGE_USED_METRIC
)
overriddenCDBMetricsDf = (
    overriddenCDBMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenCDBMetricsDf) == 0
        else pd.concat([overriddenCDBMetricsDf, df])
    )
)

filename = overrideFilePath + os.sep + "overridden_cdb_Metrics.csv"

if len(overriddenCDBMetricsDf) > 0:
    overriddenCDBMetricsDf["value"] = overriddenCDBMetricsDf["value"].astype(float)
    overriddenCDBMetricsDf = overriddenCDBMetricsDf[
        ["cdb", "name", "value", "cdb_target_guid"]
    ]

    overriddenCDBMetricsDf[["cdb", "name", "value", "cdb_target_guid"]].to_csv(
        filename, index=False
    )
    lg(
        "\n"
        + str(len(overriddenCDBMetricsDf["cdb"].unique()))
        + " cdbs have at least one override value have been written to file "
        + filename
    )

else:
    lg("There are no overridden cdb metrics")

    if os.path.exists(filename):
        os.remove(filename)

# ---

cdbsDf = dbPlacementsDf[
    ["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"]
].drop_duplicates()

cdbInstanceCountsDf = dbPlacementsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"], as_index=False
)["db_target_guid"].nunique()
cdbInstanceCountsDf.columns = [
    "cdb_cohort",
    "cdb",
    "cdb_type",
    "cdb_target_guid",
    "instance_count",
]

# ---

tb = time.time()

cdbHourlyMetricsDf, cdbCohortDailyMetricsDf, instanceHourlyMetricsDf = [], [], []
overrideCDBMetricsWithTSDf, overrideInstanceMetricsWithTSDf = [], []

filename = extractFilePath + os.sep + DB_METRICS_FILE

if not os.path.exists(filename):
    lg("Telemetry file " + filename + " does not exist; cannot continue")
    quit()

metricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])
metricsDf.columns = [c.strip() for c in metricsDf.columns]
metricsDf["metric"] = metricsDf["METRIC_NAME"] + "." + metricsDf["METRIC_COLUMN"]
metricsDf = metricsDf[
    metricsDf["metric"].isin(
        [
            CPU_METRIC,
            IOPS_METRIC,
            PGA_METRIC,
            SGA_METRIC,
            STORAGE_ALLOCATED_METRIC,
            STORAGE_USED_METRIC,
        ]
    )
]
hourlyDays = sorted(metricsDf["ROLLUP_TIMESTAMP_UTC"].dt.normalize().unique())

lg(
    "\nLoaded "
    + str(len(metricsDf))
    + " db metrics in "
    + str(round(time.time() - tb, 3))
    + " s"
)

# ---
#
# Round storage metric timestamps to nearest day & eliminate duplicates
#
tb = time.time()

storageHourlyMetricsDf = metricsDf[
    (metricsDf["TARGET_GUID"].isin(cdbsDf["cdb_target_guid"]))
    & (metricsDf["metric"].isin([STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]))
].copy()
storageHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC"] = storageHourlyMetricsDf[
    "ROLLUP_TIMESTAMP_UTC"
].dt.normalize()

# ---

lg(
    "Created "
    + str(len(storageHourlyMetricsDf))
    + " storage hourly metrics in "
    + str(round(time.time() - tb, 3))
    + " s"
)

if 1 == 0:
    filename = sizingFilePath + os.sep + "storage_Hourly_Metrics.csv"
    storageHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

cdbHourlyStorageMetricsDf = pd.merge(
    left=storageHourlyMetricsDf,
    right=cdbsDf[["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"]],
    how="inner",
    left_on=["TARGET_GUID"],
    right_on=["cdb_target_guid"],
)

cdbsMissingStorageHourlyMetricsDf = cdbsDf[
    ~cdbsDf["cdb_target_guid"].isin(storageHourlyMetricsDf["TARGET_GUID"])
].copy()
storageHourlyMetricsDf = []

filename = missingFilePath + os.sep + "cdbs_Missing_All_Storage_Hourly_Metrics.csv"

if len(cdbsMissingStorageHourlyMetricsDf) > 0:
    for _ in [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]:
        lg("(1) Adding metric " + _ + " to cdbsMissingStorageHourlyMetricsDf")
        cdbsMissingStorageHourlyMetricsDf[_] = -1

    cdbsMissingStorageHourlyMetricsDf = cdbsMissingStorageHourlyMetricsDf[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "cdb_target_guid",
            STORAGE_ALLOCATED_METRIC,
            STORAGE_USED_METRIC,
        ]
    ]
    cdbsMissingStorageHourlyMetricsDf[
        ["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"]
    ].to_csv(filename, index=False)

    lg(
        "\n"
        + str(len(cdbsMissingStorageHourlyMetricsDf))
        + " cdbs missing all hourly metrics have been written to file "
        + filename
    )

else:
    lg("There are no cdbs missing all hourly storage metrics")

    if os.path.exists(filename):
        os.remove(filenane)
#
# Populate a dataframe that captures missing CDB hourly storage telemetry
#
missingCDBHourlyStorageMetricsDf = pd.pivot_table(
    cdbHourlyStorageMetricsDf,
    index=["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"],
    columns=["metric"],
    values=["AVERAGE"],
    aggfunc="count",
    fill_value=0,
).reset_index()

cols = missingCDBHourlyStorageMetricsDf.columns.to_series().str.join("_")
cols = [c.strip("AVERAGE_") for c in cols]
cols = [c.rstrip("_") for c in cols]
missingCDBHourlyStorageMetricsDf.columns = cols

for _ in [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]:
    if _ not in missingCDBHourlyStorageMetricsDf:
        lg("(2) Adding " + _ + " to missingCDBHourlyStorageMetricsDf")
        missingCDBHourlyStorageMetricsDf[_] = 0

missingCDBHourlyStorageMetricsDf = missingCDBHourlyStorageMetricsDf[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "cdb_target_guid",
        STORAGE_ALLOCATED_METRIC,
        STORAGE_USED_METRIC,
    ]
]

if 1 == 0:
    filename = missingFilePath + os.sep + "missing_cdb_Hourly_Storage_Metrics.csv"
    missingCDBHourlyStorageMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

if (
    len(missingCDBHourlyStorageMetricsDf) > 0
    and len(cdbsMissingStorageHourlyMetricsDf) > 0
):
    missingCDBHourlyStorageMetricsDf = pd.concat(
        [missingCDBHourlyStorageMetricsDf, cdbsMissingStorageHourlyMetricsDf]
    )

elif (
    len(cdbsMissingStorageHourlyMetricsDf) == 0
    and len(cdbsMissingStorageHourlyMetricsDf) > 0
):
    missingCDBHourlyStorageMetricsDf = cdbsMissingStorageHourlyMetricsDf

cdbsMissingStorageHourlyMetricsDf = []

missingCDBHourlyStorageMetricsDf = pd.melt(
    missingCDBHourlyStorageMetricsDf,
    id_vars=["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"],
)

missingCDBHourlyStorageMetricsDf = missingCDBHourlyStorageMetricsDf[
    missingCDBHourlyStorageMetricsDf["value"] <= 0
]
missingCDBHourlyStorageMetricsDf.drop(columns=["value"], inplace=True)
missingCDBHourlyStorageMetricsDf.rename(columns={"variable": "metric"}, inplace=True)

# ---

filename = (
    missingFilePath
    + os.sep
    + "missing_cdb_Hourly_Storage_Metrics_0_Before_Overrides.csv"
)

if len(missingCDBHourlyStorageMetricsDf) > 0:
    missingCDBHourlyStorageMetricsDf[
        ["cdb_cohort", "cdb", "cdb_type", "metric", "cdb_target_guid"]
    ].to_csv(filename, index=False)
    lg(
        "\n"
        + str(len(missingCDBHourlyStorageMetricsDf["cdb"].unique()))
        + " cdbs missing at least one hourly metric have been written to file "
        + filename
    )

    missingCDBHourlyStorageMetricsDf["indicator"] = missingCDBHourlyStorageMetricsDf[
        "cdb_target_guid"
    ].str.cat(missingCDBHourlyStorageMetricsDf["metric"], sep="$$$")

    if len(overriddenCDBMetricsDf) > 0:
        overriddenCDBMetricsDf["indicator"] = overriddenCDBMetricsDf[
            "cdb_target_guid"
        ].str.cat(overriddenCDBMetricsDf["name"], sep="$$$")
        missingCDBHourlyStorageMetricsDf = missingCDBHourlyStorageMetricsDf[
            ~missingCDBHourlyStorageMetricsDf["indicator"].isin(
                overriddenCDBMetricsDf["indicator"]
            )
        ]

    filename = (
        missingFilePath
        + os.sep
        + "missing_cdb_Hourly_Storage_Metrics_1_After_Overrides.csv"
    )

    if len(missingCDBHourlyStorageMetricsDf) > 0:
        if 1 == 0:
            filename = missingFilePath + os.sep + "overridden_cdb_Metrics_02.csv"
            overriddenCDBMetricsDf.to_csv(filename, index=False)
            lg("\nWrote file " + filename)

        missingCDBHourlyStorageMetricsDf[
            ["cdb_cohort", "cdb", "cdb_type", "metric", "cdb_target_guid"]
        ].to_csv(filename, index=False)
        lg(
            "\n"
            + str(len(missingCDBHourlyStorageMetricsDf["cdb"].unique()))
            + " cdbs missing at least one hourly metric after applying override values have been written to file "
            + filename
        )

    else:
        lg(
            "There are no cdbs missing at least one hourly metric after applying override values"
        )

        if os.path.exists(filename):
            os.remove(filename)

else:
    lg("There are no cdbs missing at least one hourly metric")

    if os.path.exists(filename):
        os.remove(filename)

    filename = (
        missingFilePath
        + os.sep
        + "missing_cdb_Hourly_Storage_Metrics_1_After_Overrides.csv"
    )

    if os.path.exists(filename):
        os.remove(filename)

# ---
#
# Override CDB Hourly Storage Values
#
if len(overriddenCDBMetricsDf) > 0:
    tb = time.time()
    #
    #   Replace hourly metrics with override mertrics
    #
    indicators = overriddenCDBMetricsDf["indicator"].unique()
    timeStampsDf = cdbHourlyStorageMetricsDf[["ROLLUP_TIMESTAMP_UTC"]].drop_duplicates()

    if 1 == 0:
        lg("indicators")
        lg("----------")
        lg(str(indicators))

    cdbHourlyStorageMetricsDf["indicator"] = cdbHourlyStorageMetricsDf[
        "cdb_target_guid"
    ].str.cat(cdbHourlyStorageMetricsDf["metric"], sep="$$$")

    if 1 == 0:
        lg(
            "cdbHourlyStorageMetricsDf.columns: "
            + str(cdbHourlyStorageMetricsDf.columns)
        )
        lg("overriddenCDBMetricsDf.columns   : " + str(overriddenCDBMetricsDf.columns))

    df = pd.merge(
        left=overriddenCDBMetricsDf,
        right=cdbsDf[["cdb_cohort", "cdb_type", "cdb_target_guid"]],
        how="left",
        left_on=["cdb_target_guid"],
        right_on=["cdb_target_guid"],
    )

    df["TARGET_GUID"] = df["cdb_target_guid"]
    df["TARGET_NAME"] = df["cdb"]
    df["TARGET_TYPE"] = df["cdb_type"]
    df["METRIC_LABEL"] = "override"
    df["COLUMN_LABEL"] = "override"
    df["METRIC_NAME"] = "override"
    df["METRIC_COLUMN"] = "override"

    df["MINIMUM"] = df["value"]
    df["AVERAGE"] = df["value"]
    df["MAXIMUM"] = df["value"]
    df["STANDARD_DEVIATION"] = 0
    df["SAMPLE_COUNT"] = 1

    df.rename(columns={"name": "metric"}, inplace=True)
    df.drop(columns=["indicator", "value"], inplace=True)

    overrideStorageHourlyMetricsWithTSDf = df.merge(timeStampsDf, how="cross")
    overrideStorageHourlyMetricsWithTSDf = overrideStorageHourlyMetricsWithTSDf[
        [
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "MAXIMUM",
            "AVERAGE",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "metric",
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "cdb_target_guid",
        ]
    ]

    cdbHourlyStorageMetricsDf = cdbHourlyStorageMetricsDf[
        ~cdbHourlyStorageMetricsDf["indicator"].isin(indicators)
    ]
    cdbHourlyStorageMetricsDf.drop(columns=["indicator"], inplace=True)

    if 1 == 0:
        lg(
            "\nxxx len(cdbHourlyStorageMetricsDf).00           : "
            + str(len(cdbHourlyStorageMetricsDf))
        )
        lg(
            "\nxxx len(overrideStorageHourlyMetricsWithTSDf).00: "
            + str(len(overrideStorageHourlyMetricsWithTSDf))
        )

    if 1 == 0:
        filename = sizingFilePath + os.sep + "cdb_Hourly_Storage_Metrics.00.csv"
        cdbHourlyStorageMetricsDf.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

        filename = (
            sizingFilePath + os.sep + "override_Storage_Hourly_Metrics_With_TS.00.csv"
        )
        overrideStorageHourlyMetricsWithTSDf.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    cdbHourlyStorageMetricsDf = pd.concat(
        [cdbHourlyStorageMetricsDf, overrideStorageHourlyMetricsWithTSDf],
        ignore_index=True,
    )

    lg(
        "\nAdded "
        + str(len(df))
        + " override metrics to cdbHourlyStorageMetricsDf in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    df = []

# ---

if len(overridenCdbsDf) > 0:
    tb = time.time()

    lg("\nReplacing storage hourly metrics using cdb-level overrides")

    df = cdbHourlyStorageMetricsDf[
        cdbHourlyStorageMetricsDf["cdb"].isin(overridenCdbsDf["cdb_ovr"])
    ].copy()

    df = pd.merge(
        left=df, right=overridenCdbsDf, how="left", left_on="cdb", right_on="cdb_ovr"
    )

    df["TARGET_GUID"] = df["cdb_target_guid_new"]
    df["TARGET_NAME"] = df["cdb_new"]
    df["TARGET_TYPE"] = df["cdb_type_new"]

    df["cdb_cohort"] = df["cdb_cohort_new"]
    df["cdb"] = df["cdb_new"]
    df["cdb_type"] = df["cdb_type_new"]
    df["cdb_target_guid"] = df["cdb_target_guid_new"]

    df.drop(
        columns=[
            "cdb_target_guid_new",
            "cdb_new",
            "cdb_type_new",
            "cdb_cohort_new",
            "cdb_ovr",
        ],
        inplace=True,
    )

    missingCDBHourlyStorageMetricsDf = missingCDBHourlyStorageMetricsDf[
        ~missingCDBHourlyStorageMetricsDf["cdb_target_guid"].isin(df["cdb_target_guid"])
    ]

    # ---

    filename = (
        missingFilePath
        + os.sep
        + "missing_cdb_Hourly_Storage_Metrics_After_CDB_Overrides.csv"
    )

    if len(missingCDBHourlyStorageMetricsDf) > 0:
        missingCDBHourlyStorageMetricsDf[
            ["cdb_cohort", "cdb", "cdb_type", "metric", "cdb_target_guid"]
        ].to_csv(filename, index=False)
        lg(
            "\n"
            + str(len(missingCDBHourlyStorageMetricsDf["cdb"].unique()))
            + " cdbs missing at least one hourly metric after applying cdb override values have been written to file "
            + filename
        )

    else:
        lg(
            "There are no cdbs missing at least one hourly metric after applying cdb override values"
        )

        if os.path.exists(filename):
            os.remove(filename)

    # ---

    cdbHourlyStorageMetricsDf = pd.concat(
        [
            cdbHourlyStorageMetricsDf[
                ~cdbHourlyStorageMetricsDf["cdb"].isin(overridenCdbsDf["cdb_new"])
            ],
            df,
        ],
        ignore_index=True,
    )

    lg(
        "\nAdded "
        + str(len(df))
        + " rows to cdbHourlyStorageMetricsDf for "
        + str(len(overridenCdbsDf))
        + " cdbs in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    df = 0

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdb_Hourly_Storage_Metrics.01.csv"
    cdbHourlyStorageMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ----------------------------------------------------------------------------------------------------------------------
#
# Process instance-level metrics
#
metricsDf = metricsDf[
    ~metricsDf["metric"].isin([STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC])
]

tb = time.time()

sgapgaDf = (
    metricsDf[metricsDf["metric"].isin([PGA_METRIC, SGA_METRIC])]
    .groupby(
        [
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
            "ROLLUP_TIMESTAMP_UTC",
        ],
        as_index=False,
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]]
    .sum()
)
sgapgaDf["metric"] = SGAPGA_DERIVED_METRIC

sgapgaDf = sgapgaDf[
    [
        "TARGET_GUID",
        "TARGET_NAME",
        "TARGET_TYPE",
        "METRIC_LABEL",
        "COLUMN_LABEL",
        "METRIC_NAME",
        "METRIC_COLUMN",
        "ROLLUP_TIMESTAMP_UTC",
        "MINIMUM",
        "AVERAGE",
        "MAXIMUM",
        "STANDARD_DEVIATION",
        "SAMPLE_COUNT",
        "metric",
    ]
]

lg(
    "\nCreated "
    + str(len(sgapgaDf))
    + " sga+pga metrics in "
    + str(round(time.time() - tb, 3))
    + " s"
)

metricsDf = pd.concat([metricsDf, sgapgaDf], ignore_index=True)
sgapgaDf = []

# ---

tb = time.time()

instanceHourlyMetricsDf = pd.merge(
    left=metricsDf,
    right=dbPlacementsDf[
        [
            "cdb_cohort",
            "cdb",
            "cpu_type",
            "total_cpu_cores",
            "db",
            "db_cpu_count_limit",
            "cdb_target_guid",
            "db_target_guid",
        ]
    ],
    how="left",
    left_on=["TARGET_GUID"],
    right_on=["db_target_guid"],
)

lg(
    "Created "
    + str(len(instanceHourlyMetricsDf))
    + " instance metrics in "
    + str(round(time.time() - tb, 3))
    + " s"
)

# ---

tb = time.time()

instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "MINIMUM"
] = (instanceHourlyMetricsDf["MINIMUM"] / 100)
instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "AVERAGE"
] = (instanceHourlyMetricsDf["AVERAGE"] / 100)
instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "MAXIMUM"
] = (instanceHourlyMetricsDf["MAXIMUM"] / 100)

instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (instanceHourlyMetricsDf["cpu_type"] == "IBM"),
    "MINIMUM",
] = (
    instanceHourlyMetricsDf["MINIMUM"] * instanceHourlyMetricsDf["total_cpu_cores"]
)
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (instanceHourlyMetricsDf["cpu_type"] == "IBM"),
    "AVERAGE",
] = (
    instanceHourlyMetricsDf["AVERAGE"] * instanceHourlyMetricsDf["total_cpu_cores"]
)
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (instanceHourlyMetricsDf["cpu_type"] == "IBM"),
    "MAXIMUM",
] = (
    instanceHourlyMetricsDf["MAXIMUM"] * instanceHourlyMetricsDf["total_cpu_cores"]
)

instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (
        instanceHourlyMetricsDf["MINIMUM"]
        > instanceHourlyMetricsDf["db_cpu_count_limit"]
    ),
    "MINIMUM",
] = instanceHourlyMetricsDf["db_cpu_count_limit"]
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (
        instanceHourlyMetricsDf["AVERAGE"]
        > instanceHourlyMetricsDf["db_cpu_count_limit"]
    ),
    "AVERAGE",
] = instanceHourlyMetricsDf["db_cpu_count_limit"]
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (
        instanceHourlyMetricsDf["MAXIMUM"]
        > instanceHourlyMetricsDf["db_cpu_count_limit"]
    ),
    "MAXIMUM",
] = instanceHourlyMetricsDf["db_cpu_count_limit"]

instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "metric"
] = CPU_DERIVED_METRIC

# ---

instancesMissingHourlyMetricsDf = dbPlacementsDf[
    ~dbPlacementsDf["db_target_guid"].isin(instanceHourlyMetricsDf["TARGET_GUID"])
][["cdb_cohort", "cdb", "db", "cdb_target_guid", "db_target_guid"]]

filename = missingFilePath + os.sep + "instances_Missing_All_Hourly_Metrics.csv"

if len(instancesMissingHourlyMetricsDf) > 0:
    for _ in [
        CPU_DERIVED_METRIC,
        IOPS_METRIC,
        PGA_METRIC,
        SGA_METRIC,
        SGAPGA_DERIVED_METRIC,
    ]:
        lg("(1) Adding metric " + _ + " to instancesMissingHourlyMetricsDf")
        instancesMissingHourlyMetricsDf[_] = -1

    instancesMissingHourlyMetricsDf = instancesMissingHourlyMetricsDf[
        [
            "cdb_cohort",
            "cdb",
            "db",
            "cdb_target_guid",
            "db_target_guid",
            CPU_DERIVED_METRIC,
            IOPS_METRIC,
            PGA_METRIC,
            SGA_METRIC,
            SGAPGA_DERIVED_METRIC,
        ]
    ]
    instancesMissingHourlyMetricsDf[
        ["cdb_cohort", "cdb", "db", "cdb_target_guid", "db_target_guid"]
    ].to_csv(filename, index=False)

    lg(
        "\n"
        + str(len(instancesMissingHourlyMetricsDf))
        + " instances missing all hourly metrics have been written to file "
        + filename
    )

else:
    lg("There are no instances missing all hourly metrics")

    if os.path.exists(filename):
        os.remove(filename)
#
#   Populate a dataframe that captures missing Instance hourly telemetry
#
missingInstanceHourlyMetricsDf = pd.pivot_table(
    instanceHourlyMetricsDf,
    index=["cdb_cohort", "cdb", "db", "cdb_target_guid", "db_target_guid"],
    columns=["metric"],
    values=["AVERAGE"],
    aggfunc="count",
    fill_value=0,
).reset_index()

cols = missingInstanceHourlyMetricsDf.columns.to_series().str.join("_")
cols = [c.strip("AVERAGE_") for c in cols]
cols = [c.rstrip("_") for c in cols]
missingInstanceHourlyMetricsDf.columns = cols

for _ in [
    CPU_DERIVED_METRIC,
    IOPS_METRIC,
    PGA_METRIC,
    SGA_METRIC,
    SGAPGA_DERIVED_METRIC,
]:
    if _ not in missingInstanceHourlyMetricsDf:
        lg("(2) Adding " + _ + " to missingInstanceHourlyMetricsDf")
        missingInstanceHourlyMetricsDf[_] = 0

missingInstanceHourlyMetricsDf = missingInstanceHourlyMetricsDf[
    [
        "cdb_cohort",
        "cdb",
        "db",
        "cdb_target_guid",
        "db_target_guid",
        CPU_DERIVED_METRIC,
        IOPS_METRIC,
        PGA_METRIC,
        SGA_METRIC,
        SGAPGA_DERIVED_METRIC,
    ]
]

if 1 == 0:
    filename = missingFilePath + os.sep + "missing_Instance_Hourly_Metrics_00a.csv"
    missingInstanceHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

if len(missingInstanceHourlyMetricsDf) > 0 and len(instancesMissingHourlyMetricsDf) > 0:
    missingInstanceHourlyMetricsDf = pd.concat(
        [missingInstanceHourlyMetricsDf, instancesMissingHourlyMetricsDf]
    )

elif (
    len(missingInstanceHourlyMetricsDf) == 0
    and len(instancesMissingHourlyMetricsDf) > 0
):
    missingInstanceHourlyMetricsDf = instancesMissingHourlyMetricsDf

instancesMissingHourlyMetricsDf = []

if 1 == 0:
    filename = missingFilePath + os.sep + "missing_Instance_Hourly_Metrics_00b.csv"
    missingInstanceHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

missingInstanceHourlyMetricsDf = pd.melt(
    missingInstanceHourlyMetricsDf,
    id_vars=["cdb_cohort", "cdb", "db", "cdb_target_guid", "db_target_guid"],
)
missingInstanceHourlyMetricsDf = missingInstanceHourlyMetricsDf[
    missingInstanceHourlyMetricsDf["value"] <= 0
]
missingInstanceHourlyMetricsDf.drop(columns=["value"], inplace=True)
missingInstanceHourlyMetricsDf.rename(columns={"variable": "metric"}, inplace=True)

if 1 == 0:
    filename = missingFilePath + os.sep + "missing_Instance_Hourly_Metrics_00c.csv"
    missingInstanceHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

filename = (
    missingFilePath + os.sep + "missing_Instance_Hourly_Metrics_0_Before_Overrides.csv"
)

if len(missingInstanceHourlyMetricsDf) > 0:
    missingInstanceHourlyMetricsDf[
        ["cdb_cohort", "cdb", "db", "metric", "cdb_target_guid", "db_target_guid"]
    ].to_csv(filename, index=False)
    lg(
        "\n"
        + str(len(missingInstanceHourlyMetricsDf["db"].unique()))
        + " instances missing at least one hourly metric have been written to file "
        + filename
    )

    missingInstanceHourlyMetricsDf["indicator"] = missingInstanceHourlyMetricsDf[
        "db_target_guid"
    ].str.cat(missingInstanceHourlyMetricsDf["metric"], sep="$$$")

    if len(overriddenInstanceMetricsDf) > 0:
        overriddenInstanceMetricsDf["indicator"] = overriddenInstanceMetricsDf[
            "db_target_guid"
        ].str.cat(overriddenInstanceMetricsDf["name"], sep="$$$")
        missingInstanceHourlyMetricsDf = missingInstanceHourlyMetricsDf[
            ~missingInstanceHourlyMetricsDf["indicator"].isin(
                overriddenInstanceMetricsDf["indicator"]
            )
        ]

    filename = (
        missingFilePath
        + os.sep
        + "missing_Instance_Hourly_Metrics_1_After_Overrides.csv"
    )

    if len(missingInstanceHourlyMetricsDf) > 0:
        missingInstanceHourlyMetricsDf[
            ["cdb_cohort", "cdb", "db", "metric", "cdb_target_guid", "db_target_guid"]
        ].to_csv(filename, index=False)
        lg(
            "\n"
            + str(len(missingInstanceHourlyMetricsDf["db"].unique()))
            + " instances missing at least one hourly metric after applying override values have been written to file "
            + filename
        )

        if 1 == 0:
            filename = missingFilePath + os.sep + "overridden_Instance_Metrics_02.csv"
            overriddenInstanceMetricsDf.to_csv(filename, index=False)
            lg("\nWrote file " + filename)

    else:
        lg(
            "There are no instances missing at least one hourly metric after applying override values"
        )

        if os.path.exists(filename):
            os.remove(filename)

else:
    lg("There are no instances missing at least one hourly metric")

    if os.path.exists(filename):
        os.remove(filename)

    filename = (
        missingFilePath
        + os.sep
        + "missing_Instance_Hourly_Metrics_1_After_Overrides.csv"
    )

    if os.path.exists(filename):
        os.remove(filename)

# ---

if len(overriddenInstanceMetricsDf) > 0:
    #
    #   Replace hourly metrics with override mertrics
    #
    indicators = overriddenInstanceMetricsDf["indicator"].unique()
    timeStampsDf = instanceHourlyMetricsDf[["ROLLUP_TIMESTAMP_UTC"]].drop_duplicates()

    if 1 == 0:
        lg("indicators")
        lg("----------")
        lg(str(indicators))

    instanceHourlyMetricsDf["indicator"] = instanceHourlyMetricsDf[
        "db_target_guid"
    ].str.cat(instanceHourlyMetricsDf["metric"], sep="$$$")

    df = pd.merge(
        left=overriddenInstanceMetricsDf,
        right=dbPlacementsDf[
            [
                "cdb_cohort",
                "cdb",
                "cpu_type",
                "total_cpu_cores",
                "db_cpu_count_limit",
                "cdb_target_guid",
                "db_target_guid",
            ]
        ],
        how="left",
        left_on=["db_target_guid"],
        right_on=["db_target_guid"],
    )

    df["TARGET_GUID"] = df["db_target_guid"]
    df["TARGET_NAME"] = df["db"]
    df["TARGET_TYPE"] = "oracle_database"
    df["METRIC_LABEL"] = ""
    df["COLUMN_LABEL"] = ""
    df["METRIC_NAME"] = ""
    df["METRIC_COLUMN"] = ""
    df["MINIMUM"] = df["value"]
    df["AVERAGE"] = df["value"]
    df["MAXIMUM"] = df["value"]
    df["STANDARD_DEVIATION"] = 0
    df["SAMPLE_COUNT"] = 1

    df.rename(columns={"name": "metric"}, inplace=True)
    df.drop(columns=["indicator", "value"], inplace=True)

    overrideInstanceMetricsWithTSDf = df.merge(timeStampsDf, how="cross")
    overrideInstanceMetricsWithTSDf = overrideInstanceMetricsWithTSDf[
        [
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "MAXIMUM",
            "AVERAGE",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "metric",
            "cdb_cohort",
            "cdb",
            "cpu_type",
            "total_cpu_cores",
            "db",
            "db_cpu_count_limit",
            "cdb_target_guid",
            "db_target_guid",
        ]
    ]

    if 1 == 0:
        lg(
            "xxx overrideInstanceMetricsWithTSDf.columns.1: "
            + str(overrideInstanceMetricsWithTSDf.columns)
        )
        lg("xxx instanceHourlyMetricsDf before: " + str(len(instanceHourlyMetricsDf)))

    instanceHourlyMetricsDf = instanceHourlyMetricsDf[
        ~instanceHourlyMetricsDf["indicator"].isin(indicators)
    ]
    instanceHourlyMetricsDf.drop(columns=["indicator"], inplace=True)

    if 1 == 0:
        lg(
            "\nxxx len(instanceHourlyMetricsDf).00        : "
            + str(len(instanceHourlyMetricsDf))
        )
        lg(
            "xxx instanceHourlyMetricsDf.columns          : "
            + str(instanceHourlyMetricsDf.columns)
        )
        lg(
            "xxx overrideInstanceMetricsWithTSDf.columns.1: "
            + str(overrideInstanceMetricsWithTSDf.columns)
        )

    instanceHourlyMetricsDf = pd.concat(
        [instanceHourlyMetricsDf, overrideInstanceMetricsWithTSDf], ignore_index=True
    )
    lg(
        "\nAdded "
        + str(len(overrideInstanceMetricsWithTSDf))
        + " override metrics to instanceHourlyMetricsDf"
    )

    df, overrideInstanceMetricsWithTSDf = [], []
    #
    #   Add derived sga+pga metric
    #
    if (
        PGA_METRIC in overriddenInstanceMetricsDf["name"].unique()
        or SGA_METRIC in overriddenInstanceMetricsDf["name"].unique()
    ):
        tb = time.time()

        sgapgaDf = (
            instanceHourlyMetricsDf[
                (
                    instanceHourlyMetricsDf["db_target_guid"].isin(
                        overriddenInstanceMetricsDf["db_target_guid"].unique()
                    )
                )
                & (instanceHourlyMetricsDf["metric"].isin([PGA_METRIC, SGA_METRIC]))
            ]
            .groupby(
                [
                    "TARGET_GUID",
                    "TARGET_NAME",
                    "TARGET_TYPE",
                    "METRIC_LABEL",
                    "COLUMN_LABEL",
                    "METRIC_NAME",
                    "METRIC_COLUMN",
                    "ROLLUP_TIMESTAMP_UTC",
                    "metric",
                    "cdb_cohort",
                    "cdb",
                    "cpu_type",
                    "total_cpu_cores",
                    "db",
                    "db_cpu_count_limit",
                    "cdb_target_guid",
                    "db_target_guid",
                ],
                as_index=False,
            )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]]
            .sum()
        )
        sgapgaDf["metric"] = SGAPGA_DERIVED_METRIC

        sgapgaDf = sgapgaDf[
            [
                "TARGET_GUID",
                "TARGET_NAME",
                "TARGET_TYPE",
                "METRIC_LABEL",
                "COLUMN_LABEL",
                "METRIC_NAME",
                "METRIC_COLUMN",
                "ROLLUP_TIMESTAMP_UTC",
                "MINIMUM",
                "MAXIMUM",
                "AVERAGE",
                "STANDARD_DEVIATION",
                "SAMPLE_COUNT",
                "metric",
                "cdb_cohort",
                "cdb",
                "cpu_type",
                "total_cpu_cores",
                "db",
                "db_cpu_count_limit",
                "cdb_target_guid",
                "db_target_guid",
            ]
        ]

        instanceHourlyMetricsDf = pd.concat(
            [
                instanceHourlyMetricsDf[
                    (
                        ~instanceHourlyMetricsDf["db_target_guid"].isin(
                            overriddenInstanceMetricsDf["db_target_guid"].unique()
                        )
                    )
                    | (instanceHourlyMetricsDf["metric"] != SGAPGA_DERIVED_METRIC)
                ],
                sgapgaDf,
            ],
            ignore_index=True,
        )

        if 1 == 0:
            lg(
                "\nxxx len(instanceHourlyMetricsDf).03: "
                + str(len(instanceHourlyMetricsDf))
            )

        lg(
            "\nAdded "
            + str(len(sgapgaDf))
            + " updated sga+pga metrics to instanceHourlyMetricsDf in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        sgapgaDf = []

# ---

if len(overridenCdbsDf) > 0:
    filename = (
        missingFilePath
        + os.sep
        + "missing_Instance_Hourly_Metrics_After_CDB_Overrides.csv"
    )

    missingInstanceHourlyMetricsDf = missingInstanceHourlyMetricsDf[
        ~missingInstanceHourlyMetricsDf["cdb_target_guid"].isin(
            overridenCdbsDf["cdb_target_guid_new"]
        )
    ]

    if len(missingInstanceHourlyMetricsDf) > 0:
        missingInstanceHourlyMetricsDf[
            ["cdb_cohort", "cdb", "db", "metric", "cdb_target_guid", "db_target_guid"]
        ].to_csv(filename, index=False)
        lg(
            "\n"
            + str(len(missingInstanceHourlyMetricsDf["db"].unique()))
            + " instances missing at least one hourly metric after applying cdb override values have been written to file "
            + filename
        )

    else:
        lg(
            "There are no instances missing at least one hourly metric after applying cdb override values"
        )

        if os.path.exists(filename):
            os.remove(filename)

# ----------------------------------------------------------------------------------------------------------------------

# Produce dataframe that capture structure & inclusion status
#
databasesDf = structureDf[
    [
        "cdb_cohort",
        "cdb",
        "cdb_size_allocated_ovr",
        "cdb_size_used_ovr",
        "cdb_ovr",
        "cdb_instance_count",
        "dbms_vendor",
        "cdb_version",
        "cdb_version_sizing",
        "clustered",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_type_version",
        "cdb_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()

databasesDf["excluded"] = ""
databasesDf["excluded_reason"] = ""

databasesDf.loc[databasesDf["cdb_cohort"] == "excluded", "excluded"] = "excluded"
databasesDf.loc[databasesDf["cdb_cohort"] == "excluded", "excluded_reason"] = (
    '( Cohort = "excluded" )'
)

databasesDf.loc[databasesDf["cdb_cohort"] == "", "excluded"] = "excluded"
databasesDf.loc[databasesDf["cdb_cohort"] == "", "excluded_reason"] = (
    "( Missing cohort )"
)
databasesDf.loc[databasesDf["cdb_cohort"] == "", "cdb_cohort"] = "excluded"

databasesDf.loc[
    databasesDf["cdb_target_guid"].isin(
        missingCDBHourlyStorageMetricsDf["cdb_target_guid"]
    ),
    "excluded",
] = "excluded"
databasesDf.loc[
    databasesDf["cdb_target_guid"].isin(
        missingCDBHourlyStorageMetricsDf["cdb_target_guid"]
    ),
    "excluded_reason",
] += "( Database is missing a required field(s) )"

databasesDf["cdb_size_allocated_gb_telemetry"] = ""
databasesDf["cdb_size_used_gb_telemetry"] = ""
databasesDf["Server List"] = ""

databasesDf["STOP"] = "STOP"
databasesDf = databasesDf[
    [
        "excluded",
        "excluded_reason",
        "cdb_cohort",
        "cdb",
        "cdb_size_allocated_ovr",
        "cdb_size_used_ovr",
        "cdb_ovr",
        "STOP",
        "cdb_size_allocated_gb_telemetry",
        "cdb_size_used_gb_telemetry",
        "cdb_instance_count",
        "clustered",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "Server List",
        "cdb_version",
        "cdb_status",
        "cdb_last_load_time_utc",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_target_guid",
        "cdb_type_version",
        "cdb_version_sizing",
        "dbms_vendor",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].copy()
databasesDf.rename(
    columns={
        "cdb_size_used_ovr": "Total Database Size (GB)",
        "cdb_size_allocated_ovr": "Allocated Database Size (GB)",
        "cdb_ovr": "Use Values from Database Name",
    },
    inplace=True,
)

# ---

instancesDf = structureDf[
    [
        "cdb_cohort",
        "cdb",
        "db",
        "cdb_ovr",
        "host",
        "sga_size_gb",
        "pga_size_gb",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "db_status",
        "db_last_load_time_utc",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "db_vcpu_ovr",
        "db_sga_mb_ovr",
        "db_pga_mb_ovr",
        "db_iops_ovr",
        "host_subscr_pct",
        "host_status",
        "host_last_load_time_utc",
        "physical_cpu_count",
        "cores_per_chip",
        "logical_cpu_count",
        "total_cpu_cores",
        "mem_gb",
        "nr_huge_pages",
        "host_db_cpu_count_limit",
        "vendor_name",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "dist_version",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "cdb_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "init_cpu_count",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()

excludedCdbs = instancesDf[
    instancesDf["db_target_guid"].isin(missingInstanceHourlyMetricsDf["db_target_guid"])
]["cdb_target_guid"].unique()

databasesDf.loc[databasesDf["cdb_target_guid"].isin(excludedCdbs), "excluded"] = (
    "excluded"
)
databasesDf.loc[
    databasesDf["cdb_target_guid"].isin(excludedCdbs), "excluded_reason"
] += "( At least one instance is missing a required field(s) )"

instancesDf["excluded"] = ""
instancesDf["excluded_reason"] = ""

instancesDf.loc[
    instancesDf["cdb_target_guid"].isin(
        databasesDf[databasesDf["excluded"] == "excluded"]["cdb_target_guid"]
    ),
    "excluded",
] = "excluded"
instancesDf.loc[instancesDf["excluded"] == "excluded", "excluded_reason"] = (
    "( Parent database is excluded )"
)

instancesDf.loc[
    instancesDf["db_target_guid"].isin(
        missingInstanceHourlyMetricsDf["db_target_guid"]
    ),
    "excluded",
] = "excluded"
instancesDf.loc[
    instancesDf["db_target_guid"].isin(
        missingInstanceHourlyMetricsDf["db_target_guid"]
    ),
    "excluded_reason",
] += "( Instance is missing a required field(s) )"

instancesDf["db_vcpu_telemetry"] = ""
instancesDf["db_sga_mb_telemetry"] = ""
instancesDf["db_pga_mb_telemetry"] = ""
instancesDf["db_iops_telemetry"] = ""
instancesDf["STOP"] = "STOP"

instancesDf = instancesDf[
    [
        "excluded",
        "excluded_reason",
        "cdb_cohort",
        "cdb",
        "db",
        "cdb_ovr",
        "db_vcpu_ovr",
        "db_sga_mb_ovr",
        "db_pga_mb_ovr",
        "db_iops_ovr",
        "STOP",
        "db_vcpu_telemetry",
        "db_sga_mb_telemetry",
        "db_pga_mb_telemetry",
        "db_iops_telemetry",
        "cluster",
        "host",
        "dbmachine",
        "dbmachine_owner",
        "db_status",
        "db_last_load_time_utc",
        "sga_size_gb",
        "pga_size_gb",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "host_subscr_pct",
        "host_status",
        "host_last_load_time_utc",
        "physical_cpu_count",
        "cores_per_chip",
        "logical_cpu_count",
        "total_cpu_cores",
        "mem_gb",
        "nr_huge_pages",
        "host_db_cpu_count_limit",
        "vendor_name",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "dist_version",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "cdb_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "init_cpu_count",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()
instancesDf.rename(
    columns={
        "cdb_ovr": "Use Values from Database Name",
        "db_vcpu_ovr": "vCPU",
        "db_sga_mb_ovr": "SGA (MB)",
        "db_pga_mb_ovr": "PGA (MB)",
        "db_iops_ovr": "IOPS",
    },
    inplace=True,
)
# ---

rc = {}


def addOrChangeName(df, old, new):
    if old in df:
        rc[old] = new
    else:
        df[new] = ""


df = pd.pivot_table(
    cdbHourlyStorageMetricsDf,
    index="cdb_target_guid",
    columns="metric",
    values="AVERAGE",
    aggfunc="sum",
).reset_index()
addOrChangeName(df, STORAGE_USED_METRIC, "cdb_size_allocated_gb_t")
addOrChangeName(df, STORAGE_ALLOCATED_METRIC, "cdb_size_used_gb_t")

if len(rc) > 0:
    df.rename(columns=rc, inplace=True)

databasesDf = pd.merge(
    left=databasesDf,
    right=df,
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
databasesDf["cdb_size_allocated_gb_telemetry"] = databasesDf["cdb_size_allocated_gb_t"]
databasesDf["cdb_size_used_gb_telemetry"] = databasesDf["cdb_size_used_gb_t"]

databasesDf.drop(
    columns=["cdb_size_allocated_gb_t", "cdb_size_used_gb_t"], inplace=True
)
#
# Get list of servers hosting a database
#
df = instancesDf[["cdb_target_guid", "host"]].drop_duplicates()
df = df.groupby("cdb_target_guid", as_index=False).agg(lambda x: ",".join(set(x)))
df.columns = ["cdb_target_guid", "server_list"]
databasesDf = pd.merge(
    left=databasesDf,
    right=df,
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
databasesDf["Server List"] = databasesDf["server_list"]
databasesDf.drop(columns="server_list", inplace=True)

# ---

rc = {}
df = pd.pivot_table(
    instanceHourlyMetricsDf,
    index="cdb_target_guid",
    columns="metric",
    values="AVERAGE",
    aggfunc="sum",
).reset_index()

addOrChangeName(df, CPU_DERIVED_METRIC, "vcpu_t")
addOrChangeName(df, IOPS_METRIC, "iops_t")
addOrChangeName(df, PGA_METRIC, "pga_mb_t")
addOrChangeName(df, SGA_METRIC, "sga_mb_t")

if len(rc) > 0:
    df.rename(columns=rc, inplace=True)

instancesDf = pd.merge(
    left=instancesDf,
    right=df,
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
instancesDf["db_vcpu_telemetry"] = instancesDf["vcpu_t"]
instancesDf["db_sga_mb_telemetry"] = instancesDf["sga_mb_t"]
instancesDf["db_pga_mb_telemetry"] = instancesDf["pga_mb_t"]
instancesDf["db_iops_telemetry"] = instancesDf["iops_t"]

instancesDf.drop(columns=["vcpu_t", "sga_mb_t", "pga_mb_t", "iops_t"], inplace=True)
if SGAPGA_DERIVED_METRIC in df:
    instancesDf.drop(columns=SGAPGA_DERIVED_METRIC, inplace=True)

# ---

hostsDf["STOP"] = "STOP"

hostsDf = hostsDf[
    [
        "host",
        "h_cpu_type_ovr",
        "h_physical_cpu_count_ovr",
        "h_cores_per_chip_ovr",
        "h_description_ovr",
        "STOP",
        "cpu_type",
        "physical_cpu_count",
        "cores_per_chip",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "host_type_version",
        "host_status",
        "host_last_load_time_utc",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "total_cpu_cores",
        "logical_cpu_count",
        "mem_gb",
        "nr_huge_pages",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "ma",
        "system_config",
        "vendor_name",
        "dist_version",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
]

hostsDf.rename(
    columns={
        "h_cpu_type_ovr": "CPU Type",
        "h_physical_cpu_count_ovr": "Chip Count (Actual)",
        "h_cores_per_chip_ovr": "Cores Per Chip (Actual)",
        "h_description_ovr": "Description",
    },
    inplace=True,
)

# ---

filename = sizingFilePath + os.sep + "databases.csv"
databasesDf.sort_values(["cdb"]).to_csv(filename, index=False)
lg("\nWrote file " + filename)

filename = sizingFilePath + os.sep + "instances.csv"
instancesDf.sort_values(["cdb", "db"]).to_csv(filename, index=False)
lg("\nWrote file " + filename)

filename = sizingFilePath + os.sep + "hosts.csv"
hostsDf.sort_values(["host"]).to_csv(filename, index=False)
lg("\nWrote file " + filename)
# 444
# a=1/0

# ---

excludedCdbs = databasesDf[databasesDf["excluded"] == "excluded"][
    "cdb_target_guid"
].unique()

cdbHourlyStorageMetricsDf.loc[
    cdbHourlyStorageMetricsDf["cdb_target_guid"].isin(excludedCdbs), "cdb_cohort"
] = "excluded"

if len(COHORTS) > 0:
    cdbHourlyStorageMetricsDf = cdbHourlyStorageMetricsDf[
        cdbHourlyStorageMetricsDf["cdb_cohort"].isin(COHORTS)
    ]

cdbCohortHourlyStorageMetricsDf = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

excludedDbs = instancesDf[instancesDf["excluded"] == "excluded"][
    "db_target_guid"
].unique()
instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["db_target_guid"].isin(excludedDbs), "cdb_cohort"
] = "excluded"

if len(COHORTS) > 0:
    instanceHourlyMetricsDf = instanceHourlyMetricsDf[
        instanceHourlyMetricsDf["cdb_cohort"].isin(COHORTS)
    ]

cdbHourlyMetricsDf = instanceHourlyMetricsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
    as_index=False,
)[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

# ---

if len(overridenCdbsDf) > 0:
    tb = time.time()

    lg("\nReplacing instance hourly metrics using cdb-level overrides")

    df = cdbHourlyMetricsDf[
        cdbHourlyMetricsDf["cdb"].isin(overridenCdbsDf["cdb_ovr"])
    ].copy()

    df = pd.merge(
        left=df, right=overridenCdbsDf, how="left", left_on="cdb", right_on="cdb_ovr"
    )

    df["cdb_cohort"] = df["cdb_cohort_new"]
    df["cdb"] = df["cdb_new"]
    df["cdb_target_guid"] = df["cdb_target_guid_new"]

    df.drop(
        columns=["cdb_target_guid_new", "cdb_new", "cdb_cohort_new", "cdb_ovr"],
        inplace=True,
    )

    # ---

    cdbHourlyMetricsDf = pd.concat(
        [
            cdbHourlyMetricsDf[
                ~cdbHourlyMetricsDf["cdb"].isin(overridenCdbsDf["cdb_new"])
            ],
            df,
        ],
        ignore_index=True,
    )

    lg(
        "\nAdded "
        + str(len(df))
        + " rows to cdbHourlyMetricsDf for "
        + str(len(overridenCdbsDf))
        + " cdbs in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    df = []

# ---

cdbCohortHourlyMetricsDf = cdbHourlyMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

# ---

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdb_Hourly_Metrics.csv"
    cdbHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdb_Cohort_Hourly_Metrics.csv"
    cdbCohortHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

if PLOT_HTML or PLOT_PNG:
    plotMetrics(cdbHourlyMetricsDf)
    plotMetrics(cdbHourlyStorageMetricsDf)

# ----------------------------------------------------------------------------------------------------------------------

cdbDailyMetricsDf, cdbCohortDailyMetricsDf, instanceDailyMetricsDf = [], [], []

tb0 = time.time()

lg("\nLoading db daily metrics...")

for time_period in TIME_PERIODS:
    lg("\n     Loading db daily metrics for time period: " + time_period + "...")
    filename = (
        extractFilePath
        + os.sep
        + "emcc_sizing_metrics_db_daily_"
        + time_period
        + "_months.csv"
    )

    if not os.path.exists(filename):
        lg("     Telemetry file " + filename + " is missing")
        continue

    tb = time.time()

    metricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])
    metricsDf.columns = [c.strip() for c in metricsDf.columns]
    metricsDf["metric"] = metricsDf["METRIC_NAME"] + "." + metricsDf["METRIC_COLUMN"]
    #
    #   Note: we ignore daily storage metrics
    #
    metricsDf = metricsDf[
        metricsDf["metric"].isin([CPU_METRIC, IOPS_METRIC, PGA_METRIC, SGA_METRIC])
    ]
    metricsDf["ROLLUP_TIMESTAMP_UTC"] = metricsDf["ROLLUP_TIMESTAMP_UTC"].dt.normalize()

    lg(
        "     Loaded "
        + str(len(metricsDf))
        + " "
        + filename
        + " in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    if len(metricsDf) == 0:
        lg("     Telemetry file " + filename + " is empty")
        continue

    # ---

    tb = time.time()

    sgapgaDf = (
        metricsDf[metricsDf["metric"].isin([PGA_METRIC, SGA_METRIC])]
        .groupby(
            [
                "TARGET_GUID",
                "TARGET_NAME",
                "TARGET_TYPE",
                "METRIC_LABEL",
                "COLUMN_LABEL",
                "METRIC_NAME",
                "METRIC_COLUMN",
                "ROLLUP_TIMESTAMP_UTC",
            ],
            as_index=False,
        )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]]
        .sum()
    )
    sgapgaDf["metric"] = SGAPGA_DERIVED_METRIC

    sgapgaDf = sgapgaDf[
        [
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "AVERAGE",
            "MAXIMUM",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "metric",
        ]
    ]

    lg(
        "     Created "
        + str(len(sgapgaDf))
        + " sga+pga metrics in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    metricsDf = pd.concat([metricsDf, sgapgaDf], ignore_index=True)
    sgapgaDf = []

    # --

    tb = time.time()

    df0 = pd.merge(
        left=metricsDf[metricsDf["TARGET_TYPE"] == "oracle_database"],
        right=dbPlacementsDf[
            [
                "cdb_cohort",
                "cdb",
                "cdb_target_guid",
                "db_target_guid",
                "cpu_type",
                "total_cpu_cores",
                "init_cpu_count",
            ]
        ],
        how="left",
        left_on=["TARGET_GUID"],
        right_on=["db_target_guid"],
    )
    lg(
        "     Created "
        + str(len(df0))
        + " instance daily metrics in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    # ---

    tb = time.time()

    df0.loc[df0["metric"] == CPU_METRIC, "MINIMUM"] = df0["MINIMUM"] / 100
    df0.loc[df0["metric"] == CPU_METRIC, "AVERAGE"] = df0["AVERAGE"] / 100
    df0.loc[df0["metric"] == CPU_METRIC, "MAXIMUM"] = df0["MAXIMUM"] / 100

    df0.loc[(df0["metric"] == CPU_METRIC) & (df0["cpu_type"] == "IBM"), "MINIMUM"] = (
        df0["MINIMUM"] * df0["total_cpu_cores"]
    )
    df0.loc[(df0["metric"] == CPU_METRIC) & (df0["cpu_type"] == "IBM"), "AVERAGE"] = (
        df0["AVERAGE"] * df0["total_cpu_cores"]
    )
    df0.loc[(df0["metric"] == CPU_METRIC) & (df0["cpu_type"] == "IBM"), "MAXIMUM"] = (
        df0["MAXIMUM"] * df0["total_cpu_cores"]
    )

    df0.loc[
        (df0["metric"] == CPU_METRIC) & (df0["MINIMUM"] > df0["init_cpu_count"]),
        "MINIMUM",
    ] = df0["init_cpu_count"]
    df0.loc[
        (df0["metric"] == CPU_METRIC) & (df0["AVERAGE"] > df0["init_cpu_count"]),
        "AVERAGE",
    ] = df0["init_cpu_count"]
    df0.loc[
        (df0["metric"] == CPU_METRIC) & (df0["MAXIMUM"] > df0["init_cpu_count"]),
        "MAXIMUM",
    ] = df0["init_cpu_count"]

    df0.loc[df0["metric"] == CPU_METRIC, "metric"] = CPU_DERIVED_METRIC

    lg(
        "     Reduced instance daily metrics to "
        + str(len(df0))
        + " rows in "
        + str(round(time.time() - tb, 3))
        + " s\n"
    )

    df0 = df0[
        [
            "cdb_cohort",
            "cdb",
            "TARGET_NAME",
            "metric",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "AVERAGE",
            "MAXIMUM",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "cdb_target_guid",
            "db_target_guid",
        ]
    ]
    df0.rename(columns={"TARGET_NAME": "inst"}, inplace=True)

    if 1 == 0:
        printDf("df0.aaa", df0, rows=10, showTail=False)

    instanceDailyMetricsDf = (
        df0
        if len(instanceDailyMetricsDf) == 0
        else pd.concat([instanceDailyMetricsDf, df0], ignore_index=True)
    )

lg(
    "\nLoaded "
    + str(len(instanceDailyMetricsDf))
    + " instance daily metrics in "
    + str(round(time.time() - tb0, 3))
    + " s"
)

# ---

if len(overriddenInstanceMetricsDf) and len(instanceDailyMetricsDf) > 0:
    #
    #   Replace daily metrics with override mertrics
    #
    indicators = overriddenInstanceMetricsDf["indicator"].unique()
    timeStampsDf = instanceDailyMetricsDf[["ROLLUP_TIMESTAMP_UTC"]].drop_duplicates()

    if 1 == 0:
        lg("indicators")
        lg("----------")
        lg(str(indicators))

    instanceDailyMetricsDf["indicator"] = instanceDailyMetricsDf[
        "db_target_guid"
    ].str.cat(instanceDailyMetricsDf["metric"], sep="$$$")

    df = pd.merge(
        left=overriddenInstanceMetricsDf,
        right=dbPlacementsDf[
            ["cdb_cohort", "cdb", "cdb_target_guid", "db_target_guid"]
        ],
        how="left",
        left_on=["db_target_guid"],
        right_on=["db_target_guid"],
    )

    df["MINIMUM"] = df["value"]
    df["AVERAGE"] = df["value"]
    df["MAXIMUM"] = df["value"]
    df["STANDARD_DEVIATION"] = 0
    df["SAMPLE_COUNT"] = 1

    df.rename(columns={"db": "inst", "name": "metric"}, inplace=True)
    df.drop(columns=["indicator", "value"], inplace=True)

    overrideInstanceMetricsWithTSDf = df.merge(timeStampsDf, how="cross")
    overrideInstanceMetricsWithTSDf = overrideInstanceMetricsWithTSDf[
        [
            "cdb_cohort",
            "cdb",
            "inst",
            "metric",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "MAXIMUM",
            "AVERAGE",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "cdb_target_guid",
            "db_target_guid",
        ]
    ]

    instanceDailyMetricsDf = instanceDailyMetricsDf[
        ~instanceDailyMetricsDf["indicator"].isin(indicators)
    ].copy()
    instanceDailyMetricsDf.drop(columns=["indicator"], inplace=True)

    if 1 == 0:
        lg(
            "\nxxx len(instanceDailyMetricsDf).00         : "
            + str(len(instanceDailyMetricsDf))
        )
        lg(
            "xxx instanceDailyMetricsDf.columns           : "
            + str(instanceDailyMetricsDf.columns)
        )
        lg(
            "xxx overrideInstanceMetricsWithTSDf.columns.1: "
            + str(overrideInstanceMetricsWithTSDf.columns)
        )

    instanceDailyMetricsDf = pd.concat(
        [instanceDailyMetricsDf, overrideInstanceMetricsWithTSDf], ignore_index=True
    )

    lg(
        "\nAdded "
        + str(len(overrideInstanceMetricsWithTSDf))
        + " override metrics to instanceDailyMetricsDf"
    )

    if 1 == 0:
        lg("\nxxx len(instanceDailyMetricsDf).01: " + str(len(instanceDailyMetricsDf)))

    df, overrideInstanceMetricsWithTSDf = [], []
    #
    #   Add derived sga+pga metric
    #
    if (
        PGA_METRIC in overriddenInstanceMetricsDf["name"].unique()
        or SGA_METRIC in overriddenInstanceMetricsDf["name"].unique()
    ):
        tb = time.time()

        sgapgaDf = (
            instanceDailyMetricsDf[
                (
                    instanceDailyMetricsDf["db_target_guid"].isin(
                        overriddenInstanceMetricsDf["db_target_guid"].unique()
                    )
                )
                & (instanceDailyMetricsDf["metric"].isin([PGA_METRIC, SGA_METRIC]))
            ]
            .groupby(
                [
                    "cdb_cohort",
                    "cdb",
                    "inst",
                    "metric",
                    "ROLLUP_TIMESTAMP_UTC",
                    "cdb_target_guid",
                    "db_target_guid",
                ],
                as_index=False,
            )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]]
            .sum()
        )
        sgapgaDf["metric"] = SGAPGA_DERIVED_METRIC

        sgapgaDf = sgapgaDf[
            [
                "cdb_cohort",
                "cdb",
                "inst",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "MINIMUM",
                "MAXIMUM",
                "AVERAGE",
                "STANDARD_DEVIATION",
                "SAMPLE_COUNT",
                "cdb_target_guid",
                "db_target_guid",
            ]
        ]

        instanceDailyMetricsDf = pd.concat(
            [
                instanceDailyMetricsDf[
                    (
                        ~instanceDailyMetricsDf["db_target_guid"].isin(
                            overriddenInstanceMetricsDf["db_target_guid"].unique()
                        )
                    )
                    | (instanceDailyMetricsDf["metric"] != SGAPGA_DERIVED_METRIC)
                ],
                sgapgaDf,
            ],
            ignore_index=True,
        )

        if 1 == 0:
            lg(
                "\nxxx len(instanceDailyMetricsDf).03: "
                + str(len(instanceDailyMetricsDf))
            )

        lg(
            "\nAdded "
            + str(len(sgapgaDf))
            + " updated sga+pga metrics in instanceDailyMetricsDf in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        sgapgaDf = []

# ---

excludedDbs = instancesDf[instancesDf["excluded"] == "excluded"][
    "db_target_guid"
].unique()

if len(instanceDailyMetricsDf) > 0:
    instanceDailyMetricsDf.loc[
        instanceDailyMetricsDf["db_target_guid"].isin(excludedDbs), "cdb_cohort"
    ] = "excluded"

    cdbDailyMetricsDf = instanceDailyMetricsDf.groupby(
        ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
        as_index=False,
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()
    cdbCohortDailyMetricsDf = cdbDailyMetricsDf.groupby(
        ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

lg(
    "\nCreated "
    + str(len(instanceDailyMetricsDf))
    + " instance daily metrics in "
    + str(round(time.time() - tb0, 3))
    + " s"
)
lg(
    "Created "
    + str(len(cdbDailyMetricsDf))
    + " cdb daily metrics in "
    + str(round(time.time() - tb0, 3))
    + " s"
)
lg(
    "Created "
    + str(len(cdbCohortDailyMetricsDf))
    + " cdb daily cohort metrics in "
    + str(round(time.time() - tb0, 3))
    + " s"
)

if 1 == 0:
    filename = outputFilePath + os.sep + "cdb_Daily_Metrics.csv"
    cdbDailyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

if 1 == 0:
    filename = outputFilePath + os.sep + "cdb_Cohort_Daily_Metrics.csv"
    cdbCohortDailyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ----------------------------------------------------------------------------------------------------------------------

adjustedValuesDf, timeGroupAlignedAvgDf = [], []

if len(instanceDailyMetricsDf) == 0:
    lg(
        "\n\nNo db daily metrics have benn loaded. Skipping computation of hourly adjustments..."
    )

else:
    dailyDays = sorted(
        instanceDailyMetricsDf["ROLLUP_TIMESTAMP_UTC"].unique(), reverse=True
    )
    timeStampGroup, timeStampGroups = 0, {}

    if 1 == 0:
        lg(
            "min(hourlyDays), max(hourlyDays), len(hourlyDays): "
            + str((min(hourlyDays), max(hourlyDays), len(hourlyDays)))
        )
        lg(
            "min(dailyDays),  max(dailyDays),  len(dailyDays) : "
            + str((min(dailyDays), max(dailyDays), len(dailyDays)))
        )

    for ctr, day in enumerate(dailyDays):
        timeStampGroup = -1 * math.floor(ctr / len(hourlyDays))

        if 1 == 0:
            if ctr < 30:
                lg("Placing " + str(day) + " in group " + str(timeStampGroup))

        timeStampGroups[day] = timeStampGroup

    # ---

    if 1 == 0:
        for ctr, _ in enumerate(sorted(timeStampGroups.keys())):
            if not (
                ctr <= len(hourlyDays) * 2
                or ctr >= len(timeStampGroups) - len(hourlyDays) * 2
            ):
                continue

            lg("timeStampGroups[" + str(_) + "]: " + str(timeStampGroups[_]))

    timeStampGroupsDf = pd.DataFrame.from_dict(
        timeStampGroups, orient="index", columns=["time_stamp_group"]
    )

    cdbDailyMetricsDf = pd.merge(
        left=cdbDailyMetricsDf,
        right=timeStampGroupsDf,
        how="left",
        left_on="ROLLUP_TIMESTAMP_UTC",
        right_index=True,
    )
    cdbCohortDailyMetricsDf = pd.merge(
        left=cdbCohortDailyMetricsDf,
        right=timeStampGroupsDf,
        how="left",
        left_on="ROLLUP_TIMESTAMP_UTC",
        right_index=True,
    )

    # ---

    timeStampGroup0MetricsDf = (
        cdbDailyMetricsDf[cdbDailyMetricsDf["time_stamp_group"] == 0]
        .groupby(["cdb_target_guid", "metric"], as_index=False)[["AVERAGE"]]
        .agg(["mean", max])
        .reset_index()
    )
    timeStampGroup0MetricsDf.columns = [
        "cdb_target_guid",
        "metric",
        "DAILY_AVERAGE_avg_group_0",
        "DAILY_AVERAGE_max_group_0",
    ]

    if 1 == 0:
        lg("cdbDailyMetricsDf.ccc.columns: " + str(cdbDailyMetricsDf.columns))
        printDf("cdbDailyMetricsDf.ccc", cdbDailyMetricsDf, rows=10, showTail=False)

    cdbDailyAdjustmentsDf = cdbDailyMetricsDf.groupby(
        ["cdb_target_guid", "cdb_cohort", "cdb", "metric", "time_stamp_group"],
        as_index=False,
    )[["AVERAGE", "ROLLUP_TIMESTAMP_UTC"]].agg(
        {"AVERAGE": ["mean", max], "ROLLUP_TIMESTAMP_UTC": [min, max]}
    )

    if 1 == 0:
        lg("cdbDailyAdjustmentsDf..ccc.columns: " + str(cdbDailyAdjustmentsDf.columns))
        printDf(
            "cdbDailyAdjustmentsDf.ccc", cdbDailyAdjustmentsDf, rows=10, showTail=False
        )

    cdbDailyAdjustmentsDf.columns = [
        "cdb_target_guid",
        "cdb_cohort",
        "cdb",
        "metric",
        "time_stamp_group",
        "DAILY_AVERAGE_avg",
        "DAILY_AVERAGE_max",
        "ROLLUP_TIMESTAMP_min",
        "ROLLUP_TIMESTAMP_max",
    ]

    if 1 == 0:
        printDf(
            "cdbDailyAdjustmentsDf.ccc", cdbDailyAdjustmentsDf, rows=10, showTail=False
        )
        printDf(
            "timeStampGroup0MetricsDf.ccc",
            timeStampGroup0MetricsDf,
            rows=10,
            showTail=False,
        )

    cdbDailyAdjustmentsDf = pd.merge(
        left=cdbDailyAdjustmentsDf,
        right=timeStampGroup0MetricsDf,
        how="left",
        left_on=["cdb_target_guid", "metric"],
        right_on=["cdb_target_guid", "metric"],
    )

    cdbDailyAdjustmentsDf["AVERAGE_avg_multiplier"] = round(
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_avg"]
        / cdbDailyAdjustmentsDf["DAILY_AVERAGE_avg_group_0"],
        4,
    )
    cdbDailyAdjustmentsDf.loc[
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_avg_group_0"] == 0,
        "AVERAGE_avg_multiplier",
    ] = 0

    cdbDailyAdjustmentsDf["AVERAGE_max_multiplier"] = round(
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_max"]
        / cdbDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"],
        4,
    )
    cdbDailyAdjustmentsDf.loc[
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"] == 0,
        "AVERAGE_max_multiplier",
    ] = 0

    cdbDailyAdjustmentsDf["days_to_subtract_from_g0"] = (
        -1 * cdbDailyAdjustmentsDf["time_stamp_group"] * len(hourlyDays)
    )

    cdbDailyAdjustmentsDf = cdbDailyAdjustmentsDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "time_stamp_group",
            "days_to_subtract_from_g0",
            "ROLLUP_TIMESTAMP_min",
            "ROLLUP_TIMESTAMP_max",
            "DAILY_AVERAGE_avg",
            "DAILY_AVERAGE_avg_group_0",
            "AVERAGE_avg_multiplier",
            "DAILY_AVERAGE_max",
            "DAILY_AVERAGE_max_group_0",
            "AVERAGE_max_multiplier",
            "cdb_target_guid",
        ]
    ]
    lg(
        "Computed cdb daily time stamp group adjustments from "
        + str(len(cdbDailyMetricsDf))
        + " rows in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    cdbDailyAdjustmentsDf["summary_of"] = "cdb"
    cdbDailyAdjustmentsDf["version"] = __version__

    # ---

    timeStampGroup0MetricsDf = (
        cdbCohortDailyMetricsDf[cdbCohortDailyMetricsDf["time_stamp_group"] == 0]
        .groupby(["cdb_cohort", "metric"], as_index=False)[["AVERAGE"]]
        .agg(["mean", max])
        .reset_index()
    )
    timeStampGroup0MetricsDf.columns = [
        "cdb_cohort",
        "metric",
        "DAILY_AVERAGE_avg_group_0",
        "DAILY_AVERAGE_max_group_0",
    ]

    if 1 == 0:
        printDf(
            "cdbDailyMetricsDf.ddd", cdbCohortDailyMetricsDf, rows=10, showTail=False
        )

    cdbCohortDailyAdjustmentsDf = cdbCohortDailyMetricsDf.groupby(
        ["cdb_cohort", "metric", "time_stamp_group"], as_index=False
    )[["AVERAGE", "ROLLUP_TIMESTAMP_UTC"]].agg(
        {"AVERAGE": ["mean", max], "ROLLUP_TIMESTAMP_UTC": [min, max]}
    )
    cdbCohortDailyAdjustmentsDf.columns = [
        "cdb_cohort",
        "metric",
        "time_stamp_group",
        "DAILY_AVERAGE_avg",
        "DAILY_AVERAGE_max",
        "ROLLUP_TIMESTAMP_min",
        "ROLLUP_TIMESTAMP_max",
    ]

    cdbCohortDailyAdjustmentsDf["cdb_target_guid"] = "All"
    cdbCohortDailyAdjustmentsDf["cdb"] = "All"

    if 1 == 0:
        printDf(
            "cdbCohortDailyAdjustmentsDf.ddd",
            cdbCohortDailyAdjustmentsDf,
            rows=10,
            showTail=False,
        )
        printDf(
            "timeStampGroup0MetricsDf.ddd",
            timeStampGroup0MetricsDf,
            rows=10,
            showTail=False,
        )

    cdbCohortDailyAdjustmentsDf = pd.merge(
        left=cdbCohortDailyAdjustmentsDf,
        right=timeStampGroup0MetricsDf,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )

    cdbCohortDailyAdjustmentsDf["AVERAGE_avg_multiplier"] = round(
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_avg"]
        / cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"],
        4,
    )
    cdbCohortDailyAdjustmentsDf.loc[
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_avg_group_0"] == 0,
        "AVERAGE_avg_multiplier",
    ] = 0

    cdbCohortDailyAdjustmentsDf["AVERAGE_max_multiplier"] = round(
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max"]
        / cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"],
        4,
    )
    cdbCohortDailyAdjustmentsDf.loc[
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"] == 0,
        "AVERAGE_max_multiplier",
    ] = 0

    cdbCohortDailyAdjustmentsDf["days_to_subtract_from_g0"] = (
        -1 * cdbCohortDailyAdjustmentsDf["time_stamp_group"] * len(hourlyDays)
    )

    cdbCohortDailyAdjustmentsDf = cdbCohortDailyAdjustmentsDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "time_stamp_group",
            "days_to_subtract_from_g0",
            "ROLLUP_TIMESTAMP_min",
            "ROLLUP_TIMESTAMP_max",
            "DAILY_AVERAGE_avg",
            "DAILY_AVERAGE_avg_group_0",
            "AVERAGE_avg_multiplier",
            "DAILY_AVERAGE_max",
            "DAILY_AVERAGE_max_group_0",
            "AVERAGE_max_multiplier",
            "cdb_target_guid",
        ]
    ]
    lg(
        "Computed cdb cohort daily time stamp group adjustments from "
        + str(len(cdbDailyMetricsDf))
        + " rows in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    cdbCohortDailyAdjustmentsDf["summary_of"] = "cdb_cohort"
    cdbCohortDailyAdjustmentsDf["version"] = __version__

    if 1 == 0:
        filename = sizingFilePath + os.sep + "cdb_Daily_Adjustments.csv"
        pd.concat(
            [cdbDailyAdjustmentsDf, cdbCohortDailyAdjustmentsDf], ignore_index=True
        ).sort_values(["cdb_cohort", "cdb", "metric", "time_stamp_group"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    # ----------------------------------------------------------------------------------------------------------------------

    tb = time.time()

    _ = {g for g in list(timeStampGroups.values())}  # use a set to get unique values
    _ = [g for g in _]

    lg("\nAdding time_groups....")

    for ctr, groups in enumerate(sorted(_)):
        lg("     Adding time_stamp_group: " + str(groups))

        if groups == 0:
            df1 = cdbHourlyMetricsDf
            df2 = cdbCohortHourlyMetricsDf

        else:
            df1 = pd.merge(
                left=cdbHourlyMetricsDf,
                right=cdbDailyAdjustmentsDf[
                    cdbDailyAdjustmentsDf["time_stamp_group"] == groups
                ][
                    [
                        "cdb_target_guid",
                        "metric",
                        "days_to_subtract_from_g0",
                        "AVERAGE_avg_multiplier",
                        "AVERAGE_max_multiplier",
                    ]
                ],
                left_on=["cdb_target_guid", "metric"],
                right_on=["cdb_target_guid", "metric"],
                how="left",
            )
            df1["ROLLUP_TIMESTAMP_UTC"] -= df1[
                "days_to_subtract_from_g0"
            ].values.astype("timedelta64[D]")
            df1["AVERAGE"] = df1["AVERAGE"] * df1["AVERAGE_max_multiplier"]

            df2 = pd.merge(
                left=cdbCohortHourlyMetricsDf,
                right=cdbCohortDailyAdjustmentsDf[
                    cdbCohortDailyAdjustmentsDf["time_stamp_group"] == groups
                ][
                    [
                        "cdb_cohort",
                        "metric",
                        "days_to_subtract_from_g0",
                        "AVERAGE_avg_multiplier",
                        "AVERAGE_max_multiplier",
                    ]
                ],
                left_on=["cdb_cohort", "metric"],
                right_on=["cdb_cohort", "metric"],
                how="left",
            )
            df2["ROLLUP_TIMESTAMP_UTC"] -= df2[
                "days_to_subtract_from_g0"
            ].values.astype("timedelta64[D]")
            df2["AVERAGE"] = df2["AVERAGE"] * df2["AVERAGE_max_multiplier"]

        df2["cdb"] = "All"
        df2["cdb_target_guid"] = "All"

        # ---

        df = df1.groupby(
            ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
            as_index=False,
        )[["AVERAGE"]].sum()
        df["time_stamp_group"] = groups
        df["summary_of"] = "cdb"
        timeGroupAlignedAvgDf = (
            df
            if len(timeGroupAlignedAvgDf) == 0
            else pd.concat([timeGroupAlignedAvgDf, df])
        )

        # ---

        df = df2.groupby(
            ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
            as_index=False,
        )[["AVERAGE"]].sum()
        df["time_stamp_group"] = groups
        df["summary_of"] = "cdb_cohort"
        timeGroupAlignedAvgDf = (
            df
            if len(timeGroupAlignedAvgDf) == 0
            else pd.concat([timeGroupAlignedAvgDf, df])
        )

        df1, df2 = [], []
    #
    #       We need to hang onto df1 & df2 for plotting yearly charts
    #
    # ---

    hrsDf = timeGroupAlignedAvgDf.groupby("cdb_target_guid", as_index=False)[
        "ROLLUP_TIMESTAMP_UTC"
    ].nunique()
    hrsDf.columns = ["cdb_target_guid", "hrs"]

    df0 = (
        timeGroupAlignedAvgDf[timeGroupAlignedAvgDf["summary_of"] != "cdb_cohort"]
        .groupby(
            ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "summary_of"],
            as_index=False,
        )["AVERAGE"]
        .agg(["max", "sum"])
        .reset_index()
    )
    df0.columns = [
        "cdb_cohort",
        "cdb",
        "cdb_target_guid",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
    ]

    df0 = pd.merge(
        left=df0,
        right=cdbInstanceCountsDf[["cdb_target_guid", "cdb_type", "instance_count"]],
        left_on="cdb_target_guid",
        right_on="cdb_target_guid",
        how="left",
    )
    df0 = pd.merge(
        left=df0,
        right=hrsDf,
        how="left",
        left_on="cdb_target_guid",
        right_on="cdb_target_guid",
    )

    df0 = df0[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "peak",
            "sum_metric_x_hrs",
            "hrs",
            "cdb_target_guid",
        ]
    ]

    # ---

    cdbCohortInstanceCountsDf = df0.groupby("cdb_cohort", as_index=False)[
        "instance_count"
    ].sum()

    hrsDf = timeGroupAlignedAvgDf.groupby("cdb_cohort", as_index=False)[
        "ROLLUP_TIMESTAMP_UTC"
    ].nunique()
    hrsDf.columns = ["cdb_cohort", "hrs"]

    df1 = (
        timeGroupAlignedAvgDf[timeGroupAlignedAvgDf["summary_of"] == "cdb_cohort"]
        .groupby(["cdb_cohort", "metric", "summary_of"], as_index=False)["AVERAGE"]
        .agg(["max", "sum"])
        .reset_index()
    )
    df1.columns = ["cdb_cohort", "metric", "summary_of", "peak", "sum_metric_x_hrs"]

    df1 = pd.merge(
        left=df1,
        right=cdbCohortInstanceCountsDf,
        left_on="cdb_cohort",
        right_on="cdb_cohort",
        how="left",
    )
    df1 = pd.merge(
        left=df1, right=hrsDf, how="left", left_on="cdb_cohort", right_on="cdb_cohort"
    )

    df1["cdb"] = "All"
    df1["cdb_type"] = "All"
    df1["cdb_target_guid"] = "All"

    df1 = df1[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "peak",
            "sum_metric_x_hrs",
            "hrs",
            "cdb_target_guid",
        ]
    ]

    adjustedValuesDf = pd.concat([df0, df1])

    # ---

    df0, df1 = [], []

# ---

hrsDf = cdbHourlyMetricsDf.groupby("cdb_target_guid", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_target_guid", "hrs"]

df = cdbHourlyMetricsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
    as_index=False,
)[["AVERAGE"]].sum()
df0 = (
    df.groupby(["cdb_cohort", "cdb", "cdb_target_guid", "metric"], as_index=False)[
        "AVERAGE"
    ]
    .agg(["max", "sum"])
    .reset_index()
)
df0.columns = [
    "cdb_cohort",
    "cdb",
    "cdb_target_guid",
    "metric",
    "peak",
    "sum_metric_x_hrs",
]

df0 = pd.merge(
    left=df0,
    right=cdbInstanceCountsDf[["cdb_target_guid", "cdb_type", "instance_count"]],
    how="left",
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
)
df0 = pd.merge(
    left=df0,
    right=hrsDf,
    how="left",
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
)

df0["summary_of"] = "cdb"

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = df0.copy()

cdbCohortInstanceCountsDf = df0.groupby("cdb_cohort", as_index=False)[
    "instance_count"
].sum()

# ---

hrsDf = cdbHourlyStorageMetricsDf.groupby("cdb_target_guid", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_target_guid", "hrs"]

df = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
    as_index=False,
)[["AVERAGE"]].sum()
df0 = (
    df.groupby(["cdb_cohort", "cdb", "cdb_target_guid", "metric"], as_index=False)[
        "AVERAGE"
    ]
    .agg(["max", "sum"])
    .reset_index()
)
df0.columns = [
    "cdb_cohort",
    "cdb",
    "cdb_target_guid",
    "metric",
    "peak",
    "sum_metric_x_hrs",
]

df0 = pd.merge(
    left=df0,
    right=cdbInstanceCountsDf[["cdb_target_guid", "cdb_type", "instance_count"]],
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
df0 = pd.merge(
    left=df0,
    right=hrsDf,
    how="left",
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
)

df0["summary_of"] = "cdb"
#
# Storage metrics are captured at the daily level
#
df0["hrs"] *= 24
df0["sum_metric_x_hrs"] *= 24

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = pd.concat([finalDf, df0])

if len(adjustedValuesDf) > 0:
    adjustedValuesDf = pd.concat([adjustedValuesDf, df0], ignore_index=True)

# ---

df = cdbCohortHourlyMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["AVERAGE"]].sum()

hrsDf = cdbCohortHourlyMetricsDf.groupby("cdb_cohort", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_cohort", "hrs"]

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdbCohortHourlyMetricsDf.csv"
    cdbCohortHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdbCohortHourlyMetricsDf.hrs.csv"
    hrsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

df0 = (
    df.groupby(["cdb_cohort", "metric"], as_index=False)["AVERAGE"]
    .agg(["max", "sum"])
    .reset_index()
)
df0.columns = ["cdb_cohort", "metric", "peak", "sum_metric_x_hrs"]

df0 = pd.merge(
    left=df0,
    right=cdbCohortInstanceCountsDf,
    how="left",
    left_on="cdb_cohort",
    right_on="cdb_cohort",
)
df0 = pd.merge(
    left=df0, right=hrsDf, how="left", left_on="cdb_cohort", right_on="cdb_cohort"
)

df0["cdb"] = "All"
df0["cdb_type"] = "All"
df0["cdb_target_guid"] = "All"
df0["summary_of"] = "cdb_cohort"

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = pd.concat([finalDf, df0])

# ---

df = cdbCohortHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["AVERAGE"]].sum()

hrsDf = cdbCohortHourlyStorageMetricsDf.groupby("cdb_cohort", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_cohort", "hrs"]

df0 = (
    df.groupby(["cdb_cohort", "metric"], as_index=False)["AVERAGE"]
    .agg(["max", "sum"])
    .reset_index()
)
df0.columns = ["cdb_cohort", "metric", "peak", "sum_metric_x_hrs"]

df0 = pd.merge(
    left=df0,
    right=cdbCohortInstanceCountsDf,
    left_on="cdb_cohort",
    right_on="cdb_cohort",
    how="left",
)
df0 = pd.merge(
    left=df0, right=hrsDf, how="left", left_on="cdb_cohort", right_on="cdb_cohort"
)

df0["cdb"] = "All"
df0["cdb_type"] = "All"
df0["cdb_target_guid"] = "All"
df0["summary_of"] = "cdb_cohort"
#
# Storage metrics are captured at the daily level
#
df0["hrs"] *= 24
df0["sum_metric_x_hrs"] *= 24

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = pd.concat([finalDf, df0])

if len(adjustedValuesDf) > 0:
    adjustedValuesDf = pd.concat([adjustedValuesDf, df0], ignore_index=True)

# ---

finalDf["adjusted"] = 0
finalDf["sum_peak_x_hrs"] = finalDf["peak"] * finalDf["hrs"]
finalDf["sum_peak_x_hrs_m_sum_metric_x_hrs"] = (
    finalDf["sum_peak_x_hrs"] - finalDf["sum_metric_x_hrs"]
)
finalDf["sum_metric_x_hrs_o_sum_peak_x_hrs"] = round(
    finalDf["sum_metric_x_hrs"] / finalDf["sum_peak_x_hrs"], PRECISION
)
finalDf.loc[finalDf["sum_peak_x_hrs"] == 0, "sum_metric_x_hrs_o_sum_peak_x_hrs"] = 1

finalDf = finalDf[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "adjusted",
        "summary_of",
        "peak",
        "sum_peak_x_hrs",
        "sum_metric_x_hrs",
        "sum_peak_x_hrs_m_sum_metric_x_hrs",
        "sum_metric_x_hrs_o_sum_peak_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]
finalDf["version"] = __version__

# ---

if len(adjustedValuesDf) > 0:
    adjustedValuesDf["adjusted"] = 1
    adjustedValuesDf["sum_peak_x_hrs"] = (
        adjustedValuesDf["peak"] * adjustedValuesDf["hrs"]
    )
    adjustedValuesDf["sum_peak_x_hrs_m_sum_metric_x_hrs"] = (
        adjustedValuesDf["sum_peak_x_hrs"] - adjustedValuesDf["sum_metric_x_hrs"]
    )
    adjustedValuesDf["sum_metric_x_hrs_o_sum_peak_x_hrs"] = round(
        adjustedValuesDf["sum_metric_x_hrs"] / adjustedValuesDf["sum_peak_x_hrs"],
        PRECISION,
    )
    adjustedValuesDf.loc[
        adjustedValuesDf["sum_peak_x_hrs"] == 0, "sum_metric_x_hrs_o_sum_peak_x_hrs"
    ] = 1

    adjustedValuesDf = adjustedValuesDf[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "adjusted",
            "summary_of",
            "peak",
            "sum_peak_x_hrs",
            "sum_metric_x_hrs",
            "sum_peak_x_hrs_m_sum_metric_x_hrs",
            "sum_metric_x_hrs_o_sum_peak_x_hrs",
            "hrs",
            "cdb_target_guid",
        ]
    ]
    adjustedValuesDf["version"] = __version__

    finalDf = pd.concat([finalDf, adjustedValuesDf])

filename = sizingFilePath + os.sep + "sizing.csv"
finalDf.sort_values(["cdb_cohort", "cdb", "metric", "adjusted", "summary_of"]).to_csv(
    filename, index=False
)
lg("\nWrote file " + filename)

if 1 == 0:
    filename = sizingFilePath + os.sep + "TimeGroup_TimeAligned_Avg.csv"
    timeGroupAlignedAvgDf["version"] = __version__
    timeGroupAlignedAvgDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ----------------------------------------------------------------------------------------------------------------------

Duplicate_Tests.emitDuplicateTestResults(duplicateTestResults, logFile)

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nProcessing "
    + str(len(structureDf))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg("\nEnd @ " + datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S") + " UTC\n")

logFile.close()
