HEIGHT = 1185
WIDTH = 1920

import argparse
import datetime
import locale
import os
import pandas as pd
import platform
import sys
import time

import plotly as plt
import plotly.express as px

from occa_Shared import *
from version import version, __version__

#
# Not quite ready for this yet
#
# locale.setlocale(locale.LC_ALL, '')
#

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Plot_Metrics_CDFs.py",
    description="Plot Cumulative Distribution charts for occa metrics",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + ", version " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

#
# This script depends on a setting for the parameters shown below
# Values for these parameters will be read from the parameter file
#

CDF_DATABASE_COUNT = 15

COHORTS = []

PLOT_HTML = True
PLOT_PNG = False

PLOT_SUPPRESSED_COHORTS = []

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------


def format_title(title, subtitle=None, subtitle_font_size=14):
    title = f"<b>{title}</b>"

    if not subtitle:
        return title

    subtitle = f'<span style="font-size: {subtitle_font_size}px;">{subtitle}</span>'

    return f"{title}<br>{subtitle}"


# ----------------------------------------------------------------------------------------------------------------------


def plotMetrics(df, adjusted=False):
    lg("\nBeginning " + ("adjusted " if adjusted else "") + "metric plots...")

    if adjusted:
        os.makedirs(plotFilePath + os.sep + "adjusted", exist_ok=True)
    else:
        os.makedirs(plotFilePath + os.sep + "unadjusted", exist_ok=True)

    customer = os.getcwd().split(os.sep)[-1]

    for cohort in sorted(df.cdb_cohort.unique()):
        if cohort in PLOT_SUPPRESSED_COHORTS:
            lg("     Skipping plot suppressed cohort " + str(cohort) + "...")

            continue

        lg("     Beginning cohort " + str(cohort) + "...")

        tb = time.time()

        if PLOT_HTML:
            filePathHTML = (
                plotFilePath
                + os.sep
                + ("adjusted" if adjusted else "unadjusted")
                + os.sep
                + str(cohort)
                + os.sep
                + "html"
            )
            os.makedirs(filePathHTML, exist_ok=True)

        if PLOT_PNG:
            filePathPNG = (
                plotFilePath
                + os.sep
                + ("adjusted" if adjusted else "unadjusted")
                + os.sep
                + str(cohort)
                + os.sep
                + "png"
            )
            os.makedirs(filePathPNG, exist_ok=True)

        plotCtr = 0

        for metric in sorted(df.metric.unique()):
            aDf = df[(df["cdb_cohort"] == cohort) & (df["metric"] == metric)].copy()

            if len(aDf) == 0:
                lg(
                    "          Skipping 0-length cohort: "
                    + str(cohort)
                    + ", metric: "
                    + metric
                )
                continue

            metricTitle = metric
            uom = (
                EMCC_METRIC_ALIAS_UOMS[metric]
                if metric in EMCC_METRIC_ALIAS_UOMS
                else "Unknow: " + metric
            )
            aDf["metric"] = metricTitle

            lg("        Beginning plot for metric " + metricTitle + "...")

            if PLOT_HTML:
                filenameHTML = (
                    filePathHTML
                    + os.sep
                    + str(cohort)
                    + "_"
                    + metricTitle.replace(" ", "_")
                    + "_"
                    + ("adjusted" if adjusted else "unadjusted")
                    + "_cdf.html"
                )
                dashboard = open(filenameHTML, "w")
                HTMLhead = (
                    customer
                    + " : "
                    + str(cohort)
                    + ", Hourly Average "
                    + metricTitle
                    + " (occa_Plot_Metric_CDFs, Chart Version "
                    + __version__
                    + ")"
                )

                dashboard.write(
                    "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
                )

            if PLOT_PNG:
                filenamePNG = (
                    filePathPNG
                    + os.sep
                    + str(cohort)
                    + "_"
                    + metricTitle.replace(" ", "_")
                    + "_"
                    + ("adjusted" if adjusted else "unadjusted")
                    + "_cdf.png"
                )

            aDf = df[(df["metric"] == metric) & (df["cdb_cohort"] == cohort)]

            ranks = sorted(aDf["total_rank"].unique(), reverse=True)
            cdbCount = len(ranks)
            ranks = ranks[:CDF_DATABASE_COUNT]

            aDf = aDf[aDf["total_rank"].isin(ranks)]
            #
            #           Sorting by total ensures same sort order as non-CDF charts
            #
            aDf = aDf.sort_values(
                ["total", "cdb", "value"], ascending=[False, True, True]
            )
            aDf["pct"] *= 100

            fig = px.line(
                aDf,
                x="value",
                y="pct",
                color="cdb_with_max",
                labels={"value": uom, "pct": "%"},
                title=format_title(
                    customer
                    + " : "
                    + str(cohort)
                    + " : Hourly Average "
                    + ("Adjusted " if adjusted else "Unadjusted ")
                    + metricTitle
                    + " (Chart Version "
                    + __version__
                    + ")"
                    + "<br>Cumulative Distribution of the Top "
                    + str(CDF_DATABASE_COUNT)
                    + " (ordered by total consumption descending) of "
                    + str(cdbCount)
                    + " Database(s) ",
                    ("1 OCPU = 2 vCPU" if uom == "vCPU" else ""),
                    20,
                ),
                template="seaborn",
                width=WIDTH,
                height=HEIGHT,
            )
            fig.update_traces(mode="lines+markers")
            fig.update_layout(
                font={"size": 16},
                legend_font_size=12,
                autosize=False,
                width=WIDTH,
                height=HEIGHT,
                margin=dict(t=150),
            )

            if PLOT_HTML:
                inner_html = (
                    fig.to_html(include_plotlyjs=True)
                    .split("<body>")[1]
                    .split("</body>")[0]
                )
                dashboard.write(inner_html)

                dashboard.write("</body></html>" + "\n")
                dashboard.close()

                plotCtr += 1

            if PLOT_PNG:
                fig.write_image(filenamePNG)

                plotCtr += 1

        lg(
            "     Created "
            + str(plotCtr)
            + " plots for "
            + str(cohort)
            + " in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )


# ----------------------------------------------------------------------------------------------------------------------

outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
plotFilePath = outputFilePath + os.sep + "plots"
sizingFilePath = outputFilePath + os.sep + "sizing"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("pandas.__version__: " + pd.__version__)
lg("plotly.__version__: " + plt.__version__)

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n=======================================================================================================\n"
)

lg("COHORTS                : " + str(COHORTS))

lg("CDF_DATABASE_COUNT     : " + str(CDF_DATABASE_COUNT))
lg("PLOT_HTML              : " + str(PLOT_HTML))
lg("PLOT_PNG               : " + str(PLOT_PNG))
lg("PLOT_SUPPRESSED_COHORTS: " + str(PLOT_SUPPRESSED_COHORTS))

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

# ----------------------------------------------------------------------------------------------------------------------

statisticsFilename = sizingFilePath + os.sep + "database_statistics.csv"

if not os.path.exists(statisticsFilename):
    lg(
        "File "
        + statisticsFilename
        + " is missing; please run occa_Run_Metric_Analysis.py before continuing"
    )

    quit()

# ---

startTime = time.time()
lg("Plotting database statics in directory in working directory " + os.getcwd())

cwd = os.getcwd().split(os.sep)[-1]

if not PLOT_HTML and not PLOT_PNG:
    lg("\nNeither PLOT_HTML nor PLOT_PNG is True; exiting.")

    quit()

else:
    df0 = pd.read_csv(statisticsFilename)

    df1 = df0[
        [
            "adjusted",
            "cdb_cohort",
            "cdb",
            "metric",
            "min",
            "p10",
            "p20",
            "p30",
            "p40",
            "p50",
            "p60",
            "p70",
            "p80",
            "p90",
            "p95",
            "p99",
            "max",
            "max_rank",
            "total",
            "total_rank",
        ]
    ].copy()

    df1.rename(
        columns={
            "min": 0,
            "max": 1,
            "p10": 0.1,
            "p20": 0.2,
            "p30": 0.3,
            "p40": 0.4,
            "p50": 0.5,
            "p60": 0.6,
            "p70": 0.7,
            "p80": 0.8,
            "p90": 0.9,
            "p95": 0.95,
            "p99": 0.99,
        },
        inplace=True,
        errors="raise",
    )
    df1["max_str"] = df1[1].map(lambda x: f"{x:,}")
    df1["cdb_with_max"] = df1["cdb"] + " -> " + df1["max_str"]

    df1 = df1.melt(
        id_vars=[
            "adjusted",
            "cdb_cohort",
            "cdb",
            "cdb_with_max",
            "metric",
            "max_rank",
            "total",
            "total_rank",
        ]
    )
    df1.rename(columns={"variable": "pct"}, inplace=True)

    df1.fillna(0, inplace=True)

    if len(df1[df1["adjusted"] == 1]) == 0:
        #
        #   CDFs are only appropriate for unadjusted values given that multipliers for individual databases
        #   are not identical to the multipliers for cohort-level metrics.
        #
        #   Consider: if CDFs are plotted for adjiusted values, the peak values in the CDF plots can exceed the peak
        #   values in the area charts.
        #
        lg("\nThere are no unadjusted values in file " + statisticsFilename)
    else:
        plotMetrics(df1[df1["adjusted"] == 0], False)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nThe plotting of "
    + str(len(df1))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
