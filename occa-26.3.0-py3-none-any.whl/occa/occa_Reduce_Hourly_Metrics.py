from occa_Shared import *

import argparse
import datetime
import os
import pandas as pd
import platform
import sys
import time

from occa_Shared import *
from version import version, __version__

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Reduce_Hourly_Metrics.py",
    description="Reduces DB & Host hourly metrics for easy visualization",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="'Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="'Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + ", version " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

startTime = time.time()

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
# Values for these parameters will be read from the parameter file
#

FIXED = False

# ----------------------------------------------------------------------------------------------------------------------

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("pandas.__version__: " + pd.__version__)

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n=======================================================================================================\n"
)

lg("FIXED: " + str(FIXED))

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

if FIXED:
    cwd = "fixed"
    now = "1989-07-09 00:00:00"
    platformName = "fixed"
    __version__ = "fixed"
else:
    cwd = os.getcwd().split(os.sep)[-1]
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    platformName = platform.system()

# ----------------------------------------------------------------------------------------------------------------------

filename = outputFilePath + os.sep + "sizing" + os.sep + "servers.csv"

if not os.path.exists(filename):
    lg("File " + filename + " does not exist; cannot continue.")
    quit()

lg("\nLoading file " + filename + "...")
serversDf = pd.read_csv(filename)
lg("Loaded " + str(len(serversDf)) + " rows")

extract_dttm_utc = serversDf["extract_dttm_utc"].unique()[0]

filename = outputFilePath + os.sep + "sizing" + os.sep + "instances.csv"

if not os.path.exists(filename):
    lg("\nFile " + filename + " does not exist; cannot continue.")
    quit()

lg("\nLoading file " + filename + "...")
instancesDf = pd.read_csv(filename)
lg("Loaded " + str(len(instancesDf)) + " rows")

dbDf = instancesDf[
    [
        "excluded",
        "cdb_cohort",
        "db",
        "db_cpu_count_limit",
        "host",
        "cpu_type",
        "total_cpu_cores",
        "logical_cpu_count",
        "impl",
        "ma",
        "platform",
        "db_target_guid",
        "host_target_guid",
    ]
].drop_duplicates()

dbDf.fillna({"excluded": ""}, inplace=True)
dbDf = dbDf[dbDf["excluded"] == ""]

# Process database metrics

filename = extractFilePath + os.sep + "emcc_sizing_metrics_db_hourly_03_months.csv"

if not os.path.exists(filename):
    lg("\nFile " + filename + " does not exist; cannot continue.")
    quit()

lg("\nLoading file " + filename + "...")
dbMetricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])
lg("Loaded " + str(len(dbMetricsDf)) + " rows")

dbMetricsDf["metric"] = dbMetricsDf["METRIC_NAME"] + "." + dbMetricsDf["METRIC_COLUMN"]

dbMetricsDf = dbMetricsDf[
    dbMetricsDf["metric"].isin(
        [CPU_METRIC, IOPS_METRIC, LOGONS_METRIC, PGA_METRIC, SGA_METRIC]
    )
]

dbMetricsDf = pd.merge(
    left=dbMetricsDf,
    right=dbDf[
        [
            "db_target_guid",
            "db_cpu_count_limit",
            "cdb_cohort",
            "logical_cpu_count",
            "total_cpu_cores",
            "host",
            "host_target_guid",
        ]
    ],
    how="right",
    left_on="TARGET_GUID",
    right_on="db_target_guid",
)
dbMetricsDf = pd.merge(
    left=dbMetricsDf,
    right=serversDf[["host_target_guid", "cpu_type"]],
    how="left",
    left_on="host_target_guid",
    right_on="host_target_guid",
)
dbMetricsDf.fillna({"cpu_type": ""}, inplace=True)

dbMetricsDf.loc[dbMetricsDf["metric"] == CPU_METRIC, "MINIMUM"] = (
    dbMetricsDf["MINIMUM"] / 100
)
dbMetricsDf.loc[dbMetricsDf["metric"] == CPU_METRIC, "AVERAGE"] = (
    dbMetricsDf["AVERAGE"] / 100
)
dbMetricsDf.loc[dbMetricsDf["metric"] == CPU_METRIC, "MAXIMUM"] = (
    dbMetricsDf["MAXIMUM"] / 100
)

# Adjust for how IBM captures core consumption

dbMetricsDf.loc[
    (dbMetricsDf["metric"] == CPU_METRIC) & (dbMetricsDf["cpu_type"] == "IBM"),
    "MINIMUM",
] = (
    dbMetricsDf["MINIMUM"] * AIX_DEFLATION
)
dbMetricsDf.loc[
    (dbMetricsDf["metric"] == CPU_METRIC) & (dbMetricsDf["cpu_type"] == "IBM"),
    "AVERAGE",
] = (
    dbMetricsDf["AVERAGE"] * AIX_DEFLATION
)
dbMetricsDf.loc[
    (dbMetricsDf["metric"] == CPU_METRIC) & (dbMetricsDf["cpu_type"] == "IBM"),
    "MAXIMUM",
] = (
    dbMetricsDf["MAXIMUM"] * AIX_DEFLATION
)

# Throw out metrics that are clearly anomalous

dbMetricsDf.loc[
    (dbMetricsDf["metric"] == CPU_METRIC)
    & (dbMetricsDf["MINIMUM"] > dbMetricsDf["db_cpu_count_limit"]),
    "MINIMUM",
] = dbMetricsDf["db_cpu_count_limit"]
dbMetricsDf.loc[
    (dbMetricsDf["metric"] == CPU_METRIC)
    & (dbMetricsDf["AVERAGE"] > dbMetricsDf["db_cpu_count_limit"]),
    "AVERAGE",
] = dbMetricsDf["db_cpu_count_limit"]
dbMetricsDf.loc[
    (dbMetricsDf["metric"] == CPU_METRIC)
    & (dbMetricsDf["MAXIMUM"] > dbMetricsDf["db_cpu_count_limit"]),
    "MAXIMUM",
] = dbMetricsDf["db_cpu_count_limit"]

dbMetricsSumDf = dbMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["AVERAGE"]].sum()
dbMetricsSumDf["AVERAGE_max"] = dbMetricsSumDf.groupby(["cdb_cohort", "metric"])[
    "AVERAGE"
].transform("max")
dbMetricsSumDf["AVERAGE_normalized_to_peak"] = (
    dbMetricsSumDf["AVERAGE"] / dbMetricsSumDf["AVERAGE_max"]
)
dbMetricsSumDf.loc[dbMetricsSumDf["AVERAGE_max"] == 0, "AVERAGE_normalized_to_peak"] = 0
dbMetricsSumDf.drop(columns=["AVERAGE_max"], inplace=True)

# Now process host metrics

filename = extractFilePath + os.sep + "emcc_sizing_metrics_host_hourly_03_months.csv"

if not os.path.exists(filename):
    lg("\nFile " + filename + " does not exist; cannot continue.")
    quit()

lg("\nLoading file " + filename + "...")
hostMetricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])
lg("Loaded " + str(len(hostMetricsDf)) + " rows")

hostMetricsDf["metric"] = (
    hostMetricsDf["METRIC_NAME"] + "." + hostMetricsDf["METRIC_COLUMN"]
)

hostMetricsDf = hostMetricsDf[hostMetricsDf["metric"].isin([HOST_CPU_METRIC])]

hostsDf = dbDf[
    [
        "cdb_cohort",
        "host",
        "cpu_type",
        "total_cpu_cores",
        "logical_cpu_count",
        "ma",
        "impl",
        "platform",
        "host_target_guid",
    ]
].drop_duplicates()

cohortLogicalCPUDf = hostsDf.groupby("cdb_cohort", as_index=False)[
    "logical_cpu_count"
].sum()

hostMetricsDf = pd.merge(
    left=hostMetricsDf,
    right=hostsDf[["host_target_guid", "host", "cdb_cohort", "logical_cpu_count"]],
    how="right",
    left_on="TARGET_GUID",
    right_on="host_target_guid",
)

if 1 == 0:
    filename = outputFilePath + os.sep + "sizing" + os.sep + "host_metrics_before.csv"
    hostMetricsDf.sort_values(
        ["TARGET_NAME", "COLUMN_LABEL", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

hostMetricsDf.loc[hostMetricsDf["metric"] == HOST_CPU_METRIC, "AVERAGE"] = (
    hostMetricsDf["AVERAGE"] / 100
) * hostMetricsDf["logical_cpu_count"]

if 1 == 0:
    filename = outputFilePath + os.sep + "sizing" + os.sep + "host_metrics_after.csv"
    hostMetricsDf.sort_values(
        ["TARGET_NAME", "COLUMN_LABEL", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

hostMetricsSumDf = hostMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["AVERAGE"]].sum()
hostMetricsSumDf["AVERAGE_max"] = hostMetricsSumDf.groupby(["cdb_cohort", "metric"])[
    "AVERAGE"
].transform("max")
hostMetricsSumDf["AVERAGE_normalized_to_peak"] = (
    hostMetricsSumDf["AVERAGE"] / hostMetricsSumDf["AVERAGE_max"]
)
hostMetricsSumDf.loc[
    hostMetricsSumDf["AVERAGE_max"] == 0, "AVERAGE_normalized_to_peak"
] = 0
hostMetricsSumDf.drop(columns=["AVERAGE_max"], inplace=True)

metricsSumDf = pd.concat([dbMetricsSumDf, hostMetricsSumDf])
metricsSumDf = pd.merge(
    left=metricsSumDf,
    right=cohortLogicalCPUDf,
    how="left",
    left_on=["cdb_cohort"],
    right_on=["cdb_cohort"],
)
#
# Do the following to keep pivots clean
#
metricsSumDf.loc[metricsSumDf["metric"] != HOST_CPU_METRIC, "logical_cpu_count"] = 0

metricsSumDf["cwd"] = cwd
metricsSumDf["platform"] = platformName
metricsSumDf["extract_dttm_utc"] = extract_dttm_utc
metricsSumDf["create_dttm_utc"] = now
metricsSumDf["version"] = __version__

filename = outputFilePath + os.sep + "sizing" + os.sep + "reduced_hourly_metrics.csv"
metricsSumDf.sort_values(["cdb_cohort", "ROLLUP_TIMESTAMP_UTC", "metric"]).to_csv(
    filename, index=False
)

lg("\nWrote " + str(len(metricsSumDf)) + " rows to file " + filename)

# ---

dbMetricsSumDf = dbMetricsDf.groupby(
    ["host", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["AVERAGE"]].sum()
hostMetricsSumDf = hostMetricsDf.groupby(
    ["host", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)[["AVERAGE"]].sum()
metricsSumDf = pd.concat([dbMetricsSumDf, hostMetricsSumDf])

metricsSumDf = pd.merge(
    left=metricsSumDf,
    right=hostsDf[
        [
            "host",
            "cpu_type",
            "total_cpu_cores",
            "ma",
            "impl",
            "platform",
            "logical_cpu_count",
        ]
    ],
    how="left",
    left_on=["host"],
    right_on=["host"],
)
metricsSumDf.rename(columns={"platform": "host_platform"}, inplace=True)
#
# Do the following to keep pivots clean
#
metricsSumDf.loc[metricsSumDf["metric"] != HOST_CPU_METRIC, "logical_cpu_count"] = 0

metricsSumDf["cwd"] = cwd
metricsSumDf["platform"] = platformName
metricsSumDf["extract_dttm_utc"] = extract_dttm_utc
metricsSumDf["create_dttm_utc"] = now
metricsSumDf["version"] = __version__

filename = (
    outputFilePath + os.sep + "sizing" + os.sep + "reduced_hourly_metrics_by_host.csv"
)
metricsSumDf.sort_values(["host", "ROLLUP_TIMESTAMP_UTC", "metric"]).to_csv(
    filename, index=False
)

lg("\nWrote " + str(len(metricsSumDf)) + " rows to file " + filename)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg("\nProcessing completed in " + str(round(time.time() - startTime, 3)) + " s")

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
