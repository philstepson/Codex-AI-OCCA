import cx_Oracle
import pprint
import os
import pandas


def view_file_uploads(connection: cx_Oracle.Connection):
    # Connect to DB via cursor
    cursor = connection.cursor()
    #

    query = "select file_id, created_by, created_on, STATUS, error_text from file_upload order by CREATED_ON desc"
    # files_uploaded = pandas.read_sql(query, con=connection).head(5)
    # for file in files_uploaded:
    #     pprint.pprint(file)
    files_uploaded = pandas.read_sql(query, con=connection).head(5)
    print(files_uploaded.to_string())


def view_opportunites(connection):
    user = "LANCE.ORNER@ORACLE.COM"
    query = f"select * from OPPORTUNITIES where created_by = '{user}' "
    files_uploaded = pandas.read_sql(query, con=connection)

    opp_ids = files_uploaded["ID"]

    for opp_id in opp_ids:
        pprint.pprint(opp_id)
        query = f"""select * from dbc_databases where opp_id = '{opp_id}' """

        databases = pandas.read_sql(query, con=connection)
        pprint.pprint(databases)


def main():
    # Need to set the library home.  "Library not found" if not set
    cx_Oracle.init_oracle_client(os.environ["ORACLE_HOME"])

    # TNS_ADMIN must be set to find dsn specified.  sqlnet.ora must have the right "DIRECTORY" setting
    assert os.environ["TNS_ADMIN"]

    # Password is stored in an environment variable, not here
    assert os.environ["SIZING5_PW"]

    connection = cx_Oracle.connect(
        user="sizing5", password=os.environ["SIZING5_PW"], dsn="production_low"
    )
    assert connection

    view_file_uploads(connection)
    # view_opportunites(connection)


if __name__ == "__main__":
    main()
