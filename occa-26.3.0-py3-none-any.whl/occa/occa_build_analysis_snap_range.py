import os
import pandas as pd
import datetime

from constants.Paths import FilePaths as fp

def build_analysis_snaps_time() -> pd.DataFrame:
    """
    This function builds an analysis of snapshots from a snapshots DataFrame and a properties DataFrame.

    It calculates the time between snapshots ('Snap Begin' and 'Snap End') and adds additional
    information from a properties DataFrame.

    Parameters:
    -----------
    snapDf : pd.DataFrame
       DataFrame containing snapshot data, with columns like 'DB_NAME', 'SNAP_ID', 'INSTANCE', and 'end'.

    propertiesDf : pd.DataFrame
       DataFrame containing property details, with at least the columns 'WHICH_DB' and 'Cohort'.

    awrFilePath : str
       The file path where the resulting DataFrame will be saved as a CSV file.

    Returns:
    --------
    None
    """

    snapDf = pd.read_csv(fp.AWR_COMPOSITE, parse_dates=["end"])
    propertiesDbDf = pd.read_csv(fp.AWR_PROPERTIES_ORIGINAL)
    # filtered = propertiesDbDf[propertiesDbDf['Cohort'] == 'excluded']
    # list_to_exclude = filtered['WHICH_DB'].unique().tolist()
    # propertiesDbDf = propertiesDbDf[propertiesDbDf['Cohort'] != 'excluded']
    # propertiesDbDf["Cohort"] = propertiesDbDf["Cohort"].fillna("unassigned")
    propertiesDbDf["cdb"] = propertiesDbDf["cdb"].fillna(propertiesDbDf["WHICH_DB"])
    # snapDf = snapDf[~snapDf['WHICH_DB'].isin(list_to_exclude)]

    analysis_df = snapDf.sort_values(["WHICH_DB", "SNAP_ID", "INSTANCE"])
    analysis_df = (
        analysis_df.groupby(["WHICH_DB"])
        .agg(Snap_Begin=("end", "first"), Snap_End=("end", "last"))
        .reset_index()
    )

    # Formating and getting the days based on snaps
    analysis_df["Days"] = (
        (analysis_df["Snap_End"] - analysis_df["Snap_Begin"]).dt.total_seconds()
        / (24 * 3600)
    ).round(2)
    analysis_df["Snap_Begin"] = analysis_df["Snap_Begin"].dt.strftime("%y/%d/%m %H:%M")
    analysis_df["Snap_End"] = analysis_df["Snap_End"].dt.strftime("%y/%d/%m %H:%M")

    # Merge the cohort name
    analysis_df = pd.merge(
        analysis_df, propertiesDbDf[["WHICH_DB", "Cohort"]], on="WHICH_DB", how="left"
    )

    analysis_df = analysis_df.rename(
        columns={ "Snap_Begin": "Snap Begin", "Snap_End": "Snap End"}
    )

    # Re-organize columns to have Cohort on first column
    cols = ["Cohort"] + [col for col in analysis_df.columns if col != "Cohort"]
    analysis_df = analysis_df[cols]

    analysis_df["Snap Begin"] = pd.to_datetime(
        analysis_df["Snap Begin"], format="%y/%d/%m %H:%M", dayfirst=True
    )
    analysis_df["Snap End"] = pd.to_datetime(
        analysis_df["Snap End"], format="%y/%d/%m %H:%M", dayfirst=True
    )

    # getting the timezone .csv to merge and get the tz offset
    tz_data = pd.read_csv(fp.AWR_TZ_ORIGINAL)

    analysis_df = analysis_df.merge(tz_data, on="WHICH_DB", how="left")

    analysis_df[["Time Zone Offset", "Snap Begin GMT", "Snap End GMT"]] = (
        analysis_df.apply(adjust_to_gmt, axis=1)
    )

    # Removing columns from tz merged previously (needed for calculos need to be removed)
    analysis_df = analysis_df.drop(
        columns=[
            "TZ",
            "MINUTES_DIFF_FROM_UTC_list",
            "snaps_with_tz_offset_count",
            "snaps_missing_tz_offset_count",
        ]
    )

    analysis_df.to_csv(fp.AWR_ANALYSIS_SNAPS_DATA, index=False)

    if os.environ.get("RUN_FROM_API", "False") == "True":
        pass



def adjust_to_gmt(row):
    offset_minutes = row[
        "MINUTES_DIFF_FROM_UTC_list"
    ]  # getting the offset from the merged tz
    offset_hours = offset_minutes / 60  # Hours

    val = row["MINUTES_DIFF_FROM_UTC_list"]
    if pd.isna(val):
        offset_hours = 0

    begin_gmt = row["Snap Begin"] - datetime.timedelta(hours=offset_hours)
    end_gmt = row["Snap End"] - datetime.timedelta(hours=offset_hours)
    return pd.Series([offset_hours, begin_gmt, end_gmt])