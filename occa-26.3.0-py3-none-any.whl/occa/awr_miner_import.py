import argparse
import datetime
import getpass
import hashlib
import json
import re
import numpy as np
import os
import platform
from typing import List

import pandas
import pandas as pd
import sys
import time
import logging

import simplejson
from pandas.errors import MergeError

from pathlib import Path

from version import version, __version__
from occa_Shared import raise_error_when_run_from_api

# Print everything to stdout
logging.basicConfig(stream=sys.stdout, format="%(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# Create a flag to enable pretty printing of json output for troubleshooting purposes
JSON_OUTPUT_PRETTY_PRINT = False

# Flags to enable the dump of blocks
dump_db_parameters = True
dump_top_sql = True
dump_top_sql_by_snapshot = False
dump_segment_io = True
PLOT_UPLOAD_HTML = True

# Flag to allow bypass of detected excluded databases an instances
ALLOW_EXCLUDED = False

# Define constants
current_path = Path().resolve()
output_filename = os.path.join("awr_miner_occa", "awr_occa_upload_data.json")
application_endpoint = f"https://occa.us.oracle.com/ords/f?p=500"


def generate_cohort_rollup(
    database_df: pd.DataFrame, sizing_df: pd.DataFrame
) -> pd.DataFrame:
    # Need a pandas pivot table to put the per cohort and metric in as columns

    # select value
    # group by cdb_cohort, metric, adjusted
    # where summary_of = 'cdb_cohort'
    cohort_df = sizing_df[sizing_df["summary_of"] == "cdb_cohort"]
    cohort_pivot = cohort_df.pivot(
        index=["cdb_cohort", "adjusted"], columns="metric", values="peak"
    )
    cohort_pivot = cohort_pivot.reset_index()
    cohort_pivot["included_count"] = 0
    cohort_pivot["excluded_count"] = 0
    excluded_count = (
        database_df[database_df["excluded"] == "excluded"].groupby("cdb_cohort").size()
    )
    cohort_df.set_index("cdb_cohort")
    # new_df = cohort_df.merge(excluded_count, on="cdb_cohort")
    return cohort_pivot


def pivot_database_metrics(
    database_df: pd.DataFrame, sizing_df: pd.DataFrame
) -> pd.DataFrame:
    sizing_metrics_df = sizing_df[sizing_df["summary_of"] == "cdb"]
    sizing_metrics_df = sizing_metrics_df.pivot(
        index=["cdb_cohort", "cdb", "adjusted"], columns="metric", values="peak"
    )
    sizing_metrics_df = sizing_metrics_df.reset_index()
    return sizing_metrics_df


def write_to_file(filename, data):
    """
    Write content into a file.

    Parameters:
        filename : str
            The Absolute path to the file to write
        data : str
            The data to write
    """
    with open(filename, "w", encoding="UTF-8") as data_file:
        data_file.write(data)
        logger.info(f"\nCreated AWR Collection Import file:  {filename}")


def read_csv_if_exists(csv_filename) -> pd.DataFrame:
    """
    Read a CSV file and load it content into a DataFrame

    Parameters:
        csv_filename : Path
            Path to the csv file to be read

    Returns:
        panda.DataFrame : panda.DataFrame
            DataFrame containing the data from the file
    """
    if os.path.exists(csv_filename):
        return pd.read_csv(csv_filename)
    else:
        return pd.DataFrame()


def get_db_parameters_block(
    databases_dict: dict, if1: str, if2: str
) -> pandas.DataFrame:
    """
    Create a DataFrame merging the contents of DATABASE-PARAMETERS.csv and
    DATABASE-PARAMTERS2.csv.

    Parameters:
        databases_dict : dict
            The dict containing the databases information
        if1 : str
            The DATABASE-PARAMETERS.csv file
        if2 : str
            The  DATABASE-PARAMETERS2.csv file

    Returns:
        pandas.DataFrame : pandas.DataFrame
            The DataFrame containing the DATABASE-PARAMETERS information
    """

    database_parameters_df = pd.DataFrame()
    database_parameters_file = if1
    database_parameters2_file = if2

    if dump_db_parameters:
        db_param_df = pd.DataFrame()
        db_param2_df = pd.DataFrame()

        for db, pth in databases_dict.items():
            # Process DATABASE-PARAMETERS block
            db_params_per_db_df = read_csv_if_exists(
                os.path.join(pth, database_parameters_file)
            )
            db_params_per_db_df["cdb"] = db

            if "INSTANCE_NUMBER" not in db_params_per_db_df:
                db_params_per_db_df["INSTANCE_NUMBER"] = 1

            db_param_df = pd.concat(
                [db_param_df, db_params_per_db_df], axis=0, ignore_index=True
            )

            # Process DATABASE-PARAMETERS2 block when present
            db_params2_per_db_df = read_csv_if_exists(
                os.path.join(pth, database_parameters2_file)
            )
            if not db_params2_per_db_df.empty:
                db_params2_per_db_df["cdb"] = db
                db_param2_df = pd.concat(
                    [db_param2_df, db_params2_per_db_df], axis=0, ignore_index=True
                )

        # Merge both blocks as they contain reduntant information, although db_param2_df could be empty
        try:
            database_parameters_df = pd.merge(
                left=db_param_df, right=db_param2_df, how="outer"
            )
        except MergeError:
            database_parameters_df = db_param_df

    return database_parameters_df


def get_top_sql_statements_block(databases_dict: dict, fil: str) -> pandas.DataFrame:
    """
    Create a DataFrame with the contents of TOP-SQL-SUMMARY.csv.

    Parameters:
        databases_dict : dict
            The dict containing the databases information
        fil : str
            The TOP-SQL-SUMMARY.csv file

    Returns:
        pandas.DataFrame : pandas.DataFrame
            The DataFrame containing the TOP-SQL-SUMMARY information
    """

    top_sql_df = pd.DataFrame()
    top_sql_summary_file = fil

    if dump_top_sql:
        for db, pth in databases_dict.items():
            top_sql_per_db_df = read_csv_if_exists(
                os.path.join(pth, top_sql_summary_file)
            )
            top_sql_per_db_df["cdb"] = db
            top_sql_df = pd.concat(
                [top_sql_df, top_sql_per_db_df], axis=0, ignore_index=True
            )

    return top_sql_df


def get_top_sql_statements_by_snap_id_block(
    databases_dict: dict, fil: str
) -> pandas.DataFrame:
    """
    Create a DataFrame with the contents of TOP-SQL-BY-SNAPID.csv.

    Parameters:
        databases_dict : dict
            The dict containing the databases information
        fil : str
            The TOP-SQL-BY-SNAPID.csv file

    Returns:
        pandas.DataFrame : pandas.DataFrame
            The DataFrame containing the TOP-SQL-BY-SNAPID information
    """

    top_sql_by_snap_df = pd.DataFrame()
    top_sql_by_snapid_file = fil

    if dump_top_sql_by_snapshot:
        for db, pth in databases_dict.items():
            top_sql_per_db_by_snap_df = read_csv_if_exists(
                os.path.join(pth, top_sql_by_snapid_file)
            )
            top_sql_per_db_by_snap_df["cdb"] = db
            top_sql_by_snap_df = pd.concat(
                [top_sql_by_snap_df, top_sql_per_db_by_snap_df],
                axis=0,
                ignore_index=True,
            )

    return top_sql_by_snap_df


def get_segment_io_block(databases_dict: dict, fil: str) -> pandas.DataFrame:
    """
    Create a DataFrame with the contents of SEGMENT-IO.csv.

    The columns are normalized in the DataFrame created renaming some columns expected from old collections.
    For those columns containing dates are normalized to  ISO 8601 format or either discarded if the normalization
    is not successful.

    The number of rows returned in the dataframe is limited following some conditions.

    Parameters:
        databases_dict : dict
            The dict containing the databases information
        fil : str
            The SEGMENT-IO.csv file

    Returns:
        pandas.DataFrame : pandas.DataFrame
            The DataFrame containing the SEGMENT-IO information
    """

    segment_io_df = pd.DataFrame()
    segment_io_file = fil
    limit_by_rows = 1000
    limit_by_pct = 99

    if dump_segment_io:
        for db, pth in databases_dict.items():
            segment_io_per_db_df = read_csv_if_exists(
                os.path.join(pth, segment_io_file)
            )

            # Backward compatibility for SIZING_UPLOAD package for collections obtained before change
            # https://orahub.oci.oraclecorp.com/maa-pe-engsys/maa-pe-engsw-emcc-sizing/-/commit/c541614c3fb36fffc9daaab9422d54805200a09a
            if (
                "RUNNING_SEG_PHYSCIAL_IO_PCT_OF_TOT" in segment_io_per_db_df
                and "RUNNING_PHYSCIAL_IO_PCT_OF_TOT" in segment_io_per_db_df
            ):
                segment_io_per_db_df.rename(
                    columns={
                        "RUNNING_SEG_PHYSCIAL_IO_PCT_OF_TOT": "RUN_SEG_PHYS_IO_PCT_OF_TOT",
                        "RUNNING_PHYSCIAL_IO_PCT_OF_TOT": "RUN_PHYSCIAL_IO_PCT_OF_TOT",
                    },
                    inplace=True,
                )

            # Limit the dataframe rows to the less value of : 1000 rows or those rows with RUN_PHYSCIAL_IO_PCT_OF_TOT <= 99%
            if "RUN_PHYSCIAL_IO_PCT_OF_TOT" in segment_io_per_db_df:
                segment_io_per_db_df_sorted = segment_io_per_db_df.sort_values(
                    "RUN_PHYSCIAL_IO_PCT_OF_TOT"
                )
                segment_io_per_db_by_thousend_df = segment_io_per_db_df_sorted.head(
                    limit_by_rows
                )
                segment_io_per_db_by_pct_df = segment_io_per_db_df_sorted[
                    segment_io_per_db_df_sorted["RUN_PHYSCIAL_IO_PCT_OF_TOT"]
                    <= limit_by_pct
                ]

                # Discard database if there are no rows less or equal the limit_by_pct value
                if segment_io_per_db_by_pct_df.empty:
                    continue

                if (
                    segment_io_per_db_by_pct_df.shape[0]
                    < segment_io_per_db_by_thousend_df.shape[0]
                ):
                    segment_io_per_db_df = segment_io_per_db_by_pct_df.copy()
                else:
                    segment_io_per_db_df = segment_io_per_db_by_thousend_df.copy()

            # Convert datetime columns to ISO 8601 format , these columns come in csv with format 'YYYY/MON/DD HH24:MI:SS'
            if (
                "STARTUP_TIME" in segment_io_per_db_df
                and "REPORT_TIME_UTC" in segment_io_per_db_df
            ):
                segment_io_per_db_df["STARTUP_TIME"] = pd.to_datetime(
                    segment_io_per_db_df.STARTUP_TIME,
                    format="%Y/%b/%d %H:%M:%S",
                    errors="coerce",
                )
                segment_io_per_db_df["STARTUP_TIME"] = segment_io_per_db_df[
                    "STARTUP_TIME"
                ].dt.strftime("%y-%m-%dT%H:%M:%S")

                segment_io_per_db_df["REPORT_TIME_UTC"] = pd.to_datetime(
                    segment_io_per_db_df.REPORT_TIME_UTC,
                    format="%Y/%b/%d %H:%M:%S",
                    errors="coerce",
                )
                segment_io_per_db_df["REPORT_TIME_UTC"] = segment_io_per_db_df[
                    "REPORT_TIME_UTC"
                ].dt.strftime("%y-%m-%dT%H:%M:%S")

                count_nan_in_report_time_col = (
                    segment_io_per_db_df["REPORT_TIME_UTC"].isnull().sum()
                )
                count_nan_in_startup_time_col = (
                    segment_io_per_db_df["STARTUP_TIME"].isnull().sum()
                )
                total_rows = len(segment_io_per_db_df)
                if (
                    count_nan_in_report_time_col > 0
                    or count_nan_in_startup_time_col > 0
                ):
                    file_with_nan = os.path.join(pth, segment_io_file)
                    logger.warning(
                        f" File : {file_with_nan} contains rows with unparseable date format:"
                    )
                    if count_nan_in_report_time_col > 0:
                        logger.warning(
                            f"        Column REPORT_TIME_UTC :  {count_nan_in_report_time_col} rows [{str(total_rows)}]"
                        )
                    if count_nan_in_startup_time_col > 0:
                        logger.warning(
                            f"        Column STARTUP_TIME :  {count_nan_in_report_time_col}  rows [{str(total_rows)}]"
                        )
                    logger.warning(
                        f"        These rows have been skipped from the import"
                    )

            segment_io_per_db_df["cdb"] = db
            segment_io_df = pd.concat(
                [segment_io_df, segment_io_per_db_df], axis=0, ignore_index=True
            )

    return segment_io_df


def get_path_to_db_files(
    awr_miner_parsed_path: Path, databases_df: pandas.DataFrame
) -> dict:
    """
    Build a dict using the database_name as key and path to the database files as value

    Parameters:
        awr_miner_parsed_path : Path
            The path to the awr_miner_patsed directory
        databases_df : pandas.DataFrame
            The DataFrame containing the databases information

    Returns:
        dict : dict
            The dict with the path information to the parsed files for each database
    """

    which_db_pattern = re.compile(r"(db)_(.*)_(\d+)-(\d+)-(\d+)")

    # Get the list of databases
    db_to_path_dict = {}
    which_db = []
    for i in list(databases_df):
        if i == "cdb":
            which_db = databases_df[i].tolist()
            break

    if len(which_db) > 0:
        # For each Database
        for db in which_db:

            #Excluded DBs comes as nan
            if pd.isna(db):
                continue
            # Get the values from the which_db field
            match_groups = re.search(which_db_pattern, db)
            if match_groups:
                dbname = match_groups.group(2)
                dbid = match_groups.group(3)
                dbdir = "_".join([match_groups.group(1), dbname, dbid])
                minsnap = match_groups.group(4)
                maxsnap = match_groups.group(5)
                dbsubdir = "-".join(["awr", "hist", dbid, dbname, minsnap, maxsnap])

                pth = os.path.join(awr_miner_parsed_path, dbdir, dbsubdir)
                db_to_path_dict[db] = pth


            else :
                # Get the values from the File System if cdb field has been modified by the customer in the properties files
                # and it is not following the expected format for the generated which_db column
                parent = awr_miner_parsed_path.parent
                awr_miner_plots_path = parent / "awr_miner_plots"
                which_db = [f for f in os.listdir(awr_miner_plots_path) if f.endswith('.html')]

                for db in which_db:
                    # Get the values from the which_db field
                    match_groups = re.search(which_db_pattern, db)
                    if match_groups:
                        dbname = match_groups.group(2)
                        dbid = match_groups.group(3)
                        dbdir = "_".join([match_groups.group(1), dbname, dbid])
                        minsnap = match_groups.group(4)
                        maxsnap = match_groups.group(5)
                        dbsubdir = "-".join(["awr", "hist", dbid, dbname, minsnap, maxsnap])
                    pth = os.path.join(awr_miner_parsed_path, dbdir, dbsubdir)
                    db_to_path_dict[db] = pth
                return db_to_path_dict

    return db_to_path_dict


def get_db_version_from_os_info_block(
    databases_dict: dict, fil: str
) -> pandas.DataFrame:
    """
    Build a DataFrame collecting the database version field from the OS-INFORMATION block.

    Parameters:
        databases_dict : dict
            The databases_to_path dict
        fil : str
            The OS-INFORMATION.csv file

    Returns:
        pandas.DataFrame : pandas.DataFrame
            The DataFrame containing the database_name and the database_version information
    """

    os_info_df = pd.DataFrame()
    os_info_file = fil
    cdb_to_cdb_version_dict = {}

    for db, pth in databases_dict.items():
        os_info_per_db_df = read_csv_if_exists(os.path.join(pth, os_info_file))
        os_info_per_db_df["cdb"] = db
        os_info_df = pd.concat(
            [os_info_df, os_info_per_db_df], axis=0, ignore_index=True
        )

        # Get the DB version
        cdb_version = " "
        if "VERSION" in os_info_per_db_df["STAT_NAME"].unique():
            cdb_version = os_info_per_db_df[
                os_info_per_db_df["STAT_NAME"] == "VERSION"
            ]["STAT_VALUE"].values[0]
        cdb_to_cdb_version_dict[db] = cdb_version

    # Convert the dict to dataframe
    cdb_to_cdb_version_df = pd.DataFrame(
        cdb_to_cdb_version_dict.items(), columns=["cdb", "cdb_version"]
    )
    cdb_to_cdb_version_df = cdb_to_cdb_version_df.replace("^\\s*$", np.nan, regex=True)

    return cdb_to_cdb_version_df


def get_awr_miner_version_from_os_info_block(
    databases_dict: dict, fil: str
) -> pandas.DataFrame:
    """
    Build a DataFrame collecting the AWR Miner version field from the OS-INFORMATION block.

    Parameters:
        databases_dict : dict
            The databases_to_path dict
        fil : str
            The OS-INFORMATION.csv file

    Returns:
        pandas.DataFrame : pandas.DataFrame
            The DataFrame containing the database_name and the AWR Miner version information
    """

    os_info_df = pd.DataFrame()
    os_info_file = fil
    cdb_to_miner_version_dict = {}

    for db, pth in databases_dict.items():
        os_info_per_db_df = read_csv_if_exists(os.path.join(pth, os_info_file))
        os_info_per_db_df["cdb"] = db
        os_info_df = pd.concat(
            [os_info_df, os_info_per_db_df], axis=0, ignore_index=True
        )

        # Get the DB version
        awr_miner_version = " "
        if "AWR_MINER_VER" in os_info_per_db_df["STAT_NAME"].unique():
            awr_miner_version = os_info_per_db_df[
                os_info_per_db_df["STAT_NAME"] == "AWR_MINER_VER"
            ]["STAT_VALUE"].values[0]
        cdb_to_miner_version_dict[db] = awr_miner_version

    # Convert the dict to dataframe
    cdb_to_miner_version_df = pd.DataFrame(
        cdb_to_miner_version_dict.items(), columns=["cdb", "awr_miner_version"]
    )
    cdb_to_miner_version_df = cdb_to_miner_version_df.replace(
        "^\\s*$", np.nan, regex=True
    )

    return cdb_to_miner_version_df


def read_all_html_plots(plots_path: Path) -> List[dict]:
    """
    Read the html plots based on the file_pattern defined from disk into a structure.

    Parameters:
        plots_path : Path
            The Path to the awr_miner_occa/sizing/plots directory
    Returns:
        list[dict] : list[dict]
            The list of dicts containing the metadata and the content for the selected files
    """

    output = []

    file_patterns = ("**/*_DB_vCPU_unadjusted.html", "**/*_awr_snap_coverage.html")
    plot_path = Path(plots_path).resolve()

    if PLOT_UPLOAD_HTML:
        logger.debug(f"Reading html plots from {plot_path}")
        if not plot_path.exists():
            logger.error(f"Plot path {plot_path} doesn't exist")
            return output

        # Create the list of files
        file_list = []
        for f in file_patterns:
            file_list.extend(plot_path.glob(f))

        for html_file in file_list:
            logger.debug(f"Reading {html_file}")
            cohort_name = html_file.name.split("_")[0]

            file_data = {
                "cohort": cohort_name,
                "file_name": html_file.name,
                "file_content": html_file.read_text(encoding="UTF-8"),
                "import_source": "AWR_EXTRACT",
            }

            file_data["individual_plots"] = (
                1 if "individual_plots" in html_file.parts else 0
            )

            output.append(file_data)

        return output


def filter_cohort_rollups(df: pandas.DataFrame) -> pandas.DataFrame:
    """
    Filter data in cohort_rollups_df DataFrame.

    The rows in the DataFrame for cohort name exclude or unassigned are removed from the DataFrame.
    If after the removal there are not rows in the DataFrame an error is reported into the logger
    notifying that the cohorts have not been assigned and the process can't continue.

    Parameters:
        df : pandas.DataFrame
            The cohort_rollups DataFrame
    Return:
        panda.DataFrame : panda.DataFrame
            A cohort_rollups DataFrame where unassigned and excluded cohorts have been removed

    """

    output_df = pandas.DataFrame()
    from_file_cohorts_count = len(df)

    # Grab the rows where Database Included is greater than 0
    output_df = df[df["Databases Included"] > 0]
    database_included_count = len(output_df)

    # Grab the rows where the cohort is not set to unassigned
    output_df = output_df[output_df["Name"] != "unassigned"]
    df_unassigned = df[df["Name"] == "unassigned"]
    unsassigned_cohorts_count = len(df_unassigned)

    # Grab the rows where the cohort is not set to exclude
    output_df = output_df[output_df["Name"] != "exclude"]
    df_excluded = df[df["Name"] == "exclude"]
    excluded_cohorts_count = len(df_excluded)
    error_message = "Cohort Rollups not found in the collection!"
    if output_df.empty:
        logger.critical(f"ERROR : " + error_message)
        logger.critical(
            f"        Total[{from_file_cohorts_count}] "
            f"included[{database_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{database_included_count - unsassigned_cohorts_count - excluded_cohorts_count }]"
        )
        raise_error_when_run_from_api("AWR: ",error_message.strip())
    else:
        logger.info(
            f"Cohort   Rollups Summary : "
            f"Total[{from_file_cohorts_count}] "
            f"included[{database_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{database_included_count - unsassigned_cohorts_count - excluded_cohorts_count }]"
        )
    return output_df


def filter_database_rollups(df: pandas.DataFrame) -> pandas.DataFrame:
    """
    Filter data in database_rollups_df dataframe.

    The rows in the DataFrame for cohort name exclude or unassigned are removed from the DataFrame.
    If after the removal there are no rows in the DataFrame an error is reported into the logger
    notifying that the cohorts have not been assigned and the process can't continue.

    Parameters:
        df : pandas.DataFrame
            The database_rollups DataFrame
    Return:
        panda.DataFrame : panda.DataFrame
            A database_rollups_df DataFrame where unassigned and excluded cohorts have been removed

    """
    output_df = pandas.DataFrame()
    from_file_cohorts_count = len(df)

    output_df = df[df["Instances Included"] > 0]
    instances_included_count = len(output_df)

    output_df = output_df[output_df["Cohort"] != "unassigned"]
    df_unassigned = df[df["Cohort"] == "unassigned"]
    unsassigned_cohorts_count = len(df_unassigned)

    output_df = output_df[output_df["Cohort"] != "exclude"]
    df_excluded = df[df["Cohort"] == "exclude"]
    excluded_cohorts_count = len(df_excluded)

    if output_df.empty:
        error_message = "Database Rollups not found in the collection!"
        logger.critical("ERROR : " + error_message)
        logger.critical(
            f"        Total[{from_file_cohorts_count}] "
            f"included[{instances_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{instances_included_count - unsassigned_cohorts_count - excluded_cohorts_count}]"
        )

        raise_error_when_run_from_api("AWR: ",error_message.strip())

    else:
        logger.info(
            f"Database Rollups Summary : "
            f"Total[{from_file_cohorts_count}] "
            f"included[{instances_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{instances_included_count - unsassigned_cohorts_count - excluded_cohorts_count}]"
        )

    return output_df


def create_database_names_hash(output_dict) -> str:
    """
    Create MD5 Hash over the list of database names present in the collection.

    Parameters:
        output_dict : dict
            The dict containing the databases key after processing the files for import
    Returns:
        str : str
            The resulting MD5 Hash of joining all the database_names in the collection

    """
    database_names_list = []

    if "databases" in output_dict:
        for rec in output_dict["databases"]:
            database_name = rec["cdb"]
            #Excluded dbs comes as nan
            if pd.isna(database_name):
                continue
            database_names_list.append(database_name)
        database_names_str = " ".join(database_names_list)
        database_names_bytes = hashlib.md5(database_names_str.encode())
        database_names_hash = database_names_bytes.hexdigest()
    else:
        database_names_hash = ""

    return database_names_hash


def print_banner():
    """
    Print to stdout the tool banner.
    """
    logger.info(
        "======================================================================================================="
    )
    logger.info(sys.argv[0] + ", version " + __version__)
    logger.info("sys.version_info  : " + str(sys.version_info))
    logger.info("platform.system() : " + str(platform.system()))
    logger.info("numpy.__version__ : " + np.__version__)
    logger.info("pandas.__version__: " + pd.__version__)
    logger.info(
        "======================================================================================================="
    )
    logger.info(" ")


def check_dirs(working_path) -> bool:
    """
    Verify the needed directories exists to run this program

    Parameters:
        working_path : Path
            The absolute path of the current working directoru
    Returns:
        bool : bool
            True if all the needed directories are present , False otherwsie

    """

    sizing_pathname = os.path.join(working_path, "awr_miner_occa", "sizing")
    if not os.path.isdir(sizing_pathname):
        logger.critical(f"\nERROR: Directory {sizing_pathname} doesn't exist\n")
        return False

    parsed_pathname = os.path.join(working_path, "awr_miner_parsed")
    if not os.path.isdir(parsed_pathname):
        logger.critical(f"\nERROR: Directory {parsed_pathname} doesn't exist\n")
        return False

    properties_pathname = os.path.join(working_path, "awr_miner_occa", "properties")
    if not os.path.isdir(properties_pathname):
        logger.critical(f"\nERROR: Directory {properties_pathname} doesn't exist\n")
        return False

    plots_pathname = os.path.join(working_path, "awr_miner_occa", "plot", "unadjusted")
    if not os.path.isdir(plots_pathname):
        logger.critical(f"\nERROR: Directory {plots_pathname} doesn't exist\n")
        return False

    return True


def check_excluded_databases(db_df: pandas.DataFrame) -> bool:
    """
    Check the contents of the file databases.csv to verify that there are no excluded databases
    in the file generated by the awr-run command.

    Parameters:
        db_df : pandas.DataFrame
            The databases dataframe
    Return:
        bool : bool
            True if there are databases excluded

    """
    if not ALLOW_EXCLUDED:
        # Filter excluded and unassigned cohorts
        filtered_db_df = db_df[
            (db_df["cdb_cohort"] != "unassigned") & (db_df["cdb_cohort"] != "excluded")
        ]

        # Filter the rows without excluded reason
        filtered_db_df = filtered_db_df[filtered_db_df.excluded_reason.notnull()]

        if len(filtered_db_df) > 0:
            logger.critical(
                f"ERROR : The databases.csv file contains {len(filtered_db_df)} excluded databases!\n\n"
                f" These must be fixed before upload the file into OCCA Web.\n"
                f" Review the OCCA User Guide to figure out the exclusion reason and how to resolve it.\n"
            )

            return True

    return False


def check_excluded_instances(inst_df: pandas.DataFrame) -> bool:
    """
    Check the contents of the file instances.csv to verify that there are no excluded databases
    in the file generated by the awr-run command.

    Parameters:
        inst_df : pandas.DataFrame
            The databases dataframe
    Return:
        bool : bool
            True if there are databases excluded

    """
    if not ALLOW_EXCLUDED:
        # Filter excluded and unassigned cohorts
        filtered_inst_df = inst_df[
            (inst_df["cdb_cohort"] != "unassigned")
            & (inst_df["cdb_cohort"] != "excluded")
        ]

        # Filter the rows without excluded reason
        filtered_inst_df = filtered_inst_df[filtered_inst_df.excluded_reason.notnull()]

        if len(filtered_inst_df) > 0:
            logger.critical(
                f"ERROR : The instances.csv file contains {len(filtered_inst_df)} excluded instances!\n\n"
                f" These must be fixed before upload the file into OCCA Web.\n"
                f" Review the OCCA User Guide to figure out the exclusion reason and how to resolve it.\n"
            )
            return True

    return False


def create_input_json(write_file=True):
    """
    Create the awr_occa_upload_data.json file to be imported into OCCA Web.

    Parameters:
        write_file : bool
            Flag to enable the write of the content to the output file

    """
    global current_path
    current_path = Path().resolve()
    if os.environ.get("RUN_FROM_API", "False") == "True":
        current_path = os.getcwd()
    logger.info(
        "Begin @ " + datetime.datetime.now(datetime.timezone.utc).isoformat() + " UTC"
    )

    # Print the tool banner
    print_banner()

    # Check directories
    if not (check_dirs(current_path)):
        exit(1)

    # Set the directories
    sizing_pathname = Path(os.path.join(current_path, "awr_miner_occa", "sizing"))
    parsed_pathname = Path(os.path.join(current_path, "awr_miner_parsed"))
    properties_pathname = Path(
        os.path.join(current_path, "awr_miner_occa", "properties")
    )
    plots_pathname = Path(
        os.path.join(current_path, "awr_miner_occa", "plot", "unadjusted")
    )

    # Get databases information
    databases_df = read_csv_if_exists(os.path.join(sizing_pathname, "databases.csv"))

    # Check for excluded databases
    if check_excluded_databases(databases_df):
        exit(1)

    # Get the Path to the loaded databases
    databases_to_path_dict = get_path_to_db_files(parsed_pathname, databases_df)

    # Add DB version to databases_df
    cdb_to_cdb_versions_df = get_db_version_from_os_info_block(
        databases_to_path_dict, "OS-INFORMATION.csv"
    )
    databases_df = pd.merge(
        left=databases_df,
        right=cdb_to_cdb_versions_df,
        how="left",
        left_on=["cdb"],
        right_on=["cdb"],
    )

    # Add AWR Miner version to databases_df
    cdb_to_awr_miner_version_df = get_awr_miner_version_from_os_info_block(
        databases_to_path_dict, "OS-INFORMATION.csv"
    )
    databases_df = pd.merge(
        left=databases_df,
        right=cdb_to_awr_miner_version_df,
        how="left",
        left_on=["cdb"],
        right_on=["cdb"],
    )

    # Process Cohort Rollups
    cohort_rollups_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "cohort_rollups.csv")
    )
    error_message = "Cohort Rollups not found in the collection!"
    if cohort_rollups_df.empty:
        logger.critical(f"ERROR : " + error_message)
        raise_error_when_run_from_api("AWR: ",error_message.strip())
        exit(1)

    # Filter out unused entries in cohort rollups
    cohort_rollups_df = filter_cohort_rollups(cohort_rollups_df)
    if cohort_rollups_df.empty:
        exit(1)

    # Process Database Rollups
    database_rollups_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "database_rollups.csv")
    )
    if database_rollups_df.empty:
        error_message = "Database Rollups not found in the collection!"
        logger.critical(f"ERROR : " + error_message)
        raise_error_when_run_from_api("AWR: ",error_message.strip())
        exit(1)

    # Filter out unused entries in database rollups
    database_rollups_df = filter_database_rollups(database_rollups_df)
    if database_rollups_df.empty:
        exit(1)

    # Check for excluded instances
    instances_df = read_csv_if_exists(os.path.join(sizing_pathname, "instances.csv"))
    if check_excluded_instances(instances_df):
        exit(1)

    hosts_df = read_csv_if_exists(os.path.join(sizing_pathname, "servers.csv"))
    sizing_df = read_csv_if_exists(os.path.join(sizing_pathname, "sizing.csv"))
    database_statistics_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "database_statistics.csv")
    )
    cohort_statistics_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "cohort_statistics.csv")
    )
    adjustments_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "adjustments.csv")
    )
    metric_presence_by_stage_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "metric_presence_by_stage.csv")
    )
    database_vcpu_hours_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "database_vcpu_hours.csv")
    )
    database_parameters_df = get_db_parameters_block(
        databases_to_path_dict, "DATABASE-PARAMETERS.csv", "DATABASE-PARAMETERS2.csv"
    )
    top_sql_df = get_top_sql_statements_block(
        databases_to_path_dict, "TOP-SQL-SUMMARY.csv"
    )
    top_sql_by_snap_df = get_top_sql_statements_by_snap_id_block(
        databases_to_path_dict, "TOP-SQL-BY-SNAPID.csv"
    )
    segment_io_df = get_segment_io_block(databases_to_path_dict, "SEGMENT-IO.csv")
    properties_database_df = read_csv_if_exists(
        os.path.join(properties_pathname, "awr_properties_database.csv")
    )

    output_structure = {}
    output_structure["databases"] = databases_df.to_dict(orient="records")
    output_structure["hosts"] = hosts_df.to_dict(orient="records")
    output_structure["instances"] = instances_df.to_dict(orient="records")
    # output_structure["sizing_rollups"] = generate_cohort_rollup(databases_df, sizing_df).to_dict(orient="records")
    # output_structure["database_metrics"] = pivot_database_metrics(databases_df, sizing_df).to_dict(orient="records")
    output_structure["cohort_rollups"] = cohort_rollups_df.to_dict(orient="records")
    output_structure["database_rollups"] = database_rollups_df.to_dict(orient="records")
    output_structure["sizing"] = sizing_df.to_dict(orient="records")
    output_structure["database_statistics"] = database_statistics_df.to_dict(
        orient="records"
    )
    output_structure["cohort_rollups"] = cohort_rollups_df.to_dict(orient="records")
    output_structure["adjustments"] = adjustments_df.to_dict(orient="records")
    output_structure["metric_presence_by_stage"] = metric_presence_by_stage_df.to_dict(
        orient="records"
    )
    output_structure["database_vcpu_hours"] = database_vcpu_hours_df.to_dict(
        orient="records"
    )
    output_structure["database_parameters"] = database_parameters_df.to_dict(
        orient="records"
    )
    output_structure["top_sql"] = top_sql_df.to_dict(orient="records")
    output_structure["top_sql_by_snapshot"] = top_sql_by_snap_df.to_dict(
        orient="records"
    )
    output_structure["segment_io"] = segment_io_df.to_dict(orient="records")
    output_structure["properties_database"] = properties_database_df.to_dict(
        orient="records"
    )
    output_structure["plots_html"] = read_all_html_plots(plots_pathname)

    # Cleanup keys without values in the dict
    output_structure = {k: v for k, v in output_structure.items() if v}

    # Generation data
    output_structure["occa_version"] = version
    output_structure["input_source"] = "AWR_EXTRACT"
    output_structure["date_generated"] = datetime.datetime.now(
        datetime.timezone.utc
    ).isoformat()
    output_structure["user"] = getpass.getuser()
    output_structure["script_dir"] = str(Path(__file__).parent.resolve())
    output_structure["data_dir"] = str(Path(sizing_pathname).resolve())
    output_structure["database_names_hash"] = create_database_names_hash(
        output_structure
    )

    if JSON_OUTPUT_PRETTY_PRINT:
        output_json = json.dumps(output_structure, indent=2)
        # Python writes "NaN', Oracle expects "null".  Just replace it all
        output_json = output_json.replace("NaN", "null")
    else:
        output_json = simplejson.dumps(output_structure, ignore_nan=True)

    if write_file:
        write_to_file(
            os.path.join(current_path, output_filename),
            output_json,
        )

    logger.info(f"\nUpload file to: " + application_endpoint)

    logger.info(
        "\nEnd @ " + datetime.datetime.now(datetime.timezone.utc).isoformat() + " UTC\n"
    )
    return output_json


def main():
    global ALLOW_EXCLUDED, PLOT_UPLOAD_HTML

    argparser = argparse.ArgumentParser(
        prog="awr_miner_import.py",
        description="Create json file to upload to OCCA Web",
    )
    argparser.add_argument(
        "--allow-excluded",
        type=str,
        action="store",
        nargs="*",
        help="Allow excluded databases and instances if those are detected",
    )
    argparser.add_argument(
        "--not-upload-plots",
        type=str,
        action="store",
        nargs="*",
        help="Disable uploading of PLOT files",
    )
    args = argparser.parse_args()

    if args.allow_excluded is not None or os.environ.get("RUN_FROM_API") == "True" :
        ALLOW_EXCLUDED = True
    if args.not_upload_plots is not None:
        PLOT_UPLOAD_HTML = False

    create_input_json()


if __name__ == "__main__":
    main()
