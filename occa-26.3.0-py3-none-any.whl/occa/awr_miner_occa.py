"""
Create AWR Miner plots and json for uploading to OCCA

Much of the main code is from Tim Frazier's Jupyter notebooks

Todo:
    error handling
    override logic
    remaining metric plots
"""

import argparse
import datetime
import getpass
import json
import logging
import os
import pandas as pd
import plotly.express as px
import pprint
import pytz
import sys
from pathlib import Path
from dataclasses import dataclass, field

from version import version, __version__
from occa_Shared import raise_error_when_run_from_api

HEIGHT = 1185
WIDTH = 1920
PERCENTILES = [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 0.99]
CURRENT_PATH = Path(".").absolute()
PATH = CURRENT_PATH.__str__()

# Print everything to stdout
logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
logger = logging.getLogger(__file__)


@dataclass
class OccaStructures:
    databases: pd.DataFrame = None
    instances: pd.DataFrame = None
    database_statistics: pd.DataFrame = None
    cohort_statistics: pd.DataFrame = None


def convertToUTC(row):
    tz = pytz.timezone(row["TZ"])
    dtTZ = tz.localize(row["end_hh24"])
    dtUTC = dtTZ.astimezone(pytz.utc)

    return dtUTC.replace(tzinfo=None)


def get_parsed_data_dir():
    global PATH, TS
    data_path = CURRENT_PATH / "occa"

    # Multiple runs have multiple outputs.  Take the latest one unless told otherwise.
    data_dirs = data_path.glob("20*")
    latest_dir = max([f.name for f in data_dirs])
    latest_path = data_path / latest_dir
    assert latest_path.is_dir(), f"{latest_path} is not a directory"

    PATH = data_path.__str__()
    TS = latest_path.name

    logging.info(f"Getting data from {PATH}/{TS}")


def save_occa_json(occa_data):
    """
    Convert data to json and write to disk
    """
    output_structure = {}
    output_structure["database_rollups"] = occa_data.database_statistics.to_dict(
        orient="records"
    )
    output_structure["cohort_rollups"] = occa_data.cohort_statistics.to_dict(
        orient="records"
    )

    # Generation data
    output_structure["occa_version"] = version.version
    output_structure["date_generated"] = datetime.datetime.now(
        datetime.timezone.utc
    ).isoformat()
    output_structure["user"] = getpass.getuser()
    output_structure["script_dir"] = str(Path(__file__).parent.resolve())
    output_structure["data_dir"] = str(Path(CURRENT_PATH).resolve())

    output_json = json.dumps(output_structure, indent=2)
    # Python writes "NaN', Oracle expects "null".  Just replace it all
    output_json = output_json.replace("NaN", "null")

    output_path = CURRENT_PATH / "occa"
    output_path.mkdir(exist_ok=True)
    filename = output_path / "occa_upload_awr_data.json"
    logger.info(f"Writing file {filename}.")
    with open(filename, "w") as data_file:
        data_file.write(output_json)
        logger.info(f"Wrote File {filename}")

    logger.info("Upload file to: ")
    logger.info("https://occa.us.oracle.com/ords/f?p=500")


def main():
    occa_data = OccaStructures()

    outputPath = PATH + os.sep + TS + os.sep + "sizing"
    os.makedirs(outputPath, exist_ok=True)

    filename = PATH + os.sep + TS + os.sep + "occa_composite.csv"

    if not os.path.exists(filename):
        print(filename + " does not exist; cannot continue")
        assert False

    snapDf = pd.read_csv(filename, parse_dates=["end"])

    filename = PATH + os.sep + TS + os.sep + "awr_database_properties.csv"

    if not os.path.exists(filename):
        print(filename + " does not exist; cannot continue")
        assert False

    propertiesDf = pd.read_csv(filename)
    propertiesDf["Cohort"]=propertiesDf["Cohort"].fillna("unassigned")
    occa_data.database_statistics = propertiesDf

    # propertiesDf

    # Cohort 	DB_NAME 	Allocated Storage (GB) 	STOP 	Allocated Storage (GB).max 	DB vCPU.max 	DB PGA (MB).max 	DB SGA (MB).max 	DB Memory (MB).max 	DB IOPS.max 	... 	DB vCPU.min 	DB PGA (MB).min 	DB SGA (MB).min 	DB Memory (MB).min 	DB IOPS.min 	DB Logons.min 	cwd 	platform 	create_dttm_utc 	version
    # 0 	One 	AGAMA 	NaN 	STOP 	12.68 	0.194 	614.4 	2355.2 	2969.6 	101.9 	... 	0.002 	512.0 	1945.6 	2457.6 	6.3 	91.7 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 1 	One 	ANACONDA 	NaN 	STOP 	3.42 	0.047 	614.4 	2560.0 	3174.4 	29.4 	... 	0.002 	512.0 	2150.4 	2662.4 	6.6 	90.2 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 2 	One 	ANT 	NaN 	STOP 	150.80 	5.891 	1126.4 	2355.2 	3379.2 	905.4 	... 	0.001 	204.8 	1843.2 	2048.0 	4.5 	68.1 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 3 	One 	APE 	NaN 	STOP 	8.35 	0.046 	614.4 	1945.6 	2560.0 	51.7 	... 	0.002 	512.0 	1945.6 	2457.6 	6.5 	90.0 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 4 	One 	APHID 	NaN 	STOP 	53.00 	1.046 	716.8 	1945.6 	2662.4 	446.9 	... 	0.002 	512.0 	1843.2 	2457.6 	6.2 	90.8 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # ... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	...
    # 122 	unassigned 	WEEVIL 	NaN 	STOP 	4.11 	0.022 	716.8 	1843.2 	2560.0 	10.1 	... 	0.001 	512.0 	1843.2 	2355.2 	5.6 	81.0 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 123 	unassigned 	WHALE 	NaN 	STOP 	46.54 	0.060 	716.8 	2150.4 	2764.8 	47.7 	... 	0.002 	512.0 	1945.6 	2457.6 	6.3 	90.7 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 124 	unassigned 	WREN 	NaN 	STOP 	5.18 	0.024 	512.0 	2457.6 	2969.6 	61.2 	... 	0.001 	512.0 	2355.2 	2867.2 	7.5 	83.1 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 125 	unassigned 	YAK 	NaN 	STOP 	4.58 	0.142 	614.4 	2457.6 	2969.6 	86.4 	... 	0.002 	512.0 	2048.0 	2560.0 	6.4 	90.9 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5
    # 126 	unassigned 	ZEBRA 	NaN 	STOP 	99.08 	1.412 	819.2 	3993.6 	4812.8 	1068.3 	... 	0.000 	614.4 	3993.6 	4608.0 	6.4 	94.1 	true_commerce.01 	Darwin 	1/28/22 23:57 	21.1.5

    # 127 rows × 57 columns

    filename = PATH + os.sep + "awr_database_tz.csv"

    if not os.path.exists(filename):
        print(filename + " does not exist; cannot continue")
        assert False

    TZDf = pd.read_csv(filename)
    # TZDf

    # DB_NAME 	TZ 	MINUTES_DIFF_FROM_UTC_list 	snaps_with_tz_offset_count 	snaps_missing_tz_offset_count
    # 0 	AGAMA 	Antarctica/Casey 	480.0 	192 	23
    # 1 	ANACONDA 	Africa/Algiers 	60.0 	177 	21
    # 2 	ANT 	Antarctica/Casey 	480.0 	1660 	622
    # 3 	APE 	America/Atikokan 	-300.0 	184 	18
    # 4 	APHID 	America/Atikokan 	-300.0 	125 	78
    # ... 	... 	... 	... 	... 	...
    # 122 	WEEVIL 	America/Atikokan 	-300.0 	148 	61
    # 123 	WHALE 	America/Atikokan 	-300.0 	136 	68
    # 124 	WREN 	Antarctica/Casey 	480.0 	76 	132
    # 125 	YAK 	America/Atikokan 	-300.0 	81 	121
    # 126 	ZEBRA 	America/Atikokan 	-300.0 	43 	166

    # 127 rows × 5 columns

    snapDf["end_p_5"] = snapDf["end"] + pd.to_timedelta(5, unit="m")

    snapDf["end_hh24"] = snapDf["end_p_5"].dt.floor("h")

    # snapDf[['end', 'end_p_5', 'end_hh24']]

    # end 	end_p_5 	end_hh24
    # 0 	2022-01-17 06:59:00 	2022-01-17 07:04:00 	2022-01-17 07:00:00
    # 1 	2022-01-17 08:00:00 	2022-01-17 08:05:00 	2022-01-17 08:00:00
    # 2 	2022-01-17 09:00:00 	2022-01-17 09:05:00 	2022-01-17 09:00:00
    # 3 	2022-01-17 10:00:00 	2022-01-17 10:05:00 	2022-01-17 10:00:00
    # 4 	2022-01-17 11:00:00 	2022-01-17 11:05:00 	2022-01-17 11:00:00
    # ... 	... 	... 	...
    # 30714 	2022-01-25 12:59:00 	2022-01-25 13:04:00 	2022-01-25 13:00:00
    # 30715 	2022-01-25 13:59:00 	2022-01-25 14:04:00 	2022-01-25 14:00:00
    # 30716 	2022-01-25 15:00:00 	2022-01-25 15:05:00 	2022-01-25 15:00:00
    # 30717 	2022-01-25 16:00:00 	2022-01-25 16:05:00 	2022-01-25 16:00:00
    # 30718 	2022-01-25 16:59:00 	2022-01-25 17:04:00 	2022-01-25 17:00:00

    # 30719 rows × 3 columns

    snapDf = pd.merge(
        left=snapDf, right=TZDf, how="left", left_on=["DB_NAME"], right_on=["DB_NAME"]
    )
    snapDf["end_hh24_UTC"] = snapDf.apply(convertToUTC, axis=1)
    snapDf["end_dd_UTC"] = snapDf["end_hh24_UTC"].dt.floor("d")
    # snapDf[['end_hh24', 'TZ', 'end_hh24_UTC', 'end_dd_UTC']]

    # end_hh24 	TZ 	end_hh24_UTC 	end_dd_UTC
    # 0 	2022-01-17 07:00:00 	Antarctica/Casey 	2022-01-16 20:00:00 	2022-01-16
    # 1 	2022-01-17 08:00:00 	Antarctica/Casey 	2022-01-16 21:00:00 	2022-01-16
    # 2 	2022-01-17 09:00:00 	Antarctica/Casey 	2022-01-16 22:00:00 	2022-01-16
    # 3 	2022-01-17 10:00:00 	Antarctica/Casey 	2022-01-16 23:00:00 	2022-01-16
    # 4 	2022-01-17 11:00:00 	Antarctica/Casey 	2022-01-17 00:00:00 	2022-01-17
    # ... 	... 	... 	... 	...
    # 30714 	2022-01-25 13:00:00 	America/Atikokan 	2022-01-25 18:00:00 	2022-01-25
    # 30715 	2022-01-25 14:00:00 	America/Atikokan 	2022-01-25 19:00:00 	2022-01-25
    # 30716 	2022-01-25 15:00:00 	America/Atikokan 	2022-01-25 20:00:00 	2022-01-25
    # 30717 	2022-01-25 16:00:00 	America/Atikokan 	2022-01-25 21:00:00 	2022-01-25
    # 30718 	2022-01-25 17:00:00 	America/Atikokan 	2022-01-25 22:00:00 	2022-01-25

    # 30719 rows × 4 columns

    instAvgDf = snapDf.groupby(
        ["DB_NAME", "INSTANCE", "end_hh24_UTC", "end_dd_UTC"], as_index=False
    ).mean()

    dbHourlySumDf = instAvgDf.groupby(
        ["DB_NAME", "end_hh24_UTC", "end_dd_UTC"], as_index=False
    )[
        [
            "DB vCPU",
            "DB Logons",
            "DB SGA (MB)",
            "DB PGA (MB)",
            "DB Memory (MB)",
            "read_iops",
            "write_iops",
            "DB IOPS",
            "Allocated Storage (GB)",
        ]
    ].sum()

    dbHourlySumDf = pd.merge(
        left=dbHourlySumDf,
        right=propertiesDf[["DB_NAME", "Cohort"]],
        how="left",
        left_on=["DB_NAME"],
        right_on=["DB_NAME"],
    )
    dbHourlySumDf["Cohort"]=dbHourlySumDf["Cohort"].fillna("unassigned")

    # dbHourlySumDf

    # DB_NAME 	end_hh24_UTC 	end_dd_UTC 	DB vCPU 	DB Logons 	DB SGA (MB) 	DB PGA (MB) 	DB Memory (MB) 	read_iops 	write_iops 	DB IOPS 	Allocated Storage (GB) 	Cohort
    # 0 	AGAMA 	2022-01-16 20:00:00 	2022-01-16 	0.002 	91.7 	2150.4 	512.0 	2662.4 	7.0 	2.9 	9.9 	0.00 	One
    # 1 	AGAMA 	2022-01-16 21:00:00 	2022-01-16 	0.021 	92.0 	2150.4 	512.0 	2662.4 	11.1 	3.9 	15.0 	0.00 	One
    # 2 	AGAMA 	2022-01-16 22:00:00 	2022-01-16 	0.007 	92.7 	2150.4 	614.4 	2764.8 	6.9 	1.9 	8.8 	0.00 	One
    # 3 	AGAMA 	2022-01-16 23:00:00 	2022-01-16 	0.008 	93.2 	2150.4 	614.4 	2764.8 	7.7 	1.9 	9.6 	0.00 	One
    # 4 	AGAMA 	2022-01-17 00:00:00 	2022-01-17 	0.073 	94.9 	2150.4 	614.4 	2764.8 	10.1 	2.8 	12.9 	0.00 	One
    # ... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	...
    # 27162 	ZEBRA 	2022-01-25 18:00:00 	2022-01-25 	0.499 	96.9 	3993.6 	614.4 	4608.0 	76.9 	3.3 	80.2 	0.00 	unassigned
    # 27163 	ZEBRA 	2022-01-25 19:00:00 	2022-01-25 	0.031 	96.8 	3993.6 	614.4 	4608.0 	28.1 	6.4 	34.5 	0.00 	unassigned
    # 27164 	ZEBRA 	2022-01-25 20:00:00 	2022-01-25 	0.001 	95.8 	3993.6 	614.4 	4608.0 	8.6 	2.1 	10.7 	0.00 	unassigned
    # 27165 	ZEBRA 	2022-01-25 21:00:00 	2022-01-25 	0.003 	95.3 	3993.6 	614.4 	4608.0 	7.7 	2.0 	9.7 	0.00 	unassigned
    # 27166 	ZEBRA 	2022-01-25 22:00:00 	2022-01-25 	0.018 	96.7 	3993.6 	614.4 	4608.0 	13.9 	6.1 	20.0 	99.08 	unassigned

    # 27167 rows × 13 columns

    dbHourlySumDf["Storage_GB"] = dbHourlySumDf.groupby(["DB_NAME", "end_dd_UTC"])[
        "Allocated Storage (GB)"
    ].transform("max")

    # dbHourlySumDf[dbHourlySumDf['DB_NAME'] == 'AGAMA'].head(25)

    # DB_NAME 	end_hh24_UTC 	end_dd_UTC 	DB vCPU 	DB Logons 	DB SGA (MB) 	DB PGA (MB) 	DB Memory (MB) 	read_iops 	write_iops 	DB IOPS 	Allocated Storage (GB) 	Cohort 	Storage_GB
    # 0 	AGAMA 	2022-01-16 20:00:00 	2022-01-16 	0.002 	91.7 	2150.4 	512.0 	2662.4 	7.0 	2.9 	9.9 	0.00 	One 	0.00
    # 1 	AGAMA 	2022-01-16 21:00:00 	2022-01-16 	0.021 	92.0 	2150.4 	512.0 	2662.4 	11.1 	3.9 	15.0 	0.00 	One 	0.00
    # 2 	AGAMA 	2022-01-16 22:00:00 	2022-01-16 	0.007 	92.7 	2150.4 	614.4 	2764.8 	6.9 	1.9 	8.8 	0.00 	One 	0.00
    # 3 	AGAMA 	2022-01-16 23:00:00 	2022-01-16 	0.008 	93.2 	2150.4 	614.4 	2764.8 	7.7 	1.9 	9.6 	0.00 	One 	0.00
    # 4 	AGAMA 	2022-01-17 00:00:00 	2022-01-17 	0.073 	94.9 	2150.4 	614.4 	2764.8 	10.1 	2.8 	12.9 	0.00 	One 	12.68
    # 5 	AGAMA 	2022-01-17 01:00:00 	2022-01-17 	0.019 	93.5 	2150.4 	512.0 	2662.4 	10.5 	3.3 	13.8 	0.00 	One 	12.68
    # 6 	AGAMA 	2022-01-17 02:00:00 	2022-01-17 	0.037 	93.5 	2150.4 	614.4 	2764.8 	17.8 	3.9 	21.7 	0.00 	One 	12.68
    # 7 	AGAMA 	2022-01-17 03:00:00 	2022-01-17 	0.013 	93.6 	2150.4 	614.4 	2764.8 	7.0 	3.2 	10.2 	0.00 	One 	12.68
    # 8 	AGAMA 	2022-01-17 04:00:00 	2022-01-17 	0.009 	94.1 	2150.4 	614.4 	2764.8 	6.7 	2.0 	8.7 	0.00 	One 	12.68
    # 9 	AGAMA 	2022-01-17 05:00:00 	2022-01-17 	0.051 	95.3 	2048.0 	614.4 	2662.4 	24.6 	6.8 	31.4 	0.00 	One 	12.68
    # 10 	AGAMA 	2022-01-17 06:00:00 	2022-01-17 	0.030 	96.0 	2048.0 	512.0 	2560.0 	9.6 	3.5 	13.1 	0.00 	One 	12.68
    # 11 	AGAMA 	2022-01-17 07:00:00 	2022-01-17 	0.002 	91.9 	2048.0 	512.0 	2560.0 	5.0 	1.7 	6.7 	0.00 	One 	12.68
    # 12 	AGAMA 	2022-01-17 08:00:00 	2022-01-17 	0.018 	92.4 	2048.0 	614.4 	2662.4 	9.6 	3.9 	13.5 	0.00 	One 	12.68
    # 13 	AGAMA 	2022-01-17 09:00:00 	2022-01-17 	0.038 	93.3 	2150.4 	614.4 	2764.8 	42.1 	7.4 	49.5 	0.00 	One 	12.68
    # 14 	AGAMA 	2022-01-17 10:00:00 	2022-01-17 	0.004 	92.4 	2150.4 	614.4 	2764.8 	6.6 	2.1 	8.7 	0.00 	One 	12.68
    # 15 	AGAMA 	2022-01-17 11:00:00 	2022-01-17 	0.005 	93.3 	2150.4 	614.4 	2764.8 	5.8 	2.0 	7.8 	0.00 	One 	12.68
    # 16 	AGAMA 	2022-01-17 12:00:00 	2022-01-17 	0.003 	92.6 	2150.4 	614.4 	2764.8 	6.4 	1.9 	8.3 	12.68 	One 	12.68
    # 17 	AGAMA 	2022-01-17 13:00:00 	2022-01-17 	0.003 	92.1 	2150.4 	512.0 	2662.4 	4.9 	1.7 	6.6 	0.00 	One 	12.68
    # 18 	AGAMA 	2022-01-17 14:00:00 	2022-01-17 	0.002 	92.1 	2150.4 	512.0 	2662.4 	4.8 	1.7 	6.5 	0.00 	One 	12.68
    # 19 	AGAMA 	2022-01-17 15:00:00 	2022-01-17 	0.031 	92.0 	2150.4 	512.0 	2662.4 	13.8 	7.7 	21.5 	0.00 	One 	12.68
    # 20 	AGAMA 	2022-01-17 16:00:00 	2022-01-17 	0.141 	93.1 	2150.4 	512.0 	2662.4 	41.4 	45.0 	86.4 	0.00 	One 	12.68
    # 21 	AGAMA 	2022-01-17 17:00:00 	2022-01-17 	0.002 	92.0 	2150.4 	512.0 	2662.4 	5.0 	1.8 	6.8 	0.00 	One 	12.68
    # 22 	AGAMA 	2022-01-17 18:00:00 	2022-01-17 	0.002 	92.1 	2150.4 	512.0 	2662.4 	5.3 	1.7 	7.0 	0.00 	One 	12.68
    # 23 	AGAMA 	2022-01-17 19:00:00 	2022-01-17 	0.005 	92.2 	2150.4 	512.0 	2662.4 	5.7 	1.9 	7.6 	0.00 	One 	12.68
    # 24 	AGAMA 	2022-01-17 20:00:00 	2022-01-17 	0.002 	92.5 	2150.4 	512.0 	2662.4 	7.3 	2.8 	10.1 	0.00 	One 	12.68

    dbHourlySumDf["Allocated Storage (GB)"] = dbHourlySumDf["Storage_GB"]
    dbHourlySumDf.drop(columns=["Storage_GB"], inplace=True)
    # dbHourlySumDf[dbHourlySumDf['DB_NAME'] == 'AGAMA'].head(25)

    # DB_NAME 	end_hh24_UTC 	end_dd_UTC 	DB vCPU 	DB Logons 	DB SGA (MB) 	DB PGA (MB) 	DB Memory (MB) 	read_iops 	write_iops 	DB IOPS 	Allocated Storage (GB) 	Cohort
    # 0 	AGAMA 	2022-01-16 20:00:00 	2022-01-16 	0.002 	91.7 	2150.4 	512.0 	2662.4 	7.0 	2.9 	9.9 	0.00 	One
    # 1 	AGAMA 	2022-01-16 21:00:00 	2022-01-16 	0.021 	92.0 	2150.4 	512.0 	2662.4 	11.1 	3.9 	15.0 	0.00 	One
    # 2 	AGAMA 	2022-01-16 22:00:00 	2022-01-16 	0.007 	92.7 	2150.4 	614.4 	2764.8 	6.9 	1.9 	8.8 	0.00 	One
    # 3 	AGAMA 	2022-01-16 23:00:00 	2022-01-16 	0.008 	93.2 	2150.4 	614.4 	2764.8 	7.7 	1.9 	9.6 	0.00 	One
    # 4 	AGAMA 	2022-01-17 00:00:00 	2022-01-17 	0.073 	94.9 	2150.4 	614.4 	2764.8 	10.1 	2.8 	12.9 	12.68 	One
    # 5 	AGAMA 	2022-01-17 01:00:00 	2022-01-17 	0.019 	93.5 	2150.4 	512.0 	2662.4 	10.5 	3.3 	13.8 	12.68 	One
    # 6 	AGAMA 	2022-01-17 02:00:00 	2022-01-17 	0.037 	93.5 	2150.4 	614.4 	2764.8 	17.8 	3.9 	21.7 	12.68 	One
    # 7 	AGAMA 	2022-01-17 03:00:00 	2022-01-17 	0.013 	93.6 	2150.4 	614.4 	2764.8 	7.0 	3.2 	10.2 	12.68 	One
    # 8 	AGAMA 	2022-01-17 04:00:00 	2022-01-17 	0.009 	94.1 	2150.4 	614.4 	2764.8 	6.7 	2.0 	8.7 	12.68 	One
    # 9 	AGAMA 	2022-01-17 05:00:00 	2022-01-17 	0.051 	95.3 	2048.0 	614.4 	2662.4 	24.6 	6.8 	31.4 	12.68 	One
    # 10 	AGAMA 	2022-01-17 06:00:00 	2022-01-17 	0.030 	96.0 	2048.0 	512.0 	2560.0 	9.6 	3.5 	13.1 	12.68 	One
    # 11 	AGAMA 	2022-01-17 07:00:00 	2022-01-17 	0.002 	91.9 	2048.0 	512.0 	2560.0 	5.0 	1.7 	6.7 	12.68 	One
    # 12 	AGAMA 	2022-01-17 08:00:00 	2022-01-17 	0.018 	92.4 	2048.0 	614.4 	2662.4 	9.6 	3.9 	13.5 	12.68 	One
    # 13 	AGAMA 	2022-01-17 09:00:00 	2022-01-17 	0.038 	93.3 	2150.4 	614.4 	2764.8 	42.1 	7.4 	49.5 	12.68 	One
    # 14 	AGAMA 	2022-01-17 10:00:00 	2022-01-17 	0.004 	92.4 	2150.4 	614.4 	2764.8 	6.6 	2.1 	8.7 	12.68 	One
    # 15 	AGAMA 	2022-01-17 11:00:00 	2022-01-17 	0.005 	93.3 	2150.4 	614.4 	2764.8 	5.8 	2.0 	7.8 	12.68 	One
    # 16 	AGAMA 	2022-01-17 12:00:00 	2022-01-17 	0.003 	92.6 	2150.4 	614.4 	2764.8 	6.4 	1.9 	8.3 	12.68 	One
    # 17 	AGAMA 	2022-01-17 13:00:00 	2022-01-17 	0.003 	92.1 	2150.4 	512.0 	2662.4 	4.9 	1.7 	6.6 	12.68 	One
    # 18 	AGAMA 	2022-01-17 14:00:00 	2022-01-17 	0.002 	92.1 	2150.4 	512.0 	2662.4 	4.8 	1.7 	6.5 	12.68 	One
    # 19 	AGAMA 	2022-01-17 15:00:00 	2022-01-17 	0.031 	92.0 	2150.4 	512.0 	2662.4 	13.8 	7.7 	21.5 	12.68 	One
    # 20 	AGAMA 	2022-01-17 16:00:00 	2022-01-17 	0.141 	93.1 	2150.4 	512.0 	2662.4 	41.4 	45.0 	86.4 	12.68 	One
    # 21 	AGAMA 	2022-01-17 17:00:00 	2022-01-17 	0.002 	92.0 	2150.4 	512.0 	2662.4 	5.0 	1.8 	6.8 	12.68 	One
    # 22 	AGAMA 	2022-01-17 18:00:00 	2022-01-17 	0.002 	92.1 	2150.4 	512.0 	2662.4 	5.3 	1.7 	7.0 	12.68 	One
    # 23 	AGAMA 	2022-01-17 19:00:00 	2022-01-17 	0.005 	92.2 	2150.4 	512.0 	2662.4 	5.7 	1.9 	7.6 	12.68 	One
    # 24 	AGAMA 	2022-01-17 20:00:00 	2022-01-17 	0.002 	92.5 	2150.4 	512.0 	2662.4 	7.3 	2.8 	10.1 	12.68 	One

    cohortHourlySumDf = dbHourlySumDf.groupby(
        ["Cohort", "end_dd_UTC", "end_hh24_UTC"], as_index=False
    ).sum()
    # cohortHourlySumDf

    # Cohort 	end_dd_UTC 	end_hh24_UTC 	DB vCPU 	DB Logons 	DB SGA (MB) 	DB PGA (MB) 	DB Memory (MB) 	read_iops 	write_iops 	DB IOPS 	Allocated Storage (GB)
    # 0 	One 	2022-01-09 	2022-01-09 22:00:00 	0.001667 	75.833333 	2150.4 	307.2 	2457.6 	3.533333 	1.433333 	4.966667 	0.00
    # 1 	One 	2022-01-09 	2022-01-09 23:00:00 	0.003833 	80.416667 	2150.4 	307.2 	2457.6 	5.916667 	1.916667 	7.833333 	0.00
    # 2 	One 	2022-01-10 	2022-01-10 00:00:00 	0.002167 	81.066667 	2150.4 	307.2 	2457.6 	4.150000 	1.500000 	5.650000 	110.69
    # 3 	One 	2022-01-10 	2022-01-10 01:00:00 	0.012000 	80.050000 	2150.4 	307.2 	2457.6 	4.733333 	2.466667 	7.200000 	110.69
    # 4 	One 	2022-01-10 	2022-01-10 02:00:00 	0.002167 	77.383333 	2150.4 	307.2 	2457.6 	4.066667 	1.500000 	5.566667 	110.69
    # ... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	...
    # 2048 	unassigned 	2022-01-25 	2022-01-25 18:00:00 	1.116500 	6012.950000 	144691.2 	36556.8 	181248.0 	615.400000 	218.350000 	833.750000 	1300.90
    # 2049 	unassigned 	2022-01-25 	2022-01-25 19:00:00 	0.518500 	5860.000000 	140185.6 	35328.0 	175513.6 	497.950000 	160.700000 	658.650000 	1276.66
    # 2050 	unassigned 	2022-01-25 	2022-01-25 20:00:00 	0.378000 	5833.250000 	140185.6 	35328.0 	175513.6 	433.200000 	138.600000 	571.800000 	1276.66
    # 2051 	unassigned 	2022-01-25 	2022-01-25 21:00:00 	0.316500 	5822.550000 	140185.6 	35328.0 	175513.6 	443.550000 	154.750000 	598.300000 	1276.66
    # 2052 	unassigned 	2022-01-25 	2022-01-25 22:00:00 	0.202000 	3385.300000 	78745.6 	20582.4 	99328.0 	253.800000 	108.100000 	361.900000 	774.40

    # 2053 rows × 12 columns

    dbHourlySumDf = dbHourlySumDf.melt(
        id_vars=["Cohort", "DB_NAME", "end_dd_UTC", "end_hh24_UTC"]
    )
    dbHourlySumDf.rename(columns={"variable": "metric"}, inplace=True)

    pctDf = (
        dbHourlySumDf.groupby(["Cohort", "DB_NAME", "metric"])
        .describe(percentiles=PERCENTILES)
        .reset_index()
    )
    cols = ["Cohort", "DB_NAME", "metric", "count", "mean", "std", "min"]
    cols += ["p" + str(int(_ * 100)) for _ in PERCENTILES if _ != "0"] + ["max"]

    pctDf.columns = cols
    filename = outputPath + os.sep + "database_statistics.csv"
    pctDf.to_csv(filename, index=False)
    occa_data.database_statistics = pctDf
    print("Wrote file " + filename)

    # Wrote file /Users/tfrazier/Pycharm_NetworkTopology/sizing/AWR_Miner_Examples/true_commerce.01/occa/2022-01-28_23-57-40_UTC/sizing/database_statistics.csv

    cohortHourlySumDf = cohortHourlySumDf.melt(
        id_vars=["Cohort", "end_dd_UTC", "end_hh24_UTC"]
    )
    cohortHourlySumDf.rename(columns={"variable": "metric"}, inplace=True)
    # cohortHourlySumDf

    # Cohort 	end_dd_UTC 	end_hh24_UTC 	metric 	value
    # 0 	One 	2022-01-09 	2022-01-09 22:00:00 	DB vCPU 	0.001667
    # 1 	One 	2022-01-09 	2022-01-09 23:00:00 	DB vCPU 	0.003833
    # 2 	One 	2022-01-10 	2022-01-10 00:00:00 	DB vCPU 	0.002167
    # 3 	One 	2022-01-10 	2022-01-10 01:00:00 	DB vCPU 	0.012000
    # 4 	One 	2022-01-10 	2022-01-10 02:00:00 	DB vCPU 	0.002167
    # ... 	... 	... 	... 	... 	...
    # 18472 	unassigned 	2022-01-25 	2022-01-25 18:00:00 	Allocated Storage (GB) 	1300.900000
    # 18473 	unassigned 	2022-01-25 	2022-01-25 19:00:00 	Allocated Storage (GB) 	1276.660000
    # 18474 	unassigned 	2022-01-25 	2022-01-25 20:00:00 	Allocated Storage (GB) 	1276.660000
    # 18475 	unassigned 	2022-01-25 	2022-01-25 21:00:00 	Allocated Storage (GB) 	1276.660000
    # 18476 	unassigned 	2022-01-25 	2022-01-25 22:00:00 	Allocated Storage (GB) 	774.400000

    # 18477 rows × 5 columns

    pctDf = (
        cohortHourlySumDf.groupby(["Cohort", "metric"])
        .describe(percentiles=PERCENTILES)
        .reset_index()
    )
    cols = ["Cohort", "metric", "count", "mean", "std", "min"]
    cols += ["p" + str(int(_ * 100)) for _ in PERCENTILES if _ != "0"] + ["max"]

    pctDf.columns = cols
    filename = outputPath + os.sep + "cohort_statistics.csv"
    pctDf.to_csv(filename, index=False)
    occa_data.cohort_statistics = pctDf
    print("Wrote file " + filename)

    # Wrote file /Users/tfrazier/Pycharm_NetworkTopology/sizing/AWR_Miner_Examples/true_commerce.01/occa/2022-01-28_23-57-40_UTC/sizing/cohort_statistics.csv

    for c in dbHourlySumDf["Cohort"].unique():
        print("Plotting cohort " + c)

        aDf = dbHourlySumDf[
            (dbHourlySumDf["Cohort"] == c) & (dbHourlySumDf["metric"] == "DB vCPU")
        ][["DB_NAME", "end_hh24_UTC", "value"]].copy()
        aDf["total"] = aDf.groupby(["DB_NAME"])["value"].transform("sum")
        aDf["rank"] = aDf["total"].rank(method="dense").astype(str)
        aDf["sort"] = aDf["rank"].str.zfill(5) + "$$$" + aDf["DB_NAME"]
        aDf.rename(
            columns={"DB_NAME": " DB_NAME_original", "sort": "DB_NAME"}, inplace=True
        )
        aDf.sort_values(
            ["DB_NAME", "end_hh24_UTC"], ascending=[False, True], inplace=True
        )

        fig = px.area(
            aDf,
            x="end_hh24_UTC",
            y="value",
            color="DB_NAME",
            title="AWR DB vCPU for Cohort " + c,
            labels={"end_hh24_UTC": "Date", "value": "DB vCPU"},
            template="seaborn",
            width=WIDTH,
            height=HEIGHT,
        )

        fig.update_layout(
            font={"size": 16},
            legend_font_size=12,
            autosize=False,
            width=WIDTH,
            height=HEIGHT,
            margin=dict(t=150),
        )

        for idx in range(len(fig.data)):
            cdb = fig.data[idx].name

            if cdb is None:
                continue

            cdb = cdb[cdb.find("$$$") + 3 :]

            fig.data[idx].name = cdb
            fig.data[idx].legendgroup = cdb
            fig.data[idx].hovertemplate = cdb

        fig.write_image(outputPath + os.sep + "area_DB_vCPU_" + c + ".png")
        fig.write_html(outputPath + os.sep + "area_DB_vCPU_" + c + ".html")

    # Plotting cohort One
    # Plotting cohort Two
    # Plotting cohort Three
    # Plotting cohort unassigned

    snapDf = pd.merge(
        left=snapDf, right=propertiesDf[["DB_NAME", "Cohort"]], how="left"
    )
    snapDf["Cohort"] = snapDf["Cohort"].fillna("unassigned")

    rDf = snapDf[["DB_NAME", "Cohort"]].drop_duplicates()
    rDf["DB_NAME_idx"] = rDf.groupby(["Cohort"])["DB_NAME"].cumcount().add(1)
    snapDf = pd.merge(left=snapDf, right=rDf)
    # snapDf

    # DB_NAME 	WHICH_DB 	end 	SNAP_ID 	INSTANCE 	dur_m 	DB vCPU 	DB Logons 	DB SGA (MB) 	DB PGA (MB) 	... 	end_p_5 	end_hh24 	TZ 	MINUTES_DIFF_FROM_UTC_list 	snaps_with_tz_offset_count 	snaps_missing_tz_offset_count 	end_hh24_UTC 	end_dd_UTC 	Cohort 	DB_NAME_idx
    # 0 	AGAMA 	db_AGAMA_669604932-12010-12225 	2022-01-17 06:59:00 	12011 	1 	59 	0.002 	91.7 	2150.4 	512.0 	... 	2022-01-17 07:04:00 	2022-01-17 07:00:00 	Antarctica/Casey 	480.0 	192 	23 	2022-01-16 20:00:00 	2022-01-16 	One 	1
    # 1 	AGAMA 	db_AGAMA_669604932-12010-12225 	2022-01-17 08:00:00 	12012 	1 	61 	0.021 	92.0 	2150.4 	512.0 	... 	2022-01-17 08:05:00 	2022-01-17 08:00:00 	Antarctica/Casey 	480.0 	192 	23 	2022-01-16 21:00:00 	2022-01-16 	One 	1
    # 2 	AGAMA 	db_AGAMA_669604932-12010-12225 	2022-01-17 09:00:00 	12013 	1 	60 	0.007 	92.7 	2150.4 	614.4 	... 	2022-01-17 09:05:00 	2022-01-17 09:00:00 	Antarctica/Casey 	480.0 	192 	23 	2022-01-16 22:00:00 	2022-01-16 	One 	1
    # 3 	AGAMA 	db_AGAMA_669604932-12010-12225 	2022-01-17 10:00:00 	12014 	1 	60 	0.008 	93.2 	2150.4 	614.4 	... 	2022-01-17 10:05:00 	2022-01-17 10:00:00 	Antarctica/Casey 	480.0 	192 	23 	2022-01-16 23:00:00 	2022-01-16 	One 	1
    # 4 	AGAMA 	db_AGAMA_669604932-12010-12225 	2022-01-17 11:00:00 	12015 	1 	60 	0.073 	94.9 	2150.4 	614.4 	... 	2022-01-17 11:05:00 	2022-01-17 11:00:00 	Antarctica/Casey 	480.0 	192 	23 	2022-01-17 00:00:00 	2022-01-17 	One 	1
    # ... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	... 	...
    # 30714 	ZEBRA 	db_ZEBRA_3148940996-17002-17211 	2022-01-25 12:59:00 	17207 	2 	60 	0.499 	96.9 	3993.6 	614.4 	... 	2022-01-25 13:04:00 	2022-01-25 13:00:00 	America/Atikokan 	-300.0 	43 	166 	2022-01-25 18:00:00 	2022-01-25 	unassigned 	67
    # 30715 	ZEBRA 	db_ZEBRA_3148940996-17002-17211 	2022-01-25 13:59:00 	17208 	2 	60 	0.031 	96.8 	3993.6 	614.4 	... 	2022-01-25 14:04:00 	2022-01-25 14:00:00 	America/Atikokan 	-300.0 	43 	166 	2022-01-25 19:00:00 	2022-01-25 	unassigned 	67
    # 30716 	ZEBRA 	db_ZEBRA_3148940996-17002-17211 	2022-01-25 15:00:00 	17209 	2 	61 	0.001 	95.8 	3993.6 	614.4 	... 	2022-01-25 15:05:00 	2022-01-25 15:00:00 	America/Atikokan 	-300.0 	43 	166 	2022-01-25 20:00:00 	2022-01-25 	unassigned 	67
    # 30717 	ZEBRA 	db_ZEBRA_3148940996-17002-17211 	2022-01-25 16:00:00 	17210 	2 	60 	0.003 	95.3 	3993.6 	614.4 	... 	2022-01-25 16:05:00 	2022-01-25 16:00:00 	America/Atikokan 	-300.0 	43 	166 	2022-01-25 21:00:00 	2022-01-25 	unassigned 	67
    # 30718 	ZEBRA 	db_ZEBRA_3148940996-17002-17211 	2022-01-25 16:59:00 	17211 	2 	59 	0.018 	96.7 	3993.6 	614.4 	... 	2022-01-25 17:04:00 	2022-01-25 17:00:00 	America/Atikokan 	-300.0 	43 	166 	2022-01-25 22:00:00 	2022-01-25 	unassigned 	67

    # 30719 rows × 29 columns

    fig = px.line(
        x=snapDf["end_dd_UTC"],
        y=snapDf["DB_NAME_idx"],
        color=snapDf["DB_NAME"],
        facet_col=snapDf["Cohort"],
        facet_col_wrap=2,
        title="AWR Snap Coverage by Cohort, Database",
        labels={"x": "Sanp End", "y": ""},
        template="seaborn",
        width=WIDTH,
        height=HEIGHT,
    )
    fig.update_layout(
        font={"size": 16},
        legend_font_size=12,
        autosize=False,
        width=WIDTH,
        height=HEIGHT,
        margin=dict(t=150),
    )

    fig.write_image(outputPath + os.sep + "snap_coverage.png")
    fig.write_html(outputPath + os.sep + "snap_coverage.html")

    print("All files & plots written to " + outputPath)

    save_occa_json(occa_data)


if __name__ == "__main__":
    logging.info(f"Starting script {Path(__file__).resolve()}")
    get_parsed_data_dir()
    try:
        main()
    except Exception as e:
        raise_error_when_run_from_api("AWR: ", str(e))
        raise(e)

