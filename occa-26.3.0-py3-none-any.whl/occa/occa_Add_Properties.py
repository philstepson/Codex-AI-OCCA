import argparse
import datetime
import os
import platform
import sys
import time

import numpy as np
import pandas as pd

import Duplicate_Tests
from occa_Shared import *
from version import version, __version__

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Add_Properties.py",
    description="Add properties in property files to occa sizing files for sizing",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + " version: " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------




# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
# Values for these parameters will be read from the parameter file
#

FIXED = False

# ----------------------------------------------------------------------------------------------------------------------

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------

now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
propertiesFilePath = ROOT_DIR + os.sep + "occa_sizing_properties"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("numpy.__version__ : " + np.__version__)
lg("pandas.__version__: " + pd.__version__)

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n=======================================================================================================\n"
)

lg("FIXED: " + str(FIXED))

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

if not os.path.exists(extractFilePath):
    lg("Directory " + extractFilePath + " is missing; cannot continue")

    quit()

structureFilename = extractFilePath + os.sep + "emcc_sizing_structure_db.csv"

if not os.path.exists(structureFilename):
    lg("File " + structureFilename + " is missing; cannot continue")

    quit()

os.makedirs(outputFilePath, exist_ok=True)

# ----------------------------------------------------------------------------------------------------------------------


def e(text):
    errors.append(text)


# ----------------------------------------------------------------------------------------------------------------------


def convertColumnBytesToGB(df, column):
    if column not in df:
        df[column + "_gb"] = np.nan
    else:
        df.loc[df[column].notnull(), column + "_gb"] = round(
            df[column].astype(float) / (1024 * 1024 * 1024), 3
        )
        df.drop(column, axis=1, inplace=True)


# ----------------------------------------------------------------------------------------------------------------------


def convertToGB(old, new, divisor):
    if old not in df:
        df[new + "_gb"] = np.nan
    else:
        df.loc[df[old].notnull(), new + "_gb"] = round(
            df[old].astype(float) / divisor, 3
        )
        df.drop(old, axis=1, inplace=True)


# ----------------------------------------------------------------------------------------------------------------------


def replaceCDBProperty(structureDfName, propertyName):
    global structureDf

    propsDf = cdbPropsDf[["target_guid", propertyName]].drop_duplicates()
    propsDf = propsDf[pd.notnull(propsDf[propertyName])]

    if len(propsDf) == 0:
        # needed to avoid FutureWarning: elementwise comparison failed; returning scalar instead, but in the future will perform elementwise comparison
        return True

    propsDf.columns = ["target_guid", structureDfName + "_new"]

    structureDf = pd.merge(
        left=structureDf,
        right=propsDf,
        how="left",
        left_on="cdb_target_guid",
        right_on="target_guid",
    )

    if 1 == 0:
        filename = (
            outputFilePath + os.sep + "replaceCDBProperty." + propertyName + ".csv"
        )
        structureDf.to_csv(filename, index=False)
        lg("Wrote " + filename)

    structureDf.loc[
        pd.notnull(structureDf[structureDfName + "_new"]), structureDfName
    ] = structureDf[structureDfName + "_new"]
    structureDf.drop(structureDfName + "_new", axis=1, inplace=True)
    structureDf.drop("target_guid", axis=1, inplace=True)

    if len(propsDf) > 0:
        lg(
            "\n     Replaced "
            + str(len(propsDf))
            + " occurrence(s) of property "
            + propertyName
            + " ("
            + structureDfName
            + ") using database properties file"
        )

    return True


# ----------------------------------------------------------------------------------------------------------------------


def replaceDBProperty(structureDfName, propertyName):
    global structureDf

    propsDf = dbPropsDf[["target_guid", propertyName]].drop_duplicates()
    propsDf[propertyName] = propsDf[propertyName].fillna("").astype(str)
    propsDf.loc[pd.isnull(propsDf[propertyName]), propertyName] = "__missing__"

    gbDf = propsDf.groupby("target_guid")[propertyName].agg("count").reset_index()
    gbDf = gbDf[gbDf[propertyName] > 1]["target_guid"].values

    filename = (
        outputFilePath
        + os.sep
        + "conflicting_assignments_for_instance_"
        + propertyName.replace(" ", "_").replace("?", "")
        + ".csv"
    )

    if len(gbDf) > 0:
        propsDf[propsDf["target_guid"].isin(gbDf)].sort_values(
            ["target_guid", propertyName]
        ).to_csv(filename, index=False)

        e(
            "\nThere are "
            + str(len(gbDf))
            + " conflicting assignments for instance property "
            + propertyName
        )
        e("See file " + filename + " for details")

        return False

    elif os.path.exists(filename):
        os.remove(filename)

    # ---

    propsDf = dbPropsDf[["target_guid", propertyName]].drop_duplicates()
    propsDf = propsDf[pd.notnull(propsDf[propertyName])]

    if len(propsDf) == 0:
        # needed to avoid FutureWarning: elementwise comparison failed; returning scalar instead, but in the future will perform elementwise comparison
        return True

    propsDf.columns = ["target_guid", structureDfName + "_new"]

    structureDf = pd.merge(
        left=structureDf,
        right=propsDf,
        how="left",
        left_on="db_target_guid",
        right_on="target_guid",
    )

    structureDf.loc[
        pd.notnull(structureDf[structureDfName + "_new"]), structureDfName
    ] = structureDf[structureDfName + "_new"]
    structureDf.drop(structureDfName + "_new", axis=1, inplace=True)
    structureDf.drop("target_guid", axis=1, inplace=True)

    if len(propsDf) > 0:
        lg(
            "\n     Replaced "
            + str(len(propsDf))
            + " occurrence(s) of property "
            + propertyName
            + " ("
            + structureDfName
            + ") using instance properties file"
        )

    return True


# ----------------------------------------------------------------------------------------------------------------------


def replaceHProperty(structureDfName, propertyName):
    global structureDf

    propsDf = hPropsDf[["target_guid", propertyName]].drop_duplicates()
    propsDf[propertyName] = propsDf[propertyName].astype(str)
    propsDf.loc[pd.isnull(propsDf[propertyName]), propertyName] = "__missing__"

    gbDf = propsDf.groupby("target_guid")[propertyName].agg("count").reset_index()
    gbDf = gbDf[gbDf[propertyName] > 1]["target_guid"].values

    filename = (
        outputFilePath
        + os.sep
        + "conflicting_assignments_for_server_"
        + propertyName.replace(" ", "_").replace("?", "")
        + ".csv"
    )

    if len(gbDf) > 0:
        propsDf[propsDf["target_guid"].isin(gbDf)].sort_values(
            ["target_guid", propertyName]
        ).to_csv(filename, index=False)

        e(
            "\nThere are "
            + str(len(gbDf))
            + " conflicting assignments for server property "
            + propertyName
        )
        e("See file " + filename + " for details")

        return False

    elif os.path.exists(filename):
        os.remove(filename)

    # ---

    propsDf = hPropsDf[["target_guid", propertyName]].drop_duplicates()
    propsDf = propsDf[pd.notnull(propsDf[propertyName])]

    if len(propsDf) == 0:
        # needed to avoid FutureWarning: elementwise comparison failed; returning scalar instead, but in the future will perform elementwise comparison
        return True

    propsDf.columns = ["target_guid", structureDfName + "_new"]

    structureDf = pd.merge(
        left=structureDf,
        right=propsDf,
        how="left",
        left_on="host_target_guid",
        right_on="target_guid",
    )

    structureDf.loc[
        pd.notnull(structureDf[structureDfName + "_new"]), structureDfName
    ] = structureDf[structureDfName + "_new"]
    structureDf.drop(structureDfName + "_new", axis=1, inplace=True)
    structureDf.drop("target_guid", axis=1, inplace=True)

    if len(propsDf) > 0:
        lg(
            "\n     Replaced "
            + str(len(propsDf))
            + " occurrence(s) of property "
            + propertyName
            + " ("
            + structureDfName
            + ") using host properties file"
        )

    return True


# ----------------------------------------------------------------------------------------------------------------------


def sizingVersion(v):
    if str(v)[:3] == "7.3":
        return "7.3"
    if str(v)[:1] == "8":
        return "8i"
    if str(v)[:1] == "9":
        return "9i"
    if str(v)[:2] == "10":
        return "10g"
    if str(v)[:2] == "11":
        return "11g"
    if str(v)[:2] == "12":
        return "12c"
    if str(v)[:2] == "18":
        return "18c"
    if str(v)[:2] == "19":
        return "19c"
    if str(v)[:2] == "20":
        return "20c"

    return v


# ----------------------------------------------------------------------------------------------------------------------

startTime = time.time()
lg(
    "Processing emcc_sizing extract files in directory "
    + extractFilePath
    + " in working directory "
    + os.getcwd()
)

errors = []

try:
    structureDf = pd.read_csv(structureFilename)
except:
    try:
        structureDf = pd.read_csv(structureFilename, encoding="ISO-8859-1")
    except Exception as fc:
        lg_cannotReadCSVFile(structureFilename, fc)
        quit()

structureDf.columns = [c.strip() for c in structureDf.columns]

structureDf.loc[structureDf["clustered"] == "yes", "clustered"] = "CLUSTERED"
structureDf.loc[structureDf["clustered"] == "no", "clustered"] = "NON-CLUSTERED"

len0 = len(structureDf)

# ---

if os.path.exists(extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"):
    try:
        cpuDf = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"
        )
    except:
        cpuDdf = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv",
            encoding="ISO-8859-1",
        )

    cols = [c.strip() for c in cpuDf.columns]
    cpuDf.columns = cols

    cpuDf = cpuDf[
        ["target_guid", "ecache_in_mb", "impl", "revision", "is_hyperthread_enabled"]
    ]
    cpuDf.columns = [
        "host_target_guid",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
    ]

    structureDf = pd.merge(
        left=structureDf,
        right=cpuDf,
        how="left",
        left_on="host_target_guid",
        right_on="host_target_guid",
    )

else:
    structureDf["ecache_in_mb"] = -1
    structureDf["impl"] = "not_loaded"
    structureDf["revision"] = "not_loaded"
    structureDf["is_hyperthread_enabled"] = -1

len1 = len(structureDf)

# ----------------------------------------------------------------------------------------------------------------------

if not os.path.exists(
    extractFilePath + os.sep + "emcc_sizing_structure_host_props.csv"
):
    lg(
        "\nFile "
        + extractFilePath
        + os.sep
        + "emcc_sizing_structure_host_props.csv; skipping"
    )
    structureDf["nr_huge_pages"] = ""
else:
    df = pd.read_csv(extractFilePath + os.sep + "emcc_sizing_structure_host_props.csv")

    if len(df) == 0:
        structureDf["nr_huge_pages"] = ""

    else:
        try:
            df = pd.pivot(
                df, index="TARGET_GUID", columns="NAME", values="VALUE"
            ).reset_index()
        except Exception as fc:
            lg_notLikelyCSVFile(
                extractFilePath + os.sep + "emcc_sizing_structure_host_props.csv", fc
            )
            quit()

        df.columns = ["TARGET_GUID", "nr_huge_pages"]

        structureDf = pd.merge(
            left=structureDf,
            right=df,
            how="left",
            left_on="host_target_guid",
            right_on="TARGET_GUID",
        )
        structureDf.drop("TARGET_GUID", axis=1, inplace=True)

len2 = len(structureDf)

# ----------------------------------------------------------------------------------------------------------------------

try:
    df = pd.read_csv(extractFilePath + os.sep + "emcc_sizing_structure_db_params.csv")
except:
    try:
        df = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_db_params.csv",
            encoding="ISO-8859-1",
        )
    except Exception as fc:
        lg_cannotReadCSVFile(
            extractFilePath + os.sep + "emcc_sizing_structure_db_params.csv", fc
        )
        quit()

df.loc[df["TARGET_GUID"].isnull(), "TARGET_GUID"] = "none"
df["count"] = df.groupby(["TARGET_GUID", "NAME"])["EXTRACT_DTTM_UTC"].transform("count")

dupCnt = len(df[df["count"] > 1])

if dupCnt > 0:
    df[df["count"] > 1].to_csv(
        outputFilePath + os.sep + "duplicate_db_params.csv", index=False
    )
    lg(
        "\nWrote "
        + str(dupCnt)
        + " duplicate rows in file "
        + extractFilePath
        + os.sep
        + "emcc_sizing_structure_db_params.csv to "
        + outputFilePath
        + os.sep
        + "duplicate_db_params.csv"
    )
    df = df[df["count"] == 1]

elif os.path.exists(outputFilePath + os.sep + "duplicate_db_params.csv"):
    os.remove(outputFilePath + os.sep + "duplicate_db_params.csv")

# ---

df = pd.pivot(df, index="TARGET_GUID", columns="NAME", values="VALUE").reset_index()

convertColumnBytesToGB(df, "pga_aggregate_limit")
convertColumnBytesToGB(df, "pga_aggregate_target")
convertColumnBytesToGB(df, "sga_max_size")
convertColumnBytesToGB(df, "sga_target")

df["cpu_count"] = df["cpu_count"].astype(float)

if "cpu_min_count" not in df:
    df["cpu_min_count"] = np.nan
else:
    df["cpu_min_count"] = df["cpu_min_count"].astype(float)

df["processes"] = df["processes"].astype(float)
df["sessions"] = df["sessions"].astype(float)

cols = df.columns.values
cols = ["init_" + i if i != "TARGET_GUID" else i for i in cols]

df.columns = cols

# ---

structureDf = pd.merge(
    left=structureDf,
    right=df,
    how="left",
    left_on="db_target_guid",
    right_on="TARGET_GUID",
)
structureDf.drop("TARGET_GUID", axis=1, inplace=True)

len3 = len(structureDf)

structureDf["db_cpu_count_limit"] = structureDf["init_cpu_count"]
structureDf.loc[structureDf["db_cpu_count_limit"].isnull(), "db_cpu_count_limit"] = (
    structureDf["logical_cpu_count"]
)
structureDf.loc[structureDf["db_cpu_count_limit"] == 0, "db_cpu_count_limit"] = (
    structureDf["logical_cpu_count"]
)

structureDf["host_db_cpu_count_limit"] = structureDf.groupby("host")[
    "db_cpu_count_limit"
].transform("sum")

structureDf.loc[
    structureDf["host_db_cpu_count_limit"] == 0, "db_cpu_count_guarantee"
] = 0
structureDf.loc[
    structureDf["host_db_cpu_count_limit"] < structureDf["logical_cpu_count"],
    "db_cpu_count_guarantee",
] = structureDf["db_cpu_count_limit"]
structureDf.loc[
    structureDf["host_db_cpu_count_limit"] >= structureDf["logical_cpu_count"],
    "db_cpu_count_guarantee",
] = round(
    (structureDf["db_cpu_count_limit"] / structureDf["host_db_cpu_count_limit"])
    * structureDf["logical_cpu_count"],
    3,
)

len4 = len(structureDf)

# ----------------------------------------------------------------------------------------------------------------------

try:
    df = pd.read_csv(extractFilePath + os.sep + "emcc_sizing_structure_db_props.csv")
except:
    df = pd.read_csv(
        extractFilePath + os.sep + "emcc_sizing_structure_db_props.csv",
        encoding="ISO-8859-1",
    )

df = pd.pivot(df, index="TARGET_GUID", columns="NAME", values="VALUE").reset_index()

cols = df.columns.values

# ---

colsNew = [
    "cdb_" + i[9:] if i[0:8] == "orcl_gtp" else "cdb_version" if i == "Version" else i
    for i in cols
]
df.columns = colsNew

structureDf = pd.merge(
    left=structureDf,
    right=df,
    how="left",
    left_on="cdb_target_guid",
    right_on="TARGET_GUID",
)
structureDf.drop("TARGET_GUID", axis=1, inplace=True)

len5 = len(structureDf)

# ---

colsNew = [
    "db_" + i[9:] if i[0:8] == "orcl_gtp" else "db_version" if i == "Version" else i
    for i in cols
]
df.columns = colsNew

structureDf = pd.merge(
    left=structureDf,
    right=df,
    how="left",
    left_on="db_target_guid",
    right_on="TARGET_GUID",
)
structureDf.drop("TARGET_GUID", axis=1, inplace=True)

# ---

structureDf["cdb_version_sizing"] = structureDf["cdb_version"].apply(sizingVersion)
structureDf["db_version_sizing"] = structureDf["db_version"].apply(sizingVersion)

# ---

if "cdb_cost_center" not in structureDf:
    structureDf["cdb_cost_center"] = ""
if "cdb_department" not in structureDf:
    structureDf["cdb_department"] = ""
if "cdb_cohort" not in structureDf:
    structureDf["cdb_cohort"] = ""
if "cdb_lifecycle_status" not in structureDf:
    structureDf["cdb_lifecycle_status"] = ""
if "cdb_line_of_bus" not in structureDf:
    structureDf["cdb_line_of_bus"] = ""
if "cdb_location" not in structureDf:
    structureDf["cdb_location"] = ""
if "cdb_version" not in structureDf:
    structureDf["cdb_version"] = ""

if "db_cost_center" not in structureDf:
    structureDf["db_cost_center"] = ""
if "db_department" not in structureDf:
    structureDf["db_department"] = ""
if "db_cohort" not in structureDf:
    structureDf["db_cohort"] = ""
if "db_lifecycle_status" not in structureDf:
    structureDf["db_lifecycle_status"] = ""
if "db_line_of_bus" not in structureDf:
    structureDf["db_line_of_bus"] = ""
if "db_location" not in structureDf:
    structureDf["db_location"] = ""
if "db_version" not in structureDf:
    structureDf["db_version"] = ""

if "h_cost_center" not in structureDf:
    structureDf["h_cost_center"] = ""
if "h_department" not in structureDf:
    structureDf["h_department"] = ""
if "h_lifecycle_status" not in structureDf:
    structureDf["h_lifecycle_status"] = ""
if "h_line_of_bus" not in structureDf:
    structureDf["h_line_of_bus"] = ""
if "h_location" not in structureDf:
    structureDf["h_location"] = ""

if "cdb_type_version" not in structureDf:
    structureDf["cdb_type_version"] = ""
if "db_type_version" not in structureDf:
    structureDf["db_type_version"] = ""
if "host_type_version" not in structureDf:
    structureDf["host_type_version"] = ""

len6 = len(structureDf)

# ----------------------------------------------------------------------------------------------------------------------

if not os.path.exists(extractFilePath + os.sep + "emcc_sizing_structure_db_sga.csv"):
    lg(
        "\nFile "
        + extractFilePath
        + os.sep
        + "emcc_sizing_structure_db_sga.csv; skipping"
    )
else:

    df = pd.read_csv(extractFilePath + os.sep + "emcc_sizing_structure_db_sga.csv")

    try:
        df.loc[df["TARGET_GUID"].isnull(), "TARGET_GUID"] = "none"
        df["count"] = df.groupby(["TARGET_GUID", "SGANAME"])[
            "EXTRACT_DTTM_UTC"
        ].transform("count")
    except Exception as fc:
        lg_notLikelyCSVFile(
            extractFilePath + os.sep + "emcc_sizing_structure_db_sga.csv", fc
        )
        quit()

    dupCnt = len(df[df["count"] > 1])

    if dupCnt > 0:
        df[df["count"] > 1].to_csv(
            outputFilePath + os.sep + "duplicate_db_sga.csv", index=False
        )
        lg(
            "\nWrote "
            + str(dupCnt)
            + " duplicate rows in file "
            + extractFilePath
            + os.sep
            + "emcc_sizing_structure_db_sga.csv to "
            + outputFilePath
            + os.sep
            + "duplicate_db_sga.csv"
        )
        df = df[df["count"] == 1]

    elif os.path.exists(outputFilePath + os.sep + "duplicate_db_sga.csv"):
        os.remove(outputFilePath + os.sep + "duplicate_db_sga.csv")

    # ---

    df = pd.pivot(
        df, index="TARGET_GUID", columns="SGANAME", values="SGASIZE"
    ).reset_index()

    convertToGB("Buffered Cache (MB)", "sga_buffered_cache", 1024)
    convertToGB("Fixed SGA (KB)", "sga_fixed_sga", 1024 * 1024 * 1024)
    convertToGB("Java Pool (MB)", "sga_java_pool", 1024)
    convertToGB("Large Pool (KB)", "sga_large_java_pool", 1024 * 1024 * 1024)
    convertToGB("Maximum SGA (MB)", "sga_maximum_sga", 1024)
    convertToGB("Redo Buffers (KB)", "sga_redo_buffers", 1024 * 1024 * 1024)
    convertToGB("Shared Pool (MB)", "sga_shared_pool", 1024)
    convertToGB("Total SGA (MB)", "sga_total_sga", 1024)
    convertToGB("Variable SGA (MB)", "sga_variable_sga", 1024)

    colsToDrop = [
        c if c != "TARGET_GUID" and c[0:4] != "sga_" else "" for c in df.columns
    ]

    for c in colsToDrop:
        if c == "":
            continue

        df.drop(c, axis=1)

    structureDf = pd.merge(
        left=structureDf,
        right=df,
        how="left",
        left_on="db_target_guid",
        right_on="TARGET_GUID",
    )
    structureDf.drop("TARGET_GUID", axis=1, inplace=True)

    structureDf["cdb_size_allocated_ovr"] = ""
    structureDf["cdb_size_used_ovr"] = ""
    structureDf["cdb_ovr"] = ""
    structureDf["cdb_scope_ovr"] = ""
    structureDf["cdb_percentage_ovr"] = ""

    structureDf["db_vcpu_ovr"] = ""
    structureDf["db_sga_mb_ovr"] = ""
    structureDf["db_pga_mb_ovr"] = ""
    structureDf["db_iops_ovr"] = ""
    structureDf["db_logons_ovr"] = ""
    structureDf["db_ovr"] = ""

    structureDf["h_cpu_type_ovr"] = ""
    structureDf["h_physical_cpu_count_ovr"] = ""
    structureDf["h_cores_per_chip_ovr"] = ""
    structureDf["h_total_cpu_cores_ovr"] = ""
    structureDf["h_description_ovr"] = ""

len7 = len(structureDf)

# ---

if not os.path.exists(propertiesFilePath + os.sep + "properties_database.csv"):
    lg(
        "\nFile "
        + propertiesFilePath
        + os.sep
        + "properties_database.csv does not exist; cannot continue"
    )
    quit()

lg(
    "\nExamining file "
    + propertiesFilePath
    + os.sep
    + "properties_database.csv for replacement values..."
)

cdbPropsDf = pd.read_csv(propertiesFilePath + os.sep + "properties_database.csv")
cdbPropsDf.columns = [c.strip() for c in cdbPropsDf.columns]

# ---

cdbPropsDf["Cohort"] = cdbPropsDf["Cohort"].fillna("unassigned")

cdbPropsDf["Cohort"] = cdbPropsDf["Cohort"].str.strip()
cdbPropsDf.loc[cdbPropsDf["Cohort"].str.lower() == "excluded", "Cohort"] = "excluded"
cdbPropsDf.loc[cdbPropsDf["Cohort"].str.lower() == "unassigned", "Cohort"] = (
    "unassigned"
)
cdbPropsDf.loc[cdbPropsDf["Cohort"].str.lower() == "", "Cohort"] = "unassigned"

df = cdbPropsDf[["Cohort"]].drop_duplicates()
df["lower"] = df["Cohort"].str.lower()

lowerDf = df.groupby("lower", as_index=False)["Cohort"].count()
lowerDf = lowerDf[lowerDf["Cohort"] > 1]

dfLowerList = lowerDf["lower"].unique()

databasesOk = True

if len(lowerDf) > 0:
    databsesOk = False

    df = df[df["lower"].isin(dfLowerList)]["Cohort"].drop_duplicates().values

    lg(
        "\n\nCohort names are case sensitive; case inconsistencies are likely due to editing errors and will cause errors."
    )

    for _ in df:
        lg(_)

# ---

cdbPropsDf["Database Name"] = cdbPropsDf["Database Name"].str.strip()
cdbPropsDf["Use Values from Database Name"] = cdbPropsDf[
    "Use Values from Database Name"
].fillna("")
cdbPropsDf["Use Values from Database Name"] = cdbPropsDf[
    "Use Values from Database Name"
].str.strip()

df = cdbPropsDf[
    cdbPropsDf["Database Name"] == cdbPropsDf["Use Values from Database Name"]
]["Database Name"].values

if len(df) > 0:
    databasesOk = False

    lg(
        "\n\nThe following databases are set to use values from themselves; this is the default and does not need to be specified."
    )

    for _ in df:
        lg(_)

# ---

df = cdbPropsDf[
    (cdbPropsDf["Use Values from Database Name"] != "")
    & (~cdbPropsDf["Use Values from Database Name"].isin(cdbPropsDf["Database Name"]))
][["Database Name", "Use Values from Database Name"]].values

if len(df) > 0:
    databasesOk = False

    lg(
        "\n\nThe folliowing [Use Values from Database Name, Database Name] pairs reference a Database Name that does not exist."
    )

    for _ in df:
        lg(str(_))

# ---

df = cdbPropsDf[
    cdbPropsDf["Database Name"].isin(cdbPropsDf["Use Values from Database Name"])
]
df = df[df["Use Values from Database Name"] != df["Database Name"]]
df = df[df["Use Values from Database Name"] != ""]

filename = outputFilePath + os.sep + "Add_Properties_Database_Override_Chains.csv"

if len(df) > 0:
    databasesOk = False

    df.sort_values(["Database Name"]).to_csv(filename, index=False)
    lg(
        "\nThere are "
        + str(len(df))
        + " databases that use override values from databases that themselves are overridden; they have been written to file "
        + filename
    )

elif os.path.exists(filename):
    os.remove(filename)

# ---

try:
    # Replace whitespace only with nan, Excel sometimes puts whitespace in a cell if formatting is applied
    cdbPropsDf["Allocated Database Size (GB)"] = cdbPropsDf[
        "Allocated Database Size (GB)"
    ].replace(r"^\s*$", np.nan, regex=True)
    cdbPropsDf["Allocated Database Size (GB)"] = cdbPropsDf[
        "Allocated Database Size (GB)"
    ].apply(pd.to_numeric)
except ValueError:
    databasesOk = False
    lg(
        '\n\nOne or more values of column "Allocated Database Size (GB)" is a non-numeric value.'
    )

# ---

try:
    # Replace whitespace only with nan, Excel sometimes puts whitespace in a cell if formatting is applied
    cdbPropsDf["Total Database Size (GB)"] = cdbPropsDf[
        "Total Database Size (GB)"
    ].replace(r"^\s*$", np.nan, regex=True)
    cdbPropsDf["Total Database Size (GB)"] = pd.to_numeric(
        cdbPropsDf["Total Database Size (GB)"]
    )
except ValueError:
    databasesOk = False
    lg(
        '\n\nOne or more values of column "Total Database Size (GB)" is a non-numeric value.'
    )
    raise

# ---

if "Use Values Scope" in cdbPropsDf:
    cdbPropsDf["Use Values Scope"] = cdbPropsDf["Use Values Scope"].fillna("")
    cdbPropsDf["Use Values Pct"] = cdbPropsDf["Use Values Pct"].fillna("")

    cdbPropsDf["Use Values Scope"] = cdbPropsDf["Use Values Scope"].str.strip()
    cdbPropsDf["Use Values Scope"] = cdbPropsDf["Use Values Scope"].fillna("")
    cdbPropsDf["Use Values Scope"] = cdbPropsDf["Use Values Scope"].str.title()

    # ---

    df = cdbPropsDf[
        (cdbPropsDf["Use Values from Database Name"] == "")
        & (cdbPropsDf["Use Values Scope"] != "")
    ]

    if len(df) > 0:
        databasesOk = False
        lg(
            "\n\nThere are "
            + str(len(df))
            + ' database(s) that have a value in column "Use Values Scope" but no value in column "Use Values From Database Name.'
        )

        lg(str(df["Database Name"].unique()))

    # ---

    df = cdbPropsDf[
        (cdbPropsDf["Use Values from Database Name"] != "")
        & (cdbPropsDf["Use Values Scope"] == "")
    ]

    if len(df) > 0:
        databasesOk = False
        lg(
            "\n\nThere are "
            + str(len(df))
            + ' database(s) with a value in column "Use Value from Database Name" but no value in column "Use Values Scope".'
        )

    # ---

    df = cdbPropsDf[
        (cdbPropsDf["Use Values from Database Name"] != "")
        & (
            ~cdbPropsDf["Use Values Scope"].isin(
                [
                    "All",
                    PHYSICAL_STANDBY,
                    PRIMARY_PLUS_STANDBY,
                    STANDBY_INSTANCE_METRICS,
                ]
            )
        )
    ]

    if len(df) > 0:
        databasesOk = False
        lg(
            "\n\nThere are "
            + str(len(df))
            + ' value(s) of column "Use Values Scope" not in: "All"'
            + ', "'
            + PHYSICAL_STANDBY
            + '"'
            ', "' + PRIMARY_PLUS_STANDBY + '"'
            ', "' + STANDBY_INSTANCE_METRICS + '".'
        )

        lg(str(df["Use Values Scope"].unique()))
    # ---
    # 999
    df = cdbPropsDf[
        (cdbPropsDf["Use Values Pct"] != "")
        & (~cdbPropsDf["Use Values Scope"].isin(["All", PHYSICAL_STANDBY]))
    ]

    if len(df) > 0:
        databasesOk = False
        lg(
            "\n\nThere are "
            + str(len(df))
            + 'database(s) with a value in column "Use Values Pct" and a value in column "Use Values Scope" that does not use a percentage.'
        )

# ---

if "Use Values Pct" in cdbPropsDf:
    try:
        cdbPropsDf["Use Values Pct"] = cdbPropsDf["Use Values Pct"].apply(pd.to_numeric)

        df = cdbPropsDf[cdbPropsDf["Use Values Pct"] < 0.0]

        if len(df) > 0:
            databasesOk = False
            lg(
                "\n\nThere are "
                + str(len(df))
                + ' value(s) in column "Use Value Pct" that are either < 0.0.'
            )

    except Exception as fc:
        databasesOk = False
        lg('\n\nOne or more values in column "Use Value Pct" is a non-numeric value.')

# ---

if not databasesOk:
    lg(
        "\n\nPlease correct the inconsistencies in file "
        + propertiesFilePath
        + os.sep
        + "properties_database.csv and re-run this script.\n"
    )
    quit()

# --

if "target_guid" not in cdbPropsDf:
    if (
        "cdb_target_guid" in cdbPropsDf
    ):  # needed just in case they have copied the AUDIT spreadsheet to properties
        cdbPropsDf.rename(columns={"cdb_target_guid": "target_guid"}, inplace=True)
    else:
        e(
            "\nUnable to replace properties using file "
            + propertiesFilePath
            + os.sep
            + 'properties_database.csv; missing column "target_guid"'
        )
        quit()

if len(cdbPropsDf) > 0:
    for c in cdbPropsDf.columns:
        if c == "Database Name":
            continue

        elif c == "Cohort":
            if cdbPropsDf[c].astype(str).str.len().max() > COHORT_MAX_LEN:
                e(
                    "\nDatabase cohort values must be <= "
                    + str(COHORT_MAX_LEN)
                    + " chars"
                )

            else:
                replaceCDBProperty("cdb_cohort", c)

        elif c == "Total Database Size (GB)":
            replaceCDBProperty("cdb_size_used_ovr", c)

        elif c == "Allocated Database Size (GB)":
            replaceCDBProperty("cdb_size_allocated_ovr", c)

        elif c == "Use Values from Database Name":
            replaceCDBProperty("cdb_ovr", c)

        elif c == "Use Values Scope":
            replaceCDBProperty("cdb_scope_ovr", c)

        elif c == "Use Values Pct":
            replaceCDBProperty("cdb_percentage_ovr", c)

        else:
            continue

len8 = len(structureDf)

# ---

if not os.path.exists(propertiesFilePath + os.sep + "properties_instance.csv"):
    lg(
        "\nFile "
        + propertiesFilePath
        + os.sep
        + "properties_instance.csv does not exist; skipping"
    )

else:
    lg(
        "\nExamining file "
        + propertiesFilePath
        + os.sep
        + "properties_instance.csv for replacement values..."
    )

    dbPropsDf = pd.read_csv(propertiesFilePath + os.sep + "properties_instance.csv")
    dbPropsDf.columns = [c.strip() for c in dbPropsDf.columns]

    if "target_guid" not in dbPropsDf:
        lg(
            "Unable to replace properties using file "
            + propertiesFilePath
            + os.sep
            + 'properties_instance.csv; missing column "target_guid"'
        )

    elif len(dbPropsDf) > 0:
        if "Use Values from Instance" in dbPropsDf:
            instancesOk = True

            dbPropsDf["Instance"] = dbPropsDf["Instance"].str.strip()
            dbPropsDf["Use Values from Instance"] = dbPropsDf[
                "Use Values from Instance"
            ].fillna("")
            dbPropsDf["Use Values from Instance"] = dbPropsDf[
                "Use Values from Instance"
            ].str.strip()

            df = dbPropsDf[
                dbPropsDf["Instance"] == dbPropsDf["Use Values from Instance"]
            ]["Instance"].values

            if len(df) > 0:
                instancesOk = False

                lg(
                    "\n\nThe following instances are set to use values from themselves; this is the default and does not need to be specified."
                )

                for _ in df:
                    lg(_)

            # ---

            df = dbPropsDf[
                dbPropsDf["Instance"].isin(dbPropsDf["Use Values from Instance"])
            ]
            df = df[df["Use Values from Instance"] != df["Instance"]]
            df = df[df["Use Values from Instance"] != ""]

            filename = (
                outputFilePath + os.sep + "Add_Properties_Instance_Override_Chains.csv"
            )

            if len(df) > 0:
                instancesOk = False

                df.sort_values(["Database Name", "Instance"]).to_csv(
                    filename, index=False
                )
                lg(
                    "\nThere are "
                    + str(len(df))
                    + " instances that use override values from instances that themselves are overridden; they have been written to file "
                    + filename
                )

            elif os.path.exists(filename):
                os.remove(filename)
            # ---

            try:
                dbPropsDf["vCPU"] = dbPropsDf["vCPU"].apply(pd.to_numeric)
            except:
                instancesOk = False
                lg('\n\nOne or more values of column "vCPU" is a non-numeric value.')

            # ---

            try:
                dbPropsDf["SGA (MB)"] = dbPropsDf["SGA (MB)"].apply(pd.to_numeric)
            except:
                instancesOk = False
                lg(
                    '\n\nOne or more values of column "SGA (MB)" is a non-numeric value.'
                )

            # ---

            try:
                dbPropsDf["PGA (MB)"] = dbPropsDf["PGA (MB)"].apply(pd.to_numeric)
            except:
                instancesOk = False
                lg(
                    '\n\nOne or more values of column "PGA (MB)" is a non-numeric value.'
                )

            # ---

            try:
                dbPropsDf["IOPS"] = dbPropsDf["IOPS"].apply(pd.to_numeric)
            except:
                instancesOk = False
                lg('\n\nOne or more values of column "IOPS" is a non-numeric value.')
            # ---

            if "Logons" in dbPropsDf:
                try:
                    dbPropsDf["Logons"] = dbPropsDf["Logons"].apply(pd.to_numeric)
                except:
                    instancesOk = False
                    lg(
                        '\n\nOne or more values of column "Logons" is a non-numeric value.'
                    )

            # ---

            df = dbPropsDf[
                (dbPropsDf["Use Values from Instance"] != "")
                & (~dbPropsDf["Use Values from Instance"].isin(dbPropsDf["Instance"]))
            ][["Instance", "Use Values from Instance"]].values

            if len(df) > 0:
                instancesOk = False

                lg(
                    "\n\nThe folliowing [Use Values from Instance, Instance] pairs reference an Instance that does not exist."
                )

                for _ in df:
                    lg(str(_))

            df = dbPropsDf[(dbPropsDf["Use Values from Instance"] != "")][
                ["Database Name", "Instance", "Use Values from Instance"]
            ].drop_duplicates()
            df = df[df["Use Values from Instance"] != df["Instance"]].drop_duplicates()

            if len(df) > 0:
                df.rename(
                    columns={
                        "Database Name": "Target Database Name",
                        "Instance": "Target Instance",
                    },
                    inplace=True,
                )

                df = pd.merge(
                    left=df,
                    right=dbPropsDf[["Database Name", "Instance"]],
                    how="left",
                    left_on=["Use Values from Instance"],
                    right_on=["Instance"],
                )
                df.rename(
                    columns={
                        "Database Name": "Source Database Name",
                        "Instance": "Source Instance",
                    },
                    inplace=True,
                )
                df = df[
                    [
                        "Source Database Name",
                        "Target Database Name",
                        "Target Instance",
                        "Use Values from Instance",
                    ]
                ]
                df.rename(
                    columns={
                        "Target Database Name": "Database Name",
                        "Target Instance": "Instance",
                    },
                    inplace=True,
                )

                df = df[df["Source Database Name"] != df["Database Name"]]

                filename = (
                    outputFilePath
                    + os.sep
                    + "Add_Properties_Instance_Override_Mismatches.csv"
                )

                if len(df) > 0:
                    instancesOk = False

                    df.sort_values(["Database Name", "Instance"]).to_csv(
                        filename, index=False
                    )
                    lg(
                        "\nThere are "
                        + str(len(df))
                        + " instances that use override values from another database; they have been written to file "
                        + filename
                    )

                elif os.path.exists(filename):
                    os.remove(filename)

            if not instancesOk:
                lg(
                    "\n\nPlease correct the inconsistencies in file "
                    + propertiesFilePath
                    + os.sep
                    + "properties_instances.csv and re-run this script.\n"
                )

                quit()

        # ---

        for c in dbPropsDf.columns:
            if c == "Instance":
                continue

            elif c == "vCPU":
                replaceDBProperty("db_vcpu_ovr", c)

            elif c == "SGA (MB)":
                replaceDBProperty("db_sga_mb_ovr", c)

            elif c == "PGA (MB)":
                replaceDBProperty("db_pga_mb_ovr", c)

            elif c == "IOPS":
                replaceDBProperty("db_iops_ovr", c)

            elif c == "Logons":
                replaceDBProperty("db_logons_ovr", c)

            elif c == "Use Values from Instance":
                replaceDBProperty("db_ovr", c)

            else:
                continue

# ---

len9 = len(structureDf)
if 1 == 0:
    filename = outputFilePath + os.sep + "Add_Properties.len10.csv"
    structureDf.sort_values(["cluster", "cdb", "host", "db"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

# ---

if not os.path.exists(propertiesFilePath + os.sep + "properties_server.csv"):
    lg(
        "\nFile "
        + propertiesFilePath
        + os.sep
        + "properties_server.csv does not exist; skipping"
    )

else:
    lg(
        "\nExamining file "
        + propertiesFilePath
        + os.sep
        + "properties_server.csv for replacement values..."
    )

    hPropsDf = pd.read_csv(propertiesFilePath + os.sep + "properties_server.csv")
    hPropsDf.columns = [c.strip() for c in hPropsDf.columns]

    if "CPU Type" in hPropsDf:
        hPropsDf["CPU Type"] = hPropsDf["CPU Type"].fillna("")
        hPropsDf["CPU Type"] = hPropsDf["CPU Type"].str.strip()
        hPropsDf["CPU Type"] = hPropsDf["CPU Type"].str.upper()

    if "target_guid" not in hPropsDf:
        if (
            "h_target_guid" in hPropsDf
        ):  # needed just in case they have copied the AUDIT spreadsheet to properties
            hPropsDf.rename(columns={"h_target_guid": "target_guid"}, inplace=True)
        else:
            e(
                "\nUnable to replace properties using file "
                + propertiesFilePath
                + os.sep
                + 'properties_server.csv; missing column "target_guid"'
            )
            quit()

    # ---

    cols = {}

    if "physical_cpu_count" in hPropsDf and "h_physical_cpu_count" not in hPropsDf:
        cols["physical_cpu_count"] = "h_physical_cpu_count"
    if "logical_cpu_count" in hPropsDf and "h_logical_cpu_count" not in hPropsDf:
        cols["logical_cpu_count"] = "h_logical_cpu_count"
    if "total_cpu_cores" in hPropsDf and "h_total_cpu_cores" not in hPropsDf:
        cols["total_cpu_cores"] = "h_total_cpu_cores"

    if len(cols) > 0:
        hPropsDf.rename(columns=cols, inplace=True)

    # ---

    if len(hPropsDf) > 0:
        hPropsDf["total_cpu_cores_ovr"] = hPropsDf["h_total_cpu_cores"]
        hPropsDf.loc[
            (hPropsDf["Chip Count (Actual)"] > 0)
            & (hPropsDf["Cores Per Chip (Actual)"] > 0),
            "total_cpu_cores_ovr",
        ] = (
            hPropsDf["Chip Count (Actual)"] * hPropsDf["Cores Per Chip (Actual)"]
        )

        # hPropsDf.to_csv(propertiesFilePath + os.sep + 'properties_server_ovr.csv', index=False)

        for c in hPropsDf.columns:
            if c == "Server Name":
                continue

            elif c == "CPU Type":
                replaceHProperty("h_cpu_type_ovr", c)

            elif c == "Chip Count (Actual)":
                replaceHProperty("h_physical_cpu_count_ovr", c)
                replaceHProperty("h_total_cpu_cores_ovr", "total_cpu_cores_ovr")

            elif c == "Cores Per Chip (Actual)":
                replaceHProperty("h_cores_per_chip_ovr", c)
                replaceHProperty("h_total_cpu_cores_ovr", "total_cpu_cores_ovr")

            elif c == "Description":
                replaceHProperty("h_description_ovr", c)

            else:
                continue

# ----------------------------------------------------------------------------------------------------------------------

dFilename = outputFilePath + os.sep + "Add_Properties.noDb.csv"
noDbDf = structureDf[structureDf["db"] == "none"][
    ["host", "dbmachine"]
].drop_duplicates()

if len(noDbDf) > 0:
    lg(
        "\n\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    )
    lg(
        "\nThere are "
        + str(len(noDbDf))
        + " rows in file "
        + structureFilename
        + " that have no database assignment"
    )
    lg("These rows have been removed and written to file " + dFilename)
    lg(
        "\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"
    )

    noDbDf.sort_values(["host"]).to_csv(dFilename, index=False)

elif os.path.exists(dFilename):
    os.remove(dFilename)

# ----------------------------------------------------------------------------------------------------------------------

len10 = len(structureDf)

dFilename = outputFilePath + os.sep + "Add_Properties.len11.csv"

if len9 < len10:
    lg(
        "\nThe length of structureDf has changed from "
        + str(len9)
        + " to "
        + str(len10)
    )
    lg("Values have been written to file " + dFilename + " that might assist debugging")

    structureDf.sort_values(["cluster", "cdb", "host", "db"]).to_csv(
        outputFilePath + os.sep + "Add_Properties.len11.csv", index=False
    )

elif os.path.exists(dFilename):
    os.remove(dFilename)

# ----------------------------------------------------------------------------------------------------------------------

if FIXED:
    cwd = "fixed"
    now = "1989-07-09 00:00:00"
    __version__ = "fixed"
else:
    cwd = os.getcwd().split(os.sep)[-1]

structureDf["cwd"] = cwd
structureDf["created_dttm_utc"] = now
structureDf["version"] = __version__

structureDf["cdb_cohort"] = structureDf["cdb_cohort"].fillna("")
structureDf["db_cohort"] = structureDf["cdb_cohort"]

filename = outputFilePath + os.sep + "occa_sizing_structure_after_replacement.csv"
structureDf.sort_values(["db"]).to_csv(filename, index=False)

# ----------------------------------------------------------------------------------------------------------------------

duplicateTestResults, structureDf = Duplicate_Tests.duplicateTests(
    structureDf, "Add_Properties", outputFilePath
)

# ----------------------------------------------------------------------------------------------------------------------

structureDf.sort_values(["db"]).to_csv(
    outputFilePath + os.sep + "occa_sizing_structure_db_combined.csv", index=False
)
lg("\nWrote file " + outputFilePath + os.sep + "occa_sizing_structure_db_combined.csv")

if (
    len0 < len1
    or len1 < len2
    or len2 < len3
    or len3 < len4
    or len4 < len5
    or len5 < len6
    or len6 < len7
    or len7 < len8
    or len8 < len9
    or len9 < len10
):
    lg("\nThere is a suspicious change in the number of rows")
    lg("--------------------------------------------------")
    lg("len0: " + str(len0))
    lg("len1: " + str(len1))
    lg("len2: " + str(len2))
    lg("len3: " + str(len3))
    lg("len4: " + str(len4))
    lg("len5: " + str(len5))
    lg("len6: " + str(len6))
    lg("len7: " + str(len7))
    lg("len8: " + str(len8))
    lg("len9: " + str(len9))
    lg("len10: " + str(len10))

# ----------------------------------------------------------------------------------------------------------------------

if len(errors) > 0:
    lg(
        "\n\n-------------------------------------------------------------------------------------------------------"
    )

    for t in errors:
        lg(t)

    lg(
        "\n-------------------------------------------------------------------------------------------------------"
    )

    quit()

# ----------------------------------------------------------------------------------------------------------------------

Duplicate_Tests.emitDuplicateTestResults(duplicateTestResults, logFile)

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nThe processing of "
    + str(len(structureDf))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
