import inspect
import math
import re
import os
from version import version, __version__

SHARED_VERSION = __version__

CPU_DERIVED_METRIC = "Derived.logical_cores_used-metric-2"
CPU_DERIVED_METRIC_STANDBY = "Derived.logical_cores_used-metric-2.standby"
IOPS_METRIC_STANDBY = "instance_throughput.iorequests_ps.standby"
SGAPGA_DERIVED_METRIC = "Derived.sga_plus_pga_usage"

CPU_METRIC = "db_inst_cpu_usage.avg_tot_cpu_usage_ps"
IOPS_METRIC = "instance_throughput.iorequests_ps"
IOMBS_METRIC = "instance_throughput.iombs_ps"
PHYSREADS_METRIC = "instance_throughput.physreads_ps"
PHYSWRITES_METRIC = "instance_throughput.physwrites_ps"
LOGONS_METRIC = "Database_Resource_Usage.logons"
PGA_METRIC = "memory_usage_sga_pga.pga_total"
SGA_METRIC = "memory_usage_sga_pga.sga_total"

STORAGE_ALLOCATED_METRIC = "DATABASE_SIZE.ALLOCATED_GB"
STORAGE_USED_METRIC = "DATABASE_SIZE.USED_GB"

HOST_CPU_METRIC = "Load.cpuUtil"

VCPU_REDUCABLE_CPU_TYPES = ["SPARC"]

#
# Error bar percentage for eliminating CPU consumption values > cpu_count
#
CPU_CAGING_ERROR_BAR_PCT = 10
#
# https://confluence.oraclecorp.com/confluence/display/~christian.craft@oracle.com/2.OCCA+Sizing+Algorithm
#
AIX_DEFLATION = 4

PHYSICAL_STANDBY = "Physical Standby"
PRIMARY_PLUS_STANDBY = "Primary + Standby Instance Metrics"
STANDBY_INSTANCE_METRICS = "Standby Instance Metrics"

EMCC_INSTANCE_METRICS = [
    CPU_METRIC,
    IOMBS_METRIC,
    IOPS_METRIC,
    LOGONS_METRIC,
    PGA_METRIC,
    SGA_METRIC,
    PHYSREADS_METRIC,
    PHYSWRITES_METRIC,
]
EMCC_STORAGE_METRICS = [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]


EMCC_INSTANCE_REQUIRED_METRICS = [CPU_METRIC, IOPS_METRIC, PGA_METRIC, SGA_METRIC,LOGONS_METRIC]

EMCC_METRIC_COULMN_ALIASES = {
    CPU_DERIVED_METRIC: "DB vCPU",
    CPU_DERIVED_METRIC_STANDBY: "DB vCPU for Standby",
    CPU_METRIC: "DB vCPU",
    IOPS_METRIC_STANDBY: "DB IOPS for Standby",
    IOPS_METRIC: "DB IOPS",
    PHYSREADS_METRIC: "DB Reads",
    PHYSWRITES_METRIC: "DB Writes",
    IOMBS_METRIC: "DB IO MBs",
    LOGONS_METRIC: "DB Logons",
    PGA_METRIC: "DB PGA (MB)",
    SGA_METRIC: "DB SGA (MB)",
    SGAPGA_DERIVED_METRIC: "DB Memory (MB)",
    STORAGE_ALLOCATED_METRIC: "Allocated Storage (GB)",
    STORAGE_USED_METRIC: "Used Storage (GB)",
}

EMCC_METRIC_COULMN_UOMS = {
    CPU_DERIVED_METRIC: "vCPU",
    CPU_DERIVED_METRIC_STANDBY: "vCPU",
    CPU_METRIC: "vCPU",
    IOPS_METRIC_STANDBY: "IOPS",
    IOPS_METRIC: "IOPS",
    IOMBS_METRIC: "IO MBs",
    PHYSREADS_METRIC: "IOPS",
    PHYSWRITES_METRIC: "IOPS",
    LOGONS_METRIC: "Logons",
    PGA_METRIC: "MB",
    SGA_METRIC: "MB",
    SGAPGA_DERIVED_METRIC: "MB",
    STORAGE_ALLOCATED_METRIC: "GB",
    STORAGE_USED_METRIC: "GB",
}

OCCA_METRIC_COULMN_UOMS = {
    "DB vCPU": "vCPU",
    "DB IOPS": "IOPS",
    "DB Logons": "IOPS",
    "DB PGA (MB)": "MB",
    "DB SGA (MB)": "MB",
    "DB Memory (MB)": "MB",
    "Allocated Storage (GB)": "GB",
    "Used Storage (GB)": "GB",
    "DB Reads": "IOPS",
    "DB Writes": "IOPS",
    "DB IO MBs": "IO MBs",
}

EMCC_METRIC_ALIAS_UOMS = {}
for k in EMCC_METRIC_COULMN_ALIASES:
    EMCC_METRIC_ALIAS_UOMS[EMCC_METRIC_COULMN_ALIASES[k]] = EMCC_METRIC_COULMN_UOMS[k]

EMCC_INSTANCE_METRIC_OVERRIDE_COLUMNS = {
    CPU_METRIC: "db_vcpu_ovr",
    IOPS_METRIC: "db_iops_ovr",
    LOGONS_METRIC: "db_logons_ovr",
    PGA_METRIC: "db_pga_mb_ovr",
    SGA_METRIC: "db_sga_mb_ovr",
}

EMCC_STORAGE_METRIC_OVERRIDE_COLUMNS = {
    STORAGE_ALLOCATED_METRIC: "cdb_size_allocated_ovr",
    STORAGE_USED_METRIC: "cdb_size_used_ovr",
}

#
# Limit cohort length because of the limit of 31 chars for worksheet names
#

COHORT_MAX_LEN = 150

# CPU NAMES CONSTANTS
SPARC = "SPARC"
INTEL = "INTEL"
IBM = "IBM"
AMD = "AMD"

# CPU Types patterns :
SPARC_PATTERN = re.compile(r"SPARC|SUN4V|SOLARIS", re.IGNORECASE)
INTEL_PATTERN = re.compile(r"GenuineIntel|x86", re.IGNORECASE)
IBM_PATTERN = re.compile(r"POWER|AIX|ZSERIES", re.IGNORECASE)
AMD_PATTERN = re.compile(r"AMD", re.IGNORECASE)

logFile = ""

# ---------------------------------------------------------------------------------------------------------------------


def close_Log():
    global logFile

    logFile.close()


# ----------------------------------------------------------------------------------------------------------------------


def getCPUType(ma, impl=""):
    """
    Try to get cpu_type from 'ma' column or 'impl' column based on patterns.

    Parameters:
        ma : str
        impl : str, optional
    Returns:
        str
            The CPU type.
    """
    ma = str(ma)  # Cast to string (sometimes it's float)
    impl = str(impl)

    if INTEL_PATTERN.search(ma) or INTEL_PATTERN.search(impl):
        return INTEL

    if IBM_PATTERN.search(ma) or IBM_PATTERN.search(impl):
        return IBM

    if AMD_PATTERN.search(ma) or AMD_PATTERN.search(impl):
        return AMD

    if SPARC_PATTERN.search(ma) or SPARC_PATTERN.search(impl):
        return SPARC

    return "OTHER: " + ma if ma else ""


# ----------------------------------------------------------------------------------------------------------------------


def logical_cpu_count_effective(cpu_type, cores, logical_cpu_count):
    #
    # SPARC T4-1 measurements for an OLTP workload
    # strands per core
    #
    # Use: If the OS says a box with n cores is using x strands, find
    # x' = alpha(n)[x] - rounding x up or down, or interpolating, it won't
    # matter much. x' is the real number of strands worth of throughput
    # the box is providing, in units of the throughput of the 'unloaded'
    # strands - the throughput you would see if the box was only using
    # the first strand of each core.
    #
    # Suppose a database is running on the box, and reports that it is
    # using y strands. The adjusted value (the one we want to use) is
    # then y * (x'/x).
    #
    # For example, if the box has 8 cores, and the OS says that it is
    # running at 100% utilization - using all 64 strands - and a database
    # reports that it is using 16 strands, then alpha(8)[63] = 15.68, and
    # the number we actually want is 16 * (15.68/64), or about 3.92 strands.
    #

    SPARC_COEFS = [1.000, 0.481, 0.220, 0.116, 0.087, 0.053, 0.003, 0.000]

    if cpu_type == "SPARC" and logical_cpu_count == math.floor(cores) * 8:
        cv, rv = 0, [0] * (math.floor(cores) * len(SPARC_COEFS))

        if len(rv) == 0:
            rv = [0]

        for i in range(len(SPARC_COEFS)):
            for j in range(math.floor(cores)):
                cv += SPARC_COEFS[i]
                rv[i * math.floor(cores) + j] = cv

    else:
        if not math.isnan(logical_cpu_count):
            rv = [_ + 1 for _ in range(int(logical_cpu_count))]

            if len(rv) == 0:
                rv = [0]
        else:
            rv = [0]
    return rv


# ----------------------------------------------------------------------------------------------------------------------


def getEffectivehostCPU(hostCPUEffectiveDict, target_guid, logical_cpu_count):
    try:

        if target_guid in hostCPUEffectiveDict:
            if math.floor(logical_cpu_count) >= len(hostCPUEffectiveDict[target_guid]):
                rv = hostCPUEffectiveDict[target_guid][-1]
            else:
                rv = min(
                    logical_cpu_count,
                    hostCPUEffectiveDict[target_guid][math.floor(logical_cpu_count)],
                )
        else:
            rv = logical_cpu_count

    except Exception as es:
        lg("getEffectivehostCPU raised the following exception\n" + str(es))
        lg("target_guid      : " + target_guid)
        lg("logical_cpu_count: " + str(logical_cpu_count))

        raise

    return rv


# ----------------------------------------------------------------------------------------------------------------------


def getMetricAlias(metric):
    r = (
        EMCC_METRIC_COULMN_ALIASES[metric]
        if metric in EMCC_METRIC_COULMN_ALIASES
        else metric
    )

    return r


# ----------------------------------------------------------------------------------------------------------------------


def getOverrideValues(sourceDf, guid, displayColumn, valueColumn, name):
    df = sourceDf[[guid, displayColumn, valueColumn]].drop_duplicates()
    df = df[df[valueColumn].notnull()]

    if len(df) == 0:
        return []

    df["name"] = name
    df.rename(columns={valueColumn: "value"}, inplace=True)

    return df


# ----------------------------------------------------------------------------------------------------------------------


def lg(t: object) -> object:

    print(t)
    logFile.write(t + "\n")
    logFile.flush()


# ----------------------------------------------------------------------------------------------------------------------


def ln():
    return str(inspect.currentframe().f_back.f_lineno)


# ----------------------------------------------------------------------------------------------------------------------


def open_log(logFilename):
    global logFile

    logFile = open(logFilename, "a")

    return logFile


# ----------------------------------------------------------------------------------------------------------------------


def printDf(lbl, dataFrameToPrint, rows=25, showTail=True):
    lg("\n" + lbl + " of len " + str(len(dataFrameToPrint)))
    lg("--------------------------------------------------")
    lg("index")
    lg("=====")

    for c in dataFrameToPrint.index.names:
        if c is None:
            lg("None")
        else:
            lg(str(c).ljust(45))

    lg("\ncolumns")
    lg("========")

    for c in sorted(dataFrameToPrint.columns):
        lg(str(c).ljust(45) + " : " + str(dataFrameToPrint[c].dtypes))

    lg("\nhead(" + str(rows) + ")")
    lg(str(dataFrameToPrint.head(rows)))

    if showTail:
        lg("\ntail(" + str(rows) + ")")
        lg(str(dataFrameToPrint.tail(rows)))

    lg("--------------------------------------------------")

def raise_error_when_run_from_api(type : str = 'AWR ',message : str = "Something wrong happened"):
    if os.environ.get("RUN_FROM_API", "False") == "True":
        raise Exception(type+message)

def lg_cannotReadCSVFile(fileName, fc):
    message_error = f"""
        \n\nUnbale to read 
         {fileName}
        assuming a comma-separated-values (csv) format.
        Please examine the contents of this file directly.
        If the file contents are not a properly formatted csv file, the scripts in the repair directory may be able to re-format them.
        \nThe specific exception raised follows\n" + {str(fc)}
    """
    lg(message_error)
    raise_error_when_run_from_api("EMCC: ",message_error)


def lg_notLikelyCSVFile(fileName, fc):
    message_error = f"""
        \n\nThe contents of
        {fileName}
        were read assuming a comma-separated-values (csv) format which is not likely the case.
        \nPlease examine the contents of this file directly.
        If the file contents are not a properly formatted csv file, the scripts in the repair directory may be able to re-format them.
        \nThe specific exception raised follows\n" + {str(fc)}
    """
    lg(message_error)
    raise_error_when_run_from_api("EMCC: ", message_error)
