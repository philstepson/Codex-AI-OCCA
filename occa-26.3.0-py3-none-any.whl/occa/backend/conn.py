from functools import wraps

import oracledb

from backend.api_utils.custom_response import CustomResponse
from version import version, __version__
from .config import Config
import logging

class DatabaseConnector:
    _instance = None
    _connection = None


    def __new__(cls, *args, **kwargs):
        """
        Create a new DatabaseConnector instance if it does not exist, otherwise return the existing instance.

        Parameters
        ----------
        args : tuple
            Positional arguments for initializing the instance.
        kwargs : dict
            Keyword arguments for initializing the instance.

        Returns
        -------
        DatabaseConnector
            The DatabaseConnector instance.
        """
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize_connection(*args, **kwargs)
        return cls._instance

    def _initialize_connection(self):
        """
       Initialize the database connection.

       Raises
       ------
       oracledb.DatabaseError
           If the connection to the database fails.
       """
        try:
            self.connection = oracledb.connect(Config.get_connect_string())
        except oracledb.DatabaseError as e:
            print(f"Failed to connect to the database: {e}")
            raise

    @staticmethod
    def get_connection() -> oracledb.Connection :
        if DatabaseConnector._connection is None or  not DatabaseConnector._connection.is_healthy():
            try:
                DatabaseConnector._connection = oracledb.connect(Config.get_connect_string())
                logging.info("Connection to the database established successfully.")
            except oracledb.DatabaseError as e:
                logging.error(f"Failed to connect to the database: {e}")
                raise
        return DatabaseConnector._connection

    @staticmethod
    def with_database_connection(func):
        """
        Decorator function to ensure database connection management for a given function.

        Parameters
        ----------
        func : function
            The function to be decorated.

        Returns
        -------
        function
            The decorated function.
        """
        @wraps(func)
        def wrapper(*args, **kwargs):
            connection = DatabaseConnector.get_connection()
            result = func(connection, *args, **kwargs)
            return result

        return wrapper

    @classmethod
    def check_database_connection(cls) -> dict:
        """
        Check the status of the database connection.

        Returns
        -------
        CustomResponse
            Response returning data and status code
        """

        try:
            conn = cls.get_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT 1 FROM dual")
                cursor.fetchone()
            return CustomResponse.success(cls._ok_message())
        except Exception as e:
            return CustomResponse.server_error(cls._bad_message(e))

    @classmethod
    def _ok_message(cls) -> dict:
        """
        Healthy DB.

        Returns
        -------
        dict
            Dictionary containing the success message and connection status.
        """
        return {
            "message":"All good here :)",
            "status":"Connected"
        }

    @classmethod
    def _bad_message(cls, error_message: str) -> dict:
        """
        Generates a message when the db is down or an error occurred.

        Parameters
        ----------
        error_message : str
            Error message describing the reason for the connection failure.

        Returns
        -------
        dict
            Dictionary containing the failure message and connection status.
        """
        return {
            "message":f"Failed to connect: {error_message}",
            "status":"Failed"
        }
