import json
import os

from datetime import datetime

from fastapi import APIRouter
from starlette.responses import JSONResponse
from fastapi.encoders import jsonable_encoder


from ..api_utils.database import DatabaseManager
from ..conn import DatabaseConnector
from ..services.main_service import download_extract
from ..services.complete_processing import generate_opportunity
from ..api_utils.queries import *
from version import version, __version__

main_router = APIRouter()


@main_router.get("/health_check/")
def health_check():
    """
    Endpoint for checking the health of the database.

    Returns
    -------
    tuple
        A tuple containing the JSON response and the status code.
    """
    db_response, status_code = DatabaseConnector.check_database_connection()
    return JSONResponse(status_code=status_code, content=db_response)


from fastapi import BackgroundTasks
def process_download_file_in_background(upload_id: int):
    db_manager = DatabaseManager()
    download_extract(upload_id, db_manager=db_manager)


def complete_processing_in_background(upload_id: int):
    db_manager = DatabaseManager()
    generate_opportunity(upload_id, db_manager=db_manager)


@main_router.get("/download_file/{id}")
def download_file(id: str, background_tasks: BackgroundTasks,SMOKE_TEST: str = ''):
    """
   Endpoint for processing extracts.

   Parameters
   ----------
   id : str
       The ID of the file to download.

   Returns
   -------
   custom_response
       A tuple containing the JSON response and the status code.
   """
    # Add the background task
    os.environ["SMOKE_TEST"] = "True" if SMOKE_TEST == 'True' else "False"

    background_tasks.add_task(process_download_file_in_background, id)
    return JSONResponse(status_code=200, content={"message":"Processing in the background"})


@main_router.get("/complete_processing/{id}")
def complete_processing(id: str, background_tasks: BackgroundTasks,SMOKE_TEST: str = ''):
    """
   Endpoint for processing extracts.

   Parameters
   ----------
   id : str
       The ID of the file to download.

   Returns
   -------
   custom_response
       A tuple containing the JSON response and the status code.
   """
    # db_manager = DatabaseManager()
    # res, status_code = generate_opportunity(id, db_manager=db_manager)

    os.environ["SMOKE_TEST"] = "True" if SMOKE_TEST == 'True' else "False"


    background_tasks.add_task(complete_processing_in_background, id)
    return JSONResponse(status_code=200, content={"message":"Final Processing Started"})


def json_serial(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()


@main_router.get("/run_pending")
def run_pending(background_tasks: BackgroundTasks):
    """
    Endpoint to process all pending uploads.

    Parameters
    ----------
    background_tasks : BackgroundTasks
        Background task manager to run tasks in the background.

    Returns
    -------
    JSONResponse
        A response indicating that the processing has started.
    """
    db_manager = DatabaseManager()
    pending_uploads = db_manager.get_pending_uploads()

    if not pending_uploads:
        return JSONResponse(status_code=200, content={"message":"No pending uploads found."})

    for upload in pending_uploads:
        print('Added to queue:   ', upload)
        background_tasks.add_task(process_download_file_in_background, str(upload[0]))

    return JSONResponse(
        status_code=200,
        content={"message":json.dumps(pending_uploads, default=json_serial)}
    )


@main_router.get("/errors")
def get_error_uploads():
    """
    Endpoint to fetch all uploads with errors in their status.

    Returns
    -------
    JSONResponse
        A response containing the records with errors.
    """
    db_manager = DatabaseManager()
    error_uploads = db_manager.fetch_error_uploads()
    formatted_errors = []
    for upload in error_uploads:
        formatted_errors.append({
            "id":upload[0],
            "status":upload[1],
            "created_by":upload[2],
            "created_on":upload[3].isoformat() if upload[3] else ''
        })

    return JSONResponse(status_code=200, content=formatted_errors)

@main_router.get("/errors/{created_by}")
def fetch_error_uploads( created_by : str):
    db_manager = DatabaseManager()

    # params to search
    params = {
        'status':'%error%',
        'created_by':created_by.upper()
    }
    data= db_manager.fetch_error_uploads_by_user(params)

    return JSONResponse(status_code=200, content=jsonable_encoder(data))
