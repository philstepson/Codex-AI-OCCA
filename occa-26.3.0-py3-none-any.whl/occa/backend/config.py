import os
from version import version, __version__

class Config:

    user = os.environ.get("USER")
    password = os.environ.get("PASSWORD")
    host = os.environ.get("HOST")
    port = os.environ.get("PORT")
    service_name = os.environ.get("SERVICE_NAME")

    @staticmethod
    def get_connect_string():
        if "CONNECT_OCCAPROD" in os.environ:
            connect_string = os.environ["CONNECT_OCCAPROD"]
        elif "CONN_STRING" in os.environ:
            connect_string = os.environ["CONN_STRING"]
        else:
            connect_string = f"{Config.user}/{Config.password}@{Config.host}:{Config.port}/{Config.service_name}"
            if connect_string.count('None') > 1: #Needed for test
                print('Need to setup one of the [CONN_STRING,CONNECT_OCCAPROD] variables'.center(100,'*'))
                return None
        return connect_string
