from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from backend.conn import DatabaseConnector
from .config import Config



def create_app():
    app = FastAPI()

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    from backend.routes.main_routes import main_router
    app.include_router(main_router)
    if Config.get_connect_string() :
        DatabaseConnector()  # Initialize the DB connection
    # DatabaseConnector.initialize_pool()

    return app
