import contextlib
import os
import shutil
from datetime import datetime
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

import backend.api_utils.constants as c
from backend.api_utils.queries import *
from backend.conn import DatabaseConnector
from backend.services.main_service import download_extract, format_data_plots, insert_plots,\
    organize_files, directory_to_create


def cleanup(directory):
    """
    Teardown for creating temp files.
    """
    if os.path.exists(directory):
        shutil.rmtree(directory)


@pytest.fixture
def sample_plots_data():
    return {
        "FILENAME":"alodev",
        "OPP_ID":"12345678",
        "created_by":"megatron",
        "FILE_BLOB":MagicMock(),
        "DB_NAME":"my_db"

    }


@contextlib.contextmanager
def chdir(dir):
    """Change the directory to temp dir and when finished return to the original dir"""
    orig_cwd = os.getcwd()
    os.chdir(dir)
    try:
        yield
    finally:
        os.chdir(orig_cwd)


@pytest.fixture
def temp_dir(tmpdir, request):
    directory = tmpdir.mkdir("customer_name").mkdir("filename")

    request.addfinalizer(lambda:cleanup(tmpdir))
    return directory


@pytest.fixture
def awr_temp_dir(tmpdir, request):
    directory = tmpdir.mkdir("customer_name").mkdir("awr_miner_out")
    request.addfinalizer(lambda:cleanup(tmpdir))
    return str(directory)


@pytest.fixture
def emcc_temp_dir(tmpdir, request):
    directory = tmpdir.mkdir("customer_name").mkdir("emcc_sizing_extracts")
    request.addfinalizer(lambda:cleanup(tmpdir))
    return str(directory)


@pytest.fixture
def mock_db_manager():
    with patch("backend.api_utils.database.DatabaseManager") as mock_db_manager:
        yield mock_db_manager.return_value


@pytest.fixture
def mock_automation():
    with patch("backend.api_utils.automation") as mock_automation:
        yield mock_automation.return_value


def test_download_extract_success(mock_db_manager, temp_dir):
    mock_db_manager.get_archive_extract_by_id.return_value = (
        "filename.zip",
        b"zip_file_content",
        "application/zip",
        "customer_name",
        "charset",
        "comments",
        "opportunity_name",
        "created_by"
    )

    mock_connection = MagicMock()

    mock_db_manager.connection.cursor.return_value.__enter__.return_value = mock_connection
    mock_db_manager.get_connection.return_value = mock_connection
    with patch("backend.services.main_service.DirectoryHandler") as mock_directory_handler,\
            patch("backend.services.main_service.open", create=True) as mock_open,\
            patch("backend.services.main_service.organize_files") as mock_organize_files,\
            patch(
                "backend.services.main_service.run_and_insert_initial_process") as mock_run_and_insert_initial_process,\
            patch("backend.services.main_service.inserting_plots_for_awr") as inserting_plots_for_awr,\
            patch("backend.services.main_service.ProcessPoolExecutor") as mock_pool,\
            patch("backend.services.main_service.DatabaseConnector.get_connection", return_value = mock_connection),\
            patch("backend.services.main_service.os.chdir") as mock_chdir:
        mock_chdir.side_effect = lambda dir:None

        mock_organize_files.return_value = Path(c.AWR_MINER_OUT)

        mock_directory_handler.make_directories.return_value = Path("/customer_name/created_by/1/filename.zip")
        mock_directory_handler.extract_file.return_value = None
        mock_directory_handler.get_extracts_dir.return_value = Path("/customer_name/1/filename/")

        mock_file_obj = mock_open.return_value.__enter__.return_value
        mock_file_obj.write.return_value = None

        with mock_pool() as mock_pool_obj:
            mock_pool_obj.map_async.return_value.get.return_value = [{"FILENAME":"plot1"}, {"FILENAME":"plot2"}]
            mock_pool_obj.is_awr=True
            with chdir("/"):
                response = download_extract('1', mock_db_manager)
                assert response[1] == 201
                assert response[0] == {'message':'Properties & TZ csv files created & inserted to tables.'}

        mock_os_walk = MagicMock()
        mock_os_walk.return_value = [('/customer_name/filename/', [], [])]

        mock_organize_files.return_value = Path("/customer_name/filename/")

        mock_directory_handler.make_directories.assert_called_once_with(Path("/customer_name/1/filename"))
        mock_directory_handler.write_binary.assert_called_once_with(Path("/customer_name/1/filename/filename.zip"),
                                                                    b"zip_file_content")
        mock_directory_handler.extract_file.assert_called_once_with(Path("/customer_name/1/filename/"),
                                                                    Path("/customer_name/1/filename/filename.zip"))
        mock_organize_files.assert_called_once_with(Path("/customer_name/1/filename/"))
        mock_run_and_insert_initial_process.assert_called_once()
        inserting_plots_for_awr.assert_called_once()


def test_download_extract_failing(mock_db_manager):
    exception_message = "Testing"
    mock_db_manager.get_archive_extract_by_id.side_effect = Exception(exception_message)
    response = download_extract(1, mock_db_manager)

    assert response[1] == 500
    assert f"An error occurred: {exception_message}" in response[0]["message"]


def test_format_data_plots(sample_plots_data):
    upload_id = "12345678"
    db = "alodev"

    formatted_data = format_data_plots(upload_id, db, sample_plots_data, 'db_name')

    assert formatted_data["UPLOAD_ID"] == upload_id
    assert formatted_data["WHICH_DB"] == db
    assert formatted_data["FILE_MIMETYPE"] == "image/png"
    assert formatted_data["CREATED_BY"] == sample_plots_data['created_by']
    assert isinstance(formatted_data["CREATED_ON"], datetime)
    assert isinstance(formatted_data["MODIFIED_ON"], datetime)


def test_insert_plots(sample_plots_data, mock_db_manager):
    with patch.object(DatabaseConnector, 'get_connection') as mock_get_connection:
        mock_connection = MagicMock()
        mock_get_connection.return_value = mock_connection

        result = insert_plots(sample_plots_data)
        assert result == INSERT_AWR_PLOTS_QRY

    mock_connection.commit.assert_called_once()

    expected = {'FILENAME':'alodev', 'OPP_ID':'12345678', 'created_by':'megatron',
                'FILE_BLOB':sample_plots_data['FILE_BLOB'], 'DB_NAME':'my_db'}
    expected_args = (
        INSERT_AWR_PLOTS_QRY, (expected)
    )

    mock_connection.cursor.return_value.__enter__.return_value.execute.assert_called_with(*expected_args)


def test_organize_files_awr_files(temp_dir):
    # backend/services/main_service.py
    with chdir(temp_dir):
        # temp_dir = Path(temp_dir)
        test_files = ['a.out,b.out', 'c.out']
        for file in test_files:
            with open(temp_dir / file, 'w') as f:
                f.write("I like cats")

        organize_files(Path(temp_dir))

        awr_miner_out_dir = os.path.join(temp_dir, c.AWR_MINER_OUT)
        for file_name in test_files:
            original_path = os.path.join(temp_dir, file_name)
            destination_path = os.path.join(awr_miner_out_dir, file_name)
            assert not os.path.exists(original_path)  # the file should not be in the original path
            assert os.path.exists(destination_path)  # file moved by organize_files


def test_organize_files_emcc_files(temp_dir):
    with chdir(temp_dir):

        test_files = ['a.txt,b.csv', 'c.txt']
        for file in test_files:
            with open(temp_dir / file, 'w') as f:
                f.write("You're doing great:)")

        organize_files(Path(temp_dir))

        emcc_sizing_dir = os.path.join(temp_dir, c.EMCC_SIZING_EXTRACTS)
        for file_name in test_files:
            original_path = os.path.join(temp_dir, file_name)
            destination_path = os.path.join(emcc_sizing_dir, file_name)
            assert not os.path.exists(original_path)  # the file should not be in the original path
            assert os.path.exists(destination_path)  # file moved by organize_files


def test_directory_to_create_awr(awr_temp_dir):
    parent_dir = Path(awr_temp_dir).parent

    # Testing the first if condition the directory is already created and the .outs files are within it.
    with open(Path(awr_temp_dir) / 'random.out', 'w') as f:
        f.write("Sorry Im late I saw a cat")
    dir_to_create = directory_to_create(parent_dir)
    assert dir_to_create == Path(awr_temp_dir)


def test_directory_to_create_awr_walk_files(temp_dir):
    temp_dir_path = Path(temp_dir)

    # Testing looking for .out files
    with open(temp_dir_path / 'sparkles.out', 'w') as f:
        f.write("mew mew mew miau")
    dir_to_create = directory_to_create(temp_dir)
    assert dir_to_create == Path(temp_dir) / c.AWR_MINER_OUT


def test_directory_to_create_emcc(emcc_temp_dir):
    parent_dir = Path(emcc_temp_dir).parent

    # Testing the first if condition the directory is already created and the .txt or .csv files are within it.
    with open(Path(emcc_temp_dir) / 'cat.csv', 'w') as f:
        f.write("meow meow silly cat")
    dir_to_create = directory_to_create(parent_dir)
    assert dir_to_create == Path(emcc_temp_dir)


def test_directory_to_create_emcc_walk_files(temp_dir):
    temp_dir_path = Path(temp_dir)

    # Testing looking for .out files
    with open(temp_dir_path / 'random.csv', 'w') as f:
        f.write("Just live")
    dir_to_create = directory_to_create(temp_dir)
    assert dir_to_create == Path(temp_dir) / c.EMCC_SIZING_EXTRACTS


def test_directory_to_create_raise(temp_dir):
    # no source files nor dirs (awr/emcc) found.
    with pytest.raises(FileNotFoundError):
        organize_files(temp_dir)
