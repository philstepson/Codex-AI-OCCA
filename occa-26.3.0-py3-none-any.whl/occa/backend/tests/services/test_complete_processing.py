import contextlib
import os
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

import pandas as pd
import pytest

from backend.api_utils.queries import *
from backend.conn import DatabaseConnector
from backend.services.complete_processing import generate_opportunity, ColumnsNotMatched, check_columns_match


def cleanup(directory):
    """
    Teardown for creating temp files.
    """
    if os.path.exists(directory):
        shutil.rmtree(directory)


@contextlib.contextmanager
def chdir(dir):
    """Change the directory to temp dir and when finished return to the original dir"""
    orig_cwd = os.getcwd()
    os.chdir(dir)
    try:
        yield
    finally:
        os.chdir(orig_cwd)


@pytest.fixture
def temp_dir(tmpdir, request):
    directory = tmpdir.mkdir("customer_name").mkdir("filename")
    request.addfinalizer(lambda:cleanup(tmpdir))
    return directory


@pytest.fixture
def mock_db_manager():
    with patch("backend.api_utils.database.DatabaseManager") as mock_db_manager:
        yield mock_db_manager.return_value


@pytest.fixture
def mock_automation():
    with patch("backend.api_utils.automation") as mock_automation:
        yield mock_automation.return_value


import string
import random


def random_string(length=10):
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(length))


@pytest.fixture(autouse=True)
def patch_file_paths():
    with patch("occa.constants.Paths.FilePaths", autospec=True) as mock_fp:
        yield mock_fp


def test_generate_opportunity_success(mock_db_manager, temp_dir):
    random_data_props = [{col:random_string() for col in EXTRACTS_PROPERTIES_DATABASE_COLUMNS} for _ in range(5)]
    random_data_tz = [{col:random_string() for col in EXTRACTS_DATABASE_TZ_INFO_COLUMNS} for _ in range(5)]
    mock_db_manager.fetch_table_data_as_df.side_effect = [
        pd.DataFrame(random_data_tz),
        pd.DataFrame(random_data_props)
    ]

    mock_db_manager.fetch_raw_data.side_effect = [
        {
            'FILENAME':'filename.zip',
            'CUSTOMER':'customer_name',
            'FILE_CHARSET':'charset',
            'FILE_COMMENTS':'comments',
            'OPPORTUNITY_NAME':'opportunity_name',
            'CREATED_BY':'created_by'
        },
        ('cat',)
    ]

    mock_connection = MagicMock()
    mock_db_manager.connection = mock_connection

    with patch("backend.services.complete_processing.DirectoryHandler") as mock_directory_handler,\
            patch("backend.services.complete_processing.get_target_json") as mock_get_target_json,\
            patch.object(DatabaseConnector, 'get_connection', return_value=mock_connection),\
            patch("backend.services.complete_processing.fp.resolve_for_awr_emcc", return_value=(True, False)),\
            patch("backend.services.complete_processing.check_columns_match", return_value=True),\
            patch("backend.services.complete_processing.insert_snap_coverage_plot"),\
            patch("pandas.DataFrame.to_csv") as mock_to_csv:
        mock_directory_handler.get_extracts_dir.return_value = Path("/customer_name/1/filename/")
        mock_directory_handler.read_json.return_value = {"some":"json_data"}
        mock_directory_handler.make_directories.return_value = None
        mock_directory_handler.write_binary.return_value = None
        mock_directory_handler.extract_file.return_value = None
        mock_directory_handler.directory_structure_exists.return_value = True

        mock_get_target_json.return_value = Path("/customer_name/1/target.json")

        response = generate_opportunity('1', mock_db_manager)

        assert response[1] == 201
        assert response[0] == {
            "message":"Opportunity created.",
            "upload_id":'1',
            "file_id":mock_db_manager.insert_file_upload.return_value,
            "opportunity_id":mock_db_manager.wait_for_opportunity_creation.return_value,
            'customer_id':'cat'
        }

        mock_directory_handler.get_extracts_dir.assert_called_once()
        mock_directory_handler.directory_structure_exists.assert_called_once()
        mock_get_target_json.assert_called_once()
        mock_to_csv.assert_called()


def test_generate_opportunity_columns_not_matched(mock_db_manager, temp_dir):
    mock_db_manager.fetch_table_data_as_df.side_effect = [
        pd.DataFrame({'catcat':['yes', 'indeed', 'cats']}),
        pd.DataFrame({'of course cats':['yes']})
    ]

    mock_db_manager.fetch_raw_data.side_effect = [
        {
            'FILENAME':'filename.zip',
            'customer':'customer_name',
            'file_charset':'charset',
            'file_comments':'comments',
            'opportunity_name':'opportunity_name',
            'created_by':'created_by'
        },
        ('cat',)
    ]

    mock_connection = MagicMock()
    mock_db_manager.connection = mock_connection

    with patch("backend.services.complete_processing.DirectoryHandler") as mock_directory_handler,\
            patch("backend.services.complete_processing.get_target_json", autospec=True) as mock_get_target_json,\
            patch.object(DatabaseConnector, 'get_connection', return_value=mock_connection),\
            patch("backend.services.complete_processing.fp.resolve_for_awr_emcc", return_value=(True, False)),\
            patch("backend.services.complete_processing.insert_snap_coverage_plot"),\
            patch("pandas.DataFrame.to_csv") as mock_to_csv:
        mock_directory_handler.directory_structure_exists.return_value = True
        mock_directory_handler.get_extracts_dir.return_value = Path("/customer_name/1/filename/")
        mock_directory_handler.read_json.return_value = {"some":"json_data"}
        mock_directory_handler.make_directories.return_value = None
        mock_directory_handler.write_binary.return_value = None
        mock_directory_handler.extract_file.return_value = None
        mock_get_target_json.return_value = Path("/path/to/target.json")

        response = generate_opportunity('1', mock_db_manager)

        assert response[1] == 500
        assert "Column mismatch error" in response[0]['message']
        mock_to_csv.assert_not_called()


def test_generate_opportunity_value_error(mock_db_manager, temp_dir, patch_file_paths):
    mock_db_manager.fetch_table_data_as_df.side_effect = ValueError("Error fetching data")

    mock_connection = MagicMock()
    mock_db_manager.connection = mock_connection

    patch_file_paths.resolve_for_awr_emcc.return_value = True, False
    with patch.object(DatabaseConnector, 'get_connection', return_value=mock_connection),\
            patch("backend.services.complete_processing.insert_snap_coverage_plot"),\
            patch("backend.services.complete_processing.DirectoryHandler") as mock_directory_handler:
        mock_directory_handler.directory_structure_exists.return_value = True
        db_id = '1'
        response = generate_opportunity('1', mock_db_manager)
        assert response[1] == 404
        assert type(response[0]['message']) == str
        assert str(response[0]['message']) == f'Reading values for: {db_id}. Error fetching data'


def test_generate_opportunity_exception(mock_db_manager, temp_dir, patch_file_paths):
    mock_db_manager.fetch_table_data_as_df.side_effect = Exception("Generic error")

    mock_connection = MagicMock()
    mock_db_manager.connection = mock_connection

    patch_file_paths.resolve_for_awr_emcc.return_value = True, False
    with patch.object(DatabaseConnector, 'get_connection', return_value=mock_connection),\
            patch("backend.services.complete_processing.insert_snap_coverage_plot"),\
            patch("backend.services.complete_processing.DirectoryHandler") as mock_directory_handler:
        mock_directory_handler.directory_structure_exists.return_value = True

        response = generate_opportunity('1', mock_db_manager)

        assert response[1] == 500
        assert "An error occurred: Generic error" in response[0]['message']


def test_check_columns_match_raises_exception(temp_dir):
    df = pd.DataFrame({'cat_failed':[1, 2, 33]})
    csv_path = Path(temp_dir) / "a_ghost.csv"

    path_exists_patch = patch.object(Path, 'exists', return_value=True)

    read_csv_patch = patch("pandas.read_csv", return_value=pd.DataFrame({
        'Cohort':[1],
        'blabla':[2],
        'version':[3]
    }))

    with path_exists_patch, read_csv_patch:
        with pytest.raises(ColumnsNotMatched,
                           match="The columns of the properties does not match the existing CSV file."):
            columns_match = check_columns_match(df, csv_path)
            if not columns_match:
                raise ColumnsNotMatched("The columns of the properties does not match the existing CSV file.")
