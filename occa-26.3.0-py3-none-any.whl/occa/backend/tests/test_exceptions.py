import pytest
from unittest.mock import MagicMock

from backend.api_utils.custom_response import CustomResponse
from backend.services.complete_processing import generate_opportunity,ColumnsNotMatched
from backend.api_utils.status import FINAL_PROCESS_ERROR


@pytest.fixture
def dummy_db():
    db = MagicMock()
    return db
mismatch_error = 'error mismatch'
cat_not_found="Hi I'm a cat"
value_error = "1 is one"
runtime_error='oopsie doopsie'
#execute below test 4 times with this values
@ pytest.mark.parametrize("exception, expected_message, expected_fn", [
    (ColumnsNotMatched(mismatch_error),
     f"Column mismatch error: {mismatch_error}",
     CustomResponse.server_error),


    (ModuleNotFoundError(cat_not_found),
     f"Missing folder/data for continue process: id123. {cat_not_found}",
     CustomResponse.not_found),

    (ValueError(value_error),
     f"Reading values for: id123. {value_error}",
     CustomResponse.not_found),

    (RuntimeError(runtime_error),
     f"An error occurred: {runtime_error}",
     CustomResponse.server_error),
])
def test_generate_opportunity_exception_handling(dummy_db, exception, expected_message, expected_fn):
    upload_id = "id123"
    # Throwing the exception
    dummy_db.fetch_raw_data.side_effect = exception
    dummy_db.connection.rollback = MagicMock()
    dummy_db.update_status = MagicMock()

    response = generate_opportunity(upload_id, dummy_db)

    expected_response = expected_fn({'message': expected_message})
    assert response == expected_response

    dummy_db.connection.rollback.assert_called_once()
    dummy_db.update_status.assert_called_once_with(upload_id,
                                                   FINAL_PROCESS_ERROR,
                                                   expected_message)
