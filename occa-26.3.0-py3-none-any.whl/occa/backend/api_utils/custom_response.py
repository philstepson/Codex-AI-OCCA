from version import version, __version__
class CustomResponse:
    @staticmethod
    def success(data=None, status_code=200):
        return data, status_code

    @staticmethod
    def created(data=None):
        return data, 201

    @staticmethod
    def bad_request(data=None):
        return data, 400

    @staticmethod
    def unauthorized(data=None):
        return data, 401

    @staticmethod
    def not_found(data=None):
        return data, 404

    @staticmethod
    def server_error(data=None):
        return data, 500

    @staticmethod
    def service_unavailable(data=None):
        return data, 503
