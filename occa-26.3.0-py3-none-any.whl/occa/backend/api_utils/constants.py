ARCHIVES_DOWNLOADED="archives_download"
AWR_MINER_OUT = "awr_miner_out"
EMCC_SIZING_EXTRACTS = "emcc_sizing_extracts"
CENTER_N = 50

