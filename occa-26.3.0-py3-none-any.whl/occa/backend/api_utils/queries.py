UPDATE_MODIFIED_CREATED_BY_BY_OPPID = """
    UPDATE OPPORTUNITIES SET MODIFIED_BY = :modified_by, CREATED_BY = :created_by WHERE ID = :id
"""
UPDATE_FILE_UPLOAD_CREATED_BY = """
    UPDATE FILE_UPLOAD SET CREATED_BY = :CREATED_BY, UPDATED_BY = :created_by WHERE ID = :id
"""

SELECT_OPP_BY_ID = """
    SELECT OPP_ID from FILE_UPLOAD where file_id={}
"""
    # SELECT 1 FROM OPPORTUNITIES WHERE ID = '{}'

SELECT_ARCHIVE_EXTRACT = """
    SELECT filename, file_blob, file_mimetype, customer, file_charset, file_comments,opportunity_name,
            created_by, salescloud_id
    FROM UPLOAD_ARCHIVE_EXTRACT
    WHERE id = :upload_id
"""

SELECT_PARAMS_BY_ID ="""
   f"SELECT {', '.join(params)} FROM {table_name} WHERE ID = :key_id"
"""


DELETE_ARCHIVE_EXTRACT = """
    DELETE FROM UPLOAD_ARCHIVE_EXTRACT
    WHERE id = :upload_id
"""
INSERT_JSON_INTO_FILE_UPLOAD = """
    INSERT INTO FILE_UPLOAD (
        FILENAME, FILE_MIMETYPE, FILE_CHARSET, FILE_BLOB,
        FILE_COMMENTS, CREATED_ON, CREATED_BY, CUSTOMER_NAME,
        OPP_NAME , STATUS, SALESCLOUD_ID, TEST, 
        REGION, COUNTRY
    )
    VALUES (
        :FILENAME, :FILE_MIMETYPE, :FILE_CHARSET, :FILE_BLOB,
        :FILE_COMMENTS, :CREATED_ON, :CREATED_BY, :CUSTOMER,
        :OPPORTUNITY_NAME ,:STATUS, :SALESCLOUD_ID, :TEST, 
        :REGION, :COUNTRY
    )
    RETURNING FILE_ID INTO :FILE_ID
"""

GENERIC_DELETE="DELETE FROM {} WHERE {} = :{}"

INSERT_AWR_PLOTS_QRY = """
    INSERT INTO AWR_PLOTS_HTML (
        WHICH_DB, PLOTLY_FIG, UPLOAD_ID, CREATED_ON, FILE_MIMETYPE, MODIFIED_ON, CREATED_BY,
        FIG,DB_NAME
    )
    VALUES (
        :WHICH_DB, :PLOTLY_FIG, :UPLOAD_ID, :CREATED_ON, :FILE_MIMETYPE, :MODIFIED_ON, :CREATED_BY,
        :FIG, :DB_NAME
    )
"""
INSERT_AWR_UNADJUSTED_PLOTS_QRY = """
    INSERT INTO AWR_PLOTS_HTML (
        WHICH_DB, PLOTLY_FIG, UPLOAD_ID, CREATED_ON, FILE_MIMETYPE, MODIFIED_ON, CREATED_BY,
        FIG, COHORT, TYPE
    )
    VALUES (
        :WHICH_DB, :PLOTLY_FIG, :UPLOAD_ID, :CREATED_ON, :FILE_MIMETYPE, :MODIFIED_ON, :CREATED_BY,
        :FIG, :COHORT, :TYPE
    )
"""
INSERT_EM_PLOTS_QRY = """
    INSERT INTO EM_PLOTS_HTML (
        UPLOAD_ID,WHICH_METRIC,COHORT_NAME,FILE_MIMETYPE,PLOTLY_FIG,FIG,
        CREATED_ON, MODIFIED_ON, CREATED_BY
    ) VALUES (
        :UPLOAD_ID,:WHICH_METRIC,:COHORT_NAME,:FILE_MIMETYPE,:PLOTLY_FIG,:FIG,
        :CREATED_ON, :MODIFIED_ON, :CREATED_BY
    )
"""

DELETE_UPLOAD_ARCHIVE_FILE_BLOB="""
    UPDATE
        UPLOAD_ARCHIVE_EXTRACT
        SET
            file_blob = NULL,
            type =:type
        WHERE
        ID =:id
"""

UPDATE_UPLOAD_ARCHIVE_TYPE="""
UPDATE
    UPLOAD_ARCHIVE_EXTRACT
    SET
        type =:type
    WHERE
    ID =:id
"""

CHECK_AWR_PLOTS_EXISTENCE = """
    SELECT 1 FROM AWR_PLOTS_HTML
    WHERE WHICH_DB = :WHICH_DB AND UPLOAD_ID = :UPLOAD_ID
"""

UPDATE_PLOTS_QRY = """
    UPDATE AWR_PLOTS_HTML
    SET PLOTLY_FIG = :PLOTLY_FIG,
        MODIFIED_ON = :MODIFIED_ON,
        FILE_MIMETYPE = :FILE_MIMETYPE,
        CREATED_BY = :CREATED_BY,
        FIG = :FIG,
        DB_NAME = :DB_NAME
    WHERE WHICH_DB = :WHICH_DB AND UPLOAD_ID = :UPLOAD_ID
"""

#columns , values needed
INSERT_COLUMN_VALUES = """INSERT INTO {table_name} ({columns}) VALUES ({values})"""

INSERT_TZ_INFO = """INSERT INTO EXTRACTS_DATABASE_TZ_INFO ({}) VALUES ({})"""

#AWR Extracts table
EXTRACTS_PROPERTIES_DATABASE = 'EXTRACTS_PROPERTIES_DATABASE'
EXTRACTS_DATABASE_TZ_INFO = 'EXTRACTS_DATABASE_TZ_INFO'
EXTRACTS_ANALYSIS_SNAP_RANGE_DATA = 'EXTRACTS_ANALYSIS_SNAP_RANGE_DATA'

UPLOAD_ARCHIVE_EXTRACT = 'UPLOAD_ARCHIVE_EXTRACT'
UPLOAD_CUSTOMER = 'UPLOAD_CUSTOMER'




#AWR
EXTRACTS_PROPERTIES_DATABASE_COLUMNS = [
                "COHORT", "WHICH_DB", "CDB", "STOP", "DB_NAME",
                "ALLOCATED_STORAGE_GB_MAX", "DB_CPU_MAX", "DB_PGA_MB_MAX", "DB_SGA_MB_MAX", "DB_MEM_MB_MAX",
                "DB_IOPS_MAX", "DB_LOGONS_MAX", "ALLOCATED_STORAGE_GB_99_PCT", "DB_CPU_99_PCT", "DB_PGA_MB_99_PCT",
                "DB_SGA_MB_99_PCT", "DB_MEM_MB_99_PCT", "DB_IOPS_99_PCT", "DB_LOGONS_99_PCT",
                "ALLOCATED_STORAGE_GB_95_PCT",
                "DB_CPU_95_PCT", "DB_PGA_MB_95_PCT", "DB_SGA_MB_95_PCT", "DB_MEM_MB_95_PCT", "DB_IOPS_95_PCT",
                "DB_LOGONS_95_PCT",
                "ALLOCATED_STORAGE_GB_90_PCT", "DB_CPU_90_PCT", "DB_PGA_MB_90_PCT", "DB_SGA_MB_90_PCT",
                "DB_MEM_MB_90_PCT",
                "DB_IOPS_90_PCT", "DB_LOGONS_90_PCT", "ALLOCATED_STORAGE_GB_80_PCT", "DB_CPU_80_PCT",
                "DB_PGA_MB_80_PCT",
                "DB_SGA_MB_80_PCT", "DB_MEM_MB_80_PCT", "DB_IOPS_80_PCT", "DB_LOGONS_80_PCT",
                "ALLOCATED_STORAGE_GB_MEAN",
                "DB_CPU_MEAN", "DB_PGA_MB_MEAN", "DB_SGA_MB_MEAN", "DB_MEM_MB_MEAN", "DB_IOPS_MEAN",
                "DB_LOGONS_MEAN", "ALLOCATED_STORAGE_GB_MIN", "DB_CPU_MIN", "DB_PGA_MB_MIN", "DB_SGA_MB_MIN",
                "DB_MEM_MB_MIN", "DB_IOPS_MIN", "DB_LOGONS_MIN", "CWD", "PLATFORM", "CREATE_DTTM_UTC", "VERSION"
            ]
EXTRACTS_DATABASE_TZ_INFO_COLUMNS = [
            "WHICH_DB", "TZ", "MINUTES_DIFF_FROM_UTC",
            "SNAPS_WITH_TZ_OFFSET_COUNT",
            "SNAPS_MISSING_TZ_OFFSET_COUNT"
        ]
EXTRACTS_ANALYSIS_SNAP_RANGE_DATA_COLUMNS=  [
    "WHICH_DB","SNAP_BEGIN","SNAP_END","DAYS",
    "TIME_ZONE_OFFSET","SNAP_BEGIN_GMT",
    "SNAP_END_GMT","HOSTS"]
#AWR csv column mapping
properties_column_mapping = {
    "COHORT": "Cohort",
    "WHICH_DB": "WHICH_DB",
    "CDB": "cdb",
    "STOP": "STOP",
    "DB_NAME": "DB_NAME",
    "ALLOCATED_STORAGE_GB_MAX": "Allocated Storage (GB).max",
    "DB_CPU_MAX": "DB vCPU.max",
    "DB_PGA_MB_MAX": "DB PGA (MB).max",
    "DB_SGA_MB_MAX": "DB SGA (MB).max",
    "DB_MEM_MB_MAX": "DB Memory (MB).max",
    "DB_IOPS_MAX": "DB IOPS.max",
    "DB_LOGONS_MAX": "DB Logons.max",
    "ALLOCATED_STORAGE_GB_99_PCT": "Allocated Storage (GB).99%",
    "DB_CPU_99_PCT": "DB vCPU.99%",
    "DB_PGA_MB_99_PCT": "DB PGA (MB).99%",
    "DB_SGA_MB_99_PCT": "DB SGA (MB).99%",
    "DB_MEM_MB_99_PCT": "DB Memory (MB).99%",
    "DB_IOPS_99_PCT": "DB IOPS.99%",
    "DB_LOGONS_99_PCT": "DB Logons.99%",
    "ALLOCATED_STORAGE_GB_95_PCT": "Allocated Storage (GB).95%",
    "DB_CPU_95_PCT": "DB vCPU.95%",
    "DB_PGA_MB_95_PCT": "DB PGA (MB).95%",
    "DB_SGA_MB_95_PCT": "DB SGA (MB).95%",
    "DB_MEM_MB_95_PCT": "DB Memory (MB).95%",
    "DB_IOPS_95_PCT": "DB IOPS.95%",
    "DB_LOGONS_95_PCT": "DB Logons.95%",
    "ALLOCATED_STORAGE_GB_90_PCT": "Allocated Storage (GB).90%",
    "DB_CPU_90_PCT": "DB vCPU.90%",
    "DB_PGA_MB_90_PCT": "DB PGA (MB).90%",
    "DB_SGA_MB_90_PCT": "DB SGA (MB).90%",
    "DB_MEM_MB_90_PCT": "DB Memory (MB).90%",
    "DB_IOPS_90_PCT": "DB IOPS.90%",
    "DB_LOGONS_90_PCT": "DB Logons.90%",
    "ALLOCATED_STORAGE_GB_80_PCT": "Allocated Storage (GB).80%",
    "DB_CPU_80_PCT": "DB vCPU.80%",
    "DB_PGA_MB_80_PCT": "DB PGA (MB).80%",
    "DB_SGA_MB_80_PCT": "DB SGA (MB).80%",
    "DB_MEM_MB_80_PCT": "DB Memory (MB).80%",
    "DB_IOPS_80_PCT": "DB IOPS.80%",
    "DB_LOGONS_80_PCT": "DB Logons.80%",
    "ALLOCATED_STORAGE_GB_MEAN": "Allocated Storage (GB).mean",
    "DB_CPU_MEAN": "DB vCPU.mean",
    "DB_PGA_MB_MEAN": "DB PGA (MB).mean",
    "DB_SGA_MB_MEAN": "DB SGA (MB).mean",
    "DB_MEM_MB_MEAN": "DB Memory (MB).mean",
    "DB_IOPS_MEAN": "DB IOPS.mean",
    "DB_LOGONS_MEAN": "DB Logons.mean",
    "ALLOCATED_STORAGE_GB_MIN": "Allocated Storage (GB).min",
    "DB_CPU_MIN": "DB vCPU.min",
    "DB_PGA_MB_MIN": "DB PGA (MB).min",
    "DB_SGA_MB_MIN": "DB SGA (MB).min",
    "DB_MEM_MB_MIN": "DB Memory (MB).min",
    "DB_IOPS_MIN": "DB IOPS.min",
    "DB_LOGONS_MIN": "DB Logons.min",
    "CWD": "cwd",
    "PLATFORM": "platform",
    "CREATE_DTTM_UTC": "create_dttm_utc",
    "VERSION": "version"
}
tz_column_mapping = {
    "WHICH_DB": "WHICH_DB",
    "TZ": "TZ",
    "MINUTES_DIFF_FROM_UTC": "MINUTES_DIFF_FROM_UTC_list",
    "SNAPS_WITH_TZ_OFFSET_COUNT": "snaps_with_tz_offset_count",
    "SNAPS_MISSING_TZ_OFFSET_COUNT": "snaps_missing_tz_offset_count"
}


#EMCC Extracts properties table
EXTRACTS_EMCC_PROPERTIES_DATABASE = 'EXTRACTS_EMCC_PROPERTIES_DATABASE'
EXTRACTS_EMCC_PROPERTIES_INSTANCES = 'EXTRACTS_EMCC_PROPERTIES_INSTANCES'
EXTRACTS_EMCC_PROPERTIES_DATABASE_METADATA = 'EXTRACTS_EMCC_PROPERTIES_DATABASE_METADATA'

#The following are the ones
EXTRACTS_EMCC_PROPERTIES_DB_COLUMNS_TO_UPDATE = ['ALLOCATED_DB_SIZE_GB','TOTAL_DB_SIZE_GB']
EXTRACTS_EMCC_PROPERTIES_INSTANCES_COLUMNS_TO_UPDATE = ['VCPU','SGA_MB','PGA_MB','IOPS','LOGONS']


#EMCC Properties
EXTRACTS_EMCC_PROPERTIES_DATABASE_COLUMNS = [
    "COHORT", "DB_NAME", "ALLOCATED_DB_SIZE_GB", "TOTAL_DB_SIZE_GB", "USE_VALUES_FROM_DB_NAME",
    "USE_VALUES_SCOPE", "USE_VALUES_PCT", "STOP", "NUMBER_OF_INSTANCES", "CLUSTERED_DATABASE",
    "DB_MACHINE", "DB_MACHINE_OWNER", "CLUSTER_NAME", "SERVER_LIST", "CDB_VERSION",
    "CDB_STATUS", "CDB_LAST_LOAD_TIME_UTC", "CDB_OWNER", "CDB_STANDBY_TYPE", "CDB_COST_CENTER",
    "CDB_DEPARTMENT", "CDB_LIFECYCLE_STATUS", "CDB_LINE_OF_BUS", "CDB_LOCATION", "TARGET_GUID",
    "CWD", "PLATFORM", "EXTRACT_DTTM_UTC", "CREATE_DTTM_UTC", "VERSION"
]
EXTRACTS_EMCC_PROPERTIES_INSTANCES_COLUMNS = [
    "DB_NAME", "INSTANCE_NAME", "VCPU", "SGA_MB", "PGA_MB", "IOPS", "LOGONS", "USE_VALUES_FROM_INSTANCE",
    "STOP", "CLUSTER_NAME", "SERVER_NAME", "DB_MACHINE", "DB_MACHINE_OWNER", "STATUS", "LAST_LOAD_TIME_UTC",
    "OWNER", "STANDBY_TYPE", "CLUSTERED", "INSTANCE_COUNT", "VERSION", "COST_CENTER", "DEPARTMENT",
    "LIFECYCLE_STATUS", "LOCATION", "TARGET_GUID", "CDB_TARGET_GUID", "CWD", "PLATFORM", "EXTRACT_DTTM_UTC",
    "CREATE_DTTM_UTC","VERSION_PROPERTIES_FILE"
]
EXTRACTS_EMCC_PROPERTIES_DATABASE_METADATA_COLUMNS = [
    "DB_NAME","DBMACHINE","CLUSTER","DB_STANDBY_TYPE",
    "ORCL_GTP_COST_CENTER",
    "ORCL_GTP_DEPARTMENT",
    "ORCL_GTP_LIFECYCLE_STATUS",
    "ORCL_GTP_LINE_OF_BUS",
    "ORCL_GTP_LOCATION"
]


EMCC_SIZINGSTRUCTURE_DB_NEEDED_COLUMNS= [
    "dbmachine","cluster","cdb","db_standby_type"
]

EMCC_SIZINGSTRUCTURE_DB_PROPS_NEEDED_COLUMNS = [
"orcl_gtp_cost_center",
    "orcl_gtp_department",
    "orcl_gtp_lifecycle_status",
    "orcl_gtp_line_of_bus",
    "orcl_gtp_location"
    # "NAME","VALUE"
]


#EMCC Properties column mapping
properties_emcc_column_mapping = {
    "COHORT": "Cohort",
    "DB_NAME": "Database Name",
    "ALLOCATED_DB_SIZE_GB": "Allocated Database Size (GB)",
    "TOTAL_DB_SIZE_GB": "Total Database Size (GB)",
    "USE_VALUES_FROM_DB_NAME": "Use Values from Database Name",
    "USE_VALUES_SCOPE": "Use Values Scope",
    "USE_VALUES_PCT": "Use Values Pct",
    "STOP": "STOP",
    "NUMBER_OF_INSTANCES": "Number of Instances",
    "CLUSTERED_DATABASE": "Clustered Database?",
    "DB_MACHINE": "dbmachine",
    "DB_MACHINE_OWNER": "dbmachine_owner",
    "CLUSTER_NAME": "cluster",
    "SERVER_LIST": "Server List",
    "CDB_VERSION": "cdb_version",
    "CDB_STATUS": "cdb_status",
    "CDB_LAST_LOAD_TIME_UTC": "cdb_last_load_time_utc",
    "CDB_OWNER": "cdb_owner",
    "CDB_STANDBY_TYPE": "cdb_standby_type",
    "CDB_COST_CENTER": "cdb_cost_center",
    "CDB_DEPARTMENT": "cdb_department",
    "CDB_LIFECYCLE_STATUS": "cdb_lifecycle_status",
    "CDB_LINE_OF_BUS": "cdb_line_of_bus",
    "CDB_LOCATION": "cdb_location",
    "TARGET_GUID": "target_guid",
    "CWD": "cwd",
    "PLATFORM": "platform",
    "EXTRACT_DTTM_UTC": "extract_dttm_utc",
    "CREATE_DTTM_UTC": "create_dttm_utc",
    "VERSION": "version"
}
properties_emcc_instances_column_mapping = {
    "DB_NAME": "Database Name",
    "INSTANCE_NAME": "Instance",
    "VCPU": "vCPU",
    "SGA_MB": "SGA (MB)",
    "PGA_MB": "PGA (MB)",
    "IOPS": "IOPS",
    "LOGONS": "Logons",
    "USE_VALUES_FROM_INSTANCE": "Use Values from Instance",
    "STOP": "STOP",
    "CLUSTER_NAME": "Cluster",
    "SERVER_NAME": "Server Name",
    "DB_MACHINE": "dbmachine",
    "DB_MACHINE_OWNER": "dbmachine_owner",
    "STATUS": "status",
    "LAST_LOAD_TIME_UTC": "last_load_time_utc",
    "OWNER": "owner",
    "STANDBY_TYPE": "standby_type",
    "CLUSTERED": "clustered",
    "INSTANCE_COUNT": "instance_count",
    "VERSION": "version",
    "COST_CENTER": "cost_center",
    "DEPARTMENT": "department",
    "LIFECYCLE_STATUS": "lifecycle_status",
    "LOCATION": "location",
    "TARGET_GUID": "target_guid",
    "CDB_TARGET_GUID": "cdb_target_guid",
    "CWD": "cwd",
    "PLATFORM": "platform",
    "EXTRACT_DTTM_UTC": "extract_dttm_utc",
    "CREATE_DTTM_UTC": "create_dttm_utc",
    "VERSION_PROPERTIES_FILE":"version_properties_file"
}

#EMCC Output sizing tables
EXTRACTS_EMCC_OUTPUT_DATABASE = 'EXTRACTS_EMCC_OUTPUT_DATABASE'
EXTRACTS_EMCC_OUTPUT_INSTANCE = 'EXTRACTS_EMCC_OUTPUT_INSTANCE'
EXTRACTS_EMCC_OUTPUT_SERVER = 'EXTRACTS_EMCC_OUTPUT_SERVER'

#EMCC Output sizing tables columns
EXTRACTS_EMCC_OUTPUT_INSTANCE_COLUMNS = ['EXCLUDED', 'EXCLUDED_REASON', 'CDB_COHORT', 'CDB', 'DB', 'USE_VALUES_FROM_DATABASE_NAME',
                                         'USE_VALUES_SCOPE', 'USE_VALUES_PCT', 'VCPU', 'SGA_(MB)', 'PGA_(MB)', 'IOPS', 'LOGONS',
                                         'USE_VALUES_FROM_INSTANCE', 'STOP', 'DB_VCPU_TELEMETRY', 'DB_SGA_MB_TELEMETRY', 'DB_PGA_MB_TELEMETRY',
                                         'DB_IOPS_TELEMETRY', 'DB_LOGONS_TELEMETRY', 'INIT_SESSIONS', 'INIT_PROCESSES', 'INIT_SGA_MAX_SIZE_MB',
                                         'INIT_SGA_TARGET_MB', 'INIT_PGA_AGGR_LIMIT_MB', 'INIT_PGA_AGGR_TARGET_MB', 'CLUSTER', 'HOST',
                                         'DBMACHINE', 'DBMACHINE_OWNER', 'DB_STATUS', 'DB_LAST_LOAD_TIME_UTC', 'SGA_SIZE_GB', 'PGA_SIZE_GB',
                                         'CDB_OWNER', 'CDB_STANDBY_TYPE', 'CDB_STATUS', 'CDB_LAST_LOAD_TIME_UTC', 'INIT_USE_LARGE_PAGES',
                                         'DB_CPU_COUNT_GUARANTEE', 'DB_CPU_COUNT_LIMIT', 'HOST_SUBSCR_PCT', 'HOST_STATUS', 'HOST_LAST_LOAD_TIME_UTC',
                                         'PHYSICAL_CPU_COUNT', 'CORES_PER_CHIP', 'LOGICAL_CPU_COUNT', 'TOTAL_CPU_CORES', 'MEM_GB',
                                         'NR_HUGE_PAGES', 'HOST_DB_CPU_COUNT_LIMIT', 'VENDOR_NAME', 'H_COST_CENTER', 'H_DEPARTMENT',
                                         'H_LIFECYCLE_STATUS', 'H_LINE_OF_BUS', 'H_LOCATION', 'DIST_VERSION', 'ECACHE_IN_MB', 'IMPL',
                                         'REVISION', 'IS_HYPERTHREAD_ENABLED', 'FREQ', 'CPU_TYPE', 'MA', 'SYSTEM_CONFIG', 'H_CPU_TYPE_OVR',
                                         'H_CORES_PER_CHIP_OVR', 'H_PHYSICAL_CPU_COUNT_OVR', 'H_TOTAL_CPU_CORES_OVR', 'CDB_TYPE', 'CDB_COST_CENTER',
                                         'CDB_DEPARTMENT', 'CDB_LIFECYCLE_STATUS', 'CDB_LINE_OF_BUS', 'CDB_LOCATION', 'DB_COST_CENTER',
                                         'DB_DEPARTMENT', 'DB_COHORT', 'DB_LIFECYCLE_STATUS', 'DB_LINE_OF_BUS', 'DB_LOCATION', 'INIT_CPU_COUNT',
                                         'CDB_TYPE_VERSION', 'DB_TYPE_VERSION',  'HOST_TYPE_VERSION', 'CDB_TARGET_GUID', 'DB_TARGET_GUID',
                                         'HOST_TARGET_GUID', 'CWD', 'PLATFORM', 'EXTRACT_DTTM_UTC', 'CREATE_DTTM_UTC', 'SOURCE', 'VERSION',
                                         'INSTANCE_THROUGHPUT.IOMBS_PS', 'INSTANCE_THROUGHPUT.PHYSREADS_PS', 'INSTANCE_THROUGHPUT.PHYSWRITES_PS']

EXTRACTS_EMCC_OUTPUT_DATABASE_COLUMNS = ['EXCLUDED', 'EXCLUDED_REASON', 'CDB_COHORT', 'CDB', 'ALLOCATED_DATABASE_SIZE_(GB)', 'TOTAL_DATABASE_SIZE_(GB)',
                                         'USE_VALUES_FROM_DATABASE_NAME', 'USE_VALUES_SCOPE', 'USE_VALUES_PCT', 'STOP', 'CDB_SIZE_ALLOCATED_GB_TELEMETRY',
                                         'CDB_SIZE_USED_GB_TELEMETRY', 'INIT_SESSIONS_TOTAL', 'INIT_PROCESSES_TOTAL', 'INIT_SGA_MAX_SIZE_MB_TOTAL',
                                         'INIT_SGA_TARGET_MB_TOTAL', 'INIT_PGA_AGGR_LIMIT_MB_TOTAL', 'INIT_PGA_AGGR_TARGET_MB_TOTAL', 'CDB_INSTANCE_COUNT',
                                         'CLUSTERED', 'DBMACHINE', 'DBMACHINE_OWNER', 'CLUSTER', 'SERVER_LIST', 'CDB_VERSION', 'CDB_STATUS',
                                         'CDB_LAST_LOAD_TIME_UTC', 'CDB_OWNER', 'CDB_STANDBY_TYPE', 'CDB_COST_CENTER', 'CDB_DEPARTMENT',
                                         'CDB_LIFECYCLE_STATUS', 'CDB_LINE_OF_BUS', 'CDB_LOCATION', 'CDB_TARGET_GUID', 'CDB_TYPE_VERSION',
                                         'CDB_VERSION_SIZING', 'DBMS_VENDOR', 'CWD', 'PLATFORM', 'EXTRACT_DTTM_UTC', 'CREATE_DTTM_UTC', 'SOURCE', 'VERSION']

EXTRACTS_EMCC_OUTPUT_SERVER_COLUMNS = ['HOST', 'CPU_TYPE_1', 'CHIP_COUNT_(ACTUAL)', 'CORES_PER_CHIP_(ACTUAL)', 'DESCRIPTION', 'STOP', 'CPU_TYPE', 'PHYSICAL_CPU_COUNT',
                                       'CORES_PER_CHIP', 'DBMACHINE', 'DBMACHINE_OWNER', 'CLUSTER', 'HOST_TYPE_VERSION', 'HOST_STATUS', 'HOST_LAST_LOAD_TIME_UTC',
                                       'H_COST_CENTER', 'H_DEPARTMENT', 'H_LIFECYCLE_STATUS', 'H_LINE_OF_BUS', 'H_LOCATION', 'TOTAL_CPU_CORES',
                                       'LOGICAL_CPU_COUNT', 'MEM_GB', 'NR_HUGE_PAGES', 'ECACHE_IN_MB', 'IMPL', 'REVISION', 'IS_HYPERTHREAD_ENABLED',
                                       'FREQ', 'MA', 'SYSTEM_CONFIG', 'VENDOR_NAME', 'DIST_VERSION', 'HOST_DB_CPU_COUNT_LIMIT', 'HOST_SUBSCR_PCT',
                                       'HOST_TARGET_GUID', 'CWD', 'PLATFORM', 'EXTRACT_DTTM_UTC', 'CREATE_DTTM_UTC', 'SOURCE', 'VERSION']

output_emcc_database_column_mapping = {
    "EXCLUDED": "EXCLUDED",
    "EXCLUDED_REASON": "EXCLUDED_REASON",
    "CDB_COHORT": "CDB_COHORT",
    "CDB": "CDB",
    "ALLOCATED_DATABASE_SIZE_(GB)": "ALLOCATED_DATABASE_SIZE_(GB)",
    "TOTAL_DATABASE_SIZE_(GB)": "TOTAL_DATABASE_SIZE_(GB)",
    "USE_VALUES_FROM_DATABASE_NAME": "USE_VALUES_FROM_DATABASE_NAME",
    "USE_VALUES_SCOPE": "USE_VALUES_SCOPE",
    "USE_VALUES_PCT": "USE_VALUES_PCT",
    "STOP": "STOP",
    "CDB_SIZE_ALLOCATED_GB_TELEMETRY": "CDB_SIZE_ALLOCATED_GB_TELEMETRY",
    "CDB_SIZE_USED_GB_TELEMETRY": "CDB_SIZE_USED_GB_TELEMETRY",
    "INIT_SESSIONS_TOTAL": "INIT_SESSIONS_TOTAL",
    "INIT_PROCESSES_TOTAL": "INIT_PROCESSES_TOTAL",
    "INIT_SGA_MAX_SIZE_MB_TOTAL": "INIT_SGA_MAX_SIZE_MB_TOTAL",
    "INIT_SGA_TARGET_MB_TOTAL": "INIT_SGA_TARGET_MB_TOTAL",
    "INIT_PGA_AGGR_LIMIT_MB_TOTAL": "INIT_PGA_AGGR_LIMIT_MB_TOTAL",
    "INIT_PGA_AGGR_TARGET_MB_TOTAL": "INIT_PGA_AGGR_TARGET_MB_TOTAL",
    "CDB_INSTANCE_COUNT": "CDB_INSTANCE_COUNT",
    "CLUSTERED": "CLUSTERED",
    "DBMACHINE": "DBMACHINE",
    "DBMACHINE_OWNER": "DBMACHINE_OWNER",
    "CLUSTER": "CLUSTER",
    "SERVER_LIST": "SERVER_LIST",
    "CDB_VERSION": "CDB_VERSION",
    "CDB_STATUS": "CDB_STATUS",
    "CDB_LAST_LOAD_TIME_UTC": "CDB_LAST_LOAD_TIME_UTC",
    "CDB_OWNER": "CDB_OWNER",
    "CDB_STANDBY_TYPE": "CDB_STANDBY_TYPE",
    "CDB_COST_CENTER": "CDB_COST_CENTER",
    "CDB_DEPARTMENT": "CDB_DEPARTMENT",
    "CDB_LIFECYCLE_STATUS": "CDB_LIFECYCLE_STATUS",
    "CDB_LINE_OF_BUS": "CDB_LINE_OF_BUS",
    "CDB_LOCATION": "CDB_LOCATION",
    "CDB_TARGET_GUID": "CDB_TARGET_GUID",
    "CDB_TYPE_VERSION": "CDB_TYPE_VERSION",
    "CDB_VERSION_SIZING": "CDB_VERSION_SIZING",
    "DBMS_VENDOR": "DBMS_VENDOR",
    "CWD": "CWD",
    "PLATFORM": "PLATFORM",
    "EXTRACT_DTTM_UTC": "EXTRACT_DTTM_UTC",
    "CREATE_DTTM_UTC": "CREATE_DTTM_UTC",
    "SOURCE": "SOURCE",
    "VERSION": "VERSION"
}
output_emcc_instance_column_mapping = {
    "EXCLUDED": "excluded",
    "EXCLUDED_REASON": "excluded_reason",
    "CDB_COHORT": "cdb_cohort",
    "CDB": "cdb",
    "DB": "db",
    "USE_VALUES_FROM_DATABASE_NAME": "Use Values from Database Name",
    "USE_VALUES_SCOPE": "Use Values Scope",
    "USE_VALUES_PCT": "Use Values Pct",
    "VCPU": "vCPU",
    "SGA_(MB)": "SGA (MB)",
    "PGA_(MB)": "PGA (MB)",
    "IOPS": "IOPS",
    "LOGONS": "Logons",
    "USE_VALUES_FROM_INSTANCE": "Use Values from Instance",
    "STOP": "STOP",
    "DB_VCPU_TELEMETRY": "db_vcpu_telemetry",
    "DB_SGA_MB_TELEMETRY": "db_sga_mb_telemetry",
    "DB_PGA_MB_TELEMETRY": "db_pga_mb_telemetry",
    "DB_IOPS_TELEMETRY": "db_iops_telemetry",
    "DB_LOGONS_TELEMETRY": "db_logons_telemetry",
    "INIT_SESSIONS": "init_sessions",
    "INIT_PROCESSES": "init_processes",
    "INIT_SGA_MAX_SIZE_MB": "init_sga_max_size_mb",
    "INIT_SGA_TARGET_MB": "init_sga_target_mb",
    "INIT_PGA_AGGR_LIMIT_MB": "init_pga_aggr_limit_mb",
    "INIT_PGA_AGGR_TARGET_MB": "init_pga_aggr_target_mb",
    "CLUSTER": "cluster",
    "HOST": "host",
    "DBMACHINE": "dbmachine",
    "DBMACHINE_OWNER": "dbmachine_owner",
    "DB_STATUS": "db_status",
    "DB_LAST_LOAD_TIME_UTC": "db_last_load_time_utc",
    "SGA_SIZE_GB": "sga_size_gb",
    "PGA_SIZE_GB": "pga_size_gb",
    "CDB_OWNER": "cdb_owner",
    "CDB_STANDBY_TYPE": "cdb_standby_type",
    "CDB_STATUS": "cdb_status",
    "CDB_LAST_LOAD_TIME_UTC": "cdb_last_load_time_utc",
    "INIT_USE_LARGE_PAGES": "init_use_large_pages",
    "DB_CPU_COUNT_GUARANTEE": "db_cpu_count_guarantee",
    "DB_CPU_COUNT_LIMIT": "db_cpu_count_limit",
    "HOST_SUBSCR_PCT": "host_subscr_pct",
    "HOST_STATUS": "host_status",
    "HOST_LAST_LOAD_TIME_UTC": "host_last_load_time_utc",
    "PHYSICAL_CPU_COUNT": "physical_cpu_count",
    "CORES_PER_CHIP": "cores_per_chip",
    "LOGICAL_CPU_COUNT": "logical_cpu_count",
    "TOTAL_CPU_CORES": "total_cpu_cores",
    "MEM_GB": "mem_gb",
    "NR_HUGE_PAGES": "nr_huge_pages",
    "HOST_DB_CPU_COUNT_LIMIT": "host_db_cpu_count_limit",
    "VENDOR_NAME": "vendor_name",
    "H_COST_CENTER": "h_cost_center",
    "H_DEPARTMENT": "h_department",
    "H_LIFECYCLE_STATUS": "h_lifecycle_status",
    "H_LINE_OF_BUS": "h_line_of_bus",
    "H_LOCATION": "h_location",
    "DIST_VERSION": "dist_version",
    "ECACHE_IN_MB": "ecache_in_mb",
    "IMPL": "impl",
    "REVISION": "revision",
    "IS_HYPERTHREAD_ENABLED": "is_hyperthread_enabled",
    "FREQ": "freq",
    "CPU_TYPE": "cpu_type",
    "MA": "ma",
    "SYSTEM_CONFIG": "system_config",
    "H_CPU_TYPE_OVR": "h_cpu_type_ovr",
    "H_CORES_PER_CHIP_OVR": "h_cores_per_chip_ovr",
    "H_PHYSICAL_CPU_COUNT_OVR": "h_physical_cpu_count_ovr",
    "H_TOTAL_CPU_CORES_OVR": "h_total_cpu_cores_ovr",
    "CDB_TYPE": "cdb_type",
    "CDB_COST_CENTER": "cdb_cost_center",
    "CDB_DEPARTMENT": "cdb_department",
    "CDB_LIFECYCLE_STATUS": "cdb_lifecycle_status",
    "CDB_LINE_OF_BUS": "cdb_line_of_bus",
    "CDB_LOCATION": "cdb_location",
    "DB_COST_CENTER": "db_cost_center",
    "DB_DEPARTMENT": "db_department",
    "DB_COHORT": "db_cohort",
    "DB_LIFECYCLE_STATUS": "db_lifecycle_status",
    "DB_LINE_OF_BUS": "db_line_of_bus",
    "DB_LOCATION": "db_location",
    "INIT_CPU_COUNT": "init_cpu_count",
    "CDB_TYPE_VERSION": "cdb_type_version",
    "DB_TYPE_VERSION": "db_type_version",
    "HOST_TYPE_VERSION": "host_type_version",
    "CDB_TARGET_GUID": "cdb_target_guid",
    "DB_TARGET_GUID": "db_target_guid",
    "HOST_TARGET_GUID": "host_target_guid",
    "CWD": "cwd",
    "PLATFORM": "platform",
    "EXTRACT_DTTM_UTC": "extract_dttm_utc",
    "CREATE_DTTM_UTC": "create_dttm_utc",
    "SOURCE": "source",
    "VERSION": "version",
    "INSTANCE_THROUGHPUT.IOMBS_PS": "instance_throughput.iombs_ps",
    "INSTANCE_THROUGHPUT.PHYSREADS_PS": "instance_throughput.physreads_ps",
    "INSTANCE_THROUGHPUT.PHYSWRITES_PS": "instance_throughput.physwrites_ps"
}
output_emcc_server_column_mapping =  {
    "HOST": "host",
    "CPU_TYPE_1": "CPU Type",
    "CHIP_COUNT_(ACTUAL)": "Chip Count (Actual)",
    "CORES_PER_CHIP_(ACTUAL)": "Cores Per Chip (Actual)",
    "DESCRIPTION": "Description",
    "STOP": "STOP",
    "CPU_TYPE": "cpu_type",
    "PHYSICAL_CPU_COUNT": "physical_cpu_count",
    "CORES_PER_CHIP": "cores_per_chip",
    "DBMACHINE": "dbmachine",
    "DBMACHINE_OWNER": "dbmachine_owner",
    "CLUSTER": "cluster",
    "HOST_TYPE_VERSION": "host_type_version",
    "HOST_STATUS": "host_status",
    "HOST_LAST_LOAD_TIME_UTC": "host_last_load_time_utc",
    "H_COST_CENTER": "h_cost_center",
    "H_DEPARTMENT": "h_department",
    "H_LIFECYCLE_STATUS": "h_lifecycle_status",
    "H_LINE_OF_BUS": "h_line_of_bus",
    "H_LOCATION": "h_location",
    "TOTAL_CPU_CORES": "total_cpu_cores",
    "LOGICAL_CPU_COUNT": "logical_cpu_count",
    "MEM_GB": "mem_gb",
    "NR_HUGE_PAGES": "nr_huge_pages",
    "ECACHE_IN_MB": "ecache_in_mb",
    "IMPL": "impl",
    "REVISION": "revision",
    "IS_HYPERTHREAD_ENABLED": "is_hyperthread_enabled",
    "FREQ": "freq",
    "MA": "ma",
    "SYSTEM_CONFIG": "system_config",
    "VENDOR_NAME": "vendor_name",
    "DIST_VERSION": "dist_version",
    "HOST_DB_CPU_COUNT_LIMIT": "host_db_cpu_count_limit",
    "HOST_SUBSCR_PCT": "host_subscr_pct",
    "HOST_TARGET_GUID": "host_target_guid",
    "CWD": "cwd",
    "PLATFORM": "platform",
    "EXTRACT_DTTM_UTC": "extract_dttm_utc",
    "CREATE_DTTM_UTC": "create_dttm_utc",
    "SOURCE": "source",
    "VERSION": "version"
}


SELECT_TZ_BY_UPLOAD_ID = """SELECT * FROM EXTRACTS_DATABASE_TZ_INFO WHERE upload_id = :upload_id"""
SELECT_PROPERTIES_BY_UPLOAD_ID = "SELECT * FROM EXTRACTS_PROPERTIES_DATABASE WHERE upload_id = :upload_id"

SELECT_EMCC_PROPERTIES_BY_UPLOAD_ID = """SELECT * FROM EXTRACTS_EMCC_PROPERTIES_DATABASE WHERE upload_id = :upload_id"""
SELECT_EMCC_PROPERTIES_INSTANCE_BY_UPLOAD_ID = "SELECT * FROM EXTRACTS_EMCC_PROPERTIES_INSTANCES WHERE upload_id = :upload_id"

SELECT_BY_ID_GENERIC = """SELECT {} FROM {} WHERE {}"""


INSERT_CUSTOMER = """
        INSERT INTO UPLOAD_CUSTOMER (customer, upload_id)
        VALUES (:customer, :upload_id)
        RETURNING id INTO :id
        """
UPDATE_BY_INSERTING_PLOTS = """
    UPDATE
        UPLOAD_ARCHIVE_EXTRACT
    SET
        PLOTS_ZIP_BLOB = :zip_blob,
        PLOTS_ZIP_FILENAME = :filename
    WHERE
        ID = :upload_id
"""

UPDATE_BY_INSERTING_UNADJUSTED_PLOTS = """
    UPDATE
        UPLOAD_ARCHIVE_EXTRACT
    SET
        PLOTS_ZIP_UNADJUSTED_BLOB = :zip_blob,
        PLOTS_ZIP_UNADJUSTED_FILENAME = :filename
    WHERE
        ID = :upload_id
"""

PLOTS_BY_UPLOAD_ID= "SELECT COUNT(*) as count FROM AWR_PLOTS_HTML WHERE UPLOAD_ID = :upload_id"


UPDATE_STATUS_QUERY = """
    UPDATE UPLOAD_ARCHIVE_EXTRACT
    SET STATUS = :status
    WHERE ID = :upload_id
    """






