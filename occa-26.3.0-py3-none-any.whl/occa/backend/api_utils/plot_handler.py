import datetime
import time
import zipfile

from concurrent.futures import ProcessPoolExecutor
from datetime import datetime
from pathlib import Path

import oracledb
import plotly
from plotly.io import from_json

import backend.api_utils.constants as c
from constants.Paths import FilePaths as fp
from backend.api_utils.queries import *
from backend.conn import DatabaseConnector
from file_manager.FileSystemHandler import DirectoryHandler


# read plotly html and parsed to plotly fig
def read_from_json(path: Path):
    """
    Loads a Plotly figure from a JSON file.

    Parameters
    ----------
    path : Path
        The path to the JSON file storing the figure.

    Returns
    -------
    plotly.graph_objects.Figure or None
    """
    if not path.exists():
        return None

    with open(path, encoding='utf-8') as f:
        fig_json = f.read()

    return from_json(fig_json)


def format_data_plots(upload_id: str, db: str, data: dict, entity_name: str, plot_type='AWR', **kwargs):
    """
    Formats the data and returns the formatted data.

    Parameters
    ----------
    upload_id : str
        The upload_id ID.
    db : str
        The database identifier 'WHICH_DB'.
    data : dict
        The meta-data to be formatted.
    entity_name : str
        The DB | Cohort Name

    Returns
    -------
    dir
        The formatted data.
    """

    current_time = datetime.now()
    plots_data = {
        # key_value:key_value, # containing DB_NAME:awr or COHORT_NAME:emcc
        "UPLOAD_ID":upload_id,
        "CREATED_ON":current_time,
        "FILE_MIMETYPE":"image/png",
        "MODIFIED_ON":current_time,
        "CREATED_BY":data.get('created_by') or data.get('CREATED_BY')
    }

    if plot_type == 'AWR':
        plots_data["WHICH_DB"] = db
        plots_data["DB_NAME"] = entity_name
    elif plot_type == 'AWR_UNADJUSTED':
        plots_data["WHICH_DB"] = db
        plots_data["COHORT"] = entity_name
        plots_data["TYPE"] = kwargs.get('plot_category', 'UNADJUSTED')
    else:
        plots_data["COHORT_NAME"] = entity_name
        plots_data["WHICH_METRIC"] = kwargs['metric_type']

    return plots_data


@DatabaseConnector.with_database_connection
def insert_plots(connection: oracledb.Connection, data: dict):
    """
    Inserts data into the AWR_PLOTS_HTML table.

    Parameters
    ----------
    data : dict
        Data to be inserted.
    """
    try:
        with connection.cursor() as cursor:
            qry = get_plot_qry(data)
            cursor.execute(qry, data)
            connection.commit()
            return qry
    except Exception as e:
        print(f"Error in inserting plot data: {e}")
        raise Exception(f"Error in inserting plot data: {e}")


@staticmethod
def get_plot_qry(data):
    """

    Parameters
    ----------
    data  : dict data containing plots and properties for the insertion of plots

    Returns
    -------
    str : Query to insert

    Raises
    ------
    ValueError: if key it's mising
    """
    if 'DB_NAME' in data:
        return INSERT_AWR_PLOTS_QRY
    elif 'COHORT' in data and 'TYPE' in data:
        return INSERT_AWR_UNADJUSTED_PLOTS_QRY
    elif 'COHORT_NAME' in data:
        return INSERT_EM_PLOTS_QRY
    else:
        raise ValueError("Missing 'DB_NAME' or 'COHORT_NAME' in input data to determine query.")


@DatabaseConnector.with_database_connection
def update_plots(connection: oracledb.Connection, data: dict):
    """
    Updates existing data in the AWR_PLOTS_HTML table.

    Parameters
    ----------
    data : dict
        Data to be updated.
    """

    try:
        with connection.cursor() as cursor:
            data.pop('CREATED_ON', None)
            cursor.execute(UPDATE_PLOTS_QRY, data)
            connection.commit()
        print(f"DB Plots updated: {data['WHICH_DB']}")
    except Exception as e:
        print(f"Error in updating plot data: {e}")
        raise Exception(f"Error in updating plot data: {e}")


@DatabaseConnector.with_database_connection
def check_if_plot_exists(connection: oracledb.Connection, which_db: str, upload_id: int):
    """
    Checks if a plot already exists in the AWR_PLOTS_HTML table.

    Parameters
    ----------
    which_db : str
        The name of the database or plot (WHICH_DB).
    upload_id : int
        The upload ID to check.

    Returns
    -------
    bool
        True if the plot exists, False otherwise.
    """
    with connection.cursor() as cursor:
        cursor.execute(CHECK_AWR_PLOTS_EXISTENCE, {'WHICH_DB':which_db, 'UPLOAD_ID':upload_id})
        result = cursor.fetchone()
        return result is not None


def insert_or_update_plots(data: dict):
    """
    Inserts or updates plot data in the AWR_PLOTS_HTML table.

    Parameters
    ----------
    data : dict
        Data to be inserted or updated.
    """
    which_db = data['WHICH_DB']
    upload_id = data['UPLOAD_ID']

    if check_if_plot_exists(which_db, upload_id):
        update_plots(data)
        print('Updated plots for ', which_db)
    else:
        insert_plots(data)
        print('Inserted plots for ', which_db)


def insert_snap_coverage_plot(upload_id: str, data_by_extracts: dict, extracts_dir: Path):
    """
    insert SNAP_COVERAGE plot into AWR_PLOT_HTML

    Parameters
    ----------
    upload_id : str
        Upload ID.
    data : dict
        Dict with data to insert
    extracts_dir : Path
        path where source dirs are
    """

    try:
        fig = read_from_json(extracts_dir / 'awr_snap_coverage_all_cohorts.json')
    except Exception as e:
        raise Exception(f"plot_handler - Something went wrong Snap Coverage was not created. {e}")
    db = 'Snap Coverage Plot'  # Need to be the same as the link text in the row Apex page 69

    plots_data = format_data_plots(upload_id, db, data_by_extracts, db)

    plots_data['PLOTLY_FIG'] = fig.to_json()
    plots_data['FIG'] = 0  # FIG Index only 1 plot

    insert_or_update_plots(plots_data)
    print(f"Snap Coverage Plot processed with upload_id: {upload_id}")


import os
import json


def process_and_insert_plots(upload_id, data, extracts_dir, plot_type='AWR'):
    """
    Processes and inserts plots data.

    Parameters
    ----------
    upload_id : str
        upload_id ID.
    data : dict
        Data metadata to get properties to insert column-values
    """
    print("Inserting plots".center(c.CENTER_N, '-'))
    start = time.time()

    plots_file_path = extracts_dir / 'plots.json'
    if plot_type == 'AWR_UNADJUSTED':
        plots_file_path = extracts_dir / 'unadjusted_plots.json'
    plots_per_db_copy = DirectoryHandler.read_json(plots_file_path)
    db_plots = []

    # AWR is based on DB - plots x DB
    # EMCC is based on cohort  - plots x Cohort
    key = 'DB_NAME' if plot_type == 'AWR' else 'COHORT_NAME'
    # json.dumps(plot_data_copy['FILE_BLOB'], cls=plotly.utils.PlotlyJSONEncoder)

    # O(N) : numbers of dbs
    if plot_type == 'AWR':
        for which_db in plots_per_db_copy:
            db_name = plots_per_db_copy[which_db][0][key]
            plots_data = format_data_plots(upload_id, which_db, data, db_name)
            # O(22) 22 is the max number of plots that a DB can have
            for plot in plots_per_db_copy[which_db]:
                # DB_NAME = plot['DB_NAME']
                plot_data_copy = plots_data.copy()
                plot_data_copy['FIG'] = plot['page']  # FIG Index
                # plot_data_copy['FILE_BLOB'] = go.Figure(json.loads(plot['fig']))  # plot
                plot_data_copy['PLOTLY_FIG'] = json.dumps(json.loads(plot['fig']),
                                                          cls=plotly.utils.PlotlyJSONEncoder)  # plotly
                db_plots.append(plot_data_copy)
    elif plot_type == 'AWR_UNADJUSTED':
        for which_db, plots in plots_per_db_copy.items():
            cohort_name = plots[0].get(key)
            plot_category = plots[0].get('type', 'UNADJUSTED')
            plots_data = format_data_plots(upload_id, which_db, data, cohort_name, plot_type,
                                           plot_category=plot_category)
            for plot in plots:
                plot_data_copy = plots_data.copy()
                plot_data_copy['FIG'] = plot['page']
                plot_data_copy['PLOTLY_FIG'] = json.dumps(json.loads(plot['fig']),
                                                          cls=plotly.utils.PlotlyJSONEncoder)
                plot_data_copy['COHORT'] = plot.get('COHORT_NAME', cohort_name)
                plot_data_copy['TYPE'] = plot.get('type', plot_category)
                db_plots.append(plot_data_copy)
    elif plot_type == 'EMCC':
        for cohort_name, metrics in plots_per_db_copy.items():
            for metric_type, plots in metrics.items():
                # for EM "which_db" doesn't exist, is the same cohort_name
                plots_data = format_data_plots(upload_id, cohort_name, data, cohort_name, plot_type,
                                               **{'metric_type':metric_type})
                # O(22) 22 is the max number of plots that a DB can have
                for plot in plots:
                    # DB_NAME = plot['DB_NAME']
                    plot_data_copy = plots_data.copy()
                    plot_data_copy['FIG'] = plot['page']  # FIG Index
                    # plot_data_copy['FILE_BLOB'] = go.Figure(json.loads(plot['fig']))  # plot
                    plot_data_copy['PLOTLY_FIG'] = json.dumps(json.loads(plot['fig']),
                                                              cls=plotly.utils.PlotlyJSONEncoder)  # plotly
                    db_plots.append(plot_data_copy)
    # benchmark_process_and_insert_plots for a single call
    # Time with 2 workers: 24.286597967147827 seconds
    # Time with 4 workers: 16.285733461380005 seconds
    # Time with 8 workers: 14.562451839447021 seconds
    # Time with 12 workers: 14.023897647857666 seconds
    # Time with 16 workers: 14.641296148300171 seconds
    # Time with 24 workers: 15.635422229766846 seconds
    with ProcessPoolExecutor(max_workers=4) as executor:  # reducing for heavy workload
        # process_plots_result = list(executor.map(blob_to_image, db_plots))
        executor.map(insert_plots, db_plots)

    end = time.time()
    print("Plotting & Inserting in : ", end - start)
    # if plots_file_path.exists():
    #     plots_file_path.unlink()

    # If there's any child process
    while True:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
            if pid > 0:
                print(f"Collected zombie process with PID: {pid}")
            if pid == 0:
                break
        except ChildProcessError as e:
            break
        except Exception as e:
            break


def insert_plots_as_zip(extracts_dir: Path, connection: oracledb.Connection, plot_type: str, **kwargs ):
    # Get the AWR or EMCC path
    PLOTS_PATH = fp.get_plots_path(extracts_dir, plot_type)

    filename = "plots.zip"
    query = UPDATE_BY_INSERTING_PLOTS
    if plot_type == 'AWR_UNADJUSTED':
        filename = "plots_unadjusted.zip"
        query = UPDATE_BY_INSERTING_UNADJUSTED_PLOTS
    if not Path.exists(PLOTS_PATH):
        raise ModuleNotFoundError(f"{plot_type} Plots path doesn't exists, can't continue")

    zip_file_path = extracts_dir / f"{plot_type.lower()}_plots.zip"
    upload_id = kwargs.get('FOREIGN_KEYS')['UPLOAD_ID']

    with zipfile.ZipFile(zip_file_path, 'w') as zipf:
        for root, _, files in os.walk(PLOTS_PATH):
            for file in files:
                zipf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), PLOTS_PATH))

    with open(zip_file_path, 'rb') as f:
        zip_blob = f.read()

    with connection.cursor() as cursor:
        try:
            cursor.execute(query, zip_blob=zip_blob, filename=filename, upload_id=upload_id)
            connection.commit()
            print(f'Plot zip & filename inserted for  {plot_type} data -> u_id : {upload_id}'.center(c.CENTER_N, '-'))
            os.remove(zip_file_path)
        except Exception as e:
            print(f"Error: something happened trying to update zip_blob into UPLOAD_EXTRACTS {e}")
            raise(e)
