# Centralized status constants for backend processing phases

# AWR phases
AWR_INITIAL_PHASE_STARTED = "AWR: Initial Processing Started"
AWR_INITIAL_PHASE_COMPLETED = "AWR: Initial Processing Completed"

AWR_FINAL_PHASE_STARTED = "AWR: Final Processing Started"
AWR_FINAL_PHASE_COMPLETED = "AWR: Final Processing Completed"

# EMCC phases
EMCC_INITIAL_PHASE_STARTED = "EMCC: Initial Processing Started"
EMCC_INITIAL_PHASE_COMPLETED = "EMCC: Initial Processing Completed"

EMCC_FINAL_PHASE_STARTED = "EMCC: Final Processing Started"
EMCC_FINAL_PHASE_COMPLETED = "EMCC: Final Processing Completed"

# Error templates (format with a concise message)
INITIAL_PROCESS_ERROR = "Initial Processing Failed:  {}"
FINAL_PROCESS_ERROR   = "Final Processing Failed:  {}"