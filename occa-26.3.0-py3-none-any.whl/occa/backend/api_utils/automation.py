import os
import sys
from pathlib import Path

import subprocess
import pandas as pd

from constants.Paths import FilePaths as fp

from version import version, __version__
import logging
logger = logging.getLogger(__name__)

os.environ['RUN_FROM_API'] = 'True'
def print_running(command):
    logger.info(f"⭐️✨🌟 Current: {command} 🌟✨⭐️")


class Args:
    params = ""
    checkmetrics = ""


def handle_exceptions(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            message_error = extract_error_message(e.args[0])
            logger.info('message error: ', message_error)
            print("Wrapper Exception:", message_error)
            raise Exception(message_error.strip())

    return wrapper


def extract_error_message(stderr):
    """
    Get's the Exception message
    """
    lines = stderr.splitlines()[::-1]
    extracted_message = []
    MAX_LIMIT_STATUS_COLUMN = 4000
    for i, line in enumerate(lines):
        line = line.strip()

        if '====' in line or 'Download the latest' in line or 'Check' in line: continue
        candidate = line if not extracted_message else '<br>' + line
        temp_list = [candidate] + extracted_message
        test_message = ''.join(temp_list)
        if len(test_message) > (MAX_LIMIT_STATUS_COLUMN-45) : # 40 "Final Processing Failed: An error ocurred" appended on Exception
            break
        # Column -status-  is 4000 length
        extracted_message.insert(0, candidate)
    return ''.join(extracted_message)


def edit_property_file(base_path, choice=1):
    # Rename the files to remove the '_original' suffix
    print_running("Removing _original suffix")
    awr_properties_path = Path(base_path) / "awr_miner_occa" / "properties"

    property_path = awr_properties_path if choice == 1 else Path(base_path) / 'occa_sizing_properties'
    if not property_path.exists():
        raise FileNotFoundError("Something went wrong with Parsing & Plotting property file doesn't exists")
    files = os.listdir(property_path)
    try:
        for filename in files:

            # If awr_properties exists (not the original) it means it was created
            # by cohort-structure way.
            if fp.AWR_PROPERTIES_ORIGINAL.name in filename and (property_path / fp.AWR_PROPERTIES.name).exists():
                print(f'Cohort-Structure   -> {property_path / fp.AWR_PROPERTIES.name} exists file skipping')
                continue

            if filename.endswith("_original.csv"):
                new_name = filename.replace("_original.csv", ".csv")
                os.rename(str(property_path / filename), str(property_path / new_name))
    except FileExistsError:
        print(f"File: {filename} already exists ")

    # Uncomment to  Just to simulate OwO
    # import pandas as pd
    # print_running("SIMULATION OWO")
    # # property_path = Path(base_path) / "awr_miner_occa" / "properties" if choice == 1 else   Path(base_path) / 'occa_sizing_properties'
    # print_running("PROD in all rows under first Cohort")
    if os.environ.get("SMOKE_TEST","False") == "True":
        property_name = "awr_properties_database" if choice == 1 else "properties_database"
        properties = os.path.join(property_path, f"{property_name}.csv")
        properties_df = pd.read_csv(properties)
        properties_df["Cohort"] = "smoke_test"
        properties_df.to_csv(properties, index=False)
    # #
    if choice == 1:
        #     # Open awr_tz-database.csv in Excel. Make sure there's entries in the Timezone (TZ) column. (put 'UTC' if they're blank.)
        print_running("if TZ has no value fill it wit UTC")
        awr_tz_database_path = os.path.join(awr_properties_path, "awr_tz_database.csv")
        awr_tz_database_df = pd.read_csv(awr_tz_database_path)
        awr_tz_database_df['TZ'] = awr_tz_database_df['TZ'].fillna("UTC").replace("", "UTC")
        awr_tz_database_df.fillna({'MINUTES_DIFF_FROM_UTC_list':0.0}, inplace=True)
        awr_tz_database_df.to_csv(awr_tz_database_path, index=False)


@handle_exceptions
def run_parse(base_path):
    os.environ['RUN_FROM_API'] = 'True'

    print_running("Parsing")
    occa_script = Path(base_path).parents[4] / 'occa.py'

    process = subprocess.Popen(
        [sys.executable, occa_script, '--awr-parse'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)


@handle_exceptions
def run_plot(base_path):
    os.environ['RUN_FROM_API'] = 'True'

    print_running("Plotting")
    occa_script = Path(base_path).parents[4] / 'occa.py'

    process = subprocess.Popen(
        [sys.executable, occa_script, '--awr-plot'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)

    edit_property_file(base_path, choice=1)


def awr_run_run(base_path, data_for_snap_coverage):
    print_running("Running")
    occa_script = Path(base_path).parents[4] / 'occa.py'
    os.environ['RUN_FROM_API'] = 'True'
    process = subprocess.Popen(
        [sys.executable, occa_script, '--awr-run'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()
    if 'Snapshot dates of databases' in stderr:
        from backend.api_utils.plot_handler import insert_snap_coverage_plot

        extracts_dir = base_path
        insert_snap_coverage_plot(data_for_snap_coverage['upload_id'], data_for_snap_coverage['data_by_extracts'],
                                  extracts_dir)

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)


def awr_run_import(base_path):
    print_running("Importing")
    occa_script = Path(base_path).parents[4] / 'occa.py'
    os.environ['RUN_FROM_API'] = 'True'
    process = subprocess.Popen(
        [sys.executable, occa_script, '--awr-import'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)


def awr_run_all(base_path):
    awr_run_run(base_path)
    awr_run_import(base_path)


def emcc_run_create_properties(base_path):
    print_running("Creating Properties")
    occa_script = Path(base_path).parents[4] / 'occa.py'

    process = subprocess.Popen(
        [sys.executable, occa_script, '--create-properties'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)

    edit_property_file(base_path, choice=2)


def emcc_run_add_properties(base_path):
    print_running("Adding Properties")
    occa_script = Path(base_path).parents[4] / 'occa.py'
    process = subprocess.Popen(
        [sys.executable, occa_script, '--add-properties'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)


def emcc_run_copy_db_name(base_path):
    print_running("Adding Properties")
    occa_script = Path(base_path).parents[4] / 'occa.py'
    process = subprocess.Popen(
        [sys.executable, occa_script, '--copy-db-name'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)


def emcc_run_metrics_analysis(base_path,metadata):
    print_running("Running metrics analysis")

    occa_script = Path(base_path).parents[4] / 'occa.py'
    process = subprocess.Popen(
        [sys.executable, occa_script, '--run-metric-analysis'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()
    # first time will crash making sure user edit APEX Interactive Grid
    # main_service > automation > complete_processing > main service
    # Having a condition will only insert tables if it fails, if the user wants to keep generating opportunities
    # without an error whe output tables are always deleted on complete_processing process.


    # Following imports are on demand so the circular import error
    from backend.services.complete_processing import update_emcc_properties_csv_to_tables
    from backend.services.complete_processing import insert_emcc_output_csv_to_tables
    update_emcc_properties_csv_to_tables(base_path,**metadata)
    insert_emcc_output_csv_to_tables(base_path,**metadata)

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)


def emcc_run_import(base_path):
    print_running("Running import")
    occa_script = Path(base_path).parents[4] / 'occa.py'
    process = subprocess.Popen(
        [sys.executable, occa_script, '--emcc-import'],
        cwd=base_path,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = process.communicate()

    if stderr and 'warning' not in stderr.lower():
        raise Exception(stdout + stderr)


@handle_exceptions
def run_add_properties_and_metrics_and_import(base_path,metadata):
    os.environ['RUN_FROM_API'] = 'True'

    emcc_run_add_properties(base_path)
    emcc_run_metrics_analysis(base_path,metadata)  # to do
    run_import_no_excluded_dbs(base_path)
@handle_exceptions
def run_import_no_excluded_dbs(base_path):
    from occa.pandas_helpers.pandas_data_utils import has_no_em_output_excluded_dbs

    os.environ['RUN_FROM_API'] = 'True'
    excluded_dbs = has_no_em_output_excluded_dbs(base_path)

    if not excluded_dbs:
        emcc_run_import(base_path)



@handle_exceptions
def run_run_and_import(base_path, data_for_snap_coverage):
    os.environ['RUN_FROM_API'] = 'True'

    awr_run_run(base_path, data_for_snap_coverage)
    awr_run_import(base_path)
