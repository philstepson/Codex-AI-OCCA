from datetime import datetime
from time import sleep

import oracledb
import pandas as pd
import os

import backend.api_utils.constants as c
from backend.run import  log_entry
from backend.api_utils.queries import *
from backend.conn import DatabaseConnector
from version import version, __version__


class DatabaseManager:
    """
    This class is in charge or any database operation.
    RAWR SQL are in queries.py
    """

    def __init__(self):
        self.connection = DatabaseConnector().get_connection()
        self.created_by = None

    @log_entry
    def get_archive_extract_by_id(self, upload_id):
        """
        Retrieve a row by ID from the UPLOAD_ARCHIVE_EXTRACT table.

        Parameters
        ----------
        upload_id : str
            The Foreign key ID of the file to look up.

        Returns
        -------
        dict or None
            The fetched row as a dictionary if found, otherwise None.
        """
        with self.connection.cursor() as cursor:
            cursor.execute(SELECT_ARCHIVE_EXTRACT, {'upload_id':upload_id})
            result = cursor.fetchone()
            return result if result else None

    @log_entry
    def fetch_table_data_as_df(self, query, params, column_mapping=None, fetch='all', size=0):
        """
        Executes a SQL query and returns the result as a pandas DataFrame.

        Parameters
        ----------
        query : str
            The SQL query to be executed.
        params : dict
            The parameters to be used in the SQL query.
        column_mapping : dict, optional
            A dictionary to rename the columns in the resulting DataFrame.
        fetch : str, optional, default 'all'
            Determines the fetch method. Options are 'all' to fetch all rows, 'one' to fetch a single row
            and 'many' to fetch a specified number of rows.
        size : int, optional, default 0
            The number of rows to fetch when using fetch='many'.

        Raises
        ------
        ValueError
            If no data is found for the given query.

        Returns
        -------
        pandas.DataFrame
            The result of the SQL query as a DataFrame.
        """
        with self.connection.cursor() as cursor:
            cursor.execute(query, params)

            if fetch == 'all':
                data = cursor.fetchall()
            elif fetch == 'one':
                data = cursor.fetchone()
            else:
                data = cursor.fetcmany(size=size)

            if not data:
                return data

            columns = [col[0] for col in cursor.description]
            df = pd.DataFrame(data, columns=columns)

            self.created_by = df.iloc[0].get('CREATED_BY') or self.created_by

            if column_mapping:
                df = df.rename(columns=column_mapping)
                df = df[column_mapping.values()]
            return df

    @log_entry
    def format_generic_select_query(self, table_name=None, columns_to_search=None, params=None,query=None):
        """
        Generates a SQL SELECT query string based on the table name, parameters, and key identifier.

        Parameters
        ----------
        table_name : str
            The name of the target table.
        columns_to_search:  list
            List of params that you want to select
        id : str
            the id to look up.
        query : str
            db_manager.format_generic_select_query_by_id(query=your_query,params={'key_if_needed':x})
        """
        if query:
            return query
        columns_to_search = ', '.join(columns_to_search)
        where_clause = " AND ".join([f"{key} = :{key}" for key in params.keys()])
        return SELECT_BY_ID_GENERIC.format(columns_to_search, table_name, where_clause)

    @log_entry
    @staticmethod
    def format_generic_update_query(table_name: str, columns_to_update: list, key_columns: list) -> str:
        """
        Generates a generic SQL UPDATE statement with named bind placeholders.

        Parameters
        ----------
        table_name : str
            The name of the target table to update.
        columns_to_update : list of str
            List of column names to include in the SET clause.
        key_columns : list of str
            List of column names to include in the WHERE clause as identifiers.

        Returns
        -------
        str
            A SQL UPDATE query string formatted like:
            "UPDATE {table_name} SET col1 = :col1, col2 = :col2 WHERE key1 = :key1 AND key2 = :key2"

        Examples
        --------
        >>> sql = format_generic_update_query(
        ...     table_name='CAT_TABLE',
        ...     columns_to_update=['col1', 'col2'],
        ...     key_columns=['upload_id', 'DB_NAME']
        ... )
        >>> print(sql)
        UPDATE CAT_TABLE
          SET col1 = :col1,
              col2 = :col2
         WHERE upload_id = :upload_id
           AND DB_NAME   = :DB_NAME
        """
        set_clause = ', '.join(f"{col} = :{col}" for col in columns_to_update)
        where_clause = ' AND '.join(f"{key} = :{key}" for key in key_columns)
        return f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"

    def fetch_raw_data(self, query, params=None, to=None):
        with self.connection.cursor() as cursor:
            cursor.execute(query, params)
            data = cursor.fetchone()

            if not data:
                return data

            if to == 'dict':
                dict = self._fetch_to_dict(data, cursor.description)
                self.created_by = dict.get('CREATED_BY')
                return dict


            return data

    @log_entry
    def _fetch_to_dict(self, data, cursor_description):
        result_dict = {}
        for i, c in enumerate(cursor_description):
            column_name = c[0]
            column_value = data[i]

            # Here you can manipulate columns from columns (cursor.description), and do something with value
            # In my case filename comes as 'filename.extension'  I only need the name from that particular value.
            if 'FILENAME' in column_name:
                result_dict[column_name] = column_value.split('.')[0] if column_value else column_value
            elif isinstance(column_value, oracledb.LOB):
                result_dict[column_name] = column_value.read()
            else:
                result_dict[column_name] = column_value
        return result_dict

    @log_entry
    def insert_file_upload(self, data :dict, upload_id:int) -> dir:
        """
        Insert data into the FILE_UPLOAD table.

        Parameters
        ----------
        data: dict
            the required keys for the sql
        upload_id: int
            required for updating the upload_archive table with the file_id created
        """
        print("Inserting FILE UPLOPAD JSON".center(c.CENTER_N, '-'))
        data["CREATED_ON"] = datetime.now()
        data["STATUS"] = "IMPORTED"
        if os.environ.get("SMOKE_TEST", "False") == "True":
            data["TEST"] = "YES"
        # data["SALESCLOUD_ID"] = data["SALESCLOUD"]
        with self.connection.cursor() as cursor:
            cursor.setinputsizes(file_blob=cursor.var(bytes))
            data["FILE_ID"] = cursor.var(int)
            cursor.execute(INSERT_JSON_INTO_FILE_UPLOAD, data)
            job_id_var = cursor.var(oracledb.NUMBER)
            file_id = data["FILE_ID"].getvalue()[0]

            update_upload_archive_table_created_file_id_sql = DatabaseManager.format_generic_update_query(
                table_name=UPLOAD_ARCHIVE_EXTRACT,
                columns_to_update=['created_file_id'],
                key_columns=['ID']
            )
            cursor.execute(update_upload_archive_table_created_file_id_sql, {'created_file_id':file_id,'ID':upload_id})

            self.connection.commit() # File commited to the table

            # Using the following block the thread execution and waits until it's completed
            # cursor.callproc("sizing_upload.process_upload_id", [data["FILE_ID"].getvalue()[0], None])

            sql = f"""
                BEGIN
                  DBMS_JOB.SUBMIT(
                    job => :job_id,
                    what => 'BEGIN sizing_upload.process_upload_id({file_id}, NULL); END;',
                    next_date => SYSDATE,
                    interval => NULL
                  );
                END;
                """
            cursor.execute(sql, {"job_id":job_id_var})
            self.connection.commit() #commit to recognize the job <- and then ran it and remove it



            """
            This is for smoke test for some reason if I run from pytest -> it doesn't run 
            the job is created but the sysdate is not being picked up
            
            it fails for prod, uncomment for dev(time slip )
            """
            # if os.environ.get("SMOKE_TEST","False") == "True":
            #     import time
            #     print(f'JOB for file_id -> {file_id}  job id --> {job_id_var}')
            #     job_id = int(job_id_var.getvalue())
            #     time.sleep(3)  # see if the job ran
            #     cursor.execute("""
            #                 SELECT last_date FROM user_jobs WHERE job = :job_id
            #             """, job_id=job_id)
            #     row = cursor.fetchone()
            #     last_date = row[0] if row else None
            #     if not last_date:
            #         print(f"Job {job_id} did not run automatically. Forcing execution.")
            #         cursor.callproc("dbms_job.run", [job_id])
            #         self.connection.commit()
            #     else:
            #         print(f"Job {job_id} ran at {last_date}.")

        return data["FILE_ID"].getvalue()[0]



    def wait_for_opportunity_creation(self, file_id):
        """
        Wait for the creation of an opportunity and retrieve its ID.

        Parameters
        ----------
        file_id : str
            The file ID used to check the opportunity's existence.

        Returns
        -------
        str
            The ID of the created opportunity.

        Raises
        ------
        Exception
            If the maximum number of attempts is reached without success.
        """
        attempt = 1
        max_attempts = 120
        while attempt <= max_attempts:
            try:
                print("Getting ID #{} attempt".format(attempt).center(c.CENTER_N, '-'))
                if opp_id := self.check_opportunity_exists(file_id):
                    print("OPP_ID {}".format(opp_id).center(c.CENTER_N, '-'))
                    return opp_id
                else:
                    sleep(1)  # 0.5 seconds
                    attempt += 1
            except Exception as e:
                print("Error occurred while waiting for opportunity creation:", e)
                attempt += 1
        raise Exception("Something went wrong while waiting for opportunity creation.")


    def check_opportunity_exists(self, file_id: str):
        """
        Check if an opportunity exists for a given file ID.

        Parameters
        ----------
        file_id : str
            The file ID to check for an existing opportunity.

        Returns
        -------
        int or None
            The ID of the found opportunity, or None if no opportunity is found.
        """
        with self.connection.cursor() as cursor:
            cursor.execute(SELECT_OPP_BY_ID.format(file_id))
            result = cursor.fetchone()
            return result[0] if result else None

    @log_entry
    def update_opportunity_audit_fields(self, opp_id: str, user:str) -> None:
        """
        Update the modified_by and created_by fields of an opportunity in the OPPORTUNITIES table.

        Parameters
        ----------
        opp_id : str
            The ID of the opportunity to update.
        user : str
            The user who created the record will be the same as modified the record.
        """
        print("Updating Opportunity Audit Fields".center(c.CENTER_N, '-'))

        update_data = {
            'id':opp_id,
            'modified_by':user,
            'created_by':user
        }

        with self.connection.cursor() as cursor:
            cursor.execute(UPDATE_MODIFIED_CREATED_BY_BY_OPPID, update_data)
        self.connection.commit()

    @log_entry
    def create_customer(self,connection : oracledb.Connection, params: dict):
        """
        Create a new customer in the Customer table.

        Parameters:
        connection (oracledb.Connection): The Oracle database connection.
        customer_name (str): The name of the customer.
        upload_id (int): The upload ID to associate with the customer.

        Returns:
        int: The ID of the newly created customer.
        """
        try:
            with connection.cursor() as cur:
                id_var = cur.var(int)
                params_create = {**params, **{'id':id_var}}
                cur.execute(INSERT_CUSTOMER, params_create)
                connection.commit()
                print(f"New customer created: {params_create['customer']}".center(c.CENTER_N, '-'))
                customer_id = id_var.getvalue()[0]
                return customer_id
        except oracledb.DatabaseError as error:
            raise Exception(f"Error trying to create new customer {error}")

    @log_entry
    def plots_exist(self, upload_id):
        """
        Checks if plots already exist in the AWR_PLOTS_HTML table for a given upload ID.

        Parameters
        ----------
        upload_id : int
            The ID of the upload.

        Returns
        -------
        bool
            True if plots already exist, False otherwise.
        """
        params = {'upload_id':upload_id}
        result = self.fetch_raw_data(PLOTS_BY_UPLOAD_ID, params, to='dict')
        return result['COUNT'] > 0

    @log_entry
    def update_status(self, upload_id, status, error_message=None):
        """
        Update the status of a file in the UPLOAD_ARCHIVE_EXTRACT table.

        Parameters
        ----------
        upload_id : str
            The ID of the file to update.
        status : str
            The new status to set.
        error_message : str, optional
            The error message to set in case of an error.
        """
        if error_message:
            status = status.format(error_message)

        query = UPDATE_STATUS_QUERY
        with self.connection.cursor() as cursor:
            cursor.execute(query, {'status':status, 'upload_id':upload_id})
        self.connection.commit()

    @log_entry
    def get_pending_uploads(self):
        """
        Retrieve all rows with status 'Pending' from the UPLOAD_ARCHIVE_EXTRACT table.

        Returns
        -------
        list
            A list of dictionaries, each representing a row with status 'Pending'.
        """

        query = "SELECT ID,Status,CREATED_BY,CREATED_ON FROM UPLOAD_ARCHIVE_EXTRACT WHERE STATUS = 'Pending'"

        with self.connection.cursor() as cursor:
            cursor.execute(query)
            data= cursor.fetchall()
            return data

    @log_entry
    def fetch_error_uploads(self):
        query = "SELECT ID,STATUS,CREATED_BY,CREATED_ON FROM UPLOAD_ARCHIVE_EXTRACT WHERE STATUS LIKE :status order by created_on desc"
        params = {'status':'%error%'}
        with self.connection.cursor() as cursor:
            cursor.execute(query,params)
            data = cursor.fetchall()
            return data
    @log_entry
    def fetch_error_uploads_by_user(self,params):
        query = """
                    SELECT ID, STATUS, CREATED_BY, CREATED_ON,CUSTOMER
                    FROM UPLOAD_ARCHIVE_EXTRACT
                    WHERE STATUS LIKE :status AND CREATED_BY = :created_by
                    order by created_on desc 
                """
        with self.connection.cursor() as cursor:
            cursor.execute(query, params)
            data = cursor.fetchall()
            return data


    def execute_delete(self,table_name, column_name, param_name, value):
        """
        Executes a DELETE statement on a given table using a WHERE condition.

        Parameters
        ----------
        table_name : str
            Name of the table
        column_name : str
            Name of the column
        param_name : str
            Name of the paratemrs
        value : any
            Value for delete

        Returns
        -------
        int
            Number of rows deleted.
        """
        query = GENERIC_DELETE.format(table_name,column_name,param_name)
        with self.connection.cursor() as cursor:
            cursor.execute(query, {param_name:value})
            count = cursor.rowcount
            msg = f"No record found for in {table_name}:{column_name} = {value}" if count == 0\
                else f"Deleted {count} record(s) from {table_name} -> {column_name} = {value}"

            cursor.connection.commit();
            print(msg)
            return count


