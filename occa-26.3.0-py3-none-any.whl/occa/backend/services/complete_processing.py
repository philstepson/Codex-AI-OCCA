import logging

from backend.api_utils.status import *
import logging
from pathlib import Path

import pandas as pd

from backend.api_utils import automation
from backend.api_utils.custom_response import CustomResponse
from backend.api_utils.database import DatabaseManager
from backend.api_utils.plot_handler import *
from backend.run import log_entry
from file_manager.CSVHandler import CSVHandler
from file_manager.FileSystemHandler import DirectoryHandler
from pandas_helpers.pandas_data_utils import has_no_em_output_excluded_dbs
from services.main_service import log_step

logger = logging.getLogger(__name__)


def generate_opportunity(upload_id, db_manager: DatabaseManager = None, delete_files=True):
    """
    Continue the process by retrieving the user's working directory.
    and replace the existing csv with the upcoming data from the tables that the user edited in APEX.


    Parameters
    ----------
        upload_id :str
            The ID of the file to download.

    Raises
    ------
    ColumnsNotMatched
        if the existing CSV columns doesn't match with the upcoming data (Some malformation happened or is not the same)
    ModuleNotFoundError
        Directories not found
    Exception
        Something else happened.

    Returns
    -------
        JSON Response
    """

    root_dir = Path(__file__).parent.parent
    output_directory = root_dir / c.ARCHIVES_DOWNLOADED
    logger.info(f"Running {output_directory} for upload_id {upload_id}".center(80, '-'))
    try:
        connection = db_manager.connection
        upload_param = {'upload_id':upload_id}

        params_upload_archive = {'id':upload_id}
        query = db_manager.format_generic_select_query(table_name=UPLOAD_ARCHIVE_EXTRACT,
                                                       columns_to_search=['filename', 'customer', 'file_charset',
                                                                          'file_comments', 'opportunity_name',
                                                                          'created_by', 'salescloud_id', 'test',
                                                                          'region', 'country']
                                                       , params=params_upload_archive)

        data_by_extracts = db_manager.fetch_raw_data(query, params=params_upload_archive, to='dict')
        logger.info('Data has been fetched and extracted')
        if not data_by_extracts:
            raise ValueError(f"No data extracts for {upload_id} id.")
        customer_directory = output_directory / db_manager.created_by / upload_id
        extracts_dir = DirectoryHandler.get_extracts_dir(customer_directory, data_by_extracts['FILENAME'])

        # If there's no structure-directory to continue rebuild it from calling first endpoint process.
        is_awr, is_emcc = fp.resolve_for_awr_emcc(extracts_dir)
        logger.info(f"Resolving if it's awr : {is_awr}, or emcc: {is_emcc} ")

        if not is_awr and not is_emcc:
            # Avoid circular import main_service > automation > complete_processing > main_service
            from ..services.main_service import download_extract

            logger.info('No structure found - running download_extract')
            download_extract(upload_id, db_manager=db_manager)
            is_awr, is_emcc = fp.resolve_for_awr_emcc(extracts_dir)
            logger.info('No structure found - finished')

        if is_awr:
            if not DirectoryHandler.directory_structure_exists(extracts_dir, fp.AWR_REQUIRED_FOLDERS):
                raise Exception("Something went wrong no directory Structure for AWR")

            # Fetching all the necessary data to generate AWR  opportunity
            tz_data = db_manager.fetch_table_data_as_df(SELECT_TZ_BY_UPLOAD_ID, upload_param, tz_column_mapping)

            properties_data = db_manager.fetch_table_data_as_df(SELECT_PROPERTIES_BY_UPLOAD_ID, upload_param,
                                                                properties_column_mapping)
            logger.info(f'AWR Fetched properties data for id {upload_id}')
            db_manager.update_status(upload_id, AWR_FINAL_PHASE_STARTED)

            properties_csv_path = extracts_dir / fp.AWR_PROPERTIES
            tz_csv_path = extracts_dir / fp.AWR_TZ
            if check_columns_match(properties_data, properties_csv_path):
                properties_data.to_csv(properties_csv_path, index=False)
            else:
                raise ColumnsNotMatched("The columns of the properties does not match the existing CSV file.")

            if check_columns_match(tz_data, tz_csv_path):
                tz_data.to_csv(tz_csv_path, index=False)
            else:
                raise ColumnsNotMatched("The columns of tz does not match the existing CSV file.")

        else:
            properties_database = db_manager.fetch_table_data_as_df(SELECT_EMCC_PROPERTIES_BY_UPLOAD_ID, upload_param,
                                                                    properties_emcc_column_mapping)

            properties_instance = db_manager.fetch_table_data_as_df(SELECT_EMCC_PROPERTIES_INSTANCE_BY_UPLOAD_ID,
                                                                    upload_param,
                                                                    properties_emcc_instances_column_mapping)
            logger.info(f'EMCC Fetched properties data for id {upload_id}')
            db_manager.update_status(upload_id, EMCC_FINAL_PHASE_STARTED)

            properties_csv_path = extracts_dir / fp.EMCC_PROPERTIES_DB
            properties_instances_path = extracts_dir / fp.EMCC_PROPERTIES_INSTANCE

            # On the first run (main_service): template files will be created for the user to edit.
            # In APEX, ensure that the columns in the table match those in the CSV.
            # If the columns match, we replace the data updated from the APEX table into the local OCCA process
            # to use the relevant data and ensure integrity.
            if check_columns_match(properties_database, properties_csv_path):
                properties_database.to_csv(properties_csv_path, index=False)
            else:
                raise ColumnsNotMatched("The columns of the properties does not match the existing CSV file.")

            if check_columns_match(properties_instance, properties_instances_path):
                properties_instance.to_csv(properties_instances_path, index=False)
            else:
                raise ColumnsNotMatched("The columns of tz does not match the existing CSV file.")

            delete_output_tables_by_upload_id(db_manager, upload_id)

        metadata = {
            'upload_id':upload_id,
            'data_by_extracts':data_by_extracts
        }

        # data to insert csv - foreign key
        data_csv_insert = {
            'FOREIGN_KEYS':{
                'UPLOAD_ID':upload_id
            },
            'CREATED_BY':data_by_extracts['CREATED_BY']
        }

        log_step(upload_id, 'final_process', 'Executing automation scripts')
        target_json = get_target_json(is_awr, is_emcc, extracts_dir, **metadata, **data_csv_insert)
        if is_awr:
            log_step(upload_id, 'final_process', 'AWR phase started')
            insert_snap_coverage_plot(upload_id, data_by_extracts, extracts_dir)
            try:
                process_and_insert_plots(upload_id, data_by_extracts, extracts_dir, 'AWR_UNADJUSTED')
            except FileNotFoundError:
                logger.info('AWR unadjusted plots json not found, skipping insert')
            except Exception as e:
                logger.warning('Unable to insert AWR unadjusted plots: %s', e)
            try:
                insert_plots_as_zip(extracts_dir, connection, 'AWR_UNADJUSTED', **data_csv_insert)
            except ModuleNotFoundError:
                logger.info('AWR unadjusted plots not found, skipping zip insertion')
            log_step(upload_id, 'final_process', 'AWR phase completed')

        if is_emcc and not has_no_em_output_excluded_dbs(extracts_dir):
            log_step(upload_id, 'final_process', 'EMCC phase started')
            process_and_insert_plots(upload_id, data_by_extracts, extracts_dir, 'EMCC')
            insert_plots_as_zip(extracts_dir, connection, 'EMCC', **data_csv_insert)
            log_step(upload_id, 'final_process', 'EMCC phase completed')

        log_step(upload_id, 'final_process', 'JSON prepared for opportunity creation')
        json_data = DirectoryHandler.read_json(target_json)

        data_by_extracts["filename"] = target_json.name

        data_by_extracts["FILE_BLOB"] = json.dumps(json_data).encode('UTF-8')
        data_by_extracts["file_mimetype"] = "application/json"

        log_step(upload_id, 'final_process', 'Persisting opportunity artifacts')
        file_id_created = db_manager.insert_file_upload(data_by_extracts,upload_id)
        opp_id_created = db_manager.wait_for_opportunity_creation(file_id_created)

        db_manager.update_opportunity_audit_fields(opp_id_created, data_by_extracts['CREATED_BY'])

        response = {
            "message":"Opportunity created.",
            "upload_id":upload_id,
            "file_id":file_id_created,
            "opportunity_id":opp_id_created
        }

        # Post processing
        params_customer = {'upload_id':upload_id, 'customer':data_by_extracts['CUSTOMER']}

        customer_query = db_manager.format_generic_select_query(table_name=UPLOAD_CUSTOMER,
                                                                columns_to_search=['id'],
                                                                params=params_customer)

        log_step(upload_id, 'final_process', 'Ensuring customer linkage')
        customer_id = db_manager.fetch_raw_data(customer_query, params=params_customer)
        if not customer_id:
            response['customer_id'] = db_manager.create_customer(connection, params_customer)
        else:
            response['customer_id'] = customer_id[0]  # (id,)

        if is_awr:
            db_manager.update_status(upload_id, AWR_FINAL_PHASE_COMPLETED)
        else:
            db_manager.update_status(upload_id, EMCC_FINAL_PHASE_COMPLETED)
        logger.info(f'Finished : {response}\n\n\n')

        return CustomResponse.created(response)

    except Exception as e:
        error_message = "An error occurred: "
        if isinstance(e, ColumnsNotMatched):
            error_message += f"Column mismatch error: {e}"
            response_fn = CustomResponse.server_error
        elif isinstance(e, ModuleNotFoundError):
            error_message += f"Missing folder/data for continue process: {upload_id}. {e}"
            response_fn = CustomResponse.not_found
        elif isinstance(e, ValueError):
            error_message += f"Reading values for: {upload_id}. {e}"
            response_fn = CustomResponse.not_found
        else:
            error_message += str(e)
            response_fn = CustomResponse.server_error

        db_manager.connection.rollback()
        db_manager.update_status(upload_id, FINAL_PROCESS_ERROR, error_message)

        return response_fn({'message':error_message})


@log_entry
def get_target_json(is_awr, is_emcc, extracts_dir, **metadata: dict) -> Path:
    """
    This function checks if the type of data is AWR or EMCC and runs the corresponding processes to generate a JSON file.
    If a valid data type is not found, it raises a ModuleNotFoundError.

    Parameters
    ----------
    is_awr : bool
        If iit's AWR type.
    is_emcc : bool
        If it's EMCC type.
    extracts_dir :
        the route to the awr_miner_out || emcc_extracts folder
    metadata : dict
        data needed if it fails but the snap coverage plot is created
    Raises
    ------
    ModuleNotFoundError
        If a valid data type (neither AWR nor EMCC) is not found.

    Returns
    -------
    Path
        The path to the generated JSON file.
    """
    if is_awr:
        automation.run_run_and_import(extracts_dir, metadata)
        target_json = extracts_dir / fp.AWR_UPLOAD_JSON_PATH
    elif is_emcc:
        automation.run_add_properties_and_metrics_and_import(extracts_dir, metadata)
        target_json = extracts_dir / fp.EMCC_UPLOAD_JSON_PATH
    else:
        raise ModuleNotFoundError("AWR/EMCC Directory not found")
    return target_json


@log_entry
def check_columns_match(df, csv_path):
    """
    Checks if the columns of a given DataFrame match the columns of a CSV file.

    Parameters
    ----------
    df : pandas.DataFrame
        The DataFrame whose columns need to be checked.
    csv_path : pathlib.Path
        The path to the CSV file to compare against.

    Returns
    -------
    bool
        True if the columns match, False otherwise.

    Raises
    ------
    FileNotFoundError
        If the CSV file does not exist at the provided path.
    """
    if not csv_path.exists():
        return False
    existing_df = pd.read_csv(csv_path)
    if csv_path.name == fp.EMCC_PROPERTIES_INSTANCE.name:
        existing_df.rename(columns={'version.1':'version_properties_file'}, inplace=True)
    return list(df.columns) == list(existing_df.columns)


@log_entry
@staticmethod
def update_emcc_properties_csv_to_tables(extracts_dir: Path, **kwargs):
    """
        Inserts EMCC Output sizing CSV data into Oracle tables.

        Parameters
        ----------
        extracts_dir : Path
            The directory containing the AWR CSV files. (or EMCC)
        connection : oracledb.Connection
            The Oracle database connection.
        **kwargs
            Additional keyword arguments to pass to the CSVHandler.

        Raises
        ------
        FileNotFoundError
            If the specified CSV files are not found in the extracts directory.

        Returns
        -------
        None
        """

    properties_database_fp = extracts_dir / fp.EMCC_PROPERTIES_DB
    properties_instances_fp = extracts_dir / fp.EMCC_PROPERTIES_INSTANCE
    kwargs['commit_type'] = 'update'
    connection = DatabaseManager().connection

    kwargs['id_column'] = 'DB_NAME'
    kwargs['columns_to_update'] = EXTRACTS_EMCC_PROPERTIES_DB_COLUMNS_TO_UPDATE
    csv_handler = CSVHandler(table_name=EXTRACTS_EMCC_PROPERTIES_DATABASE,
                             columns=EXTRACTS_EMCC_PROPERTIES_DATABASE_COLUMNS,
                             csv_file_path=properties_database_fp,
                             has_audit=False,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)

    kwargs['id_column'] = 'INSTANCE_NAME'
    kwargs['columns_to_update'] = EXTRACTS_EMCC_PROPERTIES_INSTANCES_COLUMNS_TO_UPDATE
    csv_handler.setup_config(table_name=EXTRACTS_EMCC_PROPERTIES_INSTANCES,
                             columns=EXTRACTS_EMCC_PROPERTIES_INSTANCES_COLUMNS,
                             csv_file_path=properties_instances_fp,
                             has_audit=False,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)


@log_entry
@staticmethod
def insert_emcc_output_csv_to_tables(extracts_dir: Path, **kwargs):
    """
    Inserts EMCC Output sizing CSV data into Oracle tables.

    Parameters
    ----------
    extracts_dir : Path
        The directory containing the AWR CSV files. (or EMCC)
    connection : oracledb.Connection
        The Oracle database connection.
    **kwargs
        Additional keyword arguments to pass to the CSVHandler.

    Raises
    ------
    FileNotFoundError
        If the specified CSV files are not found in the extracts directory.

    Returns
    -------
    None
    """

    outout_database_fp = extracts_dir / fp.EMCC_OUTPUT_DATABASE
    output_instance_fp = extracts_dir / fp.EMCC_OUTPUT_INSTANCE
    output_server_fp = extracts_dir / fp.EMCC_OUTPUT_SERVER
    connection = DatabaseManager().connection

    csv_handler = CSVHandler(table_name=EXTRACTS_EMCC_OUTPUT_INSTANCE,
                             columns=EXTRACTS_EMCC_OUTPUT_INSTANCE_COLUMNS,
                             csv_file_path=output_instance_fp,
                             has_audit=False,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)

    csv_handler.setup_config(table_name=EXTRACTS_EMCC_OUTPUT_DATABASE,
                             columns=EXTRACTS_EMCC_OUTPUT_DATABASE_COLUMNS,
                             csv_file_path=outout_database_fp,
                             has_audit=False,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)

    csv_handler.setup_config(table_name=EXTRACTS_EMCC_OUTPUT_SERVER,
                             columns=EXTRACTS_EMCC_OUTPUT_SERVER_COLUMNS,
                             csv_file_path=output_server_fp,
                             has_audit=False,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)


@log_entry
def delete_output_tables_by_upload_id(db_manager: DatabaseManager, upload_id):
    db_manager.execute_delete(EXTRACTS_EMCC_OUTPUT_DATABASE, "UPLOAD_ID", "UPLOAD_ID", upload_id)
    db_manager.execute_delete(EXTRACTS_EMCC_OUTPUT_INSTANCE, "UPLOAD_ID", "UPLOAD_ID", upload_id)
    db_manager.execute_delete(EXTRACTS_EMCC_OUTPUT_SERVER, "UPLOAD_ID", "UPLOAD_ID", upload_id)


class ColumnsNotMatched(Exception):
    pass
