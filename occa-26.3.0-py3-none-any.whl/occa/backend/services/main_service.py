import mimetypes

from backend.api_utils.status import *
import mimetypes
from pathlib import Path

import oracledb
import shutil
import logging
import os


from backend.run import log_entry
from backend.api_utils import automation
from backend.api_utils.custom_response import CustomResponse
from backend.api_utils.database import DatabaseManager
from backend.api_utils.plot_handler import *
from cohort_folder_mapper import is_valid_folder_structure
from constants.Paths import FilePaths as fp
from file_manager.CSVHandler import CSVHandler
from file_manager.FileSystemHandler import DirectoryHandler
from version import version, __version__


logger = logging.getLogger(__name__)


def log_step(upload_id, step, detail=None):
    message = f"UPLOAD {upload_id} :: {step}"
    if detail:
        message += f" -> {detail}"
    logger.info(message)


def download_extract(upload_id, db_manager: DatabaseManager = None, delete_files=True):
    """
    Downloads a file from the database, saves it to disk, extracts it, prepares the data (get the json to update),
    and adds it to the upload file table.

    Parameters
    ----------
        upload_id : The upload_id of the file to download.

    Returns
    -------
        JSON Response
    """

    root_dir = Path(__file__).parent.parent  # Backend directory
    output_directory = root_dir / c.ARCHIVES_DOWNLOADED  # archives download directory

    try:
        connection = db_manager.connection
        log_step(upload_id, "download_extract", "Fetching archive metadata")
        row = db_manager.get_archive_extract_by_id(upload_id)

        if not row:
            error_message = f"Error : No file found with the provided ID {upload_id}."
            db_manager.update_status(upload_id, INITIAL_PROCESS_ERROR, error_message)
            return CustomResponse.not_found({"message":error_message})

        filename = row[0]
        file_blob = lob_to_bytes(row[1])
        file_mimetype = row[2]
        customer = row[3]
        file_charset = row[4]
        file_comments = row[5]
        opportunity_name = row[6]
        created_by = row[7]

        # could be used in the future gets 'zip', 'rar'
        file_extension = mimetypes.guess_extension(file_mimetype)

        customer_directory = output_directory / created_by / upload_id
        extracts_dir = DirectoryHandler.get_extracts_dir(customer_directory,
                                                         filename)  # the directory of the compressed file (name.zip -> name:dir )

        log_step(upload_id, "prepare_directories", "Ensuring local structure")
        DirectoryHandler.make_directories(extracts_dir)
        output_filename = extracts_dir / filename

        log_step(upload_id, "write_archive", filename)
        DirectoryHandler.write_binary(output_filename, file_blob)

        DirectoryHandler.extract_file(extracts_dir, output_filename)
        log_step(upload_id, "extract_archive", "Archive extracted")
        validate_extracted_files(extracts_dir,upload_id,db_manager)
        log_step(upload_id, "validate_extracts", "Extraction validated")
        awr_emcc_dir_files = organize_files(extracts_dir)
        log_step(upload_id, "organize_files", f"Detected {awr_emcc_dir_files.name}")
        is_awr = awr_emcc_dir_files.name == c.AWR_MINER_OUT
        is_em = awr_emcc_dir_files.name == c.EMCC_SIZING_EXTRACTS

        if awr_emcc_dir_files.name not in [c.AWR_MINER_OUT,c.EMCC_SIZING_EXTRACTS]:
            raise ModuleNotFoundError(f"Something went wrong, not AWR nor EMCC directories created  [{upload_id}]")

        status_mapping ={
            c.AWR_MINER_OUT:AWR_INITIAL_PHASE_STARTED,
            c.EMCC_SIZING_EXTRACTS:EMCC_INITIAL_PHASE_COMPLETED
        }
        log_step(upload_id, "initial_status_update", status_mapping[awr_emcc_dir_files.name])
        db_manager.update_status(upload_id, status_mapping[awr_emcc_dir_files.name])

        data = {
            "customer_name":customer,
            "file_charset":file_charset,
            "file_comments":file_comments,
            "opportunity_name":opportunity_name,
            "created_by":created_by
        }

        log_step(upload_id, "prepare_db_inserts", "Configuring foreign keys")
        data_csv_insert = {
            'FOREIGN_KEYS':{
                'UPLOAD_ID': upload_id
            },
            'CREATED_BY':created_by
        }

        log_step(upload_id, "initial_process", f"Preparing {awr_emcc_dir_files.name}")
        run_and_insert_initial_process(awr_emcc_dir_files, connection, **data_csv_insert)
        # for workers in [2, 4, 8, 12, 16, 24]:
        #     benchmark_process_and_insert_plots(upload_id, data, extracts_dir, workers)
        response = {'upload_id':upload_id}
        if is_awr :
            inserting_plots_for_awr(db_manager, upload_id, awr_emcc_dir_files, data)
            response = {'message':f"Properties & TZ csv files created & inserted to tables."}
        if is_em:
            log_step(upload_id, "emcc_properties", "Processing EMCC properties/instances")
            response = {'message':f"Properties database and properties instances inserted to tables."}

        status_mapping = {
            c.AWR_MINER_OUT:AWR_INITIAL_PHASE_COMPLETED,
            c.EMCC_SIZING_EXTRACTS:EMCC_INITIAL_PHASE_COMPLETED
        }
        db_manager.update_status(upload_id, status_mapping[awr_emcc_dir_files.name])
        log_step(upload_id, "download_extract", "Completed initial processing")
        return CustomResponse.created(response)

    except Exception as e:
        db_manager.connection.rollback()
        error_message = f"An error occurred: {str(e)[:3800]} "
        logger.exception("UPLOAD %s :: failure -> %s", upload_id, error_message)
        db_manager.update_status(upload_id, INITIAL_PROCESS_ERROR, error_message)
        return CustomResponse.server_error({"message":error_message})


def inserting_plots_for_awr(db_manager: DatabaseManager, upload_id: int, awr_emcc_dir_files: Path, data: dict) -> None:

    if awr_emcc_dir_files.name == c.AWR_MINER_OUT:
        if not db_manager.plots_exist(upload_id):
            try:
                process_and_insert_plots(upload_id, data, awr_emcc_dir_files.parent)
            except Exception as e:
                raise Exception("Error : Inserting plogs main_service failed with : " + str(e))
        else:
            print(f"Plots for UPLOAD_ID {upload_id} already exist. Skipping plot insertion.".center(c.CENTER_N, '-'))



# To determine the number of workers which fits better.
# def benchmark_process_and_insert_plots(upload_id, data, extracts_dir, num_workers):
#     start = time.time()
#     plots_file_path = extracts_dir / 'plots.json'
#     plots_per_db_copy = DirectoryHandler.read_json(plots_file_path)
#     db_plots = []
#
#     # O(N) : numbers of dbs
#     for db in plots_per_db_copy:
#         plots_data = format_data_plots(upload_id, db, data)
#         # O(22) 22 is the max number of plots that a DB can have
#         for plot in plots_per_db_copy[db]:
#             plot_data_copy = plots_data.copy()
#             plot_data_copy['FILE_BLOB'] = go.Figure(json.loads(plot['fig']))  # plot
#             db_plots.append(plot_data_copy)
#
#     with ProcessPoolExecutor(max_workers=num_workers) as executor:
#         list(executor.map(insert_plots, process_plots_result))
#
#     end = time.time()
#     print(f"Time with {num_workers} workers: {end - start} seconds")


@log_entry
def run_and_insert_initial_process(extracts_dir, connection, **kwargs) -> Path:
    """
    Runs initial process for AWR and EMCC extracts.
    if it's AWR will run the parse & plots to generate the tz and properties file so the user can edit them.


    Parameters
    ----------
    data_extracted_dir : Path
        The folder within the extracts folder containing .out for AWR, .csv and .txt for the EMCC
    connection : oracledb.Connection
    kwargs : dict
        aditional information to csv tables.


    """
    if extracts_dir.name == c.AWR_MINER_OUT:
        automation.run_parse(extracts_dir.parent)
        automation.run_plot(extracts_dir.parent)
        insert_snap_analysis_to_table(extracts_dir.parent,connection,**kwargs)
        insert_awr_csv_to_tables(extracts_dir.parent, connection, **kwargs)
        insert_plots_as_zip(extracts_dir.parent, connection, 'AWR', **kwargs)
    elif extracts_dir.name == c.EMCC_SIZING_EXTRACTS:
        automation.emcc_run_create_properties(extracts_dir.parent)
        automation.emcc_run_copy_db_name(extracts_dir.parent) #
        insert_emcc_csv_to_tables(extracts_dir.parent, connection, **kwargs)
        insert_emcc_metadata_databases(extracts_dir.parent,connection,**kwargs)
    else:
        raise ModuleNotFoundError("AWR/EMCC Directory not found")



@log_entry
def insert_snap_analysis_to_table(extracts_dir: Path, connection: oracledb.Connection, **kwargs):
    """
    Inserts AWR CSV data into Oracle tables.

    Parameters
    ----------
    extracts_dir : Path
        The directory containing the AWR CSV files. (or EMCC)
    connection : oracledb.Connection
        The Oracle database connection.
    **kwargs
        Additional keyword arguments to pass to the CSVHandler.

    Raises
    ------
    FileNotFoundError
        If the specified CSV files are not found in the extracts directory.

    Returns
    -------
    None
    """
    analysis_csv = extracts_dir / fp.AWR_ANALYSIS_SNAPS_DATA

    csv_handler = CSVHandler(table_name=EXTRACTS_ANALYSIS_SNAP_RANGE_DATA,
                             columns=EXTRACTS_ANALYSIS_SNAP_RANGE_DATA_COLUMNS,
                             csv_file_path=analysis_csv,
                             has_audit=False,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)


@log_entry
def insert_awr_csv_to_tables(extracts_dir: Path, connection: oracledb.Connection, **kwargs):
    """
    Inserts AWR CSV data into Oracle tables.

    Parameters
    ----------
    extracts_dir : Path
        The directory containing the AWR CSV files. (or EMCC)
    connection : oracledb.Connection
        The Oracle database connection.
    **kwargs
        Additional keyword arguments to pass to the CSVHandler.

    Raises
    ------
    FileNotFoundError
        If the specified CSV files are not found in the extracts directory.

    Returns
    -------
    None
    """
    properties_fp = extracts_dir / fp.AWR_PROPERTIES
    timezone_fp = extracts_dir / fp.AWR_TZ

    csv_handler = CSVHandler(table_name=EXTRACTS_PROPERTIES_DATABASE,
                             columns=EXTRACTS_PROPERTIES_DATABASE_COLUMNS,
                             csv_file_path=properties_fp,
                             has_audit=True,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)

    csv_handler.setup_config(table_name=EXTRACTS_DATABASE_TZ_INFO,
                             columns=EXTRACTS_DATABASE_TZ_INFO_COLUMNS,
                             csv_file_path=timezone_fp,
                             has_audit=True,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)


@log_entry
def insert_emcc_csv_to_tables(extracts_dir: Path, connection: oracledb.Connection, **kwargs):
    """
    Inserts EMCC CSV data into Oracle tables.

    Parameters
    ----------
    extracts_dir : Path
        The directory containing the AWR CSV files. (or EMCC)
    connection : oracledb.Connection
        The Oracle database connection.
    **kwargs
        Additional keyword arguments to pass to the CSVHandler.

    Raises
    ------
    FileNotFoundError
        If the specified CSV files are not found in the extracts directory.

    Returns
    -------
    None
    """
    properties_fp = extracts_dir / fp.EMCC_PROPERTIES_DB
    properties_instances = extracts_dir / fp.EMCC_PROPERTIES_INSTANCE

    csv_handler = CSVHandler(table_name=EXTRACTS_EMCC_PROPERTIES_DATABASE,
                             columns=EXTRACTS_EMCC_PROPERTIES_DATABASE_COLUMNS,
                             csv_file_path=properties_fp,
                             has_audit=True,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)

    csv_handler.setup_config(table_name=EXTRACTS_EMCC_PROPERTIES_INSTANCES,
                             columns=EXTRACTS_EMCC_PROPERTIES_INSTANCES_COLUMNS,
                             csv_file_path=properties_instances,
                             has_audit=True,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)
@log_entry
def insert_emcc_metadata_databases(extracts_dir: Path, connection: oracledb.Connection, **kwargs):
    """
    Inserts EMCC Properties database only getting the Database Name.

    Parameters
    ----------
    extracts_dir : Path
        The directory containing the AWR CSV files. (or EMCC)
    connection : oracledb.Connection
        The Oracle database connection.
    **kwargs
        Additional keyword arguments to pass to the CSVHandler.

    Raises
    ------
    FileNotFoundError
        If the specified CSV files are not found in the extracts directory.

    Returns
    -------
    None
    """
    properties_fp = extracts_dir / fp.EMCC_PROPERTIES_DB

    #Only one column needed,
    csv_handler = CSVHandler(table_name=EXTRACTS_EMCC_PROPERTIES_DATABASE_METADATA,
                             columns=EXTRACTS_EMCC_PROPERTIES_DATABASE_METADATA_COLUMNS,
                             csv_file_path=properties_fp,
                             has_audit=False,
                             **kwargs)
    csv_handler.load_csv_to_oracle(connection)


@log_entry
def validate_extracted_files(extracts_dir: Path, upload_id: int,db_manager: DatabaseManager):
    """
    Validates extracted files in a directory after decompression.

    - Detects if the content is AWR (expects .out files only) or EMCC (.csv/.txt only).
    - If unexpected files are found, removes file_blob from DB and raises error.
    - Also updates the 'TYPE' column to 'DB Miner', 'EM Miner', or 'Unknown' so I dont
    - have to handle it on the FE - Apex

    Parameters:
        extracts_dir (Path): Path to the directory where files were extracted.
        upload_id (int): Upload ID from the database.
        db_manager(DatabaseManager) : Object to handle connections
    """
    allowed_exts = set()
    unexpected_files = []
    inferred_type = 'Unknown'

    file_paths = []
    for root, _, files in os.walk(extracts_dir):

        #Ignoring apple metadata
        if "__MACOSX" in root:
            continue

        for f in files:
            if f == ".DS_Store" or f.startswith("._"):
                continue
            file_paths.append(os.path.join(root, f))

    if not file_paths:
        raise Exception("File is empty: no files found after extraction.")

    contains_out = any(f.lower().endswith('.out') for f in file_paths)
    contains_csv = any(f.lower().endswith('.csv') for f in file_paths)
    contains_txt = any(f.lower().endswith('.txt') for f in file_paths)

    if contains_out:
        #some commands create .txt,json and csv objects
        allowed_exts = {'.out','.json','.csv', '.txt','.log','.html'} #for awr

        inferred_type = 'DB Miner'
    elif contains_csv or contains_txt:
        allowed_exts = {'.csv', '.txt','.log','.html'} #for em
        inferred_type = 'EM Miner'

    for f in file_paths:
        ext = os.path.splitext(f)[1].lower()
        if ext not in allowed_exts:
            relative_path = os.path.relpath(f, extracts_dir)
            unexpected_files.append(relative_path)

    params = {"type": inferred_type, "id": upload_id}
    if unexpected_files:
        html_error = "Invalid extracts<br>Unexpected files or folders found:<ul>"
        for fname in unexpected_files:
            html_error += f"<li>{fname}</li>"
        html_error += "</ul>Please upload a correct file."

        try:
            DELETE_UPLOAD_ARCHIVE_FILE_BLOB = DatabaseManager.format_generic_update_query(
                table_name=UPLOAD_ARCHIVE_EXTRACT,
                columns_to_update=['file_blob', 'type'],
                key_columns=['id']
            )
            params['file_blob'] = None
            params['type'] = 'Invalid'

            db_manager.connection.cursor().execute(
                DELETE_UPLOAD_ARCHIVE_FILE_BLOB,
                params
            )
            db_manager.connection.commit()
        except Exception as db_exc:
            print(f"DB update failed for upload_id={upload_id}: {db_exc}")
            db_manager.connection.rollback()

        raise Exception(html_error)

    # No unexpected files -> just update the type
    UPDATE_UPLOAD_ARCHIVE_TYPE = DatabaseManager.format_generic_update_query(
        table_name=UPLOAD_ARCHIVE_EXTRACT,
        columns_to_update=['type' ],
        key_columns=['id']
    )

    db_manager.connection.cursor().execute(
        UPDATE_UPLOAD_ARCHIVE_TYPE,
        params
    )
    db_manager.connection.commit()






@log_entry
def organize_files(directory: Path) -> Path:
    """
    Organizes .out files into the awr_miner_out folder if they are not properly structured.
    If they are already in a valid folder structure, nothing is done.

    Algo organizes .txt and .csv files for EM data they would be in emcc_sizing_extracts



    i.e
    Organize the .out files into the desired path following the cohort structure.
    The desired structure should look like:
    users_zip.zip -> (unzipped creates)
    users_zip/
    └── awr_miner_out/
        └── <extracts>.out  <- this is the desired path.

    However, we might encounter cases like:
    users_zip/
    └── <extracts>.out  <- this needs to be moved to the awr_miner_out folder.

    Or:
    users_zip/
    └── <some_more_random_folders>/
        └── awr_miner_out/
            └── <extracts>.out

    In this case, we need to remove the extra random folders and reorganize to the correct structure.

    Cohort-Folder structure should only work with 2+ folders.

    Parameters
    ----------
    directory : Path
        Directory containing the .out files

    Returns
    -------
    Path
        Path to the awr_miner_out folder where the files were moved.

    """

    # this can be the directory it self or the need to create a dir within the directory
    # awr_miner_out or emcc_sizing_extracts
    archive_path = directory_to_create(directory)


    is_awr = False
    if archive_path.name == fp.awr_miner_out.name :
        is_awr = True


    if is_awr:
        #This is for cohort wizard - awr
        is_valid, awr_miner_out_container = is_valid_folder_structure(directory)

        # desired extructure exists no need to move nothing
        # if awr_miner_out_container means that the user
        if is_valid and awr_miner_out_container:
            print("Folder structure is valid. No need to move files just re-route the awr_miner_out path")
            return awr_miner_out_container

        # the user zip correctly the .out
        if archive_path.exists() and len(os.listdir(archive_path)) > 0:
            print('The user is a good person -> Good Structure')
            return archive_path

    DirectoryHandler.make_directories(archive_path)

    # Traverse the directory and move .out files to awr_miner_out
    # and .csv and .txt files to emcc_sizing_extracts
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.out') or file.endswith('.csv') or file.endswith('.txt'):
                file_path = Path(root) / file
                # If file is already there next iter
                if (archive_path / file).exists():
                    continue
                shutil.move(str(file_path), str(archive_path))

    DirectoryHandler.prune_empty_dirs(directory)
    print(f"Files moved files moved to: {archive_path}")
    return archive_path


@log_entry
def directory_to_create(directory: Path) -> Path:
    """
    Determines the directory to be created based on input directory type.

    Parameters
    ----------
    directory : Path
        Directory to check for existence and type.

    Returns
    -------
    Path
        Path to the directory to be created.

    Raises
    ------
    FileNotFoundError
        If neither AWR nor EMCC Directory can be created due to absence of source files.
    """

    awr_path = directory / c.AWR_MINER_OUT
    emcc_path = directory / c.EMCC_SIZING_EXTRACTS

    # if the extracted data it's in right format don't need to verify
    if awr_path.exists() and any(file.endswith('.out') for file in os.listdir(awr_path)):
        return awr_path

    if emcc_path.exists() and any(file.endswith('.csv') or file.endswith('.txt') for file in os.listdir(emcc_path)):
        return emcc_path

    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.out'):
                return awr_path
            elif file.endswith('.csv') or file.endswith('.txt'):
                return emcc_path

    raise FileNotFoundError("AWR nor EMCC Directory can't be created, no source files.")


def lob_to_bytes(data):
    """
    Converts a LOB object to bytes if necessary.

    Parameters
    ----------
    data : any
        The data to be checked and possibly converted.

    Returns
    -------
    bytes
        The binary data as bytes.
    """
    if isinstance(data, oracledb.LOB):
        return data.read()
    return data
