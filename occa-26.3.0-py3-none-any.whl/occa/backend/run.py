import signal

import uvicorn
import socket
import os
import logging

from version import version, __version__

def log_entry(func):
    def wrapper(*args, **kwargs):
        func_logger = logging.getLogger(func.__module__)
        func_logger.info(f" calling -> {func.__name__}()")
        return func(*args, **kwargs)
    return wrapper

def child_handler(signum, frame):
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
            if pid == 0:
                break
            print(f"Child {pid} terminated with status {status}")
        except ChildProcessError:
            break

def get_ip_address():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("1.1.1.1", 80))
        ip_address = s.getsockname()[0]
    except Exception:
        ip_address = "127.0.0.1"
    finally:
        s.close()
    return ip_address

def show_paths(app):
    print("Current Paths:")
    for route in app.routes:
        print(f"{route.path} - {route.name}")

def calculate_workers():
    cpus = os.cpu_count() or 1
    if cpus <= 3:
        return cpus

    return min(os.cpu_count()//2, 4)

signal.signal(signal.SIGCHLD, child_handler)
if __name__ == "__main__":
    print('Env: ',os.environ.get('ENVIRONMENT'))
    reload = os.environ.get('ENVIRONMENT') == 'DEV'
    if reload:
        print("Development mode enabled with reload.")
        # To know the IP and hit it (development only)
        from app import app as app_instance
        show_paths(app_instance)
        reload=True
        # To know the IP and hit it (development only)
        ip_address = get_ip_address()
        print(f"Server running on http://{ip_address}:5000 and http://0.0.0.0:5000")
        uvicorn.run("app:app", host='0.0.0.0', port=5000, timeout_keep_alive=180, reload=True)
    else:
        workers=calculate_workers()
        print('Workers',workers)

        uvicorn.run("app:app",host='0.0.0.0', port=5000,timeout_keep_alive=180,workers=workers)
