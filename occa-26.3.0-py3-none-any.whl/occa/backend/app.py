import logging
import os
from logging.handlers import RotatingFileHandler

from backend import create_app

log_path = os.path.join(os.path.dirname(__file__), "ez_miner.log")
app = create_app()


def setup_logger():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # configuring Rotating file -> messages to archive ez_miner.log
    if not any(isinstance(h, RotatingFileHandler) and getattr(h, "baseFilename", "") == log_path
               for h in logger.handlers):
        file_handler = RotatingFileHandler(log_path, maxBytes=1024 * 1024 * 15, encoding="utf-8")
        file_handler.setLevel(logging.INFO)
        logger.addHandler(file_handler)

    # Console configuration to see messages on console
    if not any(isinstance(h, logging.StreamHandler) and not hasattr(h, "baseFilename") for h in logger.handlers):
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.INFO)
        logger.addHandler(stream_handler)

    logger.info("Logger initialized")


@app.on_event('startup')
def configure_logger():
    setup_logger()
