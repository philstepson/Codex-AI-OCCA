import datetime
import os
import platform
import sys
import time

import pandas as pd

from occa_Shared import *
from version import version, __version__

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
# Values for these parameters will be read from the parameter file
#

FIXED = False
PRECISION = 3

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"

sizingFilePath = outputFilePath + os.sep + "sizing"

os.makedirs(sizingFilePath, exist_ok=True)

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
open_log(logFilename)

if FIXED:
    cwd = "fixed"
    now = "1989-07-09 00:00:00"
    platformName = "fixed"
    __version__ = "fixed"
else:
    cwd = os.getcwd().split(os.sep)[-1]
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    platformName = platform.system()

# ----------------------------------------------------------------------------------------------------------------------


def main():
    lg(
        "\n\n=======================================================================================================\n"
    )
    lg("sys.version_info  : " + str(sys.version_info))
    lg("platform.system() : " + str(platform.system()))

    lg("pandas.__version__: " + pd.__version__)

    lg(
        "\n=======================================================================================================\n"
    )

    # ----------------------------------------------------------------------------------------------------------------------
    print("\nReading parameters from file " + PARAM_FILE)

    lg(
        "\n=======================================================================================================\n"
    )

    lg("FIXED    : " + str(FIXED))
    lg("PRECISION: " + str(PRECISION))

    lg(
        "\n=======================================================================================================\n"
    )

    availabilityFilename = extractFilePath + os.sep + "emcc_sizing_availability_history"

    if not os.path.exists(availabilityFilename + ".csv"):
        lg("File " + availabilityFilename + ".csv is missing; cannot continue.")

        quit()

    startTime = time.time()
    lg(
        "Processing emcc_sizing extract files in directory "
        + extractFilePath
        + " in working directory "
        + os.getcwd()
    )

    try:
        df = pd.read_csv(
            availabilityFilename + ".csv",
            parse_dates=["START_TIMESTAMP_UTC", "END_TIMESTAMP_UTC"],
        )
    except:
        df = pd.read_csv(
            availabilityFilename + ".csv",
            parse_dates=["START_TIMESTAMP_UTC", "END_TIMESTAMP_UTC"],
            encoding="ISO-8859-1",
        )

    df.columns = [c.strip() for c in df.columns]

    df["current_flag"] = 0
    df.loc[df["END_TIMESTAMP_UTC"].isnull(), "current_flag"] = 1
    df["END_TIMESTAMP_UTC"].fillna(
        datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        inplace=True,
    )
    df["days_in_status"] = round(
        (df["END_TIMESTAMP_UTC"] - df["START_TIMESTAMP_UTC"]) / pd.Timedelta(days=1),
        PRECISION,
    )

    # ---

    pDf = df[df["current_flag"] == 1][
        [
            "TARGET_TYPE",
            "AVAILABILITY_STATUS",
            "TARGET_NAME",
            "OWNER",
            "START_TIMESTAMP_UTC",
            "days_in_status",
        ]
    ]

    pDf["cwd"] = cwd
    pDf["platform"] = platformName
    pDf["create_dttm_utc"] = now
    pDf["version"] = __version__

    filename = sizingFilePath + os.sep + "current_status_by_target.csv"
    pDf.sort_values(["TARGET_TYPE", "AVAILABILITY_STATUS", "TARGET_NAME"]).to_csv(
        filename, index=False
    )
    lg("\nWrote " + str(len(pDf)) + " rows to " + filename)

    # ---

    pDf = pd.pivot_table(
        df[df["current_flag"] == 1],
        index=["TARGET_TYPE"],
        columns=["AVAILABILITY_STATUS"],
        values=["TARGET_NAME"],
        aggfunc="count",
        fill_value=0,
    ).reset_index()

    pDf.columns = [c[0] if c[1] == "" else c[1] for c in pDf.columns]

    pDf["cwd"] = cwd
    pDf["platform"] = platformName
    pDf["create_dttm_utc"] = now
    pDf["version"] = __version__

    filename = sizingFilePath + os.sep + "current_status_by_target_type.csv"
    pDf.sort_values(["TARGET_TYPE"]).to_csv(filename, index=False)
    lg("\nWrote " + str(len(pDf)) + " rows to " + filename)

    # ---

    pDf = pd.pivot_table(
        df,
        index=["TARGET_TYPE", "TARGET_NAME", "OWNER", "TARGET_GUID"],
        columns=["AVAILABILITY_STATUS"],
        values=["days_in_status"],
        aggfunc="sum",
        fill_value=0,
    ).reset_index()

    pDf.columns = [c[0] if c[1] == "" else c[1] for c in pDf.columns]

    pDf["cwd"] = cwd
    pDf["platform"] = platformName
    pDf["create_dttm_utc"] = now
    pDf["version"] = __version__

    filename = sizingFilePath + os.sep + "status_days_by_target.csv"
    pDf.sort_values(["TARGET_TYPE", "TARGET_NAME"]).to_csv(filename, index=False)
    lg("\nWrote " + str(len(pDf)) + " rows to " + filename)

    # ----------------------------------------------------------------------------------------------------------------------

    lg(
        "\n\nAll files written to directories rooted @ "
        + (cwd if ROOT_DIR == "." else ROOT_DIR)
    )
    lg(
        "\nThe processing of "
        + str(len(df))
        + " rows completed in "
        + str(round(time.time() - startTime, 3))
        + " s"
    )

    lg(
        "\nEnd @ "
        + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        + " UTC\n"
    )

    close_Log()


if __name__ == "__main__":
    main()
