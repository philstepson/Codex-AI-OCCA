"""
Todo:
    error handling for missing attributes
    override logic
"""

import argparse
import datetime
import json
import os
import os
import zipfile
import pandas as pd
import platform
import plotly as plt
import plotly.express as px
import plotly.graph_objs as go
import pytz
import shutil
import sys
import time


from occa_Shared import *
from pathlib import Path
from constants.Paths import FilePaths as fp
from version import version, __version__

FACET_COLS = 2
SMALL_COHORTS = 20
HEIGHT = 1185
WIDTH = 1920
PERCENTILES = [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 0.99]

PLOT_INSTANCE_COUNT_LIMIT = 500

PLOT_HTML = False
PLOT_PNG = False

PLOT_PERCENTILES = True

PLOT_SUM_OF_MAX = False

PLOT_INDIVIDUAL_DB = False
PLOT_INDIVIDUAL_DB_LIMIT = 20

PLOT_SUPPRESSED_COHORTS = []

PRECISION = 3

SOURCE = "AWR_miner"
SNAP_DUR_M_MAX = 65

MAX_COHORTS_PER_PLOT = 25

ROLLUP_CSV_FILES_SUPRESSED_COHORTS = []

OVERLAP_DAYS_WITHIN_A_COHORT = 7

CHECK_DATABASES_OVERLAP_WITHIN_A_COHORT = True
TRIMMED_GRAPH = True # Putting the default value to avoid error-inspection from Pycharm
# ----------------------------------------------------------------------------------------------------------------------

plots_per_cohort = {}

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# print('\nReading parameters from file ' + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())


# ----------------------------------------------------------------------------------------------------------------------


def convertToUTC(row):
    tz = pytz.timezone(row["TZ"])
    dtTZ = tz.localize(row["end_hh24"])
    dtUTC = dtTZ.astimezone(pytz.utc)

    return dtUTC.replace(tzinfo=None)


# ----------------------------------------------------------------------------------------------------------------------


def format_title(title, subtitle=None, subtitle_font_size=14):
    title = f"<b>{title}</b>"

    if not subtitle:
        return title

    subtitle = f'<span style="font-size: {subtitle_font_size}px;">{subtitle}</span>'

    return f"{title}<br>{subtitle}"


# ----------------------------------------------------------------------------------------------------------------------


def obtain_total_hours(timedelta):
    """
    Changes a Numpy Timedelta object to hours (time is rounded to the next hour)
    Args:
        timedelta (pandas.Timedelta): Pandas Timedelta object

    Returns:
        float: Time in hours

    """
    return timedelta.total_seconds() / 3600


# ----------------------------------------------------------------------------------------------------------------------


def date_overlaps_and_overlaps_days_within_cohort(start1, end1, start2, end2):
    """
    Check if two date ranges overlap and if the overlap is greater than or equal to the required number of days.

    Parameters
    ----------
    start1 : datetime
        Start date of the first range.
    end1 : datetime
        End date of the first range.
    start2 : datetime
        Start date of the second range.
    end2 : datetime
        End date of the second range.

    Returns
    -------
    (bool , int , int)
        True if the date ranges overlap and the overlap is greater than or equal to the required number of days, False otherwise.
        the second element is the number of days
        and the third one the number of hours
        if  -1 -1 is returned as second and third arguments it means there's no overlap at all
    """
    overlap_start = max(start1, start2)
    overlap_end = min(end1, end2)

    # Check if there is an overlap
    if overlap_start < overlap_end:
        overlap_duration = overlap_end - overlap_start
        overlap_days = overlap_duration.days
        overlap_hours = overlap_duration.seconds // 3600
        if overlap_days >= OVERLAP_DAYS_WITHIN_A_COHORT:
            return (
                True,
                0,
                0,
            )  # -1 == overlaps good, no need to do something with days or hours

        # It overlaps but no sufficient time
        return False, overlap_days, overlap_hours

    # Does not overlap at all
    return False, -1, -1


def check_overlaps_within_group(group):
    """
    Check for overlaps within a cohort group and return the details of non-overlapping databases.

    Parameters
    ----------
    group : pd.DataFrame
        A DataFrame containing the cohort group data with columns 'Cohort', 'cdb', 'min', and 'max'.

    Returns
    -------
    List[Tuple]
        A list of tuples containing the cohort, database names, and their indices for non-overlapping databases.
    """

    n = len(group)
    overlaps = []
    cohort = group["Cohort"].iloc[0]
    for i in range(n):
        for j in range(i + 1, n):
            start1, end1 = group.iloc[i]["min"], group.iloc[i]["max"]
            start2, end2 = group.iloc[j]["min"], group.iloc[j]["max"]
            overlap, days_apart, hours_apart = (
                date_overlaps_and_overlaps_days_within_cohort(
                    start1, end1, start2, end2
                )
            )
            if not overlap:
                overlaps.append(
                    (
                        cohort,
                        group.iloc[i]["cdb"],
                        group.iloc[j]["cdb"],
                        (group.index[i], group.index[j]),
                        days_apart,
                        hours_apart,
                    )
                )
            # if not date_overlaps_and_overlaps_days_within_cohort(start1, end1, start2, end2):
            #     overlaps.append((cohort, group.iloc[i]['cdb'], group.iloc[j]['cdb'], (group.index[i], group.index[j])))
    return overlaps


def has_needed_data_days(df, min_days=7):
    """
    Validate that all rows in the DataFrame have a minimum number of days of data.
    The minimum is 8 days history retention, so 7 days overlap gives a bit of wiggle room.
    Overlap is 7 days, but collections should have a minimum of 8 days.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame containing 'min' and 'max' columns with datetime values.
    min_days : int, optional
        The minimum number of days required, by default 7.

    Returns
    -------
    bool
        True if all rows meet the minimum number of days, False otherwise.
    """
    all_meet = True

    # instead of using all, using a iterative way to stop the wrong row. if there's any
    for index, row in df.iterrows():
        coverage_days = (row['max'] - row['min']).days
        if coverage_days < min_days:
            print(f"The following does not match the minimum required days of data:  {min_days} it has only : {coverage_days} days of data")
            print(f"Cohort: {row['Cohort']}  CDB: {row['cdb']}")
            all_meet = False
    return all_meet


def check_all_cohorts(df):
    """
    Check for overlaps across all cohorts in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame containing the cohort data with columns 'Cohort', 'cdb', 'min', and 'max'.

    Returns
    -------
    List[Tuple]
        A list of tuples containing the cohort, database names, and their indices for non-overlapping databases.
    """

    # columns = df.columns.tolist()
    # overlap_results = df.groupby("Cohort", group_keys=False, include_groups=False).apply(check_overlaps_within_group)
    overlap_results = df.groupby("Cohort")[['Cohort','cdb','min','max']].apply(check_overlaps_within_group) #Selecting columns to avoid warning
    overlap_results_list = [item for sublist in overlap_results for item in sublist]
    return overlap_results_list


def plotMetrics(df, snapDf, cohortHoursDf):
    global plotFilePath, startTime
    run_from_api = os.getenv("RUN_FROM_API", "False") == "True"


    lg(
        "\nBeginning metric plots...time since start "
        + str(round(time.time() - startTime, 3))
        + " s"
    )

    # Delete previous copies of unadjusted directory
    plot_path = os.path.join(plotFilePath, "unadjusted")
    if Path.is_dir(Path(plot_path)):
        lg(f"    Deleting existing directory : {plot_path}")
        shutil.rmtree(plot_path, ignore_errors=True)
    else:
        os.makedirs(plot_path, exist_ok=True)

    customer = os.getcwd().split(os.sep)[-1]

    rDf = snapDf.groupby(["Cohort", "cdb"], as_index=False)["DB vCPU"].sum()
    rDf["cdb_idx"] = rDf.groupby(["Cohort"])["DB vCPU"].rank(method="dense")

    rDf = pd.merge(
        left=rDf[["cdb", "cdb_idx"]],
        right=snapDf,
        how="left",
        left_on=["cdb"],
        right_on=["cdb"],
    )
    rDf.sort_values(["Cohort", "cdb_idx", "end_hh24_UTC"], inplace=True)

    allCohorts, cohortIdx = sorted(rDf["Cohort"].unique()), 1
    # lg('\nlen(allCohorts): ' + str(len(allCohorts)))
    # lg('allCohorts       :'  + str(allCohorts))

    while True:
        cohortStart, cohortEnd = (cohortIdx - 1) * MAX_COHORTS_PER_PLOT, min(
            cohortIdx * MAX_COHORTS_PER_PLOT, len(allCohorts)
        )
        # lg('idx: ' + str(cohortIdx) + ', start: ' + str(cohortStart) + ', end: ' + str(cohortEnd))

        if cohortStart >= cohortEnd:
            break

        pDf = rDf[rDf["Cohort"].isin(allCohorts[cohortStart:cohortEnd])]
        # The plot will be create but immediately after, it will check if
        # need to stop (quit)
        need_to_stop = False
        if CHECK_DATABASES_OVERLAP_WITHIN_A_COHORT:

            # Create a DataFrame to store the cohort , cdb, min start time and max end time for each cdb
            df_dates = (
                pDf.groupby(["Cohort", "cdb"], as_index=False)["end_hh24_UTC"]
                .agg(["min", "max"])
                .reset_index()
            )

            graph_detail_log = (
                f"Check {fp.AWR_SNAP_COVERAGE} for detailed graph information."
            )
            if not has_needed_data_days(df_dates,OVERLAP_DAYS_WITHIN_A_COHORT):
                need_to_stop = True
                error_message = (
                    "Snapshots within a cohort must have at least 7 days of data."
                )
                lg(
                    "======================================================================================================================="
                )
                lg("ERROR: " + error_message)
                lg(graph_detail_log)
            elif not_overlaping := check_all_cohorts(df_dates):
                need_to_stop = True
                error_message = "Snapshot dates of databases assigned to a cohort do not match, or are too far apart. "
                lg(
                    "======================================================================================================================="
                )
                lg("ERROR: " + error_message)
                lg(
                    "       Snapshots within a cohort much have at least "
                    + str(OVERLAP_DAYS_WITHIN_A_COHORT)
                    + " of days overlapping date ranges."
                )
                lg("\n The following list of databases are not matching the criteria:")
                for i in not_overlaping:
                    cohort, cdb1, cdb2, indices, days_apart, hours_apart = i

                    # Build the message "by : x days and y hours
                    # only if there's hours
                    if days_apart > 0:
                        time_msg = f"{days_apart} days"
                        if hours_apart > 0:
                            time_msg += f" and {hours_apart} hours"
                    else:
                        time_msg = f"{hours_apart} hours"

                    # -1 means there's no overlap at all
                    # i.e
                    # CB1  Start: November 1 - November10
                    # CDB2 Start : December 1 - December 5
                    # No overlap ^
                    if days_apart == -1 and hours_apart == -1:
                        cdb_no_overlap_msg = f"Cohort: {cohort}, CDB: {cdb1} does not overlap with CDB: {cdb2}"
                    else:
                        cdb_no_overlap_msg = f"Cohort: {cohort}, CDB: {cdb1} overlaps with CDB: {cdb2} but only for : {time_msg}"

                    lg(cdb_no_overlap_msg)
                    error_message += cdb_no_overlap_msg + " ; "
                lg(
                    "\n Re-assign databases to cohorts to continue. See awr_properties_database.csv to determine new cohort arrangement."
                )
                lg(graph_detail_log)

        dbCountsDf = (
            snapDf[snapDf["Cohort"].isin(allCohorts[cohortStart:cohortEnd])][
                ["cdb", "Cohort"]
            ]
            .drop_duplicates()
            .groupby(["Cohort"], as_index=False)["cdb"]
            .count()
        )
        dbCountsDf.sort_values(["Cohort"], inplace=True)

        fig = px.line(
            x=pDf["end_hh24_UTC"],
            y=pDf["cdb_idx"],
            color=pDf["cdb"],
            facet_col=pDf["Cohort"],
            facet_col_wrap=FACET_COLS,
            title=format_title(
                customer
                + " : AWR Snap Coverage for All Cohorts By Database (AWR-Miner-OCCA Version "
                + __version__
                + ")"
            ),
            labels={"x": "Snap End Date (UTC)", "y": "", "facet_col": "Cohort"},
            template="seaborn",
            width=WIDTH,
            height=HEIGHT,
        )

        fig.update_layout(
            font={"size": 16},
            legend_font_size=12,
            width=WIDTH,
            height=HEIGHT,
            margin=dict(t=150),
        )
        fig.update_yaxes(showticklabels=False)
        #
        #       The following logic is needed to re-orient the plot grid to the lower-left cell having coordinates 1, 1
        #
        r, c = 1, 1
        idx_from_top = []

        for p in range(len(dbCountsDf)):
            if c > FACET_COLS:
                c = 1
                r += 1

            idx_from_top.append([r, c])
            c += 1

        # lg('idx_from_top: ' + str(idx_from_top))
        idx_from_bottom = [[r - i[0] + 1, i[1]] for i in idx_from_top]
        # lg('idx_from_bottom: ' + str(idx_from_bottom))

        for ctr, c in enumerate(dbCountsDf["cdb"].tolist()):
            if c <= SMALL_COHORTS:
                fig.update_traces(
                    {"line": {"width": 10}},
                    row=idx_from_bottom[ctr][0],
                    col=idx_from_bottom[ctr][1],
                )

        if PLOT_HTML:
            filePathHTML = plotFilePath
            os.makedirs(filePathHTML, exist_ok=True)

            filenameHTML = (
                filePathHTML
                + os.sep
                + "awr_snap_coverage_all_cohorts"
                + (
                    ""
                    if len(allCohorts) <= MAX_COHORTS_PER_PLOT
                    else "_" + str(cohortIdx).zfill(3)
                )
                + ".html"
            )
            dashboard = open(filenameHTML, "w", encoding="UTF-8")
            HTMLhead = (
                customer
                + " : AWR Snap Coverage (AWR-Miner-OCCA Version "
                + __version__
                + ")"
            )

            dashboard.write(
                "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
            )

            inner_html = (
                fig.to_html(include_plotlyjs=True)
                .split("<body>")[1]
                .split("</body>")[0]
            )
            dashboard.write(inner_html)

            dashboard.write("</body></html>" + "\n")
            dashboard.close()

        if PLOT_PNG:
            filePathPNG = plotFilePath
            os.makedirs(filePathPNG, exist_ok=True)

            filenamePNG = (
                filePathPNG
                + os.sep
                + "awr_snap_coverage_all_cohorts"
                + (
                    ""
                    if len(allCohorts) <= MAX_COHORTS_PER_PLOT
                    else "_" + str(cohortIdx).zfill(3)
                )
                + ".html"
            )
            fig.write_image(filenamePNG)

        cohortIdx += 1

    # Save the fig as json (error when reading plotly from )
    if run_from_api:
        from plotly.io import to_json
        print("Saving snap coverage as json".center(50, '-'))
        with open('awr_snap_coverage_all_cohorts.json', "w") as f:
            f.write(to_json(fig))

    analysis_df = pd.read_csv(fp.AWR_ANALYSIS_SNAPS_DATA)
    properties_df = pd.read_csv(fp.AWR_PROPERTIES, usecols=["WHICH_DB", "Cohort"])
    # now that the analysis df if being build on plot there's no cohort assigned but in this step
    # the user will
    # Cohort exists for properties so we can map the analysis
    analysis_df["Cohort"] = analysis_df["WHICH_DB"].map(
        properties_df.set_index("WHICH_DB")["Cohort"]
    )
    analysis_df.to_csv(fp.AWR_ANALYSIS_SNAPS_DATA, index=False)

    # Some CDBS Does not overlap
    if need_to_stop:
        analysis_df["WHICH_DB"] = analysis_df["WHICH_DB"].str.slice(0, 25) + "..."
        with pd.option_context("display.max_rows", None,
                               "display.max_columns", None,
                               "display.max_colwidth", 30):
            print(analysis_df)
            print(
                f"Check : {fp.AWR_ANALYSIS_SNAPS_DATA} for detailed information about snaps and data."
            )
            print("=" * 119)
        raise_error_when_run_from_api("AWR: ",error_message.strip())
        quit()

    # ---

    # return

    for cohort in sorted(df.cdb_cohort.unique()):
        figs = []
        which_db = analysis_df.loc[analysis_df['Cohort'] == cohort, 'WHICH_DB'].iloc[0]


        if cohort in PLOT_SUPPRESSED_COHORTS:
            lg("     Skipping plot suppressed cohort " + str(cohort) + "...")

            continue

        lg(
            "     Beginning cohort "
            + str(cohort)
            + "...time since start "
            + str(round(time.time() - startTime, 3))
            + " s"
        )

        # Accept only the following characters in cohort nane : a-zA-Z0-9_-
        cohort_name_pattern = re.compile(r"[\w-]+")
        matched_cohort_name = re.fullmatch(cohort_name_pattern, cohort)
        if not matched_cohort_name:
            error_message = (
                "Invalid characters in cohort name. The cohort ["
                + str(cohort)
                + "] does not accomplish with the name convention."
            )
            lg(
                "      ======================================================================================================================="
            )
            lg(f"      ERROR: {error_message}")
            lg(
                "      These are the only characters allowed in a cohort name : a-zA-Z0-9_-"
            )
            lg(
                "      ======================================================================================================================="
            )
            raise_error_when_run_from_api("AWR: ",error_message.strip())
            quit()

        # Stop and throw error if any of the cohorts is named as exclude (the right flag for exclusion is excluded)
        exclude_cohort_name_pattern = re.compile(r"exclude$")
        matched_cohort_name = re.fullmatch(exclude_cohort_name_pattern, cohort)
        if matched_cohort_name:
            error_message = 'Found cohort with name "exclude" . The custom flag to disable database analysis is "excluded" and not "exclude"'
            lg(
                "      ======================================================================================================================="
            )
            lg(f"      ERROR: {error_message}")
            lg(
                "      To silence this error , fix the cohort name in awr_properties_database.csv file and re-run metric analysis command."
            )
            lg(
                "      ======================================================================================================================="
            )
            raise_error_when_run_from_api("AWR: ",error_message.strip())
            quit()

        rDf = (
            snapDf[(snapDf["Cohort"] == cohort)]
            .groupby(["cdb"], as_index=False)["DB vCPU"]
            .sum()
        )

        # The tuple groups the columns together, if DB vCPU has the same value in multiple rows
        rDf["cdb_idx"] = (
            rDf[["DB vCPU", "cdb"]].apply(tuple, axis=1).rank(method="dense")
        )

        rDf = pd.merge(
            left=rDf, right=snapDf, how="left", left_on=["cdb"], right_on=["cdb"]
        )
        rDf.sort_values(
            ["cdb_idx", "end_hh24_UTC"], ascending=[False, True], inplace=True
        )

        fig = px.line(
            x=rDf["end_hh24_UTC"],
            y=rDf["cdb_idx"],
            color=rDf["cdb"],
            title=format_title(
                customer
                + " : "
                + str(cohort)
                + " : AWR Snap Coverage by Database (AWR-Miner-OCCA Version "
                + __version__
                + ")",
                "Database ranking & color assignment is based on aggregate DB vCPU contribution",
                20,
            ),
            labels={"x": "Snap End Date (UTC)", "y": ""},
            template="seaborn",
            width=WIDTH,
            height=HEIGHT,
        )

        fig.update_layout(
            font={"size": 16},
            legend_font_size=12,
            width=WIDTH,
            height=HEIGHT,
            margin=dict(t=150),
        )
        fig.update_yaxes(showticklabels=False)

        if len(rDf[["cdb"]].drop_duplicates()) <= SMALL_COHORTS:
            fig.update_traces({"line": {"width": 10}})

        if PLOT_HTML:
            filePathHTML = (
                plotFilePath
                + os.sep
                + "unadjusted"
                + os.sep
                + str(cohort)
                + os.sep
                + "html"
            )
            os.makedirs(filePathHTML, exist_ok=True)

            filenameHTML = (
                filePathHTML + os.sep + str(cohort) + "_awr_snap_coverage.html"
            )
            dashboard = open(filenameHTML, "w", encoding="UTF-8")
            HTMLhead = (
                customer
                + " : "
                + str(cohort)
                + ", AWR Snap Coverage (AWR-Miner-OCCA Version "
                + __version__
                + ")"
            )

            dashboard.write(
                "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
            )


            inner_html = (
                fig.to_html(include_plotlyjs=True)
                .split("<body>")[1]
                .split("</body>")[0]
            )
            dashboard.write(inner_html)


            dashboard.write("</body></html>" + "\n")
            dashboard.close()

        if PLOT_PNG:
            filePathPNG = (
                plotFilePath
                + os.sep
                + "unadjusted"
                + os.sep
                + str(cohort)
                + os.sep
                + "png"
            )
            os.makedirs(filePathPNG, exist_ok=True)

            filenamePNG = filePathPNG + os.sep + str(cohort) + "_awr_snap_coverage.png"
            fig.write_image(filenamePNG)

        if PLOT_INDIVIDUAL_DB:
            if PLOT_HTML:
                individual_plots_path_html = Path(filePathHTML) / "individual_plots"
                os.makedirs(individual_plots_path_html, exist_ok=True)

            if PLOT_PNG:
                individual_plots_path_png = Path(filePathPNG) / "individual_plots"
                os.makedirs(individual_plots_path_png, exist_ok=True)
            db_per_cohort = rDf["cdb"].unique()
            if len(db_per_cohort) > PLOT_INDIVIDUAL_DB_LIMIT:
                db_per_cohort = rDf["cdb"].unique()[:PLOT_INDIVIDUAL_DB_LIMIT]
            for db in db_per_cohort:
                # Create plot files
                if PLOT_HTML:
                    file_individual_db_html = (
                        Path(individual_plots_path_html)
                        / f"{cohort}_{db}_awr_snap_coverage.html"
                    )
                    plot_dashboard = open(
                        file_individual_db_html, "w", encoding="UTF-8"
                    )
                    html_head = f"{customer}: {db}: AWR Snap Coverage (AWR-Miner-OCCA Version {__version__})"
                    plot_dashboard.write(
                        f"<html><head><title> {html_head} </title></head><body>" + "\n"
                    )

                if PLOT_PNG:
                    file_individual_db_png = (
                        Path(individual_plots_path_png)
                        / f"{cohort}_{db}_awr_snap_coverage.png"
                    )

                graph_title = f"{customer}: {db}: AWR Snap Coverage by Database (AWR-Miner-OCCA Version {__version__})"
                db_df = rDf[rDf["cdb"] == db].copy()
                fig = px.line(
                    x=db_df["end_hh24_UTC"],
                    y=db_df["cdb_idx"],
                    color=db_df["cdb"],
                    title=format_title(graph_title),
                    labels={"x": "Snap End Date (UTC)", "y": ""},
                    template="seaborn",
                    width=WIDTH,
                    height=HEIGHT,
                )

                fig.update_layout(
                    font={"size": 16},
                    legend_font_size=12,
                    width=WIDTH,
                    height=HEIGHT,
                    margin=dict(t=150),
                )
                fig.update_yaxes(showticklabels=False)
                fig.update_traces({"line": {"width": 10}})

                if PLOT_HTML:
                    inner_html = (
                        fig.to_html(include_plotlyjs=True)
                        .split("<body>")[1]
                        .split("</body>")[0]
                    )
                    plot_dashboard.write(inner_html)
                    plot_dashboard.write("</body></html>" + "\n")
                    plot_dashboard.close()

                if PLOT_PNG:
                    fig.write_image(file_individual_db_png)

        # ---

        cdbCount = len(df[df["cdb_cohort"] == cohort]["cdb"].unique())

        if cdbCount > PLOT_INSTANCE_COUNT_LIMIT:
            lg(
                "     "
                + str(cohort)
                + "'s instance count "
                + str(cdbCount)
                + " exceeds limit "
                + str(PLOT_INSTANCE_COUNT_LIMIT)
                + " set by parameter PLOT_INSTANCE_COUNT_LIMIT; plotting top databases only"
            )

        tb = time.time()

        plotCtr = 0
        miner_version_title = "" if run_from_api else f" (AWR-Miner-OCCA Version {__version__}) "

        for metric in sorted(df.metric.unique()):
            # This is the main dataframe - where the plot, percentiles average is
            aDf = df[(df["cdb_cohort"] == cohort) & (df["metric"] == metric)].copy()

            if len(aDf) == 0:
                lg(
                    "          Skipping 0-length cohort: "
                    + str(cohort)
                    + ", metric: "
                    + metric
                )
                continue

            metricTitle = metric
            uom = (
                OCCA_METRIC_COULMN_UOMS[metric]
                if metric in OCCA_METRIC_COULMN_UOMS
                else "Unknown: " + metric
            )
            aDf["metric"] = metricTitle

            lg(
                ("        Beginning plot for metric " + metricTitle.ljust(60))
                + "; time since start "
                + str(round(time.time() - startTime, 3))
                + " s"
            )


            if PLOT_HTML:
                filenameHTML = (
                    filePathHTML
                    + os.sep
                    + str(cohort)
                    + "_"
                    + metricTitle.replace(" ", "_")
                    + "_unadjusted.html"
                )
                dashboard = open(filenameHTML, "w", encoding="UTF-8")
                HTMLhead = (
                    customer
                    + " : "
                    + str(cohort)
                    + ", Hourly Average "
                    + metricTitle
                    + " (AWR-Miner-OCCA Version "
                    + __version__
                    + ")"
                )

                dashboard.write(
                    "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
                )

            if PLOT_PNG:
                filenamePNG = (
                    filePathPNG
                    + os.sep
                    + str(cohort)
                    + "_"
                    + metricTitle.replace(" ", "_")
                    + "_unadjusted.png"
                )
            # The groups by and calculates the average of the whole range per dbs
            # If trimmed or don't we want the percentiles (blue dotted lines)
            # and green bar from the overlap data
            # TrimmedTrue = just trim the graph [still percentiles and avg from overlapped data]
            # TrimmedFalse = don't trim the graph  [still percentiles and avg from overlapped data]
            ranges_per_cdb = aDf.groupby("cdb_target_guid")["ROLLUP_TIMESTAMP_UTC"].agg(["min", "max"])
            overlap_begin = ranges_per_cdb["min"].max()
            overlap_ends = ranges_per_cdb["max"].min()
            filtered_end = aDf["ROLLUP_TIMESTAMP_UTC"] <= overlap_ends
            filtered_start = aDf["ROLLUP_TIMESTAMP_UTC"] >= overlap_begin


            # If the parameters it's set to True will grab data from
            # the min.max(begin data) and max.min (end_date)
            # overlap, and this will be the new main DataFrame.
            trimmed_data = aDf.loc[filtered_end & filtered_start].copy()
            timeAlignedDf_overlap = trimmed_data.groupby(["ROLLUP_TIMESTAMP_UTC"], as_index=False)[
                "AVERAGE"
            ].sum()

            # getting the hours from overlapped data
            # hours comes as entire value in cohortHoursDf
            # we want the hours from overlapped data only
            hrs = (overlap_ends - overlap_begin).total_seconds() / 3600.0
            if TRIMMED_GRAPH:
                aDf = trimmed_data #Trimmed data (graph trimmed)


            timeAlignedDf = aDf.groupby(["ROLLUP_TIMESTAMP_UTC"], as_index=False)[
                "AVERAGE"
            ].sum()

            maxDf = aDf.groupby(["cdb_target_guid"], as_index=False)["AVERAGE"].max()
            peak = round(timeAlignedDf["AVERAGE"].max(), PRECISION)
            sum_of_max = round(maxDf["AVERAGE"].sum(), PRECISION)

            timeAlignedDf["MAX"] = peak
            timeAlignedDf["DIFF"] = peak - timeAlignedDf["AVERAGE"]

            # Dotted blue lines
            statistics = timeAlignedDf_overlap["AVERAGE"].describe(
                percentiles=[0.80, 0.90, 0.95]
            )
            p80 = round(statistics["80%"], PRECISION)
            p90 = round(statistics["90%"], PRECISION)
            p95 = round(statistics["95%"], PRECISION)

            sum_peak_x_hrs = round(timeAlignedDf["MAX"].sum(), PRECISION)
            sum_metric_x_hrs = round(timeAlignedDf_overlap["AVERAGE"].sum(), PRECISION)
            sumOfDiff = round(timeAlignedDf["DIFF"].sum(), PRECISION)

            average = round(sum_metric_x_hrs / hrs, PRECISION)

            aDf["total"] = aDf.groupby(["cdb"])["AVERAGE"].transform("sum")
            aDf["rank"] = aDf["total"].rank(method="dense").astype(str)
            aDf["sort"] = aDf["rank"].str.zfill(5) + "$$$" + aDf["cdb"]

            aDf.rename(columns={"cdb": " cdb_original", "sort": "cdb"}, inplace=True)

            if metric in [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]:
                #
                #               Storage metrics are captured at the daily level
                #
                #               the following is NOT needed for AWR plots -- all metrics have the same hour value
                # hrs             *= hrs
                sum_peak_x_hrs = round(sum_peak_x_hrs * 24, PRECISION)
                sum_metric_x_hrs = round(sum_metric_x_hrs * 24, PRECISION)
                sumOfDiff = round(sumOfDiff * 24, PRECISION)

            aDf.sort_values(
                ["cdb", "ROLLUP_TIMESTAMP_UTC"], ascending=[False, True], inplace=True
            )

            if 1 == 0:
                filename = (
                    sizingFilePath
                    + os.sep
                    + "aDf_"
                    + str(cohort)
                    + "_"
                    + metric
                    + "."
                    + ln()
                    + ".csv"
                )
                aDf.to_csv(filename, index=False)
                lg("Wrote " + filename)

            if cdbCount > PLOT_INSTANCE_COUNT_LIMIT:
                aDf = aDf[
                    aDf["cdb"].isin(
                        sorted(aDf["cdb"].unique(), reverse=True)[
                            :PLOT_INSTANCE_COUNT_LIMIT
                        ]
                    )
                ]

            fig = px.area(
                aDf,
                x="ROLLUP_TIMESTAMP_UTC",
                y="AVERAGE",
                color="cdb",
                labels={"ROLLUP_TIMESTAMP_UTC": "Date (UTC)", "AVERAGE": uom},
                title=format_title(
                    customer
                    + " : "
                    + str(cohort)
                    + " : Hourly Average "
                    + "Unadjusted "
                    + metricTitle
                    + miner_version_title
                    + (
                        " (Top "
                        + str(PLOT_INSTANCE_COUNT_LIMIT)
                        + " of "
                        + str(cdbCount)
                        + " database(s) shown)"
                        if cdbCount > PLOT_INSTANCE_COUNT_LIMIT
                        else " (" + str(cdbCount) + " database(s) shown)"
                    ),
                    (
                        "Sum(Max)=" + f"{sum_of_max:,}" + " (dashed black), "
                        if PLOT_SUM_OF_MAX
                        else ""
                    )
                    + "Peak="
                    + f"{peak:,}"
                    + " (solid red)"
                    + (
                        ", 95, 90, 80="
                        + f"{p95:,}"
                        + ", "
                        + f"{p90:,}"
                        + ", "
                        + f"{p80:,}"
                        + " (dotted blue)"
                        if PLOT_PERCENTILES
                        else ""
                    )
                    + ("<br>" if PLOT_PERCENTILES else ", ")
                    + "Average="
                    + f"{average:,}"
                    + " (solid green)"
                    + ", Hrs="
                    + f"{hrs:,}"
                    + (", 1 OCPU = 2 vCPU" if uom == "vCPU" else "")
                    + (", Trimmed graph" if TRIMMED_GRAPH else ", Full graph"),

                    20,
                ),
                template="seaborn",
                width=WIDTH,
                height=HEIGHT,
            )

            fig.add_trace(
                go.Scatter(
                    x=timeAlignedDf["ROLLUP_TIMESTAMP_UTC"],
                    y=timeAlignedDf["AVERAGE"],
                    mode="lines",
                    line=dict(color="black", width=6),
                )
            )

            if PLOT_SUM_OF_MAX:
                fig.add_hline(
                    y=sum_of_max, line_width=3, line_color="black", line_dash="dash"
                )
                fig.update_layout(yaxis_range=[0, sum_of_max * 1.1])

            else:
                fig.update_layout(yaxis_range=[0, peak * 1.1])

            fig.add_hline(y=peak, line_width=3, line_color="red")
            fig.add_hline(y=average, line_width=10, line_color="green")

            if PLOT_PERCENTILES:
                fig.add_hline(y=p80, line_width=3, line_color="blue", line_dash="dot")
                fig.add_hline(y=p90, line_width=3, line_color="blue", line_dash="dot")
                fig.add_hline(y=p95, line_width=3, line_color="blue", line_dash="dot")

            fig.update_layout(
                font={"size": 16},
                legend_font_size=12,
                autosize=False,
                width=WIDTH,
                height=HEIGHT,
                margin=dict(t=150),
            )

            for idx in range(len(fig.data)):
                # lg('idx: ' + str(idx) + ', ' + str(fig.data[idx]))

                cdb = fig.data[idx].name

                if cdb is None:
                    continue

                cdb = cdb[cdb.find("$$$") + 3 :]

                fig.data[idx].name = cdb
                fig.data[idx].legendgroup = cdb
                fig.data[idx].hovertemplate = cdb


            if PLOT_HTML:
                inner_html = (
                    fig.to_html(include_plotlyjs=True)
                    .split("<body>")[1]
                    .split("</body>")[0]
                )
                dashboard.write(inner_html)

                dashboard.write("</body></html>" + "\n")
                dashboard.close()

                plotCtr += 1

            if PLOT_PNG:
                fig.write_image(filenamePNG)

                plotCtr += 1

            if PLOT_INDIVIDUAL_DB and metricTitle == "DB vCPU":
                if PLOT_HTML:
                    individual_plots_path_html = Path(filePathHTML) / "individual_plots"
                    os.makedirs(individual_plots_path_html, exist_ok=True)

                if PLOT_PNG:
                    individual_plots_path_png = Path(filePathPNG) / "individual_plots"
                    os.makedirs(individual_plots_path_png, exist_ok=True)

                dbs_cohort = aDf[" cdb_original"].unique()
                if cdbCount > PLOT_INDIVIDUAL_DB_LIMIT:
                    dbs_cohort = aDf[" cdb_original"].unique()[
                        :PLOT_INDIVIDUAL_DB_LIMIT
                    ]
                for db in dbs_cohort:
                    lg(
                        "{:85}".format(
                            f"\t\t\tPlotting graph for CDB {db}. Metric: {metricTitle}"
                        )
                        + f"; time since start {round(time.time() - startTime, 3)} s"
                    )

                    # Create plot files
                    if PLOT_HTML:
                        file_individual_db_html = (
                            Path(individual_plots_path_html)
                            / f"{cohort}_{db}_{metricTitle.replace(' ', '_')}_unadjusted.html"
                        )
                        plot_dashboard = open(
                            file_individual_db_html, "w", encoding="UTF-8"
                        )
                        html_head = (
                            f"{customer}: {db}: Hourly Average {metricTitle} (occa_Run_Metric_Analysis, Chart "
                            f"Version {__version__})"
                        )
                        plot_dashboard.write(
                            f"<html><head><title> {html_head} </title></head><body>"
                            + "\n"
                        )

                    if PLOT_PNG:
                        file_individual_db_png = (
                            Path(individual_plots_path_png)
                            / f"{cohort}_{db}_{metricTitle.replace(' ', '_')}_{metricType}.png"
                        )

                    # Calculate metrics for each DB
                    db_df = aDf[aDf[" cdb_original"] == db].copy()
                    max_db_df = db_df["AVERAGE"].max()
                    db_sum_of_max = db_df["AVERAGE"].sum()
                    db_df["MAX"] = max_db_df
                    db_df["DIFF"] = max_db_df - db_df["AVERAGE"]

                    db_statistics = db_df["AVERAGE"].describe(
                        percentiles=[0.80, 0.90, 0.95]
                    )
                    db_p80 = round(db_statistics["80%"], PRECISION)
                    db_p90 = round(db_statistics["90%"], PRECISION)
                    db_p95 = round(db_statistics["95%"], PRECISION)

                    db_sum_peak_x_hrs = round(db_df["MAX"].sum(), PRECISION)
                    db_sum_metric_x_hrs = round(db_df["AVERAGE"].sum(), PRECISION)
                    db_sum_of_diff = round(db_df["DIFF"].sum(), PRECISION)

                    db_average = round(db_sum_metric_x_hrs / hrs, PRECISION)
                    db_df.sort_values(
                        ["cdb", "ROLLUP_TIMESTAMP_UTC"],
                        ascending=[False, True],
                        inplace=True,
                    )

                    # Plot titles
                    plot_title_percentiles = (
                        f", Percentiles 95,90,80={db_p95}, {db_p90}, {db_p80} (dotted_blue)<br>"
                        if PLOT_PERCENTILES
                        else ","
                    )
                    vcpu_str = f", 1 OCPU = 2 vCPU" if uom == "vCPU" else ""

                    db_plot_title = (
                        f"{customer}: {db}: Hourly Average Unadjusted {metricTitle} (Chart "
                        f"Version {__version__})"
                    )

                    db_plot_subtitle = (
                        f"Peak= {max_db_df} (solid red) {plot_title_percentiles} Average= {db_average}"
                        f" (solid green), Hrs= {hrs} {vcpu_str}"
                    )

                    # Create the plot
                    db_fig = px.area(
                        db_df,
                        x="ROLLUP_TIMESTAMP_UTC",
                        y="AVERAGE",
                        color="cdb",
                        labels={"ROLLUP_TIMESTAMP_UTC": "Date (UTC)", "AVERAGE": uom},
                        title=format_title(
                            db_plot_title,
                            subtitle=db_plot_subtitle,
                            subtitle_font_size=20,
                        ),
                        template="seaborn",
                        width=WIDTH,
                        height=HEIGHT,
                    )

                    # Adding trace line
                    db_fig.add_trace(
                        go.Scatter(
                            x=db_df["ROLLUP_TIMESTAMP_UTC"],
                            y=db_df["AVERAGE"],
                            mode="lines",
                            line=dict(color="black", width=1),
                        )
                    )

                    # Changing the y-axis range to 10% above the max
                    db_fig.update_layout(yaxis_range=[0, max_db_df * 1.1])

                    # Adding max and average lines
                    db_fig.add_hline(y=max_db_df, line_width=3, line_color="red")
                    db_fig.add_hline(y=db_average, line_width=10, line_color="green")

                    # Adding percentiles lines
                    if PLOT_PERCENTILES:
                        db_fig.add_hline(
                            y=db_p80, line_width=3, line_color="blue", line_dash="dot"
                        )
                        db_fig.add_hline(
                            y=db_p90, line_width=3, line_color="blue", line_dash="dot"
                        )
                        db_fig.add_hline(
                            y=db_p95, line_width=3, line_color="blue", line_dash="dot"
                        )

                    db_fig.update_layout(
                        font={"size": 16},
                        legend_font_size=12,
                        autosize=False,
                        width=WIDTH,
                        height=HEIGHT,
                        margin=dict(t=150),
                    )

                    # Rename the plot legends
                    for idx in range(len(db_fig.data)):
                        curr_cdb = db_fig.data[idx].name
                        if curr_cdb is None:
                            continue
                        curr_cdb = curr_cdb[curr_cdb.find("$$$") + 3 :]
                        db_fig.data[idx].name = curr_cdb
                        db_fig.data[idx].legendgroup = curr_cdb
                        db_fig.data[idx].hovertemplate = curr_cdb

                    # Plot the graphs
                    if PLOT_HTML:
                        inner_html = (
                            db_fig.to_html(include_plotlyjs=True)
                            .split("<body>")[1]
                            .split("</body>")[0]
                        )
                        plot_dashboard.write(inner_html)
                        plot_dashboard.write("</body></html>" + "\n")
                        plot_dashboard.close()
                        plotCtr += 1

                    if PLOT_PNG:
                        db_fig.write_image(file_individual_db_png)
                        plotCtr += 1

            if os.getenv("RUN_FROM_API", "False") == "True":
                import json
                from plotly.io import to_json
                from plotly.utils import PlotlyJSONEncoder

                # print('cohort ->',cohort)
                # print('aDf -> ',aDf.columns)
                # print('analysis_df ',analysis_df.loc[analysis_df['Cohort'] == cohort, 'WHICH_DB'].iloc[0])
                page_index = len(figs)
                plot_json = json.dumps(fig, cls=PlotlyJSONEncoder, ensure_ascii=False)
                figs.append(
                    {
                        "page":page_index,
                        "fig":plot_json,
                        "type":'UNADJUSTED',
                        "COHORT_NAME":str(cohort),
                        "METRIC_NAME":metricTitle,
                    }
                )

        plots_per_cohort[which_db] = figs
        lg(
            "     Created "
            + str(plotCtr)
            + " plots for "
            + str(cohort)
            + " in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )


    if run_from_api:
        # save the plots formatted to read it on apex
        print('plots_per_cohort-> ',plots_per_cohort.keys())
        plots_file_path = os.getcwd()+ os.sep + 'unadjusted_plots.json'
        from plotly.io import to_json
        plots_per_cohort_serializable = {}
        for which_db, figures in plots_per_cohort.items():
            serialized_plots = []

            for plot in figures:

                serialized_plots.append({
                    "page": plot["page"],
                    "fig": plot["fig"],
                    "COHORT_NAME": plot.get("COHORT_NAME"),
                    "METRIC_NAME": plot.get("METRIC_NAME"),
                    "type": plot.get("type"),
                })
            plots_per_cohort_serializable[which_db] = serialized_plots

        with open(plots_file_path, "w") as f:
            json.dump(plots_per_cohort_serializable, f)


# ----------------------------------------------------------------------------------------------------------------------
def is_csv_valid(path, required_column):
    df = pd.read_csv(path)
    if df[required_column].isnull().any():
        print("="*103)
        print(f"Make sure that  the '{required_column}' column has data in the '{path}' file.")
        print("="*103)
        quit()
def validate_user_input():
    # pd.read_csv(fp.AWR_PROPERTIES)['Cohort']
    is_csv_valid(fp.AWR_PROPERTIES,'Cohort')
    is_csv_valid(fp.AWR_TZ,'TZ')
    # pd.read_csv(fp.AWR_TZ['TZ'])
def main():
    global plotFilePath, sizingFilePath, startTime

    argparser = argparse.ArgumentParser(
        prog="awr_miner_Run_Metric_Analysis.py",
        description="Prepare occa upload files from parsed AWR miner files",
    )

    argparser.add_argument(
        "-v",
        "--version",
        type=str,
        action="store",
        nargs="*",
        help="Print the version of the script",
    )
    argparser.add_argument(
        "-p",
        "--parameters",
        type=str,
        action="store",
        nargs="*",
        help="Print the parameters used by the script",
    )

    args = argparser.parse_args()

    if args.version is not None:
        print(sys.argv[0] + ", version " + __version__)
        quit()

    # ---
    global awrFilePath
    awrFilePath = ROOT_DIR + os.sep + "awr_miner_occa"
    if os.environ.get("RUN_FROM_API", "False") == "True":
        awrFilePath = os.getcwd() + os.sep + "awr_miner_occa"

    sizingFilePath = awrFilePath + os.sep + "sizing"
    plotFilePath = awrFilePath + os.sep + "plot"

    h, t = os.path.split(sys.argv[0])
    logFilename = awrFilePath + os.sep + "log" + os.sep + t + ".log"
    os.makedirs(awrFilePath + os.sep + "log", exist_ok=True)
    logFile = open_log(logFilename)

    lg(
        "\n=======================================================================================================\n"
    )
    lg(
        "Begin @ "
        + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        + " UTC\n"
    )
    lg(sys.argv[0] + ", version " + __version__ + "\n")
    lg("sys.version_info  : " + str(sys.version_info))
    lg("platform.system() : " + str(platform.system()))

    lg("pandas.__version__: " + pd.__version__)

    if PLOT_HTML or PLOT_PNG:
        lg("plotly.__version__: " + plt.__version__)

    lg(
        "\n=======================================================================================================\n"
    )
    print("\nReading parameters from file " + PARAM_FILE)

    # ----------------------------------------------------------------------------------------------------------------------

    lg(
        "\n=======================================================================================================\n"
    )

    lg("PLOT_INSTANCE_COUNT_LIMIT           : " + str(PLOT_INSTANCE_COUNT_LIMIT))
    lg("PLOT_HTML                           : " + str(PLOT_HTML))
    lg("PLOT_PNG                            : " + str(PLOT_PNG))
    lg("PLOT_PERCENTILES                    : " + str(PLOT_PERCENTILES))
    lg("PLOT_SUM_OF_MAX                     : " + str(PLOT_SUM_OF_MAX))
    lg("PLOT_INDIVIDUAL_DB                  : " + str(PLOT_INDIVIDUAL_DB))
    lg("PLOT_INDIVIDUAL_DB_LIMIT            : " + str(PLOT_INDIVIDUAL_DB_LIMIT))
    lg("PLOT_SUPPRESSED_COHORTS             : " + str(PLOT_SUPPRESSED_COHORTS))
    lg(
        "ROLLUP_CSV_FILES_SUPRESSED_COHORTS  : "
        + str(ROLLUP_CSV_FILES_SUPRESSED_COHORTS)
    )
    lg("OVERLAP_DAYS_WITHIN_A_COHORT        : " + str(OVERLAP_DAYS_WITHIN_A_COHORT))
    lg("TRIMMED_GRAPH                       : " + str(TRIMMED_GRAPH))

    lg(
        "\n=======================================================================================================\n"
    )

    if args.parameters is not None:
        quit()

    # ---

    cwd = os.getcwd().split(os.sep)[-1]
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    platformName = platform.system()
    startTime = time.time()

    lg("Processing files in directory " + awrFilePath)

    os.makedirs(sizingFilePath, exist_ok=True)

    excludedDatabases = {}

    # ---

    filename = awrFilePath + os.sep + "occa_composite.csv"

    if not os.path.exists(filename):
        lg(filename + " does not exist; cannot continue")
        quit()

    snapDf = pd.read_csv(filename, parse_dates=["end"])
    lg("\nRead " + str(len(snapDf)) + " rows from " + filename)

    # ---

    filename = "awr_miner_plots" + os.sep + "csv" + os.sep + "00_instances.csv"

    if not os.path.exists(filename):
        lg(filename + " does not exist; cannot continue")
        quit()

    instances00Df = pd.read_csv(filename)
    lg("\nRead " + str(len(instances00Df)) + " rows from " + filename)

    # ---

    filename = (
        awrFilePath + os.sep + "properties" + os.sep + "awr_properties_database.csv"
    )

    if not os.path.exists(filename):
        lg(filename + " does not exist; cannot continue")
        quit()

    propertiesDbDf = pd.read_csv(filename)
    filtered = propertiesDbDf[propertiesDbDf['Cohort'] == 'excluded']
    list_to_exclude = filtered['WHICH_DB'].unique().tolist()

    propertiesDbDf = propertiesDbDf[propertiesDbDf['Cohort'] != 'excluded']

    propertiesDbDf["Cohort"] = propertiesDbDf["Cohort"].fillna("unassigned")
    propertiesDbDf["cdb"] = propertiesDbDf["cdb"].fillna(propertiesDbDf["WHICH_DB"])

    lg("\nRead " + str(len(propertiesDbDf)) + " rows from " + filename)
    snapDf = snapDf[~snapDf['WHICH_DB'].isin(list_to_exclude)]
    validate_user_input()

    # ---

    filename = awrFilePath + os.sep + "properties" + os.sep + "awr_tz_database.csv"

    if not os.path.exists(filename):
        lg(filename + " does not exist; cannot continue")
        quit()

    TZDf = pd.read_csv(filename)
    # Handling data when Cohort is excluded
    TZDf = TZDf[~TZDf['WHICH_DB'].isin(list_to_exclude)]
    lg("\nRead " + str(len(TZDf)) + " rows from " + filename)

    # ---

    filename = awrFilePath + os.sep + "awr_miner_tz_choices.csv"

    if not os.path.exists(filename):
        lg(filename + " does not exist; cannot continue")
        quit()

    TZChoicesDf = pd.read_csv(filename)
    lg("\nRead " + str(len(TZChoicesDf)) + " rows from " + filename)

    # ---

    instances00Df["indicator"] = instances00Df["WHICH_DB"].str.cat(
        instances00Df["INSTANCE"].astype(str), sep="$$$"
    )
    snapDf["indicator"] = snapDf["WHICH_DB"].str.cat(
        snapDf["INSTANCE"].astype(str), sep="$$$"
    )

    df = instances00Df[~instances00Df["indicator"].isin(snapDf["indicator"])]

    filename = sizingFilePath + os.sep + "instances_no_metrics.csv"

    if len(df) > 0:
        lg(
            "\n============================================================================"
        )
        lg("\nThere are " + str(len(df)) + " instances with no metrics.")
        lg(
            "They have been written to file "
            + filename
            + " and eliminated from further processing."
        )
        lg(
            "\n============================================================================"
        )

        df.sort_values(["WHICH_DB", "INSTANCE"]).to_csv(filename, index=False)

        instances00Df = instances00Df[
            instances00Df["indicator"].isin(snapDf["indicator"])
        ]

    elif os.path.exists(filename):
        os.remove(filename)

    instances00Df.drop(columns=["indicator"], inplace=True)
    snapDf.drop(columns=["indicator"], inplace=True)

    df = pd.merge(
        left=instances00Df[["WHICH_DB", "DB_NAME", "INSTANCE", "HOST"]],
        right=propertiesDbDf[["WHICH_DB", "cdb"]],
        how="left",
        left_on=["WHICH_DB"],
        right_on=["WHICH_DB"],
    )

    df["inst"] = df["DB_NAME"] + "$$$" + df["HOST"]

    df.loc[df["inst"].isnull(), "inst"] = df["DB_NAME"] + "$$$" + "unk"
    df.drop(columns=["DB_NAME", "INSTANCE", "HOST"], inplace=True)
    df = df.groupby(["WHICH_DB", "cdb"], as_index=False).agg(lambda x: ",".join(set(x)))
    df.columns = ["WHICH_DB", "cdb", "host_list"]
    df["cdb_count"] = df.groupby(["cdb"])["cdb"].transform("count")

    df = df[df["cdb_count"] > 1]

    filename = sizingFilePath + os.sep + "mismatched_cdb_hosts.csv"

    if len(df) > 0:
        df = pd.merge(left=df, right=df, left_on=["cdb"], right_on=["cdb"])
        df = df[df["WHICH_DB_x"] > df["WHICH_DB_y"]]
        df = df[df["host_list_x"] != df["host_list_y"]]

        if len(df) > 0:
            df.drop(columns=["cdb_count_x", "cdb_count_y"], inplace=True)

            df = df[["cdb", "WHICH_DB_x", "host_list_x", "WHICH_DB_y", "host_list_y"]]

            df.sort_values(["cdb"]).to_csv(filename, index=False)

            lg(
                "\n============================================================================"
            )
            lg('\nThe assignment of one or more database aliases via column "cdb"')
            lg(
                "in file awr_properties_databaase.csv results in mismatched hosts & instances."
            )
            lg("\nOffending values have been written to file " + filename)
            lg(
                "\n==========================================================================="
            )

            quit()

        elif os.path.exists(filename):
            os.remove(filename)

    elif os.path.exists(filename):
        os.remove(filename)

    # ---

    TZDf["TZ"] = TZDf["TZ"].fillna("missing TZ")

    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    snapDf = pd.merge(
        left=snapDf, right=TZDf, how="left", left_on=["WHICH_DB"], right_on=["WHICH_DB"]
    )

    snapDf["TZ"] = snapDf["TZ"].fillna("unspecified TZ")

    dbs = snapDf[snapDf["TZ"] == "missing TZ"]["WHICH_DB"].unique()
    if len(dbs) > 0:
        excludedDatabases["Missing value for TZ"] = dbs

    dbs = snapDf[snapDf["TZ"] == "unspecified TZ"]["WHICH_DB"].unique()
    if len(dbs) > 0:
        excludedDatabases["No TZ specified for database in properties file"] = dbs

    dbs = snapDf[~snapDf["TZ"].isin(TZChoicesDf["TZ"])]["WHICH_DB"].unique()
    if len(dbs) > 0:
        excludedDatabases["Invalid value specified for TZ"] = dbs

    # ---

    df = snapDf.groupby(["WHICH_DB"], as_index=False)["dur_m"].max()
    df = df[df["dur_m"] > SNAP_DUR_M_MAX]

    if len(df) > 0:
        excludedDatabases["MAIN_METRICS.dur_m > " + str(SNAP_DUR_M_MAX)] = df[
            "WHICH_DB"
        ].unique()

    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    for _ in excludedDatabases:
        if 1 == 0:
            lg(str(ln()) + " removing " + str(excludedDatabases[_]) + " because " + _)
        snapDf = snapDf[~snapDf["WHICH_DB"].isin(excludedDatabases[_])]

    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    if len(snapDf) == 0:
        error_message = "All rows excluded from telemetry file due to missing or invalid choice for TZ or invalid snap interval; cannot continue"
        lg(f"\n{error_message}")
        raise_error_when_run_from_api("AWR: ",error_message.strip())
        quit()

    # ---
    #
    #   Add 5 minutes to the snap end to account for jitter then lop the end off to the nearest hour
    #
    snapDf["end_p_5"] = snapDf["end"] + pd.to_timedelta(5, unit="m")
    snapDf["end_hh24"] = snapDf["end_p_5"].dt.floor("h")

    snapDf["end_hh24_UTC"] = snapDf.apply(convertToUTC, axis=1)
    snapDf["end_dd_UTC"] = snapDf["end_hh24_UTC"].dt.floor("d")

    snapDf = pd.merge(
        left=snapDf,
        right=propertiesDbDf[["WHICH_DB", "cdb"]],
        how="left",
        left_on=["WHICH_DB"],
        right_on=["WHICH_DB"],
    )

    extract_dttm_utc = snapDf["end_hh24_UTC"].max()

    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    snapDf = pd.merge(
        left=snapDf,
        right=instances00Df[
            ["WHICH_DB", "INSTANCE", "HOST", "snap_id_start", "snap_id_end"]
        ],
        how="left",
        left_on=["WHICH_DB", "INSTANCE"],
        right_on=["WHICH_DB", "INSTANCE"],
    )
    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    gbDf = snapDf[snapDf["snap_id_start"].isnull()]

    filename = sizingFilePath + os.sep + "mismatched_instance_OS_INFORMATION.csv"

    if len(gbDf) > 0:
        lg(
            "\n====================================================================================================================="
        )
        lg(
            "\nThe value of property INSTANCES, in the OS-INFORMATION section, of at least one database"
        )
        lg(
            "in the original awr.out file(s) does not match the distinct values seen in the inst column in the MAIN-METRICS section."
        )
        lg("\nOffending values have been written to file " + filename)
        lg(
            "\nYou can examine files OS-INFORMATION.csv & MAIN-METRICS.csv in the awr_miner_parsed directory "
        )
        lg("of the offending database(s) to see the specific discrepancies.")
        lg(
            "\n====================================================================================================================="
        )

        gbDf[["WHICH_DB", "INSTANCE"]].drop_duplicates().sort_values(
            ["WHICH_DB", "INSTANCE"]
        ).to_csv(filename, index=False)

        excludedDatabases["Mismatched instance count"] = gbDf["WHICH_DB"].unique()
        snapDf = snapDf[~snapDf["WHICH_DB"].isin(gbDf["WHICH_DB"])]

    elif os.path.exists(filename):
        os.remove(filename)

    beforeDf = snapDf[["WHICH_DB", "DB_NAME", "INSTANCE", "SNAP_ID"]].drop_duplicates()
    beforeDf["key"] = (
        beforeDf["DB_NAME"]
        + "$$"
        + beforeDf["INSTANCE"].astype(str)
        + "$$"
        + beforeDf["SNAP_ID"].astype(str)
    )

    snapDf = snapDf[
        (snapDf["SNAP_ID"] >= snapDf["snap_id_start"])
        & (snapDf["SNAP_ID"] <= snapDf["snap_id_end"])
    ]

    afterDf = snapDf[["WHICH_DB", "DB_NAME", "INSTANCE", "SNAP_ID"]].drop_duplicates()
    afterDf["key"] = (
        afterDf["DB_NAME"]
        + "$$"
        + afterDf["INSTANCE"].astype(str)
        + "$$"
        + afterDf["SNAP_ID"].astype(str)
    )

    if 1 == 0:
        lg(
            str(ln())
            + " len(beforeDf), len(afterDf): "
            + str(len(beforeDf))
            + ", "
            + str(len(afterDf))
        )

    filename = sizingFilePath + os.sep + "invalid_snaps.csv"

    if len(beforeDf) != len(afterDf):
        beforeDf[~beforeDf["key"].isin(afterDf["key"])].sort_values(
            ["WHICH_DB", "DB_NAME", "INSTANCE", "SNAP_ID"]
        ).to_csv(filename, index=False)
        lg(
            "\n============================================================================="
        )
        lg(
            "\nAt least one of the sections in the AWR extract files contain rollover snaps."
        )
        lg("\nWrote file " + filename)
        lg(
            "\n============================================================================="
        )

    elif os.path.exists(filename):
        os.remove(filename)

    snapDf["INSTANCE_snap"] = snapDf["INSTANCE"]
    snapDf["INSTANCE"] = (
        snapDf["cdb"]
        + "$"
        + snapDf["HOST"]
        + "$"
        + snapDf["INSTANCE"].astype(str).str.zfill(3)
    )

    if 1 == 0:
        printDf(
            str(ln()) + " snapDf",
            snapDf[
                ["WHICH_DB", "DB_NAME", "cdb", "HOST", "INSTANCE", "INSTANCE_snap"]
            ].drop_duplicates(),
            showTail=False,
        )

    # ---

    hostsDf = instances00Df[
        ["HOST", "NUM_CPU_CORES", "NUM_CPUS", "PHYSICAL_MEMORY_GB", "PLATFORM_NAME"]
    ].drop_duplicates()
    hostsDf.columns = [
        "host",
        "total_cpu_cores",
        "logical_cpu_count",
        "mem_gb",
        "dist_version",
    ]

    hostsDf["cpu_type"] = hostsDf.apply(
        lambda r: getCPUType(r["dist_version"], ""), axis=1
    )
    hostsDf["host_target_guid"] = hostsDf["host"]
    hostsDf["cwd"] = cwd
    hostsDf["platform"] = platformName
    hostsDf["extract_dttm_utc"] = extract_dttm_utc
    hostsDf["create_dttm_utc"] = now
    hostsDf["source"] = SOURCE
    hostsDf["version"] = __version__

    hostsDf["host"] = hostsDf["host"].fillna("unk")
    hostsDf["host_target_guid"] = hostsDf["host_target_guid"].fillna("unk")

    filename = sizingFilePath + os.sep + "servers.csv"
    hostsDf.sort_values(["host"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    # ---

    instancesDf = instances00Df[
        [
            "WHICH_DB",
            "INSTANCE",
            "HOST",
            "NUM_CPU_CORES",
            "NUM_CPUS",
            "PHYSICAL_MEMORY_GB",
            "PLATFORM_NAME",
            "SGA",
            "PGA",
            "cpu_count",
        ]
    ].drop_duplicates()
    instancesDf.columns = [
        "WHICH_DB",
        "db",
        "host",
        "total_cpu_cores",
        "logical_cpu_count",
        "mem_gb",
        "dist_version",
        "sga_size_gb",
        "pga_size_gb",
        "init_cpu_count",
    ]
    instancesDf["host"] = instancesDf["host"].fillna("unk")

    instancesDf = pd.merge(
        left=instancesDf,
        right=propertiesDbDf[["WHICH_DB", "Cohort", "cdb"]],
        how="left",
        left_on=["WHICH_DB"],
        right_on=["WHICH_DB"],
    )
    instancesDf["db"] = (
        instancesDf["cdb"]
        + "$"
        + instancesDf["host"]
        + "$"
        + instancesDf["db"].astype(str).str.zfill(3)
    )
    instancesDf["cdb_target_guid"] = instancesDf["cdb"]
    instancesDf["db_target_guid"] = instancesDf["db"]
    instancesDf["host_target_guid"] = instancesDf["host"]
    instancesDf["cpu_type"] = instancesDf.apply(
        lambda r: getCPUType(r["dist_version"], ""), axis=1
    )

    instancesDf.rename(columns={"Cohort": "cdb_cohort"}, inplace=True)

    instancesDf["excluded"] = ""
    instancesDf["excluded_reason"] = ""
    instancesDf["db_cohort"] = instancesDf["cdb_cohort"]
    instancesDf = instancesDf[
        [
            "excluded",
            "excluded_reason",
            "cdb_cohort",
            "WHICH_DB",
            "cdb",
            "db",
            "host",
            "total_cpu_cores",
            "logical_cpu_count",
            "mem_gb",
            "dist_version",
            "cpu_type",
            "db_cohort",
            "sga_size_gb",
            "pga_size_gb",
            "init_cpu_count",
            "cdb_target_guid",
            "db_target_guid",
            "host_target_guid",
        ]
    ]

    instancesDf["cwd"] = cwd
    instancesDf["platform"] = platformName
    instancesDf["extract_dttm_utc"] = extract_dttm_utc
    instancesDf["create_dttm_utc"] = now
    instancesDf["source"] = SOURCE
    instancesDf["version"] = __version__

    # ---

    if len(snapDf) == 0:
        error_message = "All rows excluded from telemetry file; cannot continue"
        lg(f"\n{error_message}")
        raise_error_when_run_from_api("AWR: ",error_message.strip())
        quit()

    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    snapDf[["WHICH_DB", "INSTANCE", "INSTANCE_snap"]].drop_duplicates()

    # ---

    databasesDf = instancesDf[
        ["cdb_cohort", "WHICH_DB", "cdb", "cdb_target_guid"]
    ].drop_duplicates()

    df = instancesDf[["cdb_target_guid", "host"]].drop_duplicates()
    df = df.groupby("cdb_target_guid", as_index=False).agg(lambda x: ",".join(set(x)))
    df.columns = ["cdb_target_guid", "server_list"]

    databasesDf = pd.merge(
        left=databasesDf,
        right=df,
        left_on="cdb_target_guid",
        right_on="cdb_target_guid",
        how="left",
    )
    databasesDf["Server List"] = databasesDf["server_list"]
    databasesDf.drop(columns="server_list", inplace=True)

    df = (
        instancesDf[["cdb_target_guid", "db"]]
        .drop_duplicates()
        .groupby(["cdb_target_guid"], as_index=False)["db"]
        .count()
    )
    df.columns = ["cdb_target_guid", "cdb_instance_count"]
    databasesDf = pd.merge(
        left=databasesDf,
        right=df,
        left_on="cdb_target_guid",
        right_on="cdb_target_guid",
        how="left",
    )

    databasesDf["clustered"] = "NON-CLUSTERED"
    databasesDf.loc[databasesDf["cdb_instance_count"] > 1, "clustered"] = "CLUSTERED"

    databasesDf["excluded"] = ""
    databasesDf["excluded_reason"] = ""

    databasesDf.loc[databasesDf["cdb_cohort"] == "excluded", "excluded_reason"] = (
        '( Cohort = "excluded" )'
    )

    for _ in excludedDatabases:
        databasesDf.loc[
            databasesDf["WHICH_DB"].isin(excludedDatabases[_]), "excluded_reason"
        ] += ("( " + _ + " )")

    databasesDf.loc[databasesDf["excluded_reason"] != "", "excluded"] = "excluded"

    databasesDf = databasesDf[
        [
            "excluded",
            "excluded_reason",
            "cdb_cohort",
            "WHICH_DB",
            "cdb",
            "cdb_instance_count",
            "clustered",
            "Server List",
            "cdb_target_guid",
        ]
    ]

    databasesDf["cwd"] = cwd
    databasesDf["platform"] = platformName
    databasesDf["extract_dttm_utc"] = extract_dttm_utc
    databasesDf["create_dttm_utc"] = now
    databasesDf["source"] = SOURCE
    databasesDf["version"] = __version__

    filename = sizingFilePath + os.sep + "databases.csv"
    databasesDf.drop(columns=["WHICH_DB"]).sort_values(["cdb"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

    instancesDf.loc[
        instancesDf["cdb"].isin(databasesDf[databasesDf["excluded"] != ""]["cdb"]),
        "excluded_reason",
    ] = "( Parent database is excluded )"
    instancesDf.loc[instancesDf["excluded_reason"] != "", "excluded"] = "excluded"

    filename = sizingFilePath + os.sep + "instances.csv"
    instancesDf.sort_values(["db"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    # ---
    #
    # Get aggregate cpu counts that will be used for computation for ADWs below
    #
    dbCPUCountsDf = instancesDf.groupby(["cdb"], as_index=False)[
        "logical_cpu_count"
    ].sum()

    # ---

    cohortDatabasesIncludedDf = (
        instancesDf[instancesDf["excluded"] == ""]
        .groupby(["cdb_cohort"], as_index=False)["cdb"]
        .nunique()
    )
    cohortDatabasesIncludedDf.columns = ["Cohort", "Databases Included"]

    cohortDatabasesExcludedDf = (
        instancesDf[instancesDf["excluded"] != ""]
        .groupby(["cdb_cohort"], as_index=False)["cdb"]
        .nunique()
    )
    cohortDatabasesExcludedDf.columns = ["Cohort", "Databases Excluded"]

    cohortInstancesIncludedDf = (
        instancesDf[instancesDf["excluded"] == ""]
        .groupby(["cdb_cohort"], as_index=False)["db"]
        .nunique()
    )
    cohortInstancesIncludedDf.columns = ["Cohort", "Instances Included"]

    cohortInstancesExcludedDf = (
        instancesDf[instancesDf["excluded"] != ""]
        .groupby(["cdb_cohort"], as_index=False)["db"]
        .nunique()
    )
    cohortInstancesExcludedDf.columns = ["Cohort", "Instances Excluded"]

    cdbInstancesIncludedDf = (
        instancesDf[instancesDf["excluded"] == ""]
        .groupby(["cdb"], as_index=False)["db"]
        .nunique()
    )
    cdbInstancesIncludedDf.columns = ["Name", "Instances Included"]

    cdbInstancesExcludedDf = (
        instancesDf[instancesDf["excluded"] != ""]
        .groupby(["cdb"], as_index=False)["db"]
        .nunique()
    )
    cdbInstancesExcludedDf.columns = ["Name", "Instances Excluded"]

    # -- get the database's cohort assigned from the properties file

    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    snapDf = snapDf[
        ~snapDf["WHICH_DB"].isin(databasesDf[databasesDf["excluded"] != ""]["WHICH_DB"])
    ]

    if 1 == 0:
        lg(str(ln()) + " len(snapDf): " + str(len(snapDf)))

    snapDf = pd.merge(
        left=snapDf,
        right=propertiesDbDf[["WHICH_DB", "Cohort"]],
        how="left",
        left_on=["WHICH_DB"],
        right_on=["WHICH_DB"],
    )
    snapDf["Cohort"] = snapDf["Cohort"].fillna("unassigned")

    # -- get time-aligned instance averages

    instAvgDf = snapDf.groupby(
        ["Cohort", "cdb", "INSTANCE", "end_hh24_UTC", "end_dd_UTC"], as_index=False
    ).mean(numeric_only=True)

    # -- compute time-aligned sums at the database level

    agg_dict = {
        "DB vCPU": "sum",
        "DB Logons": "sum",
        "DB SGA (MB)": "sum",
        "DB PGA (MB)": "sum",
        "DB Memory (MB)": "sum",
        "DB IOPS": "sum",
        "Allocated Storage (GB)": "max",
    }

    # Is used storage has been propagated from parse-plot
    # it means that new columns found in SIZE-ON-DISK section
    if "Used Storage (GB)" in instAvgDf.columns:
        agg_dict["Used Storage (GB)"] = "max"

    dbHourlySumDf = instAvgDf.groupby(
        ["Cohort", "cdb", "end_hh24_UTC", "end_dd_UTC"], as_index=False
    ).agg(agg_dict)

    dbHourlySumDf.rename(columns={"Cohort": "cdb_cohort"}, inplace=True)

    # -- move the daily hourly storage value to all hourly snaps in a given day

    dbHourlySumDf["Storage_GB"] = dbHourlySumDf.groupby(["cdb", "end_dd_UTC"])[
        "Allocated Storage (GB)"
    ].transform("max")
    dbHourlySumDf["Allocated Storage (GB)"] = dbHourlySumDf["Storage_GB"]
    dbHourlySumDf.drop(columns=["Storage_GB"], inplace=True)

    # Is we find Used Storage has been propagated correctly, we'll use that data
    if "Used Storage (GB)" in dbHourlySumDf.columns:
        dbHourlySumDf["Used Storage (GB)"] = dbHourlySumDf.groupby(
            ["cdb", "end_dd_UTC"]
        )["Used Storage (GB)"].transform("max")
    else:
        dbHourlySumDf["Used Storage (GB)"] = dbHourlySumDf["Allocated Storage (GB)"]

    dbHourlySumDf["cdb_target_guid"] = dbHourlySumDf["cdb"]

    # ---

    dbHoursDf = (
        snapDf.groupby(["cdb"], as_index=False)["end_hh24_UTC"]
        .agg(["min", "max"])
        .reset_index()[["cdb", "min", "max"]]
    )
    dbHoursDf["Hours"] = (dbHoursDf["max"] - dbHoursDf["min"]).apply(
        obtain_total_hours
    ) + 1

    cohortHoursDf = pd.merge(
        left=dbHoursDf,
        right=propertiesDbDf[["cdb", "Cohort"]],
        how="left",
        left_on=["cdb"],
        right_on=["cdb"],
    )
    cohortHoursDf = cohortHoursDf.groupby(["Cohort"], as_index=False)["Hours"].max()

    dbHoursDf.columns = ["Name", "min", "max", "Hours"]
    dbHoursDf = dbHoursDf[["Name", "Hours"]]

    # ---

    cohortHourlySumDf = dbHourlySumDf.groupby(
        ["cdb_cohort", "end_dd_UTC", "end_hh24_UTC"], as_index=False
    ).sum(numeric_only=True)
    cohortHourlySumDf = cohortHourlySumDf.melt(
        id_vars=["cdb_cohort", "end_dd_UTC", "end_hh24_UTC"]
    )
    cohortHourlySumDf.rename(columns={"variable": "metric"}, inplace=True)

    totalsDf = cohortHourlySumDf.groupby(["cdb_cohort", "metric"], as_index=False)[
        "value"
    ].sum()
    totalsDf.columns = ["cdb_cohort", "metric", "total"]

    pctDf = (
        cohortHourlySumDf.groupby(["cdb_cohort", "metric"])
        .describe(percentiles=PERCENTILES)
        .reset_index()[["cdb_cohort", "metric", "value"]]
    )
    pctDf["cdb"] = "All"
    pctDf["adjusted"] = 0
    pctDf["summary_of"] = "cdb_cohort"
    pctDf["cdb_target_guid"] = "All"

    # The order in which percentiles' calculations are ordered varies between Pandas versions
    if pd.__version__ == "1.5.3":
        cols = ["cdb_cohort", "metric", "count", "mean", "std", "min"]
        cols += ["p" + str(int(_ * 100)) for _ in PERCENTILES if _ != "0"] + ["max"]
        cols += ["cdb", "adjusted", "summary_of", "cdb_target_guid"]
    else:
        cols = ["cdb_cohort", "metric", "count", "mean", "min"]
        cols += ["p" + str(int(_ * 100)) for _ in PERCENTILES if _ != "0"] + [
            "max",
            "std",
        ]
        cols += ["cdb", "adjusted", "summary_of", "cdb_target_guid"]

    pctDf.columns = cols
    pctDf = pctDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "adjusted",
            "summary_of",
            "cdb_target_guid",
            "count",
            "mean",
            "std",
            "min",
            "p10",
            "p20",
            "p30",
            "p40",
            "p50",
            "p60",
            "p70",
            "p80",
            "p90",
            "p95",
            "p99",
            "max",
        ]
    ]

    pctDf = pd.merge(
        left=pctDf,
        right=totalsDf,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )
    pctDf["max_rank"] = pctDf.groupby(["metric"])["max"].rank("dense")
    pctDf["total_rank"] = pctDf.groupby(["metric"])["total"].rank("dense")

    pctDf = pctDf.round(PRECISION)

    pctDf["Rollup Type"] = "AVERAGE"
    pctDf["Time Unit"] = "HOURLY"
    pctDf["Time Period"] = "3"
    pctDf["cwd"] = cwd
    pctDf["platform"] = platformName
    pctDf["extract_dttm_utc"] = extract_dttm_utc
    pctDf["create_dttm_utc"] = now
    pctDf["source"] = SOURCE
    pctDf["version"] = __version__

    filename = sizingFilePath + os.sep + "cohort_statistics.csv"
    pctDf.sort_values(["cdb_cohort", "metric"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    cohortFinalDf = pctDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "adjusted",
            "mean",
            "max",
            "cdb_target_guid",
            "count",
        ]
    ].copy()

    if len(cohortInstancesIncludedDf) == 0:
        cohortFinalDf["instance_count"] = 0
    else:
        cohortFinalDf = pd.merge(
            left=cohortFinalDf,
            right=cohortInstancesIncludedDf,
            how="left",
            left_on=["cdb_cohort"],
            right_on=["Cohort"],
        )
        cohortFinalDf["Instances Included"] = cohortFinalDf[
            "Instances Included"
        ].fillna(0)
        cohortFinalDf.drop(columns=["Cohort"], inplace=True)

    if len(cohortInstancesExcludedDf) == 0:
        cohortFinalDf["Instances Excluded"] = 0
    else:
        cohortFinalDf = pd.merge(
            left=cohortFinalDf,
            right=cohortInstancesExcludedDf,
            how="left",
            left_on=["cdb_cohort"],
            right_on=["Cohort"],
        )
        cohortFinalDf["Instances Excluded"] = cohortFinalDf["Instances Excluded"].fillna(0)
        cohortFinalDf.drop(columns=["Cohort"], inplace=True)

    cohortFinalDf["cdb_type"] = "All"
    cohortFinalDf["instance_count"] = cohortFinalDf[
        "Instances Included"
    ]  # note we're leaving off the excluded count
    cohortFinalDf["summary_of"] = "cdb_cohort"

    # ---

    pDf = pd.pivot_table(
        pctDf, index=["cdb_cohort"], columns="metric", values="max"
    ).reset_index()
    pDf.rename(columns={"cdb_cohort": "Cohort"}, inplace=True)

    if len(cohortDatabasesIncludedDf) == 0:
        pDf["Databases Included"] = 0
    else:
        pDf = pd.merge(
            left=pDf,
            right=cohortDatabasesIncludedDf,
            how="left",
            left_on=["Cohort"],
            right_on=["Cohort"],
        )
        pDf["Databases Included"] = pDf["Databases Included"].fillna(0)

    if len(cohortDatabasesExcludedDf) == 0:
        pDf["Databases Excluded"] = 0
    else:
        pDf = pd.merge(
            left=pDf,
            right=cohortDatabasesExcludedDf,
            how="left",
            left_on=["Cohort"],
            right_on=["Cohort"],
        )
        pDf["Databases Excluded"]=pDf["Databases Excluded"].fillna(0)

    if len(cohortInstancesIncludedDf) == 0:
        pDf["Instances Included"] = 0
    else:
        pDf = pd.merge(
            left=pDf,
            right=cohortInstancesIncludedDf,
            how="left",
            left_on=["Cohort"],
            right_on=["Cohort"],
        )
        pDf["Instances Included"] = pDf["Instances Included"].fillna(0)

    if len(cohortInstancesExcludedDf) == 0:
        pDf["Instances Excluded"] = 0
    else:
        pDf = pd.merge(
            left=pDf,
            right=cohortInstancesExcludedDf,
            how="left",
            left_on=["Cohort"],
            right_on=["Cohort"],
        )
        pDf["Instances Excluded"] = pDf["Instances Excluded"].fillna(0)

    pDf = pd.merge(
        left=pDf,
        right=cohortHoursDf,
        how="left",
        left_on=["Cohort"],
        right_on=["Cohort"],
    )
    pDf.rename(columns={"Cohort": "Name"}, inplace=True)

    pDf["Adjusted Values"] = "N"
    pDf["Rollup Type"] = "AVERAGE"
    pDf["Time Unit"] = "HOURLY"
    pDf["Time Period"] = "3"
    pDf["DB vCPU for Standby"] = pDf["DB vCPU"]
    pDf["DB IOPS for Standby"] = pDf["DB IOPS"]

    pDf = pDf[
        [
            "Name",
            "Rollup Type",
            "Time Unit",
            "Time Period",
            "Adjusted Values",
            "Databases Included",
            "Databases Excluded",
            "Instances Included",
            "Instances Excluded",
            "Hours",
            "Allocated Storage (GB)",
            "Used Storage (GB)",
            "DB vCPU",
            "DB vCPU for Standby",
            "DB PGA (MB)",
            "DB SGA (MB)",
            "DB Memory (MB)",
            "DB IOPS",
            "DB IOPS for Standby",
            "DB Logons",
        ]
    ]

    pDf["cwd"] = cwd
    pDf["platform"] = platformName
    pDf["extract_dttm_utc"] = extract_dttm_utc
    pDf["create_dttm_utc"] = now
    pDf["source"] = SOURCE
    pDf["version"] = __version__

    filename = sizingFilePath + os.sep + "cohort_rollups.csv"

    # Drop from cohort_rollups.csv cohorts stated in ROLLUP_CSV_FILES_SUPRESSED_COHORTS
    for cohort in ROLLUP_CSV_FILES_SUPRESSED_COHORTS:
        pDf = pDf[(pDf.Name != cohort)]

    pDf.sort_values(["Name"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)
    lg("   Excluding cohorts " + ",".join(ROLLUP_CSV_FILES_SUPRESSED_COHORTS))

    # ---

    dbHourlySumDf = dbHourlySumDf.melt(
        id_vars=["cdb_cohort", "cdb", "cdb_target_guid", "end_dd_UTC", "end_hh24_UTC"]
    )
    dbHourlySumDf.rename(columns={"variable": "metric"}, inplace=True)

    totalsDf = dbHourlySumDf.groupby(["cdb", "metric"], as_index=False)["value"].sum()
    totalsDf.columns = ["cdb", "metric", "total"]

    pctDf = (
        dbHourlySumDf.groupby(["cdb_cohort", "cdb", "cdb_target_guid", "metric"])
        .describe(percentiles=PERCENTILES)
        .reset_index()[["cdb_cohort", "cdb", "cdb_target_guid", "metric", "value"]]
    )
    pctDf["adjusted"] = 0
    pctDf["summary_of"] = "cdb"

    # The order in which percentiles' calculations are ordered varies between Pandas versions
    if pd.__version__ == "1.5.3":
        cols = [
            "cdb_cohort",
            "cdb",
            "cdb_target_guid",
            "metric",
            "count",
            "mean",
            "std",
            "min",
        ]
        cols += ["p" + str(int(_ * 100)) for _ in PERCENTILES if _ != "0"] + ["max"]
        cols += ["adjusted", "summary_of"]
    else:
        cols = [
            "cdb_cohort",
            "cdb",
            "cdb_target_guid",
            "metric",
            "count",
            "mean",
            "min",
        ]
        cols += ["p" + str(int(_ * 100)) for _ in PERCENTILES if _ != "0"] + [
            "max",
            "std",
        ]
        cols += ["adjusted", "summary_of"]

    pctDf.columns = cols
    pctDf = pctDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "adjusted",
            "summary_of",
            "cdb_target_guid",
            "count",
            "mean",
            "std",
            "min",
            "p10",
            "p20",
            "p30",
            "p40",
            "p50",
            "p60",
            "p70",
            "p80",
            "p90",
            "p95",
            "p99",
            "max",
        ]
    ]

    pctDf = pd.merge(
        left=pctDf,
        right=totalsDf,
        how="left",
        left_on=["cdb", "metric"],
        right_on=["cdb", "metric"],
    )
    pctDf["max_rank"] = pctDf.groupby(["metric"])["max"].rank("dense")
    pctDf["total_rank"] = pctDf.groupby(["metric"])["total"].rank("dense")

    pctDf = pctDf.round(PRECISION)

    pctDf["Rollup Type"] = "AVERAGE"
    pctDf["Time Unit"] = "HOURLY"
    pctDf["Time Period"] = "3"
    pctDf["cwd"] = cwd
    pctDf["platform"] = platformName
    pctDf["extract_dttm_utc"] = extract_dttm_utc
    pctDf["create_dttm_utc"] = now
    pctDf["source"] = SOURCE
    pctDf["version"] = __version__

    filename = sizingFilePath + os.sep + "database_statistics.csv"
    pctDf.sort_values(["cdb_cohort", "cdb", "metric"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    cdbFinalDf = pctDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "adjusted",
            "mean",
            "max",
            "cdb_target_guid",
            "count",
        ]
    ].copy()

    if len(cdbInstancesIncludedDf) == 0:
        cdbFinalDf["Instances Included"] = 0
    else:
        cdbFinalDf = pd.merge(
            left=cdbFinalDf,
            right=cdbInstancesIncludedDf,
            how="left",
            left_on=["cdb"],
            right_on=["Name"],
        )
        cdbFinalDf["Instances Included"] = cdbFinalDf["Instances Included"].fillna(0)
        cdbFinalDf.drop(columns=["Name"], inplace=True)

    if len(cdbInstancesExcludedDf) == 0:
        cdbFinalDf["Instances Excluded"] = 0
    else:
        cdbFinalDf = pd.merge(
            left=cdbFinalDf,
            right=cdbInstancesExcludedDf,
            how="left",
            left_on=["cdb"],
            right_on=["Name"],
        )
        cdbFinalDf["Instances Excluded"] = cdbFinalDf["Instances Excluded"].fillna(0)
        cdbFinalDf.drop(columns=["Name"], inplace=True)

    cdbFinalDf["instance_count"] = cdbFinalDf[
        "Instances Included"
    ]  # Note we're leaving off the excluded count

    cdbFinalDf["summary_of"] = "cdb"

    cdbFinalDf["cdb_type"] = "oracle_database"
    cdbFinalDf.loc[cdbFinalDf["instance_count"] > 0, "cdb_type"] = "rac_database"

    finalDf = pd.concat([cohortFinalDf, cdbFinalDf], ignore_index=False)
    finalDf.rename(
        columns={"mean": "average", "max": "peak", "count": "hrs"}, inplace=True
    )

    finalDf["sum_peak_x_hrs"] = finalDf["peak"] * finalDf["hrs"]
    finalDf["sum_metric_x_hrs"] = finalDf["average"] * finalDf["hrs"]
    finalDf["sum_peak_x_hrs_m_sum_metric_x_hrs"] = (
        finalDf["sum_peak_x_hrs"] - finalDf["sum_metric_x_hrs"]
    )
    finalDf["sum_metric_x_hrs_o_sum_peak_x_hrs"] = (
        finalDf["sum_metric_x_hrs"] / finalDf["sum_peak_x_hrs"]
    )

    finalDf = finalDf[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "adjusted",
            "summary_of",
            "peak",
            "average",
            "sum_peak_x_hrs",
            "sum_metric_x_hrs",
            "sum_peak_x_hrs_m_sum_metric_x_hrs",
            "sum_metric_x_hrs_o_sum_peak_x_hrs",
            "hrs",
            "cdb_target_guid",
        ]
    ]

    finalDf["cwd"] = cwd
    finalDf["platform"] = platformName
    finalDf["extract_dttm_utc"] = extract_dttm_utc
    finalDf["create_dttm_utc"] = now
    finalDf["source"] = SOURCE
    finalDf["version"] = __version__

    finalDf = finalDf.round(PRECISION)

    filename = sizingFilePath + os.sep + "sizing.csv"
    finalDf.sort_values(
        ["cdb_cohort", "cdb", "metric", "adjusted", "summary_of"]
    ).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    # ---

    pDf = pd.pivot_table(
        pctDf, index=["cdb_cohort", "cdb"], columns="metric", values="max"
    ).reset_index()
    pDf.rename(columns={"cdb_cohort": "Cohort", "cdb": "Name"}, inplace=True)

    snapCountDf = pctDf.groupby(["cdb"], as_index=False)["count"].max()
    snapCountDf.columns = ["Name", "Hours"]

    if len(cdbInstancesIncludedDf) == 0:
        pDf["Instances Included"] = 0
    else:
        pDf = pd.merge(
            left=pDf,
            right=cdbInstancesIncludedDf[["Name", "Instances Included"]],
            how="left",
            left_on=["Name"],
            right_on=["Name"],
        )
        pDf["Instances Included"] = pDf["Instances Included"].fillna(0)

    if len(cdbInstancesExcludedDf) == 0:
        pDf["Instances Excluded"] = 0
    else:
        pDf = pd.concat([pDf, cdbInstancesExcludedDf], ignore_index=True)
        pDf["Instances Included"] = pDf["Instances Included"].fillna(0)
        pDf["Instances Excluded"] = pDf["Instances Excluded"] .fillna(0)

    pDf = pd.merge(
        left=pDf, right=dbHoursDf, how="left", left_on=["Name"], right_on=["Name"]
    )

    pDf["Adjusted Values"] = "N"
    pDf["Rollup Type"] = "AVERAGE"
    pDf["Time Unit"] = "HOURLY"
    pDf["Time Period"] = "3"
    pDf["DB vCPU for Standby"] = pDf["DB vCPU"]
    pDf["DB IOPS for Standby"] = pDf["DB IOPS"]

    if "Allocated Storage (GB)" not in pDf:
        pDf["Allocated Storage (GB)"] = 0
    if "Used Storage (GB)" not in pDf:
        pDf["Used Storage (GB)"] = 0

    pDf = pDf[
        [
            "Cohort",
            "Name",
            "Rollup Type",
            "Time Unit",
            "Time Period",
            "Adjusted Values",
            "Instances Included",
            "Instances Excluded",
            "Hours",
            "Allocated Storage (GB)",
            "Used Storage (GB)",
            "DB vCPU",
            "DB vCPU for Standby",
            "DB PGA (MB)",
            "DB SGA (MB)",
            "DB Memory (MB)",
            "DB IOPS",
            "DB IOPS for Standby",
            "DB Logons",
        ]
    ]

    pDf["cwd"] = cwd
    pDf["platform"] = platformName
    pDf["extract_dttm_utc"] = extract_dttm_utc
    pDf["create_dttm_utc"] = now
    pDf["source"] = SOURCE
    pDf["version"] = __version__

    filename = sizingFilePath + os.sep + "database_rollups.csv"

    # Drop from database_rollups.csv cohorts stated in ROLLUP_CSV_FILES_SUPRESSED_COHORTS
    for cohort in ROLLUP_CSV_FILES_SUPRESSED_COHORTS:
        pDf = pDf[(pDf.Cohort != cohort)]

    # Drop from database_rollups.csv empty cohorts
    pDf = pDf.dropna(axis=0, subset=["Cohort"])

    pDf.sort_values(["Cohort", "Name"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)
    lg("   Excluding cohorts " + ",".join(ROLLUP_CSV_FILES_SUPRESSED_COHORTS))

    dbHourlySumDf.rename(
        columns={"value": "AVERAGE", "end_hh24_UTC": "ROLLUP_TIMESTAMP_UTC"},
        inplace=True,
    )

    # ---

    cpuDf = dbHourlySumDf[
        dbHourlySumDf["metric"] == EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC]
    ][["cdb", "ROLLUP_TIMESTAMP_UTC", "AVERAGE"]].copy()
    aboveCountDf = []
    missingDbs = []

    for cpu in range(0, int((cpuDf[["AVERAGE"]].max() + 2).iloc[0])):
        for incr in range(10):
            if cpu > 1 and incr > 0:
                continue

            cpuMin = (cpu * 1.0) + (incr / 10.0)
            cpuDbsDf = dbCPUCountsDf[dbCPUCountsDf["logical_cpu_count"] >= cpuMin][
                ["cdb"]
            ]

            if len(cpuDbsDf) == 0:
                break

            if cpuMin == 0:
                lg(
                    "\nCounting core hours for a list of "
                    + str(len(cpuDbsDf))
                    + " databases..."
                )

            countDf = (
                cpuDf[
                    (cpuDf["cdb"].isin(cpuDbsDf["cdb"])) & (cpuDf["AVERAGE"] > cpuMin)
                ]
                .groupby(["cdb"], as_index=False)["AVERAGE"]
                .count()
            )

            if len(countDf) == 0:
                countDf = cpuDbsDf[~cpuDbsDf["cdb"].isin(missingDbs)][["cdb"]].copy()
                if len(countDf) > 0:
                    countDf["AVERAGE"] = 0
            else:
                missingDf = cpuDbsDf[
                    ~cpuDbsDf["cdb"].isin(countDf["cdb"])
                ].drop_duplicates()
                missingDf = missingDf[~missingDf["cdb"].isin(missingDbs)]

                if len(missingDf) > 0:
                    missingDbs += missingDf["cdb"].tolist()
                    missingDf["AVERAGE"] = 0
                    countDf = pd.concat([countDf, missingDf], ignore_index=True)

            if len(countDf) > 0:
                countDf.rename(columns={"cdb": "Name", "AVERAGE": "Hrs"}, inplace=True)
                countDf["GT vCPU Count"] = cpuMin
                aboveCountDf = (
                    countDf
                    if len(aboveCountDf) == 0
                    else pd.concat([aboveCountDf, countDf])
                )

    if len(aboveCountDf) > 0:
        aboveCountDf["Adjusted Values"] = "N"
        aboveCountDf["Rollup Type"] = "AVERAGE"
        aboveCountDf["Time Unit"] = "HOURLY"
        aboveCountDf["Time Period"] = 3

        aboveCountDf = aboveCountDf[
            [
                "Name",
                "Rollup Type",
                "Time Unit",
                "Time Period",
                "Adjusted Values",
                "GT vCPU Count",
                "Hrs",
            ]
        ]
        aboveCountDf["cwd"] = cwd
        aboveCountDf["platform"] = platformName
        aboveCountDf["extract_dttm_utc"] = extract_dttm_utc
        aboveCountDf["create_dttm_utc"] = now
        aboveCountDf["source"] = SOURCE
        aboveCountDf["version"] = __version__

        filename = sizingFilePath + os.sep + "database_vcpu_hours.csv"
        aboveCountDf.sort_values(["Name", "GT vCPU Count"]).to_csv(
            filename, index=False
        )

        lg("\nWrote file " + filename)
        lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    # ---

    if PLOT_HTML or PLOT_PNG:
        plotMetrics(dbHourlySumDf, snapDf, cohortHoursDf)

    lg(
        "\n\nAll files written to directories rooted @ "
        + (cwd if ROOT_DIR == "." else ROOT_DIR)
    )
    lg(
        "\nThe processing of "
        + str(len(snapDf))
        + " rows completed in "
        + str(round(time.time() - startTime, 3))
        + " s"
    )

    lg("\nEnd @ " + datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S") + " UTC\n")

    close_Log()


if __name__ == "__main__":
    main()

