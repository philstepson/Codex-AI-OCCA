# Set the following to True to produce files suitable for diff comparisons

FIXED = False
# FIXED=True

# The following parameters control spreadsheet file production

# CREATE_OBFUSCATED_FILES=True
CREATE_OBFUSCATED_FILES = False

# CREATE_SIMULATOR_FILES_ONLY=True
CREATE_SIMULATOR_FILES_ONLY = False

#
# Use the following parameter to limit analysis to specific environment(s)
#

COHORTS = []
# COHORTS=['DEV6']

#
# Use the following to control whether or not CPU saturation is considered when
# computing DB vCPU consumption
#

COMPUTE_EFFECTIVE_VCPU = False
COMPUTE_EFFECTIVE_VCPU = True

#
# vCPU cut-off for integer run rate counts
#

MAX_INTEGER_VCPU = 2

#
# Use the following parameter to determine wether or not to plot adjustment multiplier charts
#

PLOT_ADJUSTMENT_MULTIPLIERS = True
# PLOT_ADJUSTMENT_MULTIPLIERS=False

#
# Use the following parameter to determine whether or not sum of max values are plotted on charts
#

PLOT_SUM_OF_MAX = True
PLOT_SUM_OF_MAX = False

#
# Use the following parameter to limit how many instances can be plotted in the area chart
# A value of 0, prevents all area charts from being plotted
#

PLOT_INSTANCE_COUNT_LIMIT = 50
# PLOT_INSTANCE_COUNT_LIMIT=0

#
# Use the following parameter to plot individual graphs for each database and limit how many DBs will be plotted
#
PLOT_INDIVIDUAL_DB = False
PLOT_INDIVIDUAL_DB_LIMIT = 20
#
# Use the following parameter to control which output formats are used to save plots
# If both are False, no plots will be produced
#

PLOT_HTML = True
# PLOT_HTML=False

PLOT_PNG = True
PLOT_PNG = False

#
# Use the following parameter to control whether or not percentiles are plotted on time series charts
#

PLOT_PERCENTILES = True
# PLOT_PERCENTILES=False

#
# Use the following parameter to suppress the plots for cohorts that lead to plotly crashes
#

PLOT_SUPPRESSED_COHORTS = ["excluded", "unassigned"]
# PLOT_SUPPRESSED_COHORTS=['DEV_IV2', 'PROD7']

#
# Use the following parameter determine whether or not to plot unadjusted values
#

PLOT_UNADJUSTED_VALUES = False

#
# Number of digits to which to round calculated fields
#

PRECISION = 3

#
# Default vCPU & IOPS multiplier for standby consumption
#

PHYSICAL_STANDBY_PCT = 20

#
# Use the following parameter to control which daily time periods are used to adjust hourly averages
#

TIME_PERIODS = ["03", "06", "09", "12"]
# TIME_PERIODS=['03']
# TIME_PERIODS=[]

#
# Enable or not yearly_adjustements on PLOTS
#

PLOTS_ADJUSTED_YEARLY_VALUES = False

#
# Use the following parameter to suppress cohorts from rollup csv files
#

ROLLUP_CSV_FILES_SUPRESSED_COHORTS = ["excluded", "unassigned"]

#
# Use the following parameter to set the minimum overlap in days for databases within the same Cohort
#

OVERLAP_DAYS_WITHIN_A_COHORT = 7

# plots created from awr-run
TRIMMED_GRAPH = False

"""
‼️⚠️‼️ Please Read ‼️⚠️‼️

If you want to preserve your changes, please create the following file at the same level as occa_Sizing_Parameters.py:
`occa_Sizing_Parameters_local.py` you can copy and paste the content of occa_Sizing_Parameters.py

Example structure:
|- occa_Sizing_Parameters.py
|- occa_Sizing_Parameters_local.py

In the `occa_Sizing_Parameters_local.py` file, you can override any of the default variables from `occa_Sizing_Parameters.py`.

For example, if `occa_Sizing_Parameters.py` contains:
    OVERLAP_DAYS_WITHIN_A_COHORT = 7
    PLOTS_ADJUSTED_YEARLY_VALUES = False
    
You can modify or override these variables by creating `occa_Sizing_Parameters_local.py` with:
    OVERLAP_DAYS_WITHIN_A_COHORT = 6
    PLOTS_ADJUSTED_YEARLY_VALUES = True

"""

try:
    from occa_Sizing_Parameters_local import *
except ImportError:
    pass
