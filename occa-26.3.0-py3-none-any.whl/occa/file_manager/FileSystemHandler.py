import os
import shutil
from pathlib import Path
import tarfile
import zipfile
import rarfile
import json

class DirectoryHandler:
    @staticmethod
    def make_directories(path_directory):
        """
        Create directories if they do not exist already.
        made by this to be compatible with python 2.7

        Parameters:
        - path_directory (str): The path to the directory to be created.

        Returns:
        - None
        """
        if not os.path.exists(path_directory):
            os.makedirs(path_directory)

    @staticmethod
    def find_parent_directory(target_dir_name, max_depth=5):
        current_dir = Path.cwd()
        depth = 0

        while depth < max_depth:
            if current_dir.name == target_dir_name and current_dir.exists():
                return current_dir

            current_dir = current_dir.parent
            depth += 1
        # raise FileNotFoundError(f"Directory {target_dir_name} does not exist within the first {max_depth} levels of depth.")

    @staticmethod
    def delete_directory(directory: Path) -> None:
        """
        Delete the specified directory and all its contents if it exists.

        Parameters:
            directory (Path): The path to the directory to be deleted.
        """
        if directory.exists():
            shutil.rmtree(directory)
    @staticmethod
    def detelete_file(file : Path) -> None:
        """
        Deletes the file, if exists

        Parameters
        ----------
        file : Path

        Returns
        -------
        None
        """

        if file.exists():
            os.remove(file)
    @staticmethod
    def move_file(file: Path, destination_directory: Path) -> None:
        """
        Move a file to the specified destination directory.

        Parameters:
            file (Path): The path to the file to be moved.
            destination_directory (Path): The path to the destination directory.
        """
        destination_path = destination_directory / file.name
        shutil.move(file, destination_path)

    @staticmethod
    def extract_file(directory, output_filename):
        if zipfile.is_zipfile(output_filename):
            with zipfile.ZipFile(output_filename, 'r') as zip_ref:
                zip_ref.extractall(directory)
        elif tarfile.is_tarfile(output_filename):
            with tarfile.open(output_filename, 'r') as tar_ref:
                tar_ref.extractall(directory)
        elif rarfile.is_rarfile(output_filename):
            with rarfile.RarFile(output_filename, 'r') as rar_ref:
                rar_ref.extractall(directory)
        else:
            raise ValueError(f"Unsupported file format: {output_filename}")

        os.remove(output_filename)
    def read_json(target_json: Path):
        with open(target_json, 'r') as json_file:
            json_data = json.load(json_file)
        return json_data

    @staticmethod
    def get_extracts_dir(customer_directory : Path, filename : str) -> Path:
        """
        Parameters
        ----------
        customer_directory : Path
            The customer directory
        filename : str
            The filename of the extracts

        Returns
        -------
            The filename without the extension as a Path
        """


        return customer_directory / filename.split('.')[0]

    @staticmethod
    def write_binary(path: Path, binary: bytes) -> None:
        """
        Writes binary data to a file.

        Parameters
        ----------
        path : Path
            The path where the binary data is going to be written.
        binary : bytes
            The binary data to write.

        Returns
        -------
        None

        """
        with open(path, 'wb') as file:
            file.write(binary)
    @staticmethod
    def directory_structure_exists(main_dir, subdirs):
        """
        Checks if the main directory and subdirectories exist.

        Parameters:
        main_dir : Path
            The main directory to check.
        subdirs : list[str]
            A list of subdirectory names to check within the main directory.

        Returns:
        bool: True if the structure exists, False otherwise.
        """
        # If the main directory doesn't exists there's no need to keep looking the O(n) n:subdirs
        if not main_dir.exists():
            return False

        # Needed all the subdirs to exists to continue the process
        return all((main_dir / subdir).exists() for subdir in subdirs)

    @staticmethod
    def prune_empty_dirs(directory: Path):
        for root, dirs, files in os.walk(directory, topdown=False):
            for dir in dirs:
                dir_path = Path(root) / dir
                if not os.listdir(dir_path):
                    print(f"Removing empty directory: {dir_path}")
                    os.rmdir(dir_path)