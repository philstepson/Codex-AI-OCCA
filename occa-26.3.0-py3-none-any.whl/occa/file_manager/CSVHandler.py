import pandas
import pandas as pd
from datetime import datetime
import oracledb
from pathlib import Path
from pandas.api.types import is_numeric_dtype

from occa.backend.api_utils.queries import *
from occa.backend.api_utils.database import DatabaseManager
from constants.Paths import FilePaths as fp


class CSVHandler:

    def __init__(self, table_name: str, columns: list, csv_file_path: Path, has_audit: bool, **kwargs):
        """
        Initialize the CSVHandler with table name, columns, and additional parameters.

        Parameters
        ----------
        table_name : str
            Name of the target table.
        columns : list
            Columns names.
        csv_file_path: Path
            The path to the CSV file.
        has_audit : bool
            Flag to include audit columns.
        kwargs : dict
            Additional parameters such as created_by, foreign keys, etc.
        """
        # print(kwargs)
        self.table_name = table_name
        self.extra_info = kwargs
        self.columns = columns
        self.csv_file_path = csv_file_path
        self.has_audit = has_audit

        commit_type = self.extra_info.get('commit_type', 'insert')
        if commit_type == 'update':
            self.commit_strategy = self.update_strategy
        else:
            self.commit_strategy = self.insert_strategy

    def setup_config(self, table_name: str, columns: list, csv_file_path: Path, has_audit: bool = False, **kwargs):
        """
        Setup configuration for the CSVHandler.

        Parameters
        ----------
        table_name : str
            Name of the target table.
        columns : list
            Column names.
        csv_file_path : str
            Path to the CSV file.
        has_audit : bool
            Flag indicating if audit columns should be included.
        kwargs : dict
            Additional parameters such as created_by, foreign keys, etc.
        """
        self.table_name = table_name
        self.columns = columns
        self.csv_file_path = csv_file_path
        self.has_audit = has_audit
        self.extra_info = kwargs



    def _normalize(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Fill strings, convert numerics to None for NULLs.
        """
        # Fill object (string) columns with empty str
        for col in df.columns:
            if df[col].dtype == 'object':
                df[col] = df[col].fillna('')
            else:
                # non-object: replace NaN with None
                df[col] = df[col].where(df[col].notnull(), None)

        # Convert pandas dtypes to best possible
        df = df.convert_dtypes()
        # Fill new string dtype columns
        str_cols = df.select_dtypes(include=['string']).columns
        df[str_cols] = df[str_cols].fillna('')

        # Numeric dtype → object with None for nulls
        for col in df.columns:
            if is_numeric_dtype(df[col]):
                df[col] = df[col].astype(object).where(df[col].notna(), None)

        return df

    def _dispatch_handle(self):
        if self.table_name == EXTRACTS_EMCC_PROPERTIES_INSTANCES:
            self.handle_emcc_properties_instances_data()
        elif self.table_name == EXTRACTS_PROPERTIES_DATABASE:
            self.handle_awr_properties_data()
        elif self.table_name == EXTRACTS_EMCC_OUTPUT_SERVER:
            self.handle_emcc_output_server_data()
        elif self.table_name == EXTRACTS_EMCC_PROPERTIES_DATABASE_METADATA:
            self.handle_emcc_properties_database_metadata()
        elif self.table_name == EXTRACTS_ANALYSIS_SNAP_RANGE_DATA:
            self.handle_analysis_snap_range_data()

    def insert_strategy(self, cursor: oracledb.Cursor):
        self.from_csv_insert_table(cursor)

    def update_strategy(self, cursor: oracledb.Cursor):

        if 'columns_to_update' not in self.extra_info :
            raise ValueError('needed keys to update')

        update_cols = self.extra_info['columns_to_update']
        upload_id = self.extra_info['upload_id']
        id_column = self.extra_info['id_column']  # e.g. 'DB_NAME' or 'INSTANCE_NAME'
        # DB_NAME for propertiesdb and INSTANCE_NAME for properties instances

        # update TABLE SET
        # COL1 = :COL1
        # COL2 = :COL2
        # COL3 = :COL3
        # WHERE upload_id = :upload_id and DB_NAME = :DB_NAME
        sql =  DatabaseManager.format_generic_update_query(
            self.table_name,
            update_cols,
            ['upload_id', id_column]
        )

        binds_list = []

        for _, row in self.df.iterrows():
            # Map update columns to values
            bind = {col: (row[col] if pd.notna(row[col]) else None) for col in update_cols}
            # Key column value come from the CSV row
            bind[id_column] = row[id_column]
            bind['upload_id'] = upload_id
            binds_list.append(bind)
        cursor.executemany(sql, binds_list)
        cursor.close()

        # cursor.executemany(sql, binds_list)

    def load_csv_to_oracle(self, connection: oracledb.Connection):
        """
        Load a CSV file into a table.

        Parameters
        ----------
        connection : oracledb.Connection
            Oracle database connection object.

        Returns
        -------
        None

        Raises
        ------
        Exception
            If an unspecified error occurs.
        """
        try:
            print(f'Loading CSV table process {self.table_name}'.center(50, '-'))
            ACTION = self.extra_info.get('commit_type', 'insert')
            print(f'Performing: {ACTION}'.center(50, '-'))
            self.df = pd.read_csv(self.csv_file_path)
            # Before replacing the columns with the mapping (see mapping on the right side is how came from CSV)
            # if self.table_name == EXTRACTS_EMCC_PROPERTIES_INSTANCES:
            #     self.handle_emcc_properties_instances_data(df)
            # elif self.table_name == EXTRACTS_PROPERTIES_DATABASE:
            #     self.handle_awr_properties_data(df)
            # elif self.table_name == EXTRACTS_EMCC_OUTPUT_SERVER:
            #     self.handle_emcc_output_server_data(df)
            # df = df.fillna('')
            self._dispatch_handle()
            # for col in df.columns:
            #     if df[col].dtype == 'object':
            #         df[col] = df[col].fillna('')
            #     else:
            #         df[col] = df[col].where(df[col].notnull(), None)
            #
            # from pandas.api.types import is_numeric_dtype
            # df = df.convert_dtypes()
            # df[df.select_dtypes(include=['string']).columns] = df.select_dtypes(include=['string']).fillna('')
            # for col in df.columns:
            #     if is_numeric_dtype(df[col]):
            #         df[col] = df[col].astype(object).where(df[col].notna(), None)
            self.df = self._normalize(self.df)
            # print(df.head())
            self.prepare_data()
            cursor = connection.cursor()
            # self.from_csv_insert_table(df, cursor)
            self.commit_strategy(cursor)
            print(f"Success for UPLOAD_ID: {self.extra_info.get('FOREIGN_KEYS',{}).get('UPLOAD_ID','UNKWNOWN')} :)".center(50,'-'))
            connection.commit()

        except Exception as e:
            connection.rollback()
            # print(f"An error occurred: {e} Rollback")
            raise Exception(f"An error occurred: {e} Rollback")

    def handle_emcc_properties_instances_data(self) -> None:
        column_mapping = {
            'version.1':'version_properties_file'  # there's two version in the instances.csv files
        }
        self.df.rename(columns=column_mapping, inplace=True)

    def make_unique(self, series):
        counts = {}
        result = []

        for item in series:
            if item not in counts:
                counts[item] = 0
                result.append(item)
            else:
                counts[item] += 1
                new_item = f"{item}{counts[item]}"
                result.append(new_item)

        return pd.Series(result)

    def handle_awr_properties_data(self) -> None:
        if self.df['DB_NAME'].is_unique:
            self.df['cdb'] = self.df['DB_NAME']
        else:
            self.df['cdb'] = self.make_unique(self.df['DB_NAME'])

    def handle_emcc_output_server_data(self) -> None:
        column_mapping = {
            'CPU Type':'CPU_TYPE_1'  # there's two version in the instances.csv files
        }
        self.df.rename(columns=column_mapping, inplace=True)
    def handle_analysis_snap_range_data(self) -> None:
        from pandas import to_datetime
        self.df.drop(columns=['Cohort'], inplace=True)

        self._load_hosts_to_analyis_table()

        self.df.columns = self.columns
        #converting the following columns to datetime to match the table description
        date_cols = ["SNAP_BEGIN", "SNAP_END", "SNAP_BEGIN_GMT", "SNAP_END_GMT"]

        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = to_datetime(self.df[col], format="mixed")
    def _load_hosts_to_analyis_table(self):
        os_info_df = pd.read_csv(self.csv_file_path.parents[1] / fp.AWR_OS_INFORMATION)
        os_info_df = os_info_df[os_info_df['STAT_NAME'] == 'HOSTS'][['STAT_VALUE','WHICH_DB']]
        os_info_df = os_info_df.rename(columns={'STAT_VALUE':'HOSTS'})
        self.df = self.df.merge(os_info_df,on='WHICH_DB',how='left')


    def handle_emcc_properties_database_metadata(self) -> None:
        """
        Modify the DataFrame only need the Database Name key
        Returns
        -------

        """
        # self.csv_file_path.parents[1]-> root of the extracts
        structure_db_csv_path = self.csv_file_path.parents[1] / fp.EMCC_SIZING_STRUCTURE_DB_CSV
        structure_db_props_csv_path = self.csv_file_path.parents[1] / fp.EMCC_SIZING_STRUCTURE_DB_PROPS_CSV

        df_structure_db = pd.read_csv(structure_db_csv_path)
        df_structure_db_props = pd.read_csv(structure_db_props_csv_path)

        needed_db_cols = ["dbmachine", "cluster", "cdb", "db_standby_type"]
        df_structure_db = df_structure_db[needed_db_cols]

        # there's many duplicated - cluster - dbmachine I'll
        # take only the ones with less nan values
        df_structure_db = df_structure_db.copy()
        df_structure_db['nan_count'] = df_structure_db.isna().sum(axis=1)
        df_structure_db = df_structure_db.sort_values(['cdb', 'nan_count'])
        df_structure_db_unique = df_structure_db.drop_duplicates(subset=['cdb'], keep='first').drop(columns='nan_count')

        df_structure_db_props_pivot = df_structure_db_props.pivot(
            index="TARGET_NAME",
            columns="NAME",
            values="VALUE"
        ).reset_index().rename(columns={"TARGET_NAME":"cdb"})

        df_final = pd.merge(
            df_structure_db_unique,
            df_structure_db_props_pivot,
            on='cdb',
            how='left'
        )

        df_final["Database Name"] = df_final["cdb"]

        final_cols = [
            "Database Name",  #this is same as cdb target name
            "dbmachine",
            "cluster",
            # "cdb", ? duplicated
            "db_standby_type",
            "orcl_gtp_cost_center",
            "orcl_gtp_department",
            "orcl_gtp_lifecycle_status",
            "orcl_gtp_line_of_bus",
            "orcl_gtp_location"
        ]
        for col in final_cols:
            if col not in df_final.columns:
                df_final[col] = None  # will be -> ""
        self.df = df_final[final_cols]

        # self.df = self.df[['Database Name']]

    def prepare_data(self):
        """
        Prepare data by adding missing columns and audit columns if required.

        Parameters
        ----------
        df : pd.DataFrame
           DataFrame containing the CSV data.
       """
        # for col in self.columns:
        #     if col not in df.columns:
        #         df[col] = None

        print(f'CSVHandler: Preparing data for {self.csv_file_path.name}'.center(50, '-'))

        self.df.columns = self.columns

        if self.extra_info.get('FOREIGN_KEYS'):
            for k, v in self.extra_info.get('FOREIGN_KEYS').items():
                self.df[k] = v

        if self.has_audit:
            self.df["CREATED_ON"] = datetime.now()
            self.df["CREATED_BY"] = self.extra_info.get('CREATED_BY')
            self.df["MODIFIED_ON"] = datetime.now()
            self.df["MODIFIED_BY"] = self.extra_info.get('CREATED_BY')

    def from_csv_insert_table(self ,cursor):
        """
        Insert data from DataFrame into Oracle table.

        Parameters
        ----------
        df : pd.DataFrame
            DataFrame containing the prepared data.
        cursor : oracledb.Cursor

        """

        # Adding the following to prevent double insertion when runnig from api /download_file/id
        if 'FOREIGN_KEYS' in self.extra_info and 'UPLOAD_ID' in self.extra_info['FOREIGN_KEYS']:
            upload_id = self.extra_info['FOREIGN_KEYS']['UPLOAD_ID']
            check_query = f"SELECT COUNT(*) FROM {self.table_name} where upload_id={upload_id}"
            cursor.execute(check_query)
            count = cursor.fetchone()
            if count and count[0] > 0:
                print(f'Table {self.table_name} already has data - no need to insert again')
                cursor.close()
                return
        columns = ', '.join([f'"{col}"' for col in self.df.columns])
        # columns = ' ,'.join(df.columns)
        values = ', '.join([':' + str(i + 1) for i in range(len(self.df.columns))])

        query = INSERT_COLUMN_VALUES.format(table_name=self.table_name, columns=columns, values=values)
        print(f'Inserting into {self.table_name}'.center(50, '-'))
        data = [tuple(row) for row in self.df.itertuples(index=False, name=None)]
        cursor.executemany(query, data)
        print(f'CSV: {self.csv_file_path.name} inserted into {self.table_name}')
        # cursor.connection.commit()
        cursor.close()


# csv_handler.table_name = 'EXTRACTS_DATABASE_TZ_INFO'
# csv_handler.columns = EXTRACTS_DATABASE_TZ_INFO_COLUMNS
