#!/usr/bin/python
import os
import sys
import tempfile
import logging
import time
from io import StringIO
from pathlib import Path
import rich

import oracledb
import uvicorn
from fastapi import FastAPI

from fastapi_utils.tasks import repeat_every
from html2image import Html2Image

import awr_miner_parse
import version

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Main API object
app = FastAPI()

# Database data, but don't connect on import
connect_string = ""
if "CONNECT_OCCAPROD" in os.environ:
    connect_string = os.environ["CONNECT_OCCAPROD"]
connection: oracledb.Connection = None


def init_database_connection():
    global connection
    if not connection:
        try:
            connection = oracledb.connect(connect_string)
        except oracledb.OperationalError as e:
            # Cannot connect
            print(f"Oracle exception: {e}")
            raise


@app.get("/")
def root():
    return {
        "occa_version": version.version,
        "ooca_path": str(Path(__file__).parent.resolve()),
    }


@app.get("/awr/parse")
def awr_parse():
    new_stdout = StringIO()
    sys.stdout = new_stdout
    sys.argv = ["awr_miner_parse.py", "-v"]
    awr_miner_parse.main()
    sys.stdout = sys.__stdout__
    return {"stdout": new_stdout.getvalue()}


@app.get("/awr/plot")
def awr_plot():
    new_stdout = StringIO()
    sys.stdout = new_stdout

    # Importing this file will run code
    import awr_miner_plot

    sys.stdout = sys.__stdout__
    return {"stdout": new_stdout.getvalue()}


@app.get("/util/render")
def render_image(html_path: Path, output_path: Path):
    hti = Html2Image(
        # custom_flags=["--use-gl=angle"],
        size=(2000, 1200),
        output_path=str(output_path),
    )
    output_filename = hti.screenshot(html_file=str(html_path))
    return output_filename


@app.get("/util/renderall")
def render_all_opportunity(limit=100):
    init_database_connection()
    rich.print(connection)
    cursor = connection.cursor()
    rich.print(cursor)
    cursor.execute(
        """
        select id from plots_html 
        where rendered_image is null 
        order by created_on desc
        fetch first :limit rows only 
        """,
        limit=limit,
    )
    all_rows = cursor.fetchall()
    with tempfile.TemporaryDirectory() as tempdir:
        tempdir_path = Path(tempdir)
        hti = Html2Image(
            # custom_flags=["--disable-3d-apis"],
            size=(2000, 1200),
            output_path=str(tempdir_path),
        )
        rich.print(hti)
        rich.print(f"l: {len(all_rows)}")
        for row in all_rows:
            try:
                plot_id = row[0]
                rich.print(f"Rendering for {plot_id}")
                output_filename = render_image_in_db(plot_id, tempdir_path, hti)
                if output_filename is not None:
                    update_rendered_image_in_db(plot_id, tempdir_path)
            except TypeError as e:
                rich.print(f"Thrown exception for {plot_id}: {str(e)}")
                # Keep going to next one


# @app.get("/util/renderopp")
# def render_opportunity(opp_id: str):
#     init_database_connection()
#     cursor = connection.cursor()
#     cursor.execute(
#         """
#         select id from plots_html where opp_id = :opp_id
#         """,
#         opp_id=opp_id,
#     )
#     all_rows = cursor.fetchall()
#     hti = Html2Image(
#         custom_flags=["--disable-3d-apis"],
#         size=(2000, 1200),
#         output_path=str(output_path),
#     )
#
#     with tempfile.TemporaryDirectory() as tempdir:
#         tempdir_path = Path(tempdir)
#         for row in all_rows:
#             plot_id = row[0]
#             logger.info(f"Rendering for {plot_id}")
#             render_image_in_db(plot_id, tempdir_path, hti)
#             update_rendered_image_in_db(plot_id, tempdir_path)


def render_image_in_db(plots_html_id: str, output_path: Path, html2image_library):
    init_database_connection()

    # Get html from database
    cursor = connection.cursor()
    cursor.execute(
        """
        select file_content from plots_html where id = :1
        """,
        [plots_html_id],
    )
    (image_html,) = cursor.fetchone()
    if image_html is None:
        return None

    # Create PNG image

    output_filename = html2image_library.screenshot(
        html_str=image_html, save_as=f"{plots_html_id}.png"
    )

    # Put image in database
    return output_filename


def update_rendered_image_in_db(plots_html_id: str, output_path: Path):
    init_database_connection()

    # Load image into memory
    image_path = output_path / f"{plots_html_id}.png"
    image_data = image_path.read_bytes()

    # Update database
    cursor = connection.cursor()
    cursor.execute(
        """
        update plots_html set rendered_image = :image_data where id = :plot_id
        """,
        plot_id=plots_html_id,
        image_data=image_data,
    )
    connection.commit()


# Run for debugging
if __name__ == "__main__":
    if len(sys.argv) > 1:
        first_arg = sys.argv[-1]
        if first_arg == "render":
            print("Starting Render loop...")
            while True:
                print("Rendering images...")
                render_all_opportunity(100)
                print("Sleeping for 60 sec until next image")
                time.sleep(60)
            exit(0)
        elif first_arg == "crontab":
            print("Starting Rendering process")
            render_all_opportunity(100)
            print("Ending Rendering process")
            exit(0)

    # To run as a service, you should just be able to execute this python file
    uvicorn.run(app, host="occa.us.oracle.com", port=8123)
