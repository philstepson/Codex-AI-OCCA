from plots.plot_factory import PlotFactory
from plots.plot_builder import MetricPlotBuilder
from plots.plot_utils import serialize_plots
from constants.Paths import FilePaths
from pandas_helpers.pandas_data_utils import *

# ----------------------------------------------------------------------------------------------------------------------

DB_METRICS_FILE = "emcc_sizing_metrics_db_hourly_03_months.csv"
HOST_METRICS_FILE = "emcc_sizing_metrics_host_hourly_03_months.csv"

PERCENTILES = [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 0.99]

HEIGHT = 1185
WIDTH = 1920

USE_CDB_HOURLY_OVERRIDES = True

SOURCE = "EMCC"

# ----------------------------------------------------------------------------------------------------------------------

import logging
import argparse
import datetime
import os
import platform
import shutil
import sys
import time

import numpy as np
import pandas as pd

import Duplicate_Tests
from occa_Shared import *
from pandas_helpers.pandas_data_utils import  *
from version import version, __version__

from pathlib import Path

# ----------------------------------------------------------------------------------------------------------------------

func_logger = logging.getLogger(__name__)

argparser = argparse.ArgumentParser(
    prog="occa_Run_Metric_Analysis.py",
    description="Prepare occa upload files from emcc metric extracts",
)

argparser.add_argument(
    "-c",
    "--checkmetrics",
    type=str,
    action="store",
    nargs="*",
    help="Check metric presence status only",
)
argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="Print the parameters used by the script",
)
argparser.add_argument(
    "-d",
    "--debugcdb",
    type=str,
    required=False,
    default="",
    help="csv-separated list of cdbs to print debugging message for, e.g. DB1,DB2",
)
argparser.add_argument(
    "-m",
    "--metriccdb",
    type=str,
    required=False,
    default="",
    help="csv-separated list of cdbs whose metrics will be captured in .csv files",
)
argparser.add_argument(
    "-w",
    "--writedebug",
    type=str,
    required=False,
    default="",
    help="Y to write debugging files",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + " version: " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

#
# This script depends on a setting for the parameters shown below
# Values for these parameters will be read from the parameter file
#

# CREATE_OBFUSCATED_FILES=True
CREATE_OBFUSCATED_FILES = False

# CREATE_SIMULATOR_FILES_ONLY=True
CREATE_SIMULATOR_FILES_ONLY = False

COHORTS = []

PLOT_ADJUSTMENT_MULTIPLIERS = False

PLOT_INSTANCE_COUNT_LIMIT = 500

PLOT_HTML = True
PLOT_PNG = False

PLOT_PERCENTILES = False

PLOT_SUM_OF_MAX = False

PLOT_INDIVIDUAL_DB = False
PLOT_INDIVIDUAL_DB_LIMIT = 20

PLOT_SUPPRESSED_COHORTS = []

PLOT_UNADJUSTED_VALUES = False

COMPUTE_EFFECTIVE_VCPU = True

PRECISION = 3
PHYSICAL_STANDBY_PCT = 20

TIME_PERIODS = ["03", "06", "09", "12"]

FIXED = False

MAX_INTEGER_VCPU = 2

PLOTS_ADJUSTED_YEARLY_VALUES = False

ROLLUP_CSV_FILES_SUPRESSED_COHORTS = []

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ---

CREATE_OBFUSCATED_FILES = (CREATE_OBFUSCATED_FILES) or (
    "CREATE_OBFUSCATED_FILES" in os.environ
    and os.environ["CREATE_OBFUSCATED_FILES"].upper() == "TRUE"
)
CREATE_SIMULATOR_FILES_ONLY = (CREATE_SIMULATOR_FILES_ONLY) or (
    "CREATE_SIMULATOR_FILES_ONLY" in os.environ
    and os.environ["CREATE_SIMULATOR_FILES_ONLY"].upper() == "TRUE"
)

# ----------------------------------------------------------------------------------------------------------------------


def obfuscateDf(cdbs, hosts, dbs):
    cdbs.replace({"Database Name": cdbDict}, inplace=True)
    dbs.replace({"Database": cdbDict}, inplace=True)

    hosts.replace({"Server Name": hostDict}, inplace=True)
    dbs.replace({"Server": hostDict}, inplace=True)

    if "Original Server" in dbs:
        dbs.replace({"Original Server": hostDict}, inplace=True)

    dbs.replace({"Instance": instanceDict}, inplace=True)

    hosts.replace({"cluster": cdbClusterDict}, inplace=True)
    cdbs.replace({"cluster": cdbClusterDict}, inplace=True)
    dbs.replace({"cluster": cdbClusterDict}, inplace=True)

    cdbs.replace({"cdb_owner": cdbOwnerDict}, inplace=True)
    dbs.replace({"cdb_owner": cdbOwnerDict}, inplace=True)

    hosts.replace({"dbmachine": dbmachineDict}, inplace=True)
    cdbs.replace({"dbmachine": dbmachineDict}, inplace=True)
    dbs.replace({"dbmachine": dbmachineDict}, inplace=True)

    hosts.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    cdbs.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    dbs.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)


# ----------------------------------------------------------------------------------------------------------------------


def missingDatabaseMetricCount(row):
    rv = 0
    for _ in EMCC_STORAGE_METRICS:
        if _ not in row:
            rv += 1

        elif row[_] == 0:
            rv += 1

    return rv


# ----------------------------------------------------------------------------------------------------------------------


def missingInstanceMetricCount(row):
    rv = 0
    for _ in EMCC_INSTANCE_REQUIRED_METRICS:
        if _ not in row:
            rv += 1

        elif row[_] == 0 or  pd.isna(row[_]):
            rv += 1

    return rv


# ----------------------------------------------------------------------------------------------------------------------


def getMetricStageCounts(stage, filePrefix, final=False):
    global instanceHourlyMetricsDf, cdbHourlyStorageMetricsDf
    WRITE_INTERMIEDIATE_FILES = False

    instanceHourlyCountsDf = (
        instanceHourlyMetricsDf.groupby(
            ["cdb", "db", "cdb_target_guid", "db_target_guid", "metric"], as_index=False
        )
        .agg({"ROLLUP_TIMESTAMP_UTC": ["min", "max"], "SAMPLE_COUNT": "sum"})
        .reset_index()
    )
    instanceHourlyCountsDf.columns = [
        "i",
        "cdb",
        "db",
        "cdb_target_guid",
        "db_target_guid",
        "metric",
        "ROLLUP_TIMESTAMP_UTC_min",
        "ROLLUP_TIMESTAMP_UTC_max",
        "SAMPLE_COUNT",
    ]
    instanceHourlyCountsDf.drop(columns=["i"], inplace=True)

    if WRITE_INTERMIEDIATE_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + filePrefix
            + ".instance_hourly_counts.summary."
            + ln()
            + ".csv"
        )
        instanceHourlyCountsDf.sort_values(["db", "metric"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    # ---

    cdbHourlyCountsDf = (
        cdbHourlyStorageMetricsDf.groupby(
            ["cdb", "cdb_target_guid", "metric"], as_index=False
        )
        .agg({"ROLLUP_TIMESTAMP_UTC": ["min", "max"], "SAMPLE_COUNT": "sum"})
        .reset_index()
    )
    cdbHourlyCountsDf.columns = [
        "i",
        "cdb",
        "cdb_target_guid",
        "metric",
        "ROLLUP_TIMESTAMP_UTC_min",
        "ROLLUP_TIMESTAMP_UTC_max",
        "SAMPLE_COUNT",
    ]
    cdbHourlyCountsDf.drop(columns=["i"], inplace=True)

    if len(cdbHourlyCountsDf) == 0:
        _ = instanceHourlyCountsDf[["cdb", "cdb_target_guid"]].drop_duplicates()
        _["metric"] = STORAGE_ALLOCATED_METRIC
        _["SAMPLE_COUNT"] = np.nan

        cdbHourlyCountsDf = _.copy()
        _["metric"] = STORAGE_USED_METRIC
        cdbHourlyCountsDf = pd.concat([cdbHourlyCountsDf, _], ignore_index=True)

        cdbHourlyCountsDf["ROLLUP_TIMESTAMP_UTC_min"] = now
        cdbHourlyCountsDf["ROLLUP_TIMESTAMP_UTC_max"] = now

    if WRITE_INTERMIEDIATE_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + filePrefix
            + ".cdb_hourly_counts.summary."
            + ln()
            + ".csv"
        )
        cdbHourlyCountsDf.sort_values(["cdb", "metric"]).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    cdbHourlyCountsDf = pd.merge(
        left=cdbHourlyCountsDf,
        right=instanceHourlyCountsDf[
            ["cdb_target_guid", "db_target_guid", "db"]
        ].drop_duplicates(),
        how="left",
        left_on=["cdb_target_guid"],
        right_on=["cdb_target_guid"],
    )
    cdbHourlyCountsDf = cdbHourlyCountsDf[instanceHourlyCountsDf.columns]

    if WRITE_INTERMIEDIATE_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + filePrefix
            + ".cdb_hourly_counts.summary."
            + ln()
            + ".csv"
        )
        cdbHourlyCountsDf.sort_values(["cdb", "metric"]).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    # ---

    pDf = pd.pivot_table(
        pd.concat([cdbHourlyCountsDf, instanceHourlyCountsDf], ignore_index=True),
        index=["cdb", "db", "cdb_target_guid", "db_target_guid"],
        columns=["metric"],
        values=["SAMPLE_COUNT"],
        aggfunc="count",
        fill_value=0,
    ).reset_index()
    cols = [c[0] if c[1] == "" else c[1] for c in pDf.columns]
    pDf.columns = cols

    cols = []
    if "missing_instance" in pDf:
        cols.append("missing_instance")
    if "missing_cdb" in pDf:
        cols.append("missing_cdb")

    if len(cols) > 0:
        pDf.drop(columns=cols, inplace=True)

    pDf["stage"] = stage
    pDf["final"] = 1 if final else 0

    if WRITE_INTERMIEDIATE_FILES:
        filename = sizingFilePath + os.sep + filePrefix + ".final.csv"
        pDf.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df = structureDf[~structureDf["db_target_guid"].isin(pDf["db_target_guid"])][
        ["cdb", "db", "cdb_target_guid", "db_target_guid"]
    ].drop_duplicates()

    if len(df) > 0:
        df["DATABASE_SIZE.ALLOCATED_GB"] = 0
        df["DATABASE_SIZE.USED_GB"] = 0
        df["Database_Resource_Usage.logons"] = 0
        df["db_inst_cpu_usage.avg_tot_cpu_usage_ps"] = 0
        df["instance_throughput.iorequests_ps"] = 0
        df["memory_usage_sga_pga.pga_total"] = 0
        df["memory_usage_sga_pga.sga_total"] = 0
        df["stage"] = stage
        df["final"] = 1 if final else 0

        pDf = pd.concat([pDf, df], ignore_index=True)

    return pDf


# ----------------------------------------------------------------------------------------------------------------------


def computeStatistics(adjusted=False, which="both"):
    if which in ["cdb", "both"]:
        dfs = (
            cdbHourlyMetricsDf.groupby(["cdb", "metric"])["AVERAGE"].sum().reset_index()
        )
        dfs.rename(columns={"AVERAGE": "total"}, inplace=True)

        df0 = (
            cdbHourlyMetricsDf[
                ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "AVERAGE"]
            ]
            .groupby(["cdb_cohort", "cdb", "cdb_target_guid", "metric"])
            .describe(percentiles=PERCENTILES)
            .reset_index()
        )
        cols = [c[0] if c[1] == "" else c[1] for c in df0.columns]
        df0.columns = cols

        df0 = pd.merge(
            left=df0,
            right=dfs,
            how="left",
            left_on=["cdb", "metric"],
            right_on=["cdb", "metric"],
        )

        # ---

        dfs = (
            cdbHourlyStorageMetricsDf.groupby(["cdb", "metric"])["AVERAGE"]
            .sum()
            .reset_index()
        )

        if len(dfs) == 0:
            df = df0
        else:
            dfs.rename(columns={"AVERAGE": "total"}, inplace=True)

            df1 = (
                cdbHourlyStorageMetricsDf[
                    ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "AVERAGE"]
                ]
                .groupby(["cdb_cohort", "cdb", "cdb_target_guid", "metric"])
                .describe(percentiles=PERCENTILES)
                .reset_index()
            )
            cols = [c[0] if c[1] == "" else c[1] for c in df1.columns]
            df1.columns = cols

            df1 = pd.merge(
                left=df1,
                right=dfs,
                how="left",
                left_on=["cdb", "metric"],
                right_on=["cdb", "metric"],
            )
            df = pd.concat([df0, df1], ignore_index=True)

        # ---

        cols = [c if c.find("%") == -1 else "p" + c.strip("%") for c in df.columns]
        df.columns = cols

        df["max_rank"] = df.groupby(["metric"])["max"].rank("dense")
        df["total_rank"] = df.groupby(["metric"])["total"].rank("dense")

        df = df.round(PRECISION)

        df["summary_of"] = "cdb"
        df["adjusted"] = 1 if adjusted else 0
        df["rollup_type"] = "AVERAGE"
        df["time_unit"] = "HOURLY"
        df["time_period"] = 3
        df["cwd"] = cwd
        df["platform"] = platformName
        df["extract_dttm_utc"] = extract_dttm_utc
        df["create_dttm_utc"] = now
        df["source"] = SOURCE
        df["version"] = __version__

        cols0 = [
            "cdb_cohort",
            "cdb",
            "metric",
            "adjusted",
            "summary_of",
            "cdb_target_guid",
        ]
        cols1 = [c for c in df.columns if c not in cols0]
        df = df[cols0 + cols1]

        filename = (
            sizingFilePath
            + os.sep
            + "database_"
            + ("adjusted_" if adjusted else "")
            + "statistics.csv"
        )
        df.sort_values(["cdb", "metric"]).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    if which in ["cohort", "both"]:
        #
        #   Re-compute the cohort rollups because in the case of the adjusted metrics, we will have multiplied by the
        #   adjustment factor BEFORE calling computeStatistics()
        #
        dfs = (
            cdbHourlyMetricsDf.groupby(["cdb_cohort", "metric"])["AVERAGE"]
            .sum()
            .reset_index()
        )
        dfs.rename(columns={"AVERAGE": "total"}, inplace=True)

        df = cdbHourlyMetricsDf.groupby(
            ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
        )["AVERAGE"].sum()
        df0 = (
            df[["cdb_cohort", "metric", "AVERAGE"]]
            .groupby(["cdb_cohort", "metric"])
            .describe(percentiles=PERCENTILES)
            .reset_index()
        )
        cols = [c[0] if c[1] == "" else c[1] for c in df0.columns]
        df0.columns = cols

        df0 = pd.merge(
            left=df0,
            right=dfs,
            how="left",
            left_on=["cdb_cohort", "metric"],
            right_on=["cdb_cohort", "metric"],
        )

        # ---

        dfs = (
            cdbHourlyStorageMetricsDf.groupby(["cdb_cohort", "metric"])["AVERAGE"]
            .sum()
            .reset_index()
        )

        if len(dfs) == 0:
            df = df0
        else:
            dfs.rename(columns={"AVERAGE": "total"}, inplace=True)

            df = cdbHourlyStorageMetricsDf.groupby(
                ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
            )["AVERAGE"].sum()

            df1 = (
                df[["cdb_cohort", "metric", "AVERAGE"]]
                .groupby(["cdb_cohort", "metric"])
                .describe(percentiles=PERCENTILES)
                .reset_index()
            )
            cols = [c[0] if c[1] == "" else c[1] for c in df1.columns]
            df1.columns = cols

            df1 = pd.merge(
                left=df1,
                right=dfs,
                how="left",
                left_on=["cdb_cohort", "metric"],
                right_on=["cdb_cohort", "metric"],
            )
            df = pd.concat([df0, df1], ignore_index=True)

        # ---

        cols = [c if c.find("%") == -1 else "p" + c.strip("%") for c in df.columns]
        df.columns = cols

        df["max_rank"] = df.groupby(["metric"])["max"].rank("dense")
        df["total_rank"] = df.groupby(["metric"])["total"].rank("dense")

        df = df.round(PRECISION)

        df["cdb"] = "All"
        df["cdb_target_guid"] = "All"
        df["summary_of"] = "cdb_cohort"
        df["adjusted"] = 1 if adjusted else 0
        df["rollup_type"] = "AVERAGE"
        df["time_unit"] = "HOURLY"
        df["time_period"] = 3
        df["cwd"] = cwd
        df["platform"] = platformName
        df["extract_dttm_utc"] = extract_dttm_utc
        df["create_dttm_utc"] = now
        df["source"] = SOURCE
        df["version"] = __version__

        cols0 = [
            "cdb_cohort",
            "cdb",
            "metric",
            "adjusted",
            "summary_of",
            "cdb_target_guid",
        ]
        cols1 = [c for c in df.columns if c not in cols0]
        df = df[cols0 + cols1]

        filename = (
            sizingFilePath
            + os.sep
            + "cohort_"
            + ("adjusted_" if adjusted else "")
            + "statistics.csv"
        )
        df.sort_values(["cdb_cohort", "metric"]).to_csv(filename, index=False)
        lg("\nWrote file " + filename)


# ----------------------------------------------------------------------------------------------------------------------


def format_title(title, subtitle=None, subtitle_font_size=14):
    title = f"<b>{title}</b>"

    if not subtitle:
        return title

    subtitle = f'<span style="font-size: {subtitle_font_size}px;">{subtitle}</span>'

    return f"{title}<br>{subtitle}"


# ----------------------------------------------------------------------------------------------------------------------


# Plots the peaks and creates the folders if doesn't exist,adjusted
def plotAdjustments(
    df, cdbHourlyMetricsPeaksDf, cdbDailyAdjustmentsDf, cdb_hourly_metrics_peak_db_df
):
    FACET_COLS = 2
    METRICS_TO_PLOT = [
        STORAGE_ALLOCATED_METRIC,
        STORAGE_USED_METRIC,
        CPU_DERIVED_METRIC,
        PGA_METRIC,
        SGA_METRIC,
        SGAPGA_DERIVED_METRIC,
        IOMBS_METRIC,
        IOPS_METRIC,
        LOGONS_METRIC,
    ]

    lg("\nBeginning adjustment plots...")

    # Delete previous copies of adjusted directory
    plot_path = os.path.join(plotFilePath, "adjusted")
    if Path.is_dir(Path(plot_path)):
        lg(f"    Deleting existing directory : {plot_path}")
        shutil.rmtree(plot_path, ignore_errors=True)
    else:
        os.makedirs(plot_path, exist_ok=True)

    customer = os.getcwd().split(os.sep)[-1]
    plots_per_cohort = {}
    figs = []
    for cohort in sorted(df.cdb_cohort.unique()):
        if cohort in PLOT_SUPPRESSED_COHORTS:
            lg("     Skipping plot suppressed cohort " + str(cohort) + "...")

            continue

        lg("     Beginning cohort " + str(cohort) + "...")

        # Accept only the following characters in cohort nane : a-zA-Z0-9_-
        cohort_name_pattern = re.compile(r"[\w-]+")
        matched_cohort_name = re.fullmatch(cohort_name_pattern, cohort)
        if not matched_cohort_name:
            lg(
                "      ======================================================================================================================="
            )
            lg(
                "      ERROR: Invalid characters in cohort name. The cohort ["
                + str(cohort)
                + "] does not accomplish with the name convention."
            )
            lg(
                "      These are the only characters allowed in a cohort name : a-zA-Z0-9_-"
            )
            lg(
                "      ======================================================================================================================="
            )
            quit()

        # Stop and throw error if any cohort is named as exclude (the right flag for exclusion is excluded)
        exclude_cohort_name_pattern = re.compile(r"exclude$")
        matched_cohort_name = re.fullmatch(exclude_cohort_name_pattern, cohort)
        if matched_cohort_name:
            msg = (
                'Need user input: Found cohort with name "exclude". The custom flag to '
                'disable database analysis is "excluded" and not "exclude".'
            )
            lg(
                "      ======================================================================================================================="
            )
            lg("      ERROR: " + msg)
            lg(
                "      To silence this error , fix the cohort name in properties_database.csv file , execute --add-properties command and"
            )
            lg("      re-run metric analysis command.")
            lg(
                "      ======================================================================================================================="
            )
            if os.getenv("RUN_FROM_API", "False") == "True":
                raise_error_when_run_from_api("EMCC: ", msg)
                sys.exit(1)
            quit()

        tb = time.time()

        if PLOT_HTML:
            filePathHTML = (
                plotFilePath
                + os.sep
                + "adjusted"
                + os.sep
                + str(cohort)
                + os.sep
                + "html"
            )
            os.makedirs(filePathHTML, exist_ok=True)

        if PLOT_PNG:
            filePathPNG = (
                plotFilePath
                + os.sep
                + "adjusted"
                + os.sep
                + str(cohort)
                + os.sep
                + "png"
            )
            os.makedirs(filePathPNG, exist_ok=True)

        plotCtr = 0

        pDf = df[
            (df["cdb_cohort"] == cohort) & (df["metric"].isin(METRICS_TO_PLOT))
        ].copy()

        plotCount = len(pDf["metric"].unique())

        pDf = pd.merge(
            left=pDf,
            right=cdbHourlyMetricsPeaksDf,
            how="left",
            left_on=["cdb_cohort", "metric"],
            right_on=["cdb_cohort", "metric"],
        )

        pDf.loc[pDf["metric"] == CPU_DERIVED_METRIC, "metric"] = (
            EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC]
        )
        pDf.loc[pDf["metric"] == PGA_METRIC, "metric"] = EMCC_METRIC_COULMN_ALIASES[
            PGA_METRIC
        ]
        pDf.loc[pDf["metric"] == SGA_METRIC, "metric"] = EMCC_METRIC_COULMN_ALIASES[
            SGA_METRIC
        ]
        pDf.loc[pDf["metric"] == SGAPGA_DERIVED_METRIC, "metric"] = (
            EMCC_METRIC_COULMN_ALIASES[SGAPGA_DERIVED_METRIC]
        )
        pDf.loc[pDf["metric"] == IOMBS_METRIC, "metric"] = EMCC_METRIC_COULMN_ALIASES[
            IOMBS_METRIC
        ]
        pDf.loc[pDf["metric"] == IOPS_METRIC, "metric"] = EMCC_METRIC_COULMN_ALIASES[
            IOPS_METRIC
        ]
        pDf.loc[pDf["metric"] == LOGONS_METRIC, "metric"] = EMCC_METRIC_COULMN_ALIASES[
            LOGONS_METRIC
        ]

        pDf["adjusted_peak"] = pDf["AVERAGE_max_multiplier"] * pDf["peak"]
        pDf["maximum_peak"] = pDf.groupby("metric")["adjusted_peak"].transform("max")

        pDf.sort_values(["metric", "ROLLUP_TIMESTAMP_max"], inplace=True)

        fig = px.bar(
            pDf,
            x="ROLLUP_TIMESTAMP_max",
            y="adjusted_peak",
            facet_col="metric",
            facet_col_wrap=FACET_COLS,
            labels={"ROLLUP_TIMESTAMP_max": "Date (UTC)", "adjusted_peak": "Peak"},
            title=format_title(
                customer
                + " : "
                + str(cohort)
                + " : Hourly Average Adjusted Peak Values (Chart Version "
                + __version__
                + ")",
                "Hourly Average Adjusted Peak (solid red), Observed Hourly Average Peak (solid black), 1 OCPU = 2 vCPU"
                + (
                    " (missing telemetry in daily extract files resulted in "
                    + str(len(METRICS_TO_PLOT) - plotCount)
                    + " missing facet(s) )"
                    if plotCount < len(METRICS_TO_PLOT)
                    else ""
                ),
                20,
            ),
            template="seaborn",
            width=WIDTH,
            height=HEIGHT,
        )

        peaks = (
            pDf[["metric", "peak"]].drop_duplicates().sort_values(["metric"])["peak"]
        )
        maximums = (
            pDf[["metric", "maximum_peak"]]
            .drop_duplicates()
            .sort_values(["metric"])["maximum_peak"]
        )
        #
        #       The following logic is needed to re-orient the plot grid to the lower-left cell having coordinates 1, 1
        #
        r, c = 1, 1
        idx_from_top = []

        for p in range(len(peaks)):
            if c > FACET_COLS:
                c = 1
                r += 1

            idx_from_top.append([r, c])
            c += 1

        # lg('idx_from_top: ' + str(idx_from_top))
        idx_from_bottom = [[r - i[0] + 1, i[1]] for i in idx_from_top]
        # lg('idx_from_bottom: ' + str(idx_from_bottom))

        for ctr, p in enumerate(peaks):
            fig.add_hline(
                y=p,
                line_width=3,
                line_color="black",
                row=idx_from_bottom[ctr][0],
                col=idx_from_bottom[ctr][1],
            )

        for ctr, p in enumerate(maximums):
            fig.add_hline(
                y=p,
                line_width=3,
                line_color="red",
                row=idx_from_bottom[ctr][0],
                col=idx_from_bottom[ctr][1],
            )

        fig.update_layout(
            font={"size": 16},
            legend_font_size=12,
            autosize=False,
            width=WIDTH,
            height=HEIGHT,
            margin=dict(t=150),
        )
        fig.update_yaxes(matches=None, showticklabels=True)

        if PLOT_HTML:
            filenameHTML = filePathHTML + os.sep + str(cohort) + "_Adjustments.html"
            dashboard = open(filenameHTML, "w", encoding="UTF-8")
            HTMLhead = (
                customer
                + " : "
                + str(cohort)
                + ", Hourly Average (occa_Run_Metric_Analysis, Chart Version "
                + __version__
                + ")"
            )

            dashboard.write(
                "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
            )

            inner_html = (
                fig.to_html(include_plotlyjs=True)
                .split("<body>")[1]
                .split("</body>")[0]
            )
            dashboard.write(inner_html)

            dashboard.write("</body></html>" + "\n")
            dashboard.close()

            plotCtr += 1

        if PLOT_PNG:
            filenamePNG = filePathPNG + os.sep + str(cohort) + "_Adjustments.png"
            fig.write_image(filenamePNG)

            plotCtr += 1

        if PLOT_ADJUSTMENT_MULTIPLIERS:
            fig = px.bar(
                pDf,
                x="ROLLUP_TIMESTAMP_max",
                y="AVERAGE_max_multiplier",
                facet_col="metric",
                facet_col_wrap=FACET_COLS,
                labels={
                    "ROLLUP_TIMESTAMP_max": "Date (UTC)",
                    "AVERAGE_max_multiplier": "multiplier",
                },
                title=format_title(
                    customer
                    + " : "
                    + str(cohort)
                    + " : Hourly Average Multiplier (Chart Version "
                    + __version__
                    + ")",
                    "1 OCPU = 2 vCPU"
                    + (
                        " (missing telemetry in daily extract files resulted in "
                        + str(len(METRICS_TO_PLOT) - plotCount)
                        + " missing facet(s) )"
                        if plotCount < len(METRICS_TO_PLOT)
                        else ""
                    ),
                    20,
                ),
                template="seaborn",
                width=WIDTH,
                height=HEIGHT,
            )

            fig.add_hline(y=1.0, line_width=3, line_color="black")

            fig.update_layout(
                font={"size": 16},
                legend_font_size=12,
                autosize=False,
                width=WIDTH,
                height=HEIGHT,
                margin=dict(t=150),
            )
            fig.update_yaxes(matches=None, showticklabels=True)

            if PLOT_HTML:
                filenameHTML = (
                    filePathHTML + os.sep + str(cohort) + "_Adjustments_Multiplier.html"
                )
                dashboard = open(filenameHTML, "w", encoding="UTF-8")
                HTMLhead = (
                    customer
                    + " : "
                    + str(cohort)
                    + ", Hourly Average (occa_Run_Metric_Analysis, Chart Version "
                    + __version__
                    + ")"
                )

                dashboard.write(
                    "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
                )

                inner_html = (
                    fig.to_html(include_plotlyjs=True)
                    .split("<body>")[1]
                    .split("</body>")[0]
                )
                dashboard.write(inner_html)

                dashboard.write("</body></html>" + "\n")
                dashboard.close()

                plotCtr += 1

            if PLOT_PNG:
                filenamePNG = (
                    filePathPNG + os.sep + str(cohort) + "_Adjustments_Multiplier.png"
                )
                fig.write_image(filenamePNG)

                plotCtr += 1

        if PLOT_INDIVIDUAL_DB:
            if PLOT_HTML:
                individual_plots_path_html = Path(filePathHTML) / "individual_plots"
                os.makedirs(individual_plots_path_html, exist_ok=True)

            if PLOT_PNG:
                individual_plots_path_png = Path(filePathPNG) / "individual_plots"
                os.makedirs(individual_plots_path_png, exist_ok=True)

            curr_db_df = cdbDailyAdjustmentsDf[
                (cdbDailyAdjustmentsDf["cdb_cohort"] == cohort)
                & (cdbDailyAdjustmentsDf["metric"].isin(METRICS_TO_PLOT))
            ].copy()

            num_plots = len(curr_db_df["metric"].unique())

            curr_db_df = pd.merge(
                left=curr_db_df,
                right=cdb_hourly_metrics_peak_db_df,
                how="left",
                left_on=["cdb", "metric"],
                right_on=["cdb", "metric"],
            )

            curr_db_df.loc[curr_db_df["metric"] == CPU_DERIVED_METRIC, "metric"] = (
                EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC]
            )
            curr_db_df.loc[curr_db_df["metric"] == PGA_METRIC, "metric"] = (
                EMCC_METRIC_COULMN_ALIASES[PGA_METRIC]
            )
            curr_db_df.loc[curr_db_df["metric"] == SGA_METRIC, "metric"] = (
                EMCC_METRIC_COULMN_ALIASES[SGA_METRIC]
            )
            curr_db_df.loc[curr_db_df["metric"] == SGAPGA_DERIVED_METRIC, "metric"] = (
                EMCC_METRIC_COULMN_ALIASES[SGAPGA_DERIVED_METRIC]
            )
            curr_db_df.loc[curr_db_df["metric"] == IOMBS_METRIC, "metric"] = (
                EMCC_METRIC_COULMN_ALIASES[IOMBS_METRIC]
            )
            curr_db_df.loc[curr_db_df["metric"] == IOPS_METRIC, "metric"] = (
                EMCC_METRIC_COULMN_ALIASES[IOPS_METRIC]
            )
            curr_db_df.loc[curr_db_df["metric"] == LOGONS_METRIC, "metric"] = (
                EMCC_METRIC_COULMN_ALIASES[LOGONS_METRIC]
            )

            curr_db_df["adjusted_peak"] = (
                curr_db_df["AVERAGE_max_multiplier"] * curr_db_df["peak"]
            )
            curr_db_df["maximum_peak"] = curr_db_df.groupby("metric")[
                "adjusted_peak"
            ].transform("max")

            curr_db_df.sort_values(["metric", "ROLLUP_TIMESTAMP_max"], inplace=True)

            db_cohort = curr_db_df["cdb"].unique()
            if len(db_cohort) > PLOT_INDIVIDUAL_DB_LIMIT:
                db_cohort = curr_db_df["cdb"].unique()[:PLOT_INDIVIDUAL_DB_LIMIT]
            for db in db_cohort:
                db_df = curr_db_df[(curr_db_df["cdb"] == db)].copy()
                graph_title = f"{customer}: {db}: Hourly Average Adjusted Peak Values (Chart Version {__version__})"
                graph_subtitle = (
                    f"Hourly Average Adjusted Peak (solid red), "
                    f"Observed Hourly Average Peak (solid black), 1 OCPU = 2 vCPU"
                )
                if num_plots < len(METRICS_TO_PLOT):
                    extra_sub = (
                        f" (missing telemetry in daily extract files resulted in {len(METRICS_TO_PLOT) - num_plots}"
                        f"missing facet(s) )"
                    )
                    graph_subtitle += extra_sub
                fig = px.bar(
                    db_df,
                    x="ROLLUP_TIMESTAMP_max",
                    y="adjusted_peak",
                    facet_col="metric",
                    facet_col_wrap=FACET_COLS,
                    labels={
                        "ROLLUP_TIMESTAMP_max": "Date (UTC)",
                        "adjusted_peak": "Peak",
                    },
                    title=format_title(graph_title, graph_subtitle, 20),
                    template="seaborn",
                    width=WIDTH,
                    height=HEIGHT,
                )

                peaks = (
                    db_df[["metric", "peak"]]
                    .drop_duplicates()
                    .sort_values(["metric"])["peak"]
                )
                maximums = (
                    db_df[["metric", "maximum_peak"]]
                    .drop_duplicates()
                    .sort_values(["metric"])["maximum_peak"]
                )

                # The following logic is needed to re-orient the plot grid to the lower-left cell having coordinates 1, 1
                r, c = 1, 1
                idx_from_top = []

                for p in range(len(peaks)):
                    if c > FACET_COLS:
                        c = 1
                        r += 1

                    idx_from_top.append([r, c])
                    c += 1

                # lg('idx_from_top: ' + str(idx_from_top))
                idx_from_bottom = [[r - i[0] + 1, i[1]] for i in idx_from_top]
                # lg('idx_from_bottom: ' + str(idx_from_bottom))

                for ctr, p in enumerate(peaks):
                    fig.add_hline(
                        y=p,
                        line_width=3,
                        line_color="black",
                        row=idx_from_bottom[ctr][0],
                        col=idx_from_bottom[ctr][1],
                    )

                for ctr, p in enumerate(maximums):
                    fig.add_hline(
                        y=p,
                        line_width=3,
                        line_color="red",
                        row=idx_from_bottom[ctr][0],
                        col=idx_from_bottom[ctr][1],
                    )

                fig.update_layout(
                    font={"size": 16},
                    legend_font_size=12,
                    autosize=False,
                    width=WIDTH,
                    height=HEIGHT,
                    margin=dict(t=150),
                )
                fig.update_yaxes(matches=None, showticklabels=True)

                if PLOT_HTML:
                    filenameHTML = (
                        individual_plots_path_html / f"{cohort}_{db}_Adjustments.html"
                    )
                    dashboard = open(filenameHTML, "w", encoding="UTF-8")
                    HTMLhead = f"{customer}: {db}, Hourly Average (occa_Run_Metric_Analysis, Chart Version {__version__}"

                    dashboard.write(
                        "<html><head><title>"
                        + HTMLhead
                        + "</title></head><body>"
                        + "\n"
                    )

                    inner_html = (
                        fig.to_html(include_plotlyjs=True)
                        .split("<body>")[1]
                        .split("</body>")[0]
                    )
                    dashboard.write(inner_html)

                    dashboard.write("</body></html>" + "\n")
                    dashboard.close()

                    plotCtr += 1

                if PLOT_PNG:
                    filenamePNG = (
                        individual_plots_path_png / f"{cohort}_{db}_Adjustments.png"
                    )
                    fig.write_image(filenamePNG)

                    plotCtr += 1

        lg(
            "     Created "
            + str(plotCtr)
            + " adjustment plots for "
            + str(cohort)
            + " in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )
        plots_per_cohort[cohort] = {'adjusted':{"figures":figs, "COHORT_NAME":cohort}}
    # os.environ["RUN_FROM_API"] = "True" # debug
    if os.getenv("RUN_FROM_API", "False") == "True":
        root_user_folder = os.getcwd()
        func_logger.info(f"1193 Plotting metrics using root_user_folder {root_user_folder}")
        plots_file_path = os.path.join(root_user_folder, "plots.json")
        serialize_plots(plots_per_cohort, plots_file_path)


# ----------------------------------------------------------------------------------------------------------------------



def plotMetrics(df, metricType="unadjusted"):
    VALID_METRIC_TYPES = ["adjusted", "adjusted_yearly", "unadjusted"]

    if metricType not in VALID_METRIC_TYPES:
        lg("Unknown value for metricType: " + metricType)
        lg("Valid metric types: " + str(VALID_METRIC_TYPES))

        return

    lg(
        "\nBeginning "
        + metricType
        + " metric plots...time since start "
        + str(round(time.time() - startTime, 3))
        + " s"
    )

    plot_path = plotFilePath + os.sep + metricType

    customer = os.getcwd().split(os.sep)[-1]
    plots_per_cohort = {}
    for cohort in sorted(df.cdb_cohort.unique()):
        figs = []
        if cohort in PLOT_SUPPRESSED_COHORTS:
            lg("     Skipping plot suppressed cohort " + str(cohort) + "...")

            continue

        lg(
            "     Beginning cohort "
            + str(cohort)
            + "...time since start "
            + str(round(time.time() - startTime, 3))
            + " s"
        )

        cdbCount = len(df[df["cdb_cohort"] == cohort]["cdb"].unique())

        if cdbCount > PLOT_INSTANCE_COUNT_LIMIT:
            lg(
                "     "
                + str(cohort)
                + "'s instance count "
                + str(cdbCount)
                + " exceeds limit "
                + str(PLOT_INSTANCE_COUNT_LIMIT)
                + " set by parameter PLOT_INSTANCE_COUNT_LIMIT; plotting top databases only"
            )

        tb = time.time()

        if PLOT_HTML:
            filePathHTML = (
                plotFilePath
                + os.sep
                + metricType
                + os.sep
                + str(cohort)
                + os.sep
                + "html"
            )
            os.makedirs(filePathHTML, exist_ok=True)

        if PLOT_PNG:
            filePathPNG = (
                plotFilePath
                + os.sep
                + metricType
                + os.sep
                + str(cohort)
                + os.sep
                + "png"
            )
            os.makedirs(filePathPNG, exist_ok=True)

        plotCtr = 0

        for metric in sorted(df.metric.unique()):
            aDf = df[(df["cdb_cohort"] == cohort) & (df["metric"] == metric)].copy()

            if len(aDf) == 0:
                lg(
                    "          Skipping 0-length cohort: "
                    + str(cohort)
                    + ", metric: "
                    + metric
                )
                continue

            metricTitle = (
                EMCC_METRIC_COULMN_ALIASES[metric]
                if metric in EMCC_METRIC_COULMN_ALIASES
                else "Unknown: " + metric
            )
            uom = (
                EMCC_METRIC_COULMN_UOMS[metric]
                if metric in EMCC_METRIC_COULMN_UOMS
                else "Unknown: " + metric
            )
            aDf["metric"] = metricTitle

            lg(
                ("        Beginning plot for metric " + metricTitle.ljust(40))
                + "; time since start "
                + str(round(time.time() - startTime, 3))
                + " s"
            )

            if PLOT_HTML:
                filenameHTML = (
                    filePathHTML
                    + os.sep
                    + str(cohort)
                    + "_"
                    + metricTitle.replace(" ", "_")
                    + "_"
                    + metricType
                    + ".html"
                )
                dashboard = open(filenameHTML, "w", encoding="UTF-8")
                HTMLhead = (
                    customer
                    + " : "
                    + str(cohort)
                    + ", Hourly Average "
                    + metricTitle
                    + " (occa_Run_Metric_Analysis, Chart Version "
                    + __version__
                    + ")"
                )

                dashboard.write(
                    "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
                )

            if PLOT_PNG:
                filenamePNG = (
                    filePathPNG
                    + os.sep
                    + str(cohort)
                    + "_"
                    + metricTitle.replace(" ", "_")
                    + "_"
                    + metricType
                    + ".png"
                )

            maxDf = aDf.groupby(["cdb_target_guid"], as_index=False)["AVERAGE"].max()
            timeAlignedDf = aDf.groupby(["ROLLUP_TIMESTAMP_UTC"], as_index=False)[
                "AVERAGE"
            ].sum()

            peak = round(timeAlignedDf["AVERAGE"].max(), PRECISION)
            sum_of_max = round(maxDf["AVERAGE"].sum(), PRECISION)

            timeAlignedDf["MAX"] = peak
            timeAlignedDf["DIFF"] = peak - timeAlignedDf["AVERAGE"]

            statistics = timeAlignedDf["AVERAGE"].describe(
                percentiles=[0.80, 0.90, 0.95]
            )
            p80 = round(statistics["80%"], PRECISION)
            p90 = round(statistics["90%"], PRECISION)
            p95 = round(statistics["95%"], PRECISION)

            hrs = len(timeAlignedDf)
            sum_peak_x_hrs = round(timeAlignedDf["MAX"].sum(), PRECISION)
            sum_metric_x_hrs = round(timeAlignedDf["AVERAGE"].sum(), PRECISION)
            sumOfDiff = round(timeAlignedDf["DIFF"].sum(), PRECISION)

            average = round(sum_metric_x_hrs / hrs, PRECISION)

            aDf["total"] = aDf.groupby(["cdb"])["AVERAGE"].transform("sum")
            aDf["rank"] = aDf["total"].rank(method="dense").astype(str)
            aDf["sort"] = aDf["rank"].str.zfill(5) + "$$$" + aDf["cdb"]

            aDf.rename(columns={"cdb": " cdb_original", "sort": "cdb"}, inplace=True)

            if metric in [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]:
                #
                #               Storage metrics are captured at the daily level
                #
                hrs *= hrs
                sum_peak_x_hrs = round(sum_peak_x_hrs * 24, PRECISION)
                sum_metric_x_hrs = round(sum_metric_x_hrs * 24, PRECISION)
                sumOfDiff = round(sumOfDiff * 24, PRECISION)

            aDf.sort_values(
                ["cdb", "ROLLUP_TIMESTAMP_UTC"], ascending=[False, True], inplace=True
            )

            if 1 == 0:
                filename = (
                    sizingFilePath
                    + os.sep
                    + "aDf_"
                    + str(cohort)
                    + "_"
                    + metric
                    + "."
                    + ln()
                    + ".csv"
                )
                aDf.to_csv(filename, index=False)
                lg("Wrote " + filename)

            if cdbCount > PLOT_INSTANCE_COUNT_LIMIT:
                aDf = aDf[
                    aDf["cdb"].isin(
                        sorted(aDf["cdb"].unique(), reverse=True)[
                            :PLOT_INSTANCE_COUNT_LIMIT
                        ]
                    )
                ]

            fig = px.area(
                aDf,
                x="ROLLUP_TIMESTAMP_UTC",
                y="AVERAGE",
                color="cdb",
                labels={"ROLLUP_TIMESTAMP_UTC": "Date (UTC)", "AVERAGE": uom},
                title=format_title(
                    customer
                    + " : "
                    + str(cohort)
                    + " : Hourly Average "
                    + metricType.title()
                    + " "
                    + metricTitle
                    + " (Chart Version "
                    + __version__
                    + ")"
                    + (
                        " (Top "
                        + str(PLOT_INSTANCE_COUNT_LIMIT)
                        + " of "
                        + str(cdbCount)
                        + " database(s) shown)"
                        if cdbCount > PLOT_INSTANCE_COUNT_LIMIT
                        else " (" + str(cdbCount) + " database(s) shown)"
                    ),
                    (
                        "Sum(Max)=" + f"{sum_of_max:,}" + " (dashed black), "
                        if PLOT_SUM_OF_MAX
                        else ""
                    )
                    + "Peak="
                    + f"{peak:,}"
                    + " (solid red)"
                    + (
                        ", 95, 90, 80="
                        + f"{p95:,}"
                        + ", "
                        + f"{p90:,}"
                        + ", "
                        + f"{p80:,}"
                        + " (dotted blue)"
                        if PLOT_PERCENTILES
                        else ""
                    )
                    + ("<br>" if PLOT_PERCENTILES else ", ")
                    + "Average="
                    + f"{average:,}"
                    + " (solid green)"
                    + ", Hrs="
                    + f"{hrs:,}"
                    + (", 1 OCPU = 2 vCPU" if uom == "vCPU" else ""),
                    20,
                ),
                template="seaborn",
                width=WIDTH,
                height=HEIGHT,
            )

            fig.add_trace(
                go.Scatter(
                    x=timeAlignedDf["ROLLUP_TIMESTAMP_UTC"],
                    y=timeAlignedDf["AVERAGE"],
                    mode="lines",
                    line=dict(color="black", width=6),
                )
            )

            if PLOT_SUM_OF_MAX:
                fig.add_hline(
                    y=sum_of_max, line_width=3, line_color="black", line_dash="dash"
                )
                fig.update_layout(yaxis_range=[0, sum_of_max * 1.1])

            else:
                fig.update_layout(yaxis_range=[0, peak * 1.1])

            fig.add_hline(y=peak, line_width=3, line_color="red")
            fig.add_hline(y=average, line_width=10, line_color="green")

            if PLOT_PERCENTILES:
                fig.add_hline(y=p80, line_width=3, line_color="blue", line_dash="dot")
                fig.add_hline(y=p90, line_width=3, line_color="blue", line_dash="dot")
                fig.add_hline(y=p95, line_width=3, line_color="blue", line_dash="dot")

            fig.update_layout(
                font={"size": 16},
                legend_font_size=12,
                autosize=False,
                width=WIDTH,
                height=HEIGHT,
                margin=dict(t=150),
            )

            for idx in range(len(fig.data)):
                # lg('idx: ' + str(idx) + ', ' + str(fig.data[idx]))

                cdb = fig.data[idx].name

                if cdb is None:
                    continue

                cdb = cdb[cdb.find("$$$") + 3 :]

                fig.data[idx].name = cdb
                fig.data[idx].legendgroup = cdb
                fig.data[idx].hovertemplate = cdb

            figs.append({"page":plotCtr, "fig":fig})
            if PLOT_HTML:
                inner_html = (
                    fig.to_html(include_plotlyjs=True)
                    .split("<body>")[1]
                    .split("</body>")[0]
                )
                dashboard.write(inner_html)

                dashboard.write("</body></html>" + "\n")
                dashboard.close()

                plotCtr += 1

            if PLOT_PNG:
                fig.write_image(filenamePNG)

                plotCtr += 1

            if (
                PLOT_INDIVIDUAL_DB
                and metricType == "adjusted"
                and metricTitle == "DB vCPU"
            ):
                if PLOT_HTML:
                    individual_plots_path_html = Path(filePathHTML) / "individual_plots"
                    os.makedirs(individual_plots_path_html, exist_ok=True)

                if PLOT_PNG:
                    individual_plots_path_png = Path(filePathPNG) / "individual_plots"
                    os.makedirs(individual_plots_path_png, exist_ok=True)

                dbs_cohort = aDf[" cdb_original"].unique()
                if cdbCount > PLOT_INDIVIDUAL_DB_LIMIT:
                    dbs_cohort = aDf[" cdb_original"].unique()[
                        :PLOT_INDIVIDUAL_DB_LIMIT
                    ]
                for db in dbs_cohort:
                    lg(
                        "{:<65}".format(
                            f"\t\t\tPlotting graph for CDB {db}. Metric: {metricTitle}"
                        )
                        + f"; time since start {round(time.time() - startTime, 3)} s"
                    )
                    # Create plot files
                    if PLOT_HTML:
                        file_individual_db_html = (
                            Path(individual_plots_path_html)
                            / f"{cohort}_{db}_{metricTitle.replace(' ', '_')}_{metricType}.html"
                        )
                        plot_dashboard = open(
                            file_individual_db_html, "w", encoding="UTF-8"
                        )
                        html_head = (
                            f"{customer}: {db}: Hourly Average {metricTitle} (occa_Run_Metric_Analysis, Chart "
                            f"Version {__version__})"
                        )
                        plot_dashboard.write(
                            f"<html><head><title> {html_head} </title></head><body>"
                            + "\n"
                        )

                    if PLOT_PNG:
                        file_individual_db_png = (
                            Path(individual_plots_path_png)
                            / f"{cohort}_{db}_{metricTitle.replace(' ', '_')}_{metricType}.png"
                        )

                    # Calculate metrics for each DB
                    db_df = aDf[aDf[" cdb_original"] == db].copy()
                    max_db_df = db_df["AVERAGE"].max()
                    db_sum_of_max = db_df["AVERAGE"].sum()
                    db_df["MAX"] = max_db_df
                    db_df["DIFF"] = max_db_df - db_df["AVERAGE"]

                    db_statistics = db_df["AVERAGE"].describe(
                        percentiles=[0.80, 0.90, 0.95]
                    )
                    db_p80 = round(db_statistics["80%"], PRECISION)
                    db_p90 = round(db_statistics["90%"], PRECISION)
                    db_p95 = round(db_statistics["95%"], PRECISION)

                    db_sum_peak_x_hrs = round(db_df["MAX"].sum(), PRECISION)
                    db_sum_metric_x_hrs = round(db_df["AVERAGE"].sum(), PRECISION)
                    db_sum_of_diff = round(db_df["DIFF"].sum(), PRECISION)

                    db_average = round(db_sum_metric_x_hrs / hrs, PRECISION)
                    db_df.sort_values(
                        ["cdb", "ROLLUP_TIMESTAMP_UTC"],
                        ascending=[False, True],
                        inplace=True,
                    )

                    # Plot titles
                    plot_title_percentiles = (
                        f", Percentiles 95,90,80={db_p95}, {db_p90}, {db_p80} (dotted_blue)<br>"
                        if PLOT_PERCENTILES
                        else ","
                    )
                    vcpu_str = f", 1 OCPU = 2 vCPU" if uom == "vCPU" else ""

                    db_plot_title = (
                        f"{customer}: {db}: Hourly Average {metricType.title()} {metricTitle} (Chart "
                        f"Version {__version__})"
                    )

                    db_plot_subtitle = (
                        f"Peak= {max_db_df} (solid red) {plot_title_percentiles} Average= {db_average}"
                        f" (solid green), Hrs= {hrs} {vcpu_str}"
                    )

                    # Create the plot
                    db_fig = px.area(
                        db_df,
                        x="ROLLUP_TIMESTAMP_UTC",
                        y="AVERAGE",
                        color="cdb",
                        labels={"ROLLUP_TIMESTAMP_UTC": "Date (UTC)", "AVERAGE": uom},
                        title=format_title(
                            db_plot_title,
                            subtitle=db_plot_subtitle,
                            subtitle_font_size=20,
                        ),
                        template="seaborn",
                        width=WIDTH,
                        height=HEIGHT,
                    )

                    # Adding trace line
                    db_fig.add_trace(
                        go.Scatter(
                            x=db_df["ROLLUP_TIMESTAMP_UTC"],
                            y=db_df["AVERAGE"],
                            mode="lines",
                            line=dict(color="black", width=1),
                        )
                    )

                    # Changing the y-axis range to 10% above the max
                    db_fig.update_layout(yaxis_range=[0, max_db_df * 1.1])

                    # Adding max and average lines
                    db_fig.add_hline(y=max_db_df, line_width=3, line_color="red")
                    db_fig.add_hline(y=db_average, line_width=10, line_color="green")

                    # Adding percentiles lines
                    if PLOT_PERCENTILES:
                        db_fig.add_hline(
                            y=db_p80, line_width=3, line_color="blue", line_dash="dot"
                        )
                        db_fig.add_hline(
                            y=db_p90, line_width=3, line_color="blue", line_dash="dot"
                        )
                        db_fig.add_hline(
                            y=db_p95, line_width=3, line_color="blue", line_dash="dot"
                        )

                    db_fig.update_layout(
                        font={"size": 16},
                        legend_font_size=12,
                        autosize=False,
                        width=WIDTH,
                        height=HEIGHT,
                        margin=dict(t=150),
                    )

                    # Rename the plot legends
                    for idx in range(len(db_fig.data)):
                        curr_cdb = db_fig.data[idx].name
                        if curr_cdb is None:
                            continue
                        curr_cdb = curr_cdb[curr_cdb.find("$$$") + 3 :]
                        db_fig.data[idx].name = curr_cdb
                        db_fig.data[idx].legendgroup = curr_cdb
                        db_fig.data[idx].hovertemplate = curr_cdb

                    # Plot the graphs
                    if PLOT_HTML:
                        inner_html = (
                            db_fig.to_html(include_plotlyjs=True)
                            .split("<body>")[1]
                            .split("</body>")[0]
                        )
                        plot_dashboard.write(inner_html)
                        plot_dashboard.write("</body></html>" + "\n")
                        plot_dashboard.close()
                        plotCtr += 1

                    if PLOT_PNG:
                        db_fig.write_image(file_individual_db_png)
                        plotCtr += 1

        lg(
            "     Created "
            + str(plotCtr)
            + " plots for "
            + str(cohort)
            + " in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )

        plots_per_cohort[cohort] = { metricType.lower() : {"figures":figs,"COHORT_NAME":cohort}}

    if os.getenv("RUN_FROM_API", "False") == "True":
        root_user_folder = os.getcwd()
        func_logger.info(f"1733 Plotting metrics using root_user_folder {root_user_folder}")
        plots_file_path = os.path.join(root_user_folder, "plots.json")
        serialize_plots(plots_per_cohort, plots_file_path)
# ----------------------------------------------------------------------------------------------------------------------

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
propertiesFilePath = ROOT_DIR + os.sep + "occa_sizing_properties"

overrideFilePath = outputFilePath + os.sep + "override"
plotFilePath = outputFilePath + os.sep + "plots"
sizingFilePath = outputFilePath + os.sep + "sizing"

os.makedirs(overrideFilePath, exist_ok=True)
os.makedirs(sizingFilePath, exist_ok=True)

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("numpy.__version__ : " + np.__version__)
lg("pandas.__version__: " + pd.__version__)

if PLOT_HTML or PLOT_PNG:
    import plotly as plt
    import plotly.express as px
    import plotly.graph_objs as go

    lg("plotly.__version__: " + plt.__version__)

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n=======================================================================================================\n"
)

lg("CREATE_OBFUSCATED_FILES             : " + str(CREATE_OBFUSCATED_FILES))
lg("CREATE_SIMULATOR_FILES_ONLY         : " + str(CREATE_SIMULATOR_FILES_ONLY))
lg("COHORTS                             : " + str(COHORTS))
lg("COMPUTE_EFFECTIVE_VCPU              : " + str(COMPUTE_EFFECTIVE_VCPU))
lg("FIXED                               : " + str(FIXED))
lg("PHYSICAL_STANDBY_PCT                : " + str(PHYSICAL_STANDBY_PCT))

lg("PLOTS_ADJUSTED_YEARLY_VALUES        : " + str(PLOTS_ADJUSTED_YEARLY_VALUES))
lg("PLOT_ADJUSTMENT_MULTIPLIERS         : " + str(PLOT_ADJUSTMENT_MULTIPLIERS))
lg("PLOT_INSTANCE_COUNT_LIMIT           : " + str(PLOT_INSTANCE_COUNT_LIMIT))
lg("PLOT_HTML                           : " + str(PLOT_HTML))
lg("PLOT_PNG                            : " + str(PLOT_PNG))
lg("PLOT_PERCENTILES                    : " + str(PLOT_PERCENTILES))
lg("PLOT_SUM_OF_MAX                     : " + str(PLOT_SUM_OF_MAX))
lg("PLOT_INDIVIDUAL_DB                  : " + str(PLOT_INDIVIDUAL_DB))
lg("PLOT_INDIVIDUAL_DB_LIMIT            : " + str(PLOT_INDIVIDUAL_DB_LIMIT))
lg("PLOT_SUPPRESSED_COHORTS             : " + str(PLOT_SUPPRESSED_COHORTS))
lg("PLOT_UNADJUSTED_VALUES              : " + str(PLOT_UNADJUSTED_VALUES))

lg("PRECISION                           : " + str(PRECISION))
lg("TIME_PERIODS                        : " + str(TIME_PERIODS))
lg("ROLLUP_CSV_FILES_SUPRESSED_COHORTS  : " + str(ROLLUP_CSV_FILES_SUPRESSED_COHORTS))

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------

structureFilename = outputFilePath + os.sep + "occa_sizing_structure_db_combined"

if not os.path.exists(structureFilename + ".csv"):
    lg(
        "File "
        + structureFilename
        + ".csv is missing; please run occa_Add_Properties.py before continuing"
    )

    quit()

# ---

resultsFilePrefix = "occa_sizing_spreadsheet"
simulatorFilePrefix = "occa_sizing_simulator"


# Initialize the concrete plot object for daily plots
area_plot = PlotFactory.create_plot("area")
area_plot.load_args(data_frequency="Daily")

startTime = time.time()
lg(
    "Processing emcc_sizing extract files in directory "
    + extractFilePath
    + " in working directory "
    + os.getcwd()
)

structureDf = pd.read_csv(structureFilename + ".csv")
structureDf.columns = [c.strip() for c in structureDf.columns]

if len(structureDf) == 0:
    lg("\nFile " + structureFilename + ".csv is empty; cannot continue.")
    quit()

structureDf["cdb_cohort"] = structureDf["cdb_cohort"].fillna("")
structureDf["cdb_cohort"] = structureDf["cdb_cohort"].str.strip()

structureDf["db_cohort"] = structureDf["cdb_cohort"]

if FIXED:
    cwd = "fixed"
    extract_dttm_utc = "1989-07-09 00:00:00"
    structureDf["extract_dttm_utc"] = extract_dttm_utc
    now = "1989-07-09 00:00:00"
    platformName = "fixed"
    __version__ = "fixed"
else:
    cwd = os.getcwd().split(os.sep)[-1]
    extract_dttm_utc = structureDf["extract_dttm_utc"].unique()[0]
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    platformName = platform.system()

structureDf["cwd"] = cwd
structureDf["platform"] = platformName
structureDf["dbms_vendor"] = "ORACLE"

# Get me the X column "physical_cpu_count" all the values that are null, out of that  select the column Y "cores_per_chip"  and assign = 0 to all the rows , if the column doesn't exists creates it with NaN value
structureDf.loc[structureDf["physical_cpu_count"].isnull(), "cores_per_chip"] = 0
structureDf.loc[structureDf["physical_cpu_count"].notnull(), "cores_per_chip"] = (
    structureDf["total_cpu_cores"] / structureDf["physical_cpu_count"]
)
structureDf.loc[structureDf["cores_per_chip"].isnull(), "cores_per_chip"] = 0
structureDf["cores_per_chip"] = structureDf["cores_per_chip"].astype(int)

structureDf["mem_gb"] = round(structureDf["mem_gb"], PRECISION)
structureDf["sga_size_gb"] = structureDf[
    ["init_sga_max_size_gb", "init_sga_target_gb", "sga_total_sga_gb"]
].max(axis=1)
structureDf["sga_size_gb"] = round(structureDf["sga_size_gb"], PRECISION)

structureDf["pga_size_gb"] = structureDf[
    ["init_pga_aggregate_limit_gb", "init_pga_aggregate_target_gb"]
].max(axis=1)
structureDf["pga_size_gb"] = round(structureDf["pga_size_gb"], PRECISION)

structureDf["host_subscr_pct"] = round(
    structureDf["host_db_cpu_count_limit"] / structureDf["logical_cpu_count"] * 100,
    PRECISION,
)
structureDf["db_cpu_count_guarantee_pct"] = round(
    (structureDf["db_cpu_count_guarantee"] / (structureDf["logical_cpu_count"])) * 100,
    PRECISION,
)

structureDf.loc[structureDf["logical_cpu_count"] == 0, "host_subscr_pct"] = 0
structureDf.loc[structureDf["logical_cpu_count"] == 0, "db_cpu_count_guarantee_pct"] = 0

if "cdb_scope_ovr" not in structureDf:
    structureDf["cdb_scope_ovr"] = ""
    structureDf["cdb_percentage_ovr"] = ""
else:
    structureDf["cdb_ovr"] = structureDf["cdb_ovr"].fillna("")
    structureDf["cdb_scope_ovr"] = structureDf["cdb_scope_ovr"].fillna("")
    structureDf["cdb_percentage_ovr"] = structureDf["cdb_percentage_ovr"].fillna("")

# ---

databaseOk = True

filename = outputFilePath + os.sep + "missing_Use_Values_from_Database.csv"

df = structureDf[(structureDf["cdb_ovr"] == "") & (structureDf["cdb_scope_ovr"] != "")]

if len(df) > 0:
    df = df[["cdb", "cdb_ovr", "cdb_scope_ovr", "cdb_percentage_ovr"]].drop_duplicates()
    df.columns = [
        "cdb",
        "Use Values from Database Name",
        "Use Values Scope",
        "Use Values Pct",
    ]
    df.sort_values(["cdb"]).to_csv(filename, index=False)

    lg(
        '\nAt least one database has a value in column "Use Values Scope" but no value in column "Use Values from Database Name".'
    )
    lg("Invalid databases have been written to " + filename)

    databaseOk = False

elif os.path.exists(filename):
    os.remove(filename)

# ---

filename = outputFilePath + os.sep + "missing_Use_Values_Scope.csv"

df = structureDf[(structureDf["cdb_ovr"] != "") & (structureDf["cdb_scope_ovr"] == "")]

if len(df) > 0:
    df = df[["cdb", "cdb_ovr", "cdb_scope_ovr", "cdb_percentage_ovr"]].drop_duplicates()
    df.columns = [
        "cdb",
        "Use Values from Database Name",
        "Use Values Scope",
        "Use Values Pct",
    ]
    df.sort_values(["cdb"]).to_csv(filename, index=False)

    lg(
        '\nAt least one database has a value in column "Use Values from Database Name" but no value in column "Use Values Scope".'
    )
    lg("Invalid databases have been written to " + filename)

    databaseOk = False

elif os.path.exists(filename):
    os.remove(filename)

# ---

filename = outputFilePath + os.sep + "invalid_Use_Values_Scope.csv"

df = structureDf[
    (structureDf["cdb_ovr"] != "")
    & (
        ~structureDf["cdb_scope_ovr"].isin(
            ["All", PHYSICAL_STANDBY, PRIMARY_PLUS_STANDBY, STANDBY_INSTANCE_METRICS]
        )
    )
].copy()

if len(df) > 0:
    df = df[["cdb", "cdb_ovr", "cdb_scope_ovr", "cdb_percentage_ovr"]].drop_duplicates()
    df.columns = [
        "cdb",
        "Use Values from Database Name",
        "Use Values Scope",
        "Use Values Pct",
    ]
    df.sort_values(["cdb"]).to_csv(filename, index=False)

    lg('\nAt least one database has an invalid value for "Use Values Scope"')
    lg("Invalid databases have been written to " + filename)

    databaseOk = False

elif os.path.exists(filename):
    os.remove(filename)

# ---

filename = outputFilePath + os.sep + "invalid_Use_Values_Pct.csv"

df = structureDf[
    (structureDf["cdb_percentage_ovr"] != "")
    & (~structureDf["cdb_scope_ovr"].isin(["All", PHYSICAL_STANDBY]))
].copy()

if len(df) > 0:
    df = df[["cdb", "cdb_ovr", "cdb_scope_ovr", "cdb_percentage_ovr"]].drop_duplicates()
    df.columns = [
        "cdb",
        "Use Values from Database Name",
        "Use Values Scope",
        "Use Values Pct",
    ]
    df.sort_values(["cdb"]).to_csv(filename, index=False)

    lg(
        '\nAt least one database has a value in column "Use Values Pct" and a value in column "Use Values Scope" that does not use a percentage.'
    )
    lg("Invalid entries have been written to " + filename)

    databaseOk = False

elif os.path.exists(filename):
    os.remove(filename)

# ---

structureDf.loc[
    (structureDf["cdb_scope_ovr"] == PHYSICAL_STANDBY)
    & (structureDf["cdb_percentage_ovr"] == ""),
    "cdb_percentage_ovr",
] = PHYSICAL_STANDBY_PCT
structureDf.loc[
    (structureDf["cdb_scope_ovr"] == "All") & (structureDf["cdb_percentage_ovr"] == ""),
    "cdb_percentage_ovr",
] = 100

try:
    structureDf["cdb_percentage_ovr"] = structureDf["cdb_percentage_ovr"].apply(
        pd.to_numeric
    )

    df = structureDf[structureDf["cdb_percentage_ovr"] < 0.0]

    if len(df) > 0:
        databasesOk = False
        lg(
            "\n\nThere are "
            + str(len(df))
            + ' value(s) in column "Use Value Pct" that are either < 0.0.'
        )

except Exception as fc:
    databasesOk = False
    lg('\n\nOne or more values in column "Use Value Pct" is a non-numeric value.')

# ---

if not databaseOk:
    lg(
        "\n\nPlease correct the inconsistencies in file "
        + propertiesFilePath
        + os.sep
        + "properties_database.csv, re-run occa_Add_Properties and then re-run this script.\n"
    )

    quit()

# ---

if "db_ovr" not in structureDf:
    structureDf["db_ovr"] = ""
structureDf["db_ovr"] = structureDf["db_ovr"].fillna("")

if "db_logons_ovr" not in structureDf:
    structureDf["db_logons_ovr"] = np.nan

structureDf["create_dttm_utc"] = now
structureDf["source"] = SOURCE
structureDf["version"] = __version__

# ----------------------------------------------------------------------------------------------------------------------

duplicateTestResults, structureDf = Duplicate_Tests.duplicateTests(
    structureDf, "Run_Metric_Analysis", outputFilePath
)

# ----------------------------------------------------------------------------------------------------------------------
#
# Following logic is needed just in case we are creating spreadsheets from a combined file that also includes new cpu attributes
#
if (
    "ecache_in_mb" in structureDf
    or "impl" in structureDf
    or "revision" in structureDf
    or "is_hyperthread_enabled" in structureDf
):
    try:
        structureDf.drop(
            ["ecache_in_mb", "impl", "revision", "is_hyperthread_enabled"],
            axis=1,
            inplace=True,
        )
    except:
        pass

if os.path.exists(extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"):
    try:
        cpuDf = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"
        )
    except:
        cpuDdf = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv",
            encoding="ISO-8859-1",
        )

    cols = [c.strip() for c in cpuDf.columns]
    cpuDf.columns = cols

    cpuDf = cpuDf[
        ["target_guid", "ecache_in_mb", "impl", "revision", "is_hyperthread_enabled"]
    ]
    cpuDf.columns = [
        "host_target_guid",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
    ]

    structureDf = pd.merge(
        left=structureDf,
        right=cpuDf,
        how="left",
        left_on="host_target_guid",
        right_on="host_target_guid",
    )

else:
    structureDf["ecache_in_mb"] = -1
    structureDf["impl"] = "not_loaded"
    structureDf["revision"] = "not_loaded"
    structureDf["is_hyperthread_enabled"] = -1

# ----------

if "h_total_cpu_cores_ovr" not in structureDf:
    structureDf["h_total_cpu_cores_ovr"] = np.nan
if "cdb_type_version" not in structureDf:
    structureDf["cdb_type_version"] = ""
if "db_type_version" not in structureDf:
    structureDf["db_type_version"] = ""
if "host_type_version" not in structureDf:
    structureDf["host_type_version"] = ""

structureDf["ma"] = structureDf["ma"].fillna("")
structureDf["cpu_type"] = structureDf.apply(
    lambda r: getCPUType(r["ma"], r["impl"]), axis=1
)

if COMPUTE_EFFECTIVE_VCPU:
    _ = structureDf[structureDf["cpu_type"].isin(VCPU_REDUCABLE_CPU_TYPES)]

    if len(_) == 0:
        lg(
            "\nThere are no cpu_types that require host utilization-based vCPU reduction"
        )
        COMPUTE_EFFECTIVE_VCPU = False

# ---

#
# Get simulator hosts now so that we keep hosts not running databases
#

simHostsDf = structureDf.copy()
simHostsDf.loc[simHostsDf["h_cpu_type_ovr"].notnull(), "cpu_type"] = simHostsDf[
    "h_cpu_type_ovr"
]
simHostsDf.loc[
    simHostsDf["h_physical_cpu_count_ovr"].notnull(), "physical_cpu_count"
] = simHostsDf["h_physical_cpu_count_ovr"]
simHostsDf.loc[simHostsDf["h_total_cpu_cores_ovr"].notnull(), "total_cpu_cores"] = (
    simHostsDf["h_total_cpu_cores_ovr"]
)

hostIndexDf = simHostsDf[["dbmachine", "cluster", "host"]].drop_duplicates()
hostIndexDf["dbmachine"] = hostIndexDf["dbmachine"].fillna("none")

#
# Force hosts on a DB machine into a common cluster for the purposes of generating a host index
#
hostIndexDf.loc[hostIndexDf["dbmachine"] != "none", "cluster"] = hostIndexDf[
    "dbmachine"
]
hostIndexDf.loc[hostIndexDf["cluster"] == "none", "cluster"] = hostIndexDf["host"]

hostIndexDf.sort_values(["dbmachine", "cluster", "host"], inplace=True)
hostIndexDf["cluster_host_rn"] = (
    hostIndexDf.groupby(["dbmachine", "cluster"]).cumcount() + 1
)
hostIndexDf.drop(columns=["dbmachine", "cluster"], inplace=True)

simHostsDf = pd.merge(
    left=simHostsDf, right=hostIndexDf, how="left", left_on="host", right_on="host"
)

simHostsDf = simHostsDf[
    [
        "host_num",
        "host",
        "cluster",
        "dbmachine",
        "dbmachine_owner",
        "physical_cpu_count",
        "total_cpu_cores",
        "logical_cpu_count",
        "mem_gb",
        "nr_huge_pages",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "vendor_name",
        "dist_version",
        "host_instance_count",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "host_status",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "host_type_version",
        "cluster_host_rn",
        "host_last_load_time_utc",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
].drop_duplicates()

simHostsDf.columns = [
    "h_num",
    "h",
    "cdb_cluster",
    "dbmachine",
    "dbmachine_owner",
    "h_physical_cpu_count",
    "h_total_cpu_cores",
    "h_logical_cpu_count",
    "h_mem_gb",
    "h_vm_nr_huge_pages",
    "h_ecache_in_mb",
    "h_impl",
    "h_revision",
    "h_is_hyperthread_enabled",
    "h_freq",
    "h_cpu_type",
    "h_ma",
    "h_system_config",
    "h_vendor_name",
    "h_dist_version",
    "h_inst_count",
    "h_cpu_count_total",
    "h_subscr_pct",
    "h_status",
    "h_cost_center",
    "h_department",
    "h_lifecycle_status",
    "h_line_of_bus",
    "h_location",
    "host_type_version",
    "cdb_cluster_host_rn",
    "h_last_load_time_utc",
    "h_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

# ---

#
# Eliminate hosts not running databases; they cannot be part of a sizing scenario
#

structureDf = structureDf[structureDf["db"] != "none"]

# ---

simInstancesDf = structureDf[
    [
        "cdb_num",
        "cdb",
        "cdb_type",
        "cdb_standby_type",
        "cluster",
        "cdb_owner",
        "dbmachine",
        "dbmachine_owner",
        "db_num",
        "db_version",
        "db",
        "db_standby_type",
        "sga_size_gb",
        "pga_size_gb",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "host_subscr_pct",
        "db_status",
        "db_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_cohort",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "cdb_type_version",
        "db_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
]

simInstancesDf.columns = [
    "cdb_num",
    "cdb",
    "cdb_type",
    "cdb_standby_type",
    "cdb_cluster",
    "cdb_owner",
    "dbmachine",
    "dbmachine_owner",
    "inst_num",
    "inst_version",
    "inst",
    "inst_standby_type",
    "inst_sga_size_gb",
    "inst_pga_size_gb",
    "inst_i_use_large_pages",
    "inst_cpu_count_guarantee",
    "inst_cpu_count_limit",
    "h_subscr_pct",
    "inst_status",
    "inst_last_load_time_utc",
    "cdb_cost_center",
    "cdb_department",
    "cdb_cohort",
    "cdb_lifecycle_status",
    "cdb_line_of_bus",
    "cdb_location",
    "db_cost_center",
    "db_department",
    "db_cohort",
    "db_lifecycle_status",
    "db_line_of_bus",
    "db_location",
    "cdb_type_version",
    "db_type_version",
    "cdb_guid",
    "inst_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

simInstancesDf = simInstancesDf[simInstancesDf.inst != "none"]

# ---

simPlacementsDf = structureDf.copy()

if 1 == 0:
    printDf("xxx simPlacementsDf", simPlacementsDf)

simPlacementsDf.loc[simPlacementsDf["h_cpu_type_ovr"].notnull(), "cpu_type"] = (
    simPlacementsDf["h_cpu_type_ovr"]
)
simPlacementsDf.loc[
    simPlacementsDf["h_physical_cpu_count_ovr"].notnull(), "physical_cpu_count"
] = simPlacementsDf["h_physical_cpu_count_ovr"]
simPlacementsDf.loc[
    simPlacementsDf["h_total_cpu_cores_ovr"].notnull(), "total_cpu_cores"
] = simPlacementsDf["h_total_cpu_cores_ovr"]

simPlacementsDf = simPlacementsDf[
    [
        "cdb_num",
        "cdb",
        "cdb_type",
        "cdb_standby_type",
        "cluster",
        "cdb_owner",
        "dbmachine",
        "dbmachine_owner",
        "db_num",
        "db_version",
        "db",
        "db_standby_type",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "db_cpu_count_guarantee_pct",
        "host_num",
        "host",
        "physical_cpu_count",
        "total_cpu_cores",
        "logical_cpu_count",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "mem_gb",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "db_status",
        "db_last_load_time_utc",
        "host_status",
        "host_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_cohort",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_status",
        "cdb_last_load_time_utc",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "db_owner",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]
]

simPlacementsDf.columns = [
    "cdb_num",
    "cdb",
    "cdb_type",
    "cdb_standby_type",
    "cdb_cluster",
    "cdb_owner",
    "dbmachine",
    "dbmachine_owner",
    "inst_num",
    "inst_version",
    "inst",
    "inst_standby_type",
    "inst_cpu_count_guarantee",
    "inst_cpu_count_limit",
    "inst_cpu_count_guarantee_pct",
    "h_num",
    "h",
    "h_physical_cpu_count",
    "h_total_cpu_cores",
    "h_logical_cpu_count",
    "h_cpu_count_total",
    "h_subscr_pct",
    "h_mem_gb",
    "h_freq",
    "h_cpu_type",
    "h_ma",
    "h_system_config",
    "inst_status",
    "inst_last_load_time_utc",
    "h_status",
    "h_last_load_time_utc",
    "cdb_cost_center",
    "cdb_department",
    "cdb_cohort",
    "cdb_lifecycle_status",
    "cdb_line_of_bus",
    "cdb_location",
    "cdb_status",
    "cdb_last_load_time_utc",
    "db_cost_center",
    "db_department",
    "db_cohort",
    "db_lifecycle_status",
    "db_line_of_bus",
    "db_location",
    "db_owner",
    "cdb_type_version",
    "db_type_version",
    "host_type_version",
    "cdb_guid",
    "inst_guid",
    "h_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

simPlacementsDf = simPlacementsDf[simPlacementsDf.inst != "none"]

# ----------

hostsDf = structureDf[
    [
        "host",
        "physical_cpu_count",
        "cores_per_chip",
        "mem_gb",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_description_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "host_status",
        "host_last_load_time_utc",
        "logical_cpu_count",
        "total_cpu_cores",
        "nr_huge_pages",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "vendor_name",
        "dist_version",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "host_type_version",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
].drop_duplicates()

hostsDf.loc[hostsDf["h_cpu_type_ovr"].notnull(), "cpu_type"] = hostsDf["h_cpu_type_ovr"]
hostsDf.loc[hostsDf["h_cores_per_chip_ovr"].notnull(), "cores_per_chip"] = hostsDf[
    "h_total_cpu_cores_ovr"
]
hostsDf.loc[hostsDf["h_physical_cpu_count_ovr"].notnull(), "physical_cpu_count"] = (
    hostsDf["h_physical_cpu_count_ovr"]
)
hostsDf.loc[hostsDf["h_total_cpu_cores_ovr"].notnull(), "total_cpu_cores"] = hostsDf[
    "h_total_cpu_cores_ovr"
]

cdbsDf = structureDf[
    [
        "cdb_cohort",
        "cdb",
        "cdb_instance_count",
        "dbms_vendor",
        "cdb_version",
        "cdb_version_sizing",
        "clustered",
        "cdb_size_allocated_ovr",
        "cdb_size_used_ovr",
        "cdb_ovr",
        "cdb_scope_ovr",
        "cdb_percentage_ovr",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_type_version",
        "cdb_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
].drop_duplicates()

dbPlacementsDf = structureDf[
    [
        "cdb",
        "db",
        "host",
        "sga_size_gb",
        "pga_size_gb",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "db_status",
        "db_last_load_time_utc",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "db_vcpu_ovr",
        "db_sga_mb_ovr",
        "db_pga_mb_ovr",
        "db_iops_ovr",
        "db_logons_ovr",
        "db_ovr",
        "init_sessions",
        "init_processes",
        "init_sga_max_size_gb",
        "init_sga_target_gb",
        "init_pga_aggregate_limit_gb",
        "init_pga_aggregate_target_gb",
        "host_subscr_pct",
        "host_status",
        "host_last_load_time_utc",
        "physical_cpu_count",
        "cores_per_chip",
        "logical_cpu_count",
        "total_cpu_cores",
        "mem_gb",
        "nr_huge_pages",
        "host_db_cpu_count_limit",
        "vendor_name",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "dist_version",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "cdb_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_cohort",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "init_cpu_count",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
].drop_duplicates()

dbPlacementsDf.loc[dbPlacementsDf["h_cpu_type_ovr"].notnull(), "cpu_type"] = (
    dbPlacementsDf["h_cpu_type_ovr"]
)
dbPlacementsDf.loc[
    dbPlacementsDf["h_cores_per_chip_ovr"].notnull(), "cores_per_chip"
] = dbPlacementsDf["h_total_cpu_cores_ovr"]
dbPlacementsDf.loc[
    dbPlacementsDf["h_physical_cpu_count_ovr"].notnull(), "physical_cpu_count"
] = dbPlacementsDf["h_physical_cpu_count_ovr"]
dbPlacementsDf.loc[
    dbPlacementsDf["h_total_cpu_cores_ovr"].notnull(), "total_cpu_cores"
] = dbPlacementsDf["h_total_cpu_cores_ovr"]

# ---

simulatorFilePath = ROOT_DIR + os.sep + "occa_sizing_output" + os.sep + "simulator"
os.makedirs(simulatorFilePath, exist_ok=True)

if CREATE_OBFUSCATED_FILES:
    os.makedirs(simulatorFilePath + os.sep + "obfuscated", exist_ok=True)

# ---

simHostsDf.sort_values(["h"]).to_csv(
    simulatorFilePath + os.sep + simulatorFilePrefix + "_hosts.csv", index=False
)
simInstancesDf.sort_values(["inst"]).to_csv(
    simulatorFilePath + os.sep + simulatorFilePrefix + "_instances.csv", index=False
)
simPlacementsDf.sort_values(["inst"]).to_csv(
    simulatorFilePath + os.sep + simulatorFilePrefix + "_placements.csv", index=False
)

lg("\nWrote simulator files to:")
lg("    " + simulatorFilePath + os.sep + simulatorFilePrefix + "_hosts.csv")
lg("    " + simulatorFilePath + os.sep + simulatorFilePrefix + "_instances.csv")
lg("    " + simulatorFilePath + os.sep + simulatorFilePrefix + "_placements.csv")

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ----------------------------------------------------------------------------------------------------------------------

if CREATE_OBFUSCATED_FILES:
    simHostsODf = simHostsDf.copy()
    simInstancesODf = simInstancesDf.copy()
    simPlacementsODf = simPlacementsDf.copy()

    # ---

    cdbDict = (
        simInstancesODf[["cdb", "cdb_num"]].set_index("cdb").drop_duplicates().to_dict()
    )
    cdbDict = cdbDict["cdb_num"]

    for k in cdbDict:
        cdbDict[k] = "cdb-" + str(cdbDict[k]).zfill(3)

    hostDict = simHostsODf[["h", "h_num"]].set_index("h").drop_duplicates().to_dict()
    hostDict = hostDict["h_num"]

    for k in hostDict:
        hostDict[k] = "h-" + str(hostDict[k]).zfill(3)

    instanceDict = (
        simInstancesODf[["inst", "inst_num"]]
        .set_index("inst")
        .drop_duplicates()
        .to_dict()
    )
    instanceDict = instanceDict["inst_num"]

    for k in instanceDict:
        instanceDict[k] = "inst-" + str(instanceDict[k]).zfill(3)

    # ---

    simInstancesODf.replace({"cdb": cdbDict}, inplace=True)
    simPlacementsODf.replace({"cdb": cdbDict}, inplace=True)

    simInstancesODf.replace({"inst": instanceDict}, inplace=True)
    simPlacementsODf.replace({"inst": instanceDict}, inplace=True)

    simHostsODf.replace({"h": hostDict}, inplace=True)
    simPlacementsODf.replace({"h": hostDict}, inplace=True)

    # ---

    ctr, cdbClusterDict = 1, {}
    for i in simPlacementsODf.cdb_cluster.unique():
        if i == "none":
            continue

        cdbClusterDict[i] = "cdb_cluster-" + str(ctr).zfill(3)
        ctr += 1

    simHostsODf.replace({"cdb_cluster": cdbClusterDict}, inplace=True)
    simInstancesODf.replace({"cdb_cluster": cdbClusterDict}, inplace=True)
    simPlacementsODf.replace({"cdb_cluster": cdbClusterDict}, inplace=True)

    # ---

    ctr, cdbOwnerDict = 1, {}
    for i in simPlacementsODf.cdb_owner.unique():
        if i == "none":
            continue

        cdbOwnerDict[i] = "cdb_owner-" + str(ctr).zfill(3)
        ctr += 1

    simInstancesODf.replace({"cdb_owner": cdbOwnerDict}, inplace=True)
    simPlacementsODf.replace({"cdb_owner": cdbOwnerDict}, inplace=True)

    # ---

    ctr, dbmachineDict = 1, {}
    for i in simPlacementsODf.dbmachine.unique():
        if i == "none":
            continue

        dbmachineDict[i] = "dbmachine-" + str(ctr).zfill(3)
        ctr += 1

    simHostsODf.replace({"dbmachine": dbmachineDict}, inplace=True)
    simInstancesODf.replace({"dbmachine": dbmachineDict}, inplace=True)
    simPlacementsODf.replace({"dbmachine": dbmachineDict}, inplace=True)

    # ---

    ctr, dbmachineOwnerDict = 1, {}
    for i in simPlacementsODf.dbmachine_owner.unique():
        if i == "none":
            continue

        dbmachineOwnerDict[i] = "dbmachine_owner-" + str(ctr).zfill(3)
        ctr += 1

    simHostsODf.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    simInstancesODf.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)
    simPlacementsODf.replace({"dbmachine_owner": dbmachineOwnerDict}, inplace=True)

    # ---

    simHostsODf.sort_values(["h"]).to_csv(
        simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_hosts.csv",
        index=False,
    )
    simInstancesODf.sort_values(["inst"]).to_csv(
        simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_instances.csv",
        index=False,
    )
    simPlacementsODf.sort_values(["inst"]).to_csv(
        simulatorFilePath
        + os.sep
        + "obfuscated"
        + os.sep
        + simulatorFilePrefix
        + "_placements.csv",
        index=False,
    )

    if 1 == 0:
        lg("\nWrote obfuscated simulator files to:")
        lg(
            "    "
            + simulatorFilePath
            + os.sep
            + "obfuscated"
            + os.sep
            + simulatorFilePrefix
            + "_hosts.csv"
        )
        lg(
            "    "
            + simulatorFilePath
            + os.sep
            + "obfuscated"
            + os.sep
            + simulatorFilePrefix
            + "_instances.csv"
        )
        lg(
            "    "
            + simulatorFilePath
            + os.sep
            + "obfuscated"
            + os.sep
            + simulatorFilePrefix
            + "_placements.csv"
        )

# ----------------------------------------------------------------------------------------------------------------------

if CREATE_SIMULATOR_FILES_ONLY:
    lg(
        "\n\nCREATE_SIMULATOR_FILES_ONLY = True; terminating after creation of simulator files\n\n"
    )

    Duplicate_Tests.emitDuplicateTestResults(duplicateTestResults)

    lg(
        "\n\nAll files written to directories rooted @ "
        + (cwd if ROOT_DIR == "." else ROOT_DIR)
    )
    lg(
        "\nProcessing "
        + str(len(structureDf))
        + " rows completed in "
        + str(round(time.time() - startTime, 3))
        + " s"
    )

    quit()

# ----------------------------------------------------------------------------------------------------------------------

DEBUG_COHORT = []

try:
    DEBUG_CDB = [] if args.debugcdb == "" else args.debugcdb.split(",")
except:
    DEBUG_CDB = []

try:
    METRIC_CDB = [] if args.metriccdb == "" else args.metriccdb.split(",")
except:
    METRIC_CDB = []

WRITE_DEBUG_FILES = args.writedebug.upper() == "Y"

# ----------------------------------------------------------------------------------------------------------------------

overriddenDbsDf = dbPlacementsDf[dbPlacementsDf["db_ovr"] != ""][
    ["db", "db_target_guid", "db_ovr"]
].drop_duplicates()
overriddenDbsDf.rename(
    columns={
        "db": "db_old",
        "db_target_guid": "db_target_guid_old",
        "db_ovr": "db_new",
    },
    inplace=True,
)

overriddenDbsDf = pd.merge(
    left=overriddenDbsDf,
    right=dbPlacementsDf[["db", "db_target_guid"]],
    how="left",
    left_on="db_new",
    right_on="db",
)
overriddenDbsDf.drop(columns=["db"], inplace=True)
overriddenDbsDf.rename(columns={"db_target_guid": "db_target_guid_new"}, inplace=True)

filename = overrideFilePath + os.sep + "overridden_Instances.csv"
overriddenDbsDf.sort_values(["db_old"]).to_csv(filename, index=False)
lg("\nWrote file " + filename)

# ---

overriddenCdbsDf = cdbsDf[cdbsDf["cdb_ovr"] != ""][
    [
        "cdb_cohort",
        "cdb",
        "cdb_target_guid",
        "cdb_ovr",
        "cdb_scope_ovr",
        "cdb_percentage_ovr",
    ]
].drop_duplicates()
overriddenCdbsDf.rename(
    columns={
        "cdb_cohort": "cdb_cohort_old",
        "cdb": "cdb_old",
        "cdb_target_guid": "cdb_target_guid_old",
        "cdb_ovr": "cdb_new",
    },
    inplace=True,
)

overriddenCdbsDf = pd.merge(
    left=overriddenCdbsDf,
    right=cdbsDf[["cdb", "clustered", "cdb_target_guid"]],
    how="left",
    left_on="cdb_new",
    right_on="cdb",
)
overriddenCdbsDf.drop(columns=["cdb"], inplace=True)
overriddenCdbsDf.rename(
    columns={
        "cdb": "cdb_new",
        "clustered": "cdb_type_new",
        "cdb_target_guid": "cdb_target_guid_new",
    },
    inplace=True,
)
overriddenCdbsDf.loc[
    overriddenCdbsDf["cdb_type_new"] == "NON-CLUSTERED", "cdb_type_new"
] = "oracle_database"
overriddenCdbsDf.loc[
    overriddenCdbsDf["cdb_type_new"] == "CLUSTERED", "cdb_type_new"
] = "rac_database"

overriddenCdbsDf["cdb_percentage_ovr"] = overriddenCdbsDf["cdb_percentage_ovr"].apply(
    pd.to_numeric
)

aggregateCdbInstancesDf = overriddenCdbsDf[
    overriddenCdbsDf["cdb_scope_ovr"].isin([PRIMARY_PLUS_STANDBY])
]
overriddenCdbInstancesDf = overriddenCdbsDf[
    overriddenCdbsDf["cdb_scope_ovr"].isin(["All", PHYSICAL_STANDBY])
]

filename = overrideFilePath + os.sep + "aggregate_Cdb_Instances.csv"

if len(aggregateCdbInstancesDf) > 0:
    aggregateCdbInstancesDf.sort_values(["cdb_old"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)
elif os.path.exists(filename):
    os.remove(filename)

# ---

filename = overrideFilePath + os.sep + "overridden_Databases.csv"

if len(overriddenCdbsDf) > 0:
    overriddenCdbsDf.sort_values(["cdb_old"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)
elif os.path.exists(filename):
    os.remove(filename)

# ---

overriddenInstancePropertiesDf = []

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "h_cpu_type_ovr", "cpu_type"
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "h_cores_per_chip_ovr", "cores_per_chip"
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

df = getOverrideValues(
    dbPlacementsDf,
    "db_target_guid",
    "db",
    "h_physical_cpu_count_ovr",
    "physical_cpu_count",
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "h_total_cpu_cores_ovr", "total_cpu_cores"
)
overriddenInstancePropertiesDf = (
    overriddenInstancePropertiesDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstancePropertiesDf) == 0
        else pd.concat([overriddenInstancePropertiesDf, df])
    )
)

filename = overrideFilePath + os.sep + "overridden_Instance_Properties.csv"

if len(overriddenInstancePropertiesDf) > 0:
    overriddenInstancePropertiesDf = overriddenInstancePropertiesDf[
        ["db", "name", "value", "db_target_guid"]
    ]

    overriddenInstancePropertiesDf.sort_values(["db", "name"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

else:
    lg("There are no overridden instance properties")

    if os.path.exists(filename):
        os.remove(filename)

# ---

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

overriddenCDBMetricsDf = []

df = getOverrideValues(
    cdbsDf, "cdb_target_guid", "cdb", "cdb_size_allocated_ovr", STORAGE_ALLOCATED_METRIC
)
overriddenCDBMetricsDf = (
    overriddenCDBMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenCDBMetricsDf) == 0
        else pd.concat([overriddenCDBMetricsDf, df])
    )
)

df = getOverrideValues(
    cdbsDf, "cdb_target_guid", "cdb", "cdb_size_used_ovr", STORAGE_USED_METRIC
)
overriddenCDBMetricsDf = (
    overriddenCDBMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenCDBMetricsDf) == 0
        else pd.concat([overriddenCDBMetricsDf, df])
    )
)

filename = overrideFilePath + os.sep + "overridden_Database_Metrics.csv"

if len(overriddenCDBMetricsDf) > 0:
    overriddenCDBMetricsDf["value"] = overriddenCDBMetricsDf["value"].astype(float)
    overriddenCDBMetricsDf = overriddenCDBMetricsDf[
        ["cdb", "name", "value", "cdb_target_guid"]
    ]

    overriddenCDBMetricsDf[["cdb", "name", "value", "cdb_target_guid"]].to_csv(
        filename, index=False
    )
    lg(
        "\n"
        + str(len(overriddenCDBMetricsDf["cdb"].unique()))
        + " cdbs with at least one override value have been written to file "
        + filename
    )

else:
    lg("There are no overridden cdb metrics")

    if os.path.exists(filename):
        os.remove(filename)

# ---

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

overriddenInstanceMetricsDf = []

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_vcpu_ovr", CPU_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_iops_ovr", IOPS_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_logons_ovr", LOGONS_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_pga_mb_ovr", PGA_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

df = getOverrideValues(
    dbPlacementsDf, "db_target_guid", "db", "db_sga_mb_ovr", SGA_METRIC
)
overriddenInstanceMetricsDf = (
    overriddenInstanceMetricsDf
    if len(df) == 0
    else (
        df
        if len(overriddenInstanceMetricsDf) == 0
        else pd.concat([overriddenInstanceMetricsDf, df])
    )
)

filename = overrideFilePath + os.sep + "overridden_Instance_Metrics.csv"

if len(overriddenInstanceMetricsDf) > 0:
    overriddenInstanceMetricsDf["indicator"] = overriddenInstanceMetricsDf[
        "db_target_guid"
    ].str.cat(overriddenInstanceMetricsDf["name"], sep="$$$")

    overriddenInstanceMetricsDf["value"] = overriddenInstanceMetricsDf["value"].astype(
        float
    )
    overriddenInstanceMetricsDf = overriddenInstanceMetricsDf[
        ["db", "name", "value", "db_target_guid", "indicator"]
    ]

    overriddenInstanceMetricsDf.sort_values(["db", "name"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

else:
    lg("There are no overridden instance metrics")

    if os.path.exists(filename):
        os.remove(filename)

# ---

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

cdbsDf = dbPlacementsDf[
    ["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"]
].drop_duplicates()

cdbInstanceCountsDf = dbPlacementsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"], as_index=False
)["db_target_guid"].nunique()
cdbInstanceCountsDf.columns = [
    "cdb_cohort",
    "cdb",
    "cdb_type",
    "cdb_target_guid",
    "instance_count",
]

# ---

tb = time.time()

cdbHourlyMetricsDf, cdbCohortDailyMetricsDf, instanceHourlyMetricsDf = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
overrideCDBMetricsWithTSDf, overrideInstanceMetricsWithTSDf = pd.DataFrame(), pd.DataFrame()

filename = extractFilePath + os.sep + DB_METRICS_FILE

if not os.path.exists(filename):
    lg("Telemetry file " + filename + " does not exist; cannot continue")

    quit()

try:
    metricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])
except:
    try:
        metricsDf = pd.read_csv(
            filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"], encoding="ISO-8859-1"
        )
    except Exception as fc:
        lg_cannotReadCSVFile(filename, fc)
        quit()
if metricsDf.empty :
    msg = f"The file {DB_METRICS_FILE} it's empty. cannot continue."
    print(msg)
    raise_error_when_run_from_api('EMCC', msg)
    sys.exit(1)

metricsDf = prepare_em_df(metricsDf)
metricsDf           = metricsDf[metricsDf['metric'].isin(EMCC_INSTANCE_METRICS + EMCC_STORAGE_METRICS)]
hourlyDays          = sorted(metricsDf['ROLLUP_TIMESTAMP_UTC'].dt.normalize().unique())

lg(
    "\nLoaded "
    + str(len(metricsDf))
    + " db metrics in "
    + str(round(time.time() - tb, 3))
    + " s"
)

if len(metricsDf) == 0:
    msg = "No db hourly metrics have been loaded; cannot continue"
    lg("\n\n" + msg)
    if os.getenv("RUN_FROM_API", "False") == "True":
        raise_error_when_run_from_api("EMCC: ", msg)
        sys.exit(1)

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "metrics.gb." + ln() + ".csv"
    metricsDf.groupby(
        ["TARGET_NAME", "TARGET_TYPE", "metric", "TARGET_GUID"], as_index=False
    )["SAMPLE_COUNT"].sum().sort_values(["TARGET_NAME", "metric"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

# ---

tb = time.time()

if COMPUTE_EFFECTIVE_VCPU:
    filename = extractFilePath + os.sep + HOST_METRICS_FILE

    if not os.path.exists(filename):
        lg(
            "\nTelemetry file "
            + filename
            + " does not exist; cannot apply host utilization-based vCPU reduction"
        )
        COMPUTE_EFFECTIVE_VCPU = False

    try:
        hostMetricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])
    except:
        try:
            hostMetricsDf = pd.read_csv(
                filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"], encoding="ISO-8859-1"
            )
        except Exception as fc:
            lg_cannotReadCSVFile(filename, fc)
            COMPUTE_EFFECTIVE_VCPU = False

    if hostMetricsDf.empty:
        msg = f"The file {HOST_METRICS_FILE} it's empty. cannot continue."
        print(msg)
        raise_error_when_run_from_api('EMCC',msg)
        sys.exit(1)

    if COMPUTE_EFFECTIVE_VCPU:
        lg(
            "\nLoaded "
            + str(len(hostMetricsDf))
            + " host metrics in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

if COMPUTE_EFFECTIVE_VCPU:
    hostCPUEffectiveDf = hostsDf[
        [
            "host",
            "cpu_type",
            "total_cpu_cores",
            "logical_cpu_count",
            "impl",
            "ma",
            "is_hyperthread_enabled",
            "freq",
            "vendor_name",
            "dist_version",
            "host_target_guid",
        ]
    ].copy()

    hostCPUEffectiveDf["logical_cpu_count_effective"] = hostCPUEffectiveDf.apply(
        lambda r: logical_cpu_count_effective(
            r["cpu_type"], r["total_cpu_cores"], r["logical_cpu_count"]
        ),
        axis=1,
    )

    hostCPUEffectiveDf = hostCPUEffectiveDf[
        [
            "host",
            "cpu_type",
            "total_cpu_cores",
            "logical_cpu_count",
            "logical_cpu_count_effective",
            "impl",
            "ma",
            "is_hyperthread_enabled",
            "freq",
            "vendor_name",
            "dist_version",
            "host_target_guid",
        ]
    ]

    hostCPUEffectiveDf["cwd"] = cwd
    hostCPUEffectiveDf["platform"] = platformName
    hostCPUEffectiveDf["extract_dttm_utc"] = extract_dttm_utc
    hostCPUEffectiveDf["create_dttm_utc"] = now
    hostCPUEffectiveDf["source"] = SOURCE
    hostCPUEffectiveDf["shared_version"] = SHARED_VERSION
    hostCPUEffectiveDf["version"] = __version__

    filename = sizingFilePath + os.sep + "host_effective_cpu.csv"
    hostCPUEffectiveDf.sort_values(["host"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    hostCPUEffectiveDict = {}
    for index, row in hostCPUEffectiveDf.iterrows():
        hostCPUEffectiveDict[row["host_target_guid"]] = row[
            "logical_cpu_count_effective"
        ]

    hostMetricsDf.columns = [c.strip() for c in hostMetricsDf.columns]
    hostMetricsDf["metric"] = (
        hostMetricsDf["METRIC_NAME"] + "." + hostMetricsDf["METRIC_COLUMN"]
    )
    hostMetricsDf = hostMetricsDf[hostMetricsDf["metric"] == HOST_CPU_METRIC]

    hostMetricsDf = pd.merge(
        left=hostsDf[
            [
                "host_target_guid",
                "host",
                "cpu_type",
                "total_cpu_cores",
                "logical_cpu_count",
            ]
        ],
        right=hostMetricsDf[["TARGET_GUID", "ROLLUP_TIMESTAMP_UTC", "AVERAGE"]],
        how="inner",
        left_on=["host_target_guid"],
        right_on=["TARGET_GUID"],
    )
    hostMetricsDf.drop(columns=["TARGET_GUID"], inplace=True)

    hostMetricsDf["AVERAGE_logical_cpu_count"] = round(
        hostMetricsDf["logical_cpu_count"] * (hostMetricsDf["AVERAGE"] / 100), PRECISION
    )

    hostMetricsDf["logical_cpu_count_effective"] = hostMetricsDf.apply(
        lambda r: getEffectivehostCPU(
            hostCPUEffectiveDict, r["host_target_guid"], r["AVERAGE_logical_cpu_count"]
        ),
        axis=1,
    )
    hostMetricsDf["logical_cpu_count_effective"] = round(
        hostMetricsDf["logical_cpu_count_effective"], PRECISION
    )

    hostMetricsDf["AVERAGE_logical_cpu_count_floor"] = hostMetricsDf[
        "AVERAGE_logical_cpu_count"
    ].apply(math.floor)
    hostMetricsDf["effective_o_AVERAGE_pct"] = (
        hostMetricsDf["logical_cpu_count_effective"]
        / hostMetricsDf["AVERAGE_logical_cpu_count"]
    ) * 100

    hostMetricsDf["cwd"] = cwd
    hostMetricsDf["platform"] = platformName
    hostMetricsDf["extract_dttm_utc"] = extract_dttm_utc
    hostMetricsDf["create_dttm_utc"] = now
    hostMetricsDf["source"] = SOURCE
    hostMetricsDf["shared_version"] = SHARED_VERSION
    hostMetricsDf["version"] = __version__

    filename = sizingFilePath + os.sep + "host_effective_cpu_metrics.csv"
    hostMetricsDf.sort_values(["host", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
        filename, index=False
    )
    lg("Wrote file " + filename)
    lg("")

# ---
#
# Round storage metric timestamps to the nearest day & eliminate duplicates
#
tb = time.time()

storageHourlyMetricsDf = metricsDf[
    (metricsDf["TARGET_GUID"].isin(cdbsDf["cdb_target_guid"]))
    & (metricsDf["metric"].isin(EMCC_STORAGE_METRICS))
].copy()
storageHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC_normalized"] = storageHourlyMetricsDf[
    "ROLLUP_TIMESTAMP_UTC"
].dt.normalize()
storageHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC_max"] = storageHourlyMetricsDf.groupby(
    ["TARGET_GUID", "metric", "ROLLUP_TIMESTAMP_UTC_normalized"]
)["ROLLUP_TIMESTAMP_UTC"].transform("max")

storageHourlyMetricsDf = storageHourlyMetricsDf[
    storageHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC"]
    == storageHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC_max"]
]
storageHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC"] = storageHourlyMetricsDf[
    "ROLLUP_TIMESTAMP_UTC_normalized"
]
storageHourlyMetricsDf["SAMPLE_COUNT"] = 1

storageHourlyMetricsDf.drop(
    columns=["ROLLUP_TIMESTAMP_UTC_max", "ROLLUP_TIMESTAMP_UTC_normalized"],
    inplace=True,
)

lg(
    "Created "
    + str(len(storageHourlyMetricsDf))
    + " storage hourly metrics in "
    + str(round(time.time() - tb, 3))
    + " s"
)
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "storage_hourly_metrics.gb." + ln() + ".csv"
    storageHourlyMetricsDf.groupby(
        ["TARGET_NAME", "TARGET_TYPE", "metric", "TARGET_GUID"], as_index=False
    )["SAMPLE_COUNT"].sum().sort_values(["TARGET_NAME", "metric"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

if 1 == 0:
    filename = sizingFilePath + os.sep + "storage_Hourly_Metrics.csv"
    storageHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

instanceHourlyMetricsDf = metricsDf[
    metricsDf["metric"].isin(EMCC_INSTANCE_METRICS)
].copy()

instanceHourlyMetricsDf = pd.merge(
    left=instanceHourlyMetricsDf,
    right=dbPlacementsDf[
        [
            "cdb_cohort",
            "cdb",
            "db",
            "cdb_target_guid",
            "db_target_guid",
            "db_cpu_count_limit",
            "total_cpu_cores",
            "cpu_type",
            "host_target_guid",
        ]
    ],
    how="right",
    left_on="TARGET_GUID",
    right_on="db_target_guid",
)
instanceHourlyMetricsDf["metric"] = instanceHourlyMetricsDf["metric"].fillna(
    "missing_instance"
)

tb = time.time()

instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "MINIMUM"
] = round(instanceHourlyMetricsDf["MINIMUM"] / 100, PRECISION)
instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "AVERAGE"
] = round(instanceHourlyMetricsDf["AVERAGE"] / 100, PRECISION)
instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "MAXIMUM"
] = round(instanceHourlyMetricsDf["MAXIMUM"] / 100, PRECISION)

if len(DEBUG_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "debug_cdb.instance_hourly_metrics." + ln() + ".csv"
    )
    instanceHourlyMetricsDf[instanceHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "db", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

# Adjust for how IBM captures core consumption

instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (instanceHourlyMetricsDf["cpu_type"] == "IBM"),
    "MINIMUM",
] = round(instanceHourlyMetricsDf["MINIMUM"] * AIX_DEFLATION, PRECISION)
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (instanceHourlyMetricsDf["cpu_type"] == "IBM"),
    "AVERAGE",
] = round(instanceHourlyMetricsDf["AVERAGE"] * AIX_DEFLATION, PRECISION)
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (instanceHourlyMetricsDf["cpu_type"] == "IBM"),
    "MAXIMUM",
] = round(instanceHourlyMetricsDf["MAXIMUM"] * AIX_DEFLATION, PRECISION)

# Throw out metrics that are clearly anomalous

badVCPUDf = instanceHourlyMetricsDf[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (
        instanceHourlyMetricsDf["AVERAGE"]
        > instanceHourlyMetricsDf["db_cpu_count_limit"]
        * (1 + (CPU_CAGING_ERROR_BAR_PCT / 100))
    )
].copy()
filename = sizingFilePath + os.sep + "bad_db_vcpu.csv"

if len(badVCPUDf) > 0:
    badVCPUDf.drop(
        columns=[
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
        ],
        inplace=True,
    )

    badVCPUDf["AVERAGE_o_db_cpu_count_limit"] = round(
        badVCPUDf["AVERAGE"] / badVCPUDf["db_cpu_count_limit"], PRECISION
    )

    begCols = [
        "cdb_cohort",
        "cdb",
        "db",
        "cdb_target_guid",
        "db_target_guid",
        "db_cpu_count_limit",
        "total_cpu_cores",
        "cpu_type",
        "ROLLUP_TIMESTAMP_UTC",
        "AVERAGE_o_db_cpu_count_limit",
    ]
    endCols = [c for c in badVCPUDf.columns if c not in begCols]

    badVCPUDf = badVCPUDf[begCols + endCols]

    badVCPUDf["cwd"] = cwd
    badVCPUDf["platform"] = platformName
    badVCPUDf["extract_dttm_utc"] = extract_dttm_utc
    badVCPUDf["create_dttm_utc"] = now
    badVCPUDf["source"] = SOURCE
    badVCPUDf["version"] = __version__

    badVCPUDf.sort_values(["db", "ROLLUP_TIMESTAMP_UTC"]).to_csv(filename, index=False)
    lg(
        "\nWrote "
        + str(len(badVCPUDf))
        + " rows with a value of DB vCPU > instance logcal_cpu_count"
    )

elif os.path.exists(filename):
    os.remove(filename)

# ---

instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (
        instanceHourlyMetricsDf["MINIMUM"]
        > instanceHourlyMetricsDf["db_cpu_count_limit"]
    ),
    "MINIMUM",
] = instanceHourlyMetricsDf["db_cpu_count_limit"]
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (
        instanceHourlyMetricsDf["AVERAGE"]
        > instanceHourlyMetricsDf["db_cpu_count_limit"]
    ),
    "AVERAGE",
] = instanceHourlyMetricsDf["db_cpu_count_limit"]
instanceHourlyMetricsDf.loc[
    (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
    & (
        instanceHourlyMetricsDf["MAXIMUM"]
        > instanceHourlyMetricsDf["db_cpu_count_limit"]
    ),
    "MAXIMUM",
] = instanceHourlyMetricsDf["db_cpu_count_limit"]

instanceHourlyMetricsDf = instanceHourlyMetricsDf[
    ~instanceHourlyMetricsDf["TARGET_GUID"].isnull()
]

lg("Reduced instance hourly metrics to " + str(len(instanceHourlyMetricsDf)) + " rows")
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

if len(DEBUG_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "debug_cdb.instance_hourly_metrics." + ln() + ".csv"
    )
    instanceHourlyMetricsDf[instanceHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "db", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

if COMPUTE_EFFECTIVE_VCPU:
    instanceHourlyMetricsDf = pd.merge(
        left=instanceHourlyMetricsDf,
        right=hostMetricsDf[
            ["host_target_guid", "ROLLUP_TIMESTAMP_UTC", "effective_o_AVERAGE_pct"]
        ],
        how="left",
        left_on=["host_target_guid", "ROLLUP_TIMESTAMP_UTC"],
        right_on=["host_target_guid", "ROLLUP_TIMESTAMP_UTC"],
    )

    instanceHourlyMetricsDf.loc[
        (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
        & (instanceHourlyMetricsDf["effective_o_AVERAGE_pct"] < 100),
        "MINIMUM",
    ] = instanceHourlyMetricsDf["MINIMUM"] * (
        instanceHourlyMetricsDf["effective_o_AVERAGE_pct"] / 100
    )
    instanceHourlyMetricsDf.loc[
        (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
        & (instanceHourlyMetricsDf["effective_o_AVERAGE_pct"] < 100),
        "AVERAGE",
    ] = instanceHourlyMetricsDf["AVERAGE"] * (
        instanceHourlyMetricsDf["effective_o_AVERAGE_pct"] / 100
    )
    instanceHourlyMetricsDf.loc[
        (instanceHourlyMetricsDf["metric"] == CPU_METRIC)
        & (instanceHourlyMetricsDf["effective_o_AVERAGE_pct"] < 100),
        "MAXIMUM",
    ] = instanceHourlyMetricsDf["MAXIMUM"] * (
        instanceHourlyMetricsDf["effective_o_AVERAGE_pct"] / 100
    )

    instanceHourlyMetricsDf.drop(columns=["effective_o_AVERAGE_pct"], inplace=True)

instanceHourlyMetricsDf.drop(columns=["host_target_guid"], inplace=True)

# ---

cdbHourlyStorageMetricsDf = pd.merge(
    left=storageHourlyMetricsDf,
    right=cdbsDf[["cdb_cohort", "cdb", "cdb_type", "cdb_target_guid"]],
    how="inner",
    left_on=["TARGET_GUID"],
    right_on=["cdb_target_guid"],
)
storageHourlyMetricsDf = []

# ---

counts0Df = getMetricStageCounts("0. Before Overrides", "stage.0")

lg("Finished computing stage 0 metric counts.")
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if len(METRIC_CDB) > 0:
    filename = sizingFilePath + os.sep + "metric_cdb.hourly_instance_metrics.0raw.csv"
    instanceHourlyMetricsDf[
        instanceHourlyMetricsDf["cdb"].isin(METRIC_CDB)
    ].sort_values(["cdb", "db", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

    filename = (
        sizingFilePath + os.sep + "metric_cdb.hourly_cdb_storage_metrics.0raw.csv"
    )
    cdbHourlyStorageMetricsDf[
        cdbHourlyStorageMetricsDf["cdb"].isin(METRIC_CDB)
    ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

if len(DEBUG_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "debug_cdb.instance_hourly_metrics." + ln() + ".csv"
    )
    instanceHourlyMetricsDf[instanceHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "db", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

    filename = (
        sizingFilePath
        + os.sep
        + "debug_cdb.cdb_hourly_storage_metrics."
        + ln()
        + ".csv"
    )
    cdbHourlyStorageMetricsDf[
        cdbHourlyStorageMetricsDf["cdb"].isin(DEBUG_CDB)
    ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
        filename, index=False
    )

# ---
#
# Override CDB Hourly Storage Values
#
if len(overriddenCDBMetricsDf) > 0:
    tb = time.time()
    #
    #   Replace hourly metrics with override metrics
    #
    if len(cdbHourlyStorageMetricsDf) == 0:
        #
        #       All storage metrics have been overridden
        #
        timeStampsDf = metricsDf[["ROLLUP_TIMESTAMP_UTC"]].drop_duplicates()

        df = pd.merge(
            left=overriddenCDBMetricsDf,
            right=cdbsDf[["cdb_cohort", "cdb_type", "cdb_target_guid"]],
            how="left",
            left_on=["cdb_target_guid"],
            right_on=["cdb_target_guid"],
        )

        df["TARGET_GUID"] = df["cdb_target_guid"]
        df["TARGET_NAME"] = df["cdb"]
        df["TARGET_TYPE"] = df["cdb_type"]
        df["METRIC_LABEL"] = "override"
        df["COLUMN_LABEL"] = "override"
        df["METRIC_NAME"] = "override"
        df["METRIC_COLUMN"] = "override"
        df["metric"] = df["name"]

        df["MINIMUM"] = df["value"]
        df["AVERAGE"] = df["value"]
        df["MAXIMUM"] = df["value"]
        df["STANDARD_DEVIATION"] = 0
        df["SAMPLE_COUNT"] = 1

    else:
        timeStampsDf = cdbHourlyStorageMetricsDf[
            ["ROLLUP_TIMESTAMP_UTC"]
        ].drop_duplicates()
        cdbHourlyStorageMetricsDf["indicator"] = cdbHourlyStorageMetricsDf[
            "cdb_target_guid"
        ].str.cat(cdbHourlyStorageMetricsDf["metric"], sep="$$$")

        overriddenCDBMetricsDf["indicator"] = overriddenCDBMetricsDf[
            "cdb_target_guid"
        ].str.cat(overriddenCDBMetricsDf["name"], sep="$$$")
        indicators = overriddenCDBMetricsDf["indicator"].unique()

        if 1 == 0:
            lg(
                "cdbHourlyStorageMetricsDf.columns: "
                + str(cdbHourlyStorageMetricsDf.columns)
            )
            lg(
                "overriddenCDBMetricsDf.columns   : "
                + str(overriddenCDBMetricsDf.columns)
            )

        df = pd.merge(
            left=overriddenCDBMetricsDf,
            right=cdbsDf[["cdb_cohort", "cdb_type", "cdb_target_guid"]],
            how="left",
            left_on=["cdb_target_guid"],
            right_on=["cdb_target_guid"],
        )

        df["TARGET_GUID"] = df["cdb_target_guid"]
        df["TARGET_NAME"] = df["cdb"]
        df["TARGET_TYPE"] = df["cdb_type"]
        df["METRIC_LABEL"] = "override"
        df["COLUMN_LABEL"] = "override"
        df["METRIC_NAME"] = "override"
        df["METRIC_COLUMN"] = "override"

        df["MINIMUM"] = df["value"]
        df["AVERAGE"] = df["value"]
        df["MAXIMUM"] = df["value"]
        df["STANDARD_DEVIATION"] = 0
        df["SAMPLE_COUNT"] = 1

        df.rename(columns={"name": "metric"}, inplace=True)
        df.drop(columns=["indicator", "value"], inplace=True)

    # ---

    overrideStorageHourlyMetricsWithTSDf = df.merge(timeStampsDf, how="cross")
    overrideStorageHourlyMetricsWithTSDf = overrideStorageHourlyMetricsWithTSDf[
        [
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "MAXIMUM",
            "AVERAGE",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "metric",
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "cdb_target_guid",
        ]
    ]

    if len(cdbHourlyStorageMetricsDf) == 0:
        cdbHourlyStorageMetricsDf = overrideStorageHourlyMetricsWithTSDf
    else:
        cdbHourlyStorageMetricsDf = cdbHourlyStorageMetricsDf[
            ~cdbHourlyStorageMetricsDf["indicator"].isin(indicators)
        ]
        cdbHourlyStorageMetricsDf.drop(columns=["indicator"], inplace=True)

        if 1 == 0:
            lg(
                "\nxxx len(cdbHourlyStorageMetricsDf).00           : "
                + str(len(cdbHourlyStorageMetricsDf))
            )
            lg(
                "\nxxx len(overrideStorageHourlyMetricsWithTSDf).00: "
                + str(len(overrideStorageHourlyMetricsWithTSDf))
            )

        if 1 == 0:
            filename = (
                sizingFilePath + os.sep + "cdb_Hourly_Storage_Metrics." + ln() + ".csv"
            )
            cdbHourlyStorageMetricsDf.to_csv(filename, index=False)
            lg("\nWrote file " + filename)

            filename = (
                sizingFilePath
                + os.sep
                + "override_Storage_Hourly_Metrics_With_TS."
                + ln()
                + ".csv"
            )
            overrideStorageHourlyMetricsWithTSDf.to_csv(filename, index=False)
            lg("\nWrote file " + filename)

        cdbHourlyStorageMetricsDf = pd.concat(
            [cdbHourlyStorageMetricsDf, overrideStorageHourlyMetricsWithTSDf],
            ignore_index=True,
        )

    lg(
        "\nAdded "
        + str(len(df))
        + " override metrics to cdbHourlyStorageMetricsDf in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    df = []

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if len(overriddenInstanceMetricsDf) > 0:
    #
    #   Replace hourly metrics with override mertrics
    #
    indicators = overriddenInstanceMetricsDf["indicator"].unique()
    timeStampsDf = instanceHourlyMetricsDf[["ROLLUP_TIMESTAMP_UTC"]].drop_duplicates()

    if 1 == 0:
        lg("indicators")
        lg("----------")
        lg(str(indicators))

    instanceHourlyMetricsDf["indicator"] = instanceHourlyMetricsDf[
        "db_target_guid"
    ].str.cat(instanceHourlyMetricsDf["metric"], sep="$$$")

    df = pd.merge(
        left=overriddenInstanceMetricsDf,
        right=dbPlacementsDf[
            [
                "cdb_cohort",
                "cdb",
                "cpu_type",
                "total_cpu_cores",
                "db_cpu_count_limit",
                "cdb_target_guid",
                "db_target_guid",
            ]
        ],
        how="left",
        left_on=["db_target_guid"],
        right_on=["db_target_guid"],
    )

    df["TARGET_GUID"] = df["db_target_guid"]
    df["TARGET_NAME"] = df["db"]
    df["TARGET_TYPE"] = "oracle_database"
    df["METRIC_LABEL"] = ""
    df["COLUMN_LABEL"] = ""
    df["METRIC_NAME"] = ""
    df["METRIC_COLUMN"] = ""
    df["MINIMUM"] = df["value"]
    df["AVERAGE"] = df["value"]
    df["MAXIMUM"] = df["value"]
    df["STANDARD_DEVIATION"] = 0
    df["SAMPLE_COUNT"] = 1

    df.rename(columns={"name": "metric"}, inplace=True)
    df.drop(columns=["indicator", "value"], inplace=True)

    overrideInstanceMetricsWithTSDf = df.merge(timeStampsDf, how="cross")
    overrideInstanceMetricsWithTSDf = overrideInstanceMetricsWithTSDf[
        [
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "MAXIMUM",
            "AVERAGE",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "metric",
            "cdb_cohort",
            "cdb",
            "cpu_type",
            "total_cpu_cores",
            "db",
            "db_cpu_count_limit",
            "cdb_target_guid",
            "db_target_guid",
        ]
    ]

    if 1 == 0:
        lg(
            "xxx overrideInstanceMetricsWithTSDf.columns.1: "
            + str(overrideInstanceMetricsWithTSDf.columns)
        )
        lg("xxx instanceHourlyMetricsDf before: " + str(len(instanceHourlyMetricsDf)))

    instanceHourlyMetricsDf = instanceHourlyMetricsDf[
        ~instanceHourlyMetricsDf["indicator"].isin(indicators)
    ]
    instanceHourlyMetricsDf.drop(columns=["indicator"], inplace=True)

    if 1 == 0:
        lg(
            "\nxxx len(instanceHourlyMetricsDf).00        : "
            + str(len(instanceHourlyMetricsDf))
        )
        lg(
            "xxx instanceHourlyMetricsDf.columns          : "
            + str(instanceHourlyMetricsDf.columns)
        )
        lg(
            "xxx overrideInstanceMetricsWithTSDf.columns.1: "
            + str(overrideInstanceMetricsWithTSDf.columns)
        )

    instanceHourlyMetricsDf = pd.concat(
        [instanceHourlyMetricsDf, overrideInstanceMetricsWithTSDf], ignore_index=True
    )
    lg(
        "\nAdded "
        + str(len(overrideInstanceMetricsWithTSDf))
        + " override metrics to instanceHourlyMetricsDf"
    )

    df, overrideInstanceMetricsWithTSDf = [], []

# ---

if len(DEBUG_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "debug_cdb.instance_hourly_metrics." + ln() + ".csv"
    )
    instanceHourlyMetricsDf[instanceHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "db", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

counts1Df = getMetricStageCounts("1. After Overrides", "stage.1")

lg("Finished computing stage 1 metric counts.")
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if len(overriddenDbsDf) > 0:
    tb = time.time()

    lg("\nReplacing instance hourly metrics using instance replacements")

    df0 = pd.merge(
        left=instanceHourlyMetricsDf[
            instanceHourlyMetricsDf["TARGET_GUID"].isin(
                overriddenDbsDf["db_target_guid_new"]
            )
        ],
        right=overriddenDbsDf,
        how="left",
        left_on="TARGET_GUID",
        right_on="db_target_guid_new",
    )

    df0["TARGET_NAME"] = df0["db_old"]
    df0["TARGET_GUID"] = df0["db_target_guid_old"]
    df0["db"] = df0["db_old"]
    df0["db_target_guid"] = df0["db_target_guid_old"]

    if 1 == 0:
        filename = sizingFilePath + os.sep + "override_instance_hourly." + ln() + ".csv"
        df0.sort_values(["TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    df0 = df0[instanceHourlyMetricsDf.columns]

    # ---

    df1 = instanceHourlyMetricsDf[
        ~instanceHourlyMetricsDf["TARGET_GUID"].isin(
            overriddenDbsDf["db_target_guid_old"]
        )
    ].copy()
    instanceHourlyMetricsDf = pd.concat([df0, df1], ignore_index=True)
    lg(
        "\nAdded "
        + str(len(df0))
        + " rows to instanceHourlyMetricsDf for "
        + str(len(overriddenDbsDf))
        + " instance replacements in "
        + str(round(time.time() - tb, 3))
        + " s\n"
    )

    df0, df1 = [], []

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if 1 == 0:
    filename = sizingFilePath + os.sep + "instance_hourly_metrics.gb." + ln() + ".csv"
    instanceHourlyMetricsDf.groupby(
        ["cdb", "TARGET_GUID", "TARGET_NAME", "metric"], as_index=False
    )["SAMPLE_COUNT"].sum().to_csv(filename, index=False)
    lg("Wrote file " + filename)

counts2Df = getMetricStageCounts("2. After Instance Replacements", "stage.2")

if 1 == 0:
    filename = sizingFilePath + os.sep + "instance_hourly_metrics.gb." + ln() + ".csv"
    instanceHourlyMetricsDf.groupby(
        ["cdb", "TARGET_GUID", "TARGET_NAME", "metric"], as_index=False
    )["SAMPLE_COUNT"].sum().to_csv(filename, index=False)
    lg("Wrote file " + filename)

lg("Finished computing stage 2 metric counts.")
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if len(overriddenCdbsDf) > 0:
    tb = time.time()

    lg("\nReplacing storage hourly metrics using cdb overrides")

    if 1 == 0:
        df = (
            cdbHourlyStorageMetricsDf.groupby(["cdb", "metric"], as_index=False)[
                "AVERAGE"
            ]
            .agg(["sum", "max", "count"])
            .reset_index()
        )
        filename = (
            sizingFilePath + os.sep + "cdb_Hourly_Storage_Metrics.gb." + ln() + ".csv"
        )
        df.sort_values(["cdb", "metric"]).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df0 = pd.merge(
        left=cdbHourlyStorageMetricsDf[
            cdbHourlyStorageMetricsDf["TARGET_GUID"].isin(
                overriddenCdbsDf["cdb_target_guid_new"]
            )
        ],
        right=overriddenCdbsDf,
        how="left",
        left_on="TARGET_GUID",
        right_on="cdb_target_guid_new",
    )

    df0["TARGET_NAME"] = df0["cdb_old"]
    df0["TARGET_GUID"] = df0["cdb_target_guid_old"]
    df0["TARGET_TYPE"] = df0["cdb_type_new"]
    df0["cdb_cohort"] = df0["cdb_cohort_old"]
    df0["cdb"] = df0["cdb_old"]
    df0["cdb_type"] = df0["cdb_type_new"]
    df0["cdb_target_guid"] = df0["cdb_target_guid_old"]
    #
    #   Reduce all metrics by the same amount if scope = 'All'
    #
    df0.loc[df0["cdb_scope_ovr"] == "All", "AVERAGE"] = df0["AVERAGE"] * (
        df0["cdb_percentage_ovr"] / 100
    )

    colsToDrop = [c for c in df0.columns if c not in cdbHourlyStorageMetricsDf.columns]

    df0.drop(columns=colsToDrop, inplace=True)
    df1 = cdbHourlyStorageMetricsDf[
        ~cdbHourlyStorageMetricsDf["TARGET_GUID"].isin(
            overriddenCdbsDf["cdb_target_guid_old"]
        )
    ].copy()
    cdbHourlyStorageMetricsDf = pd.concat([df0, df1], ignore_index=True)

    lg(
        "\nAdded "
        + str(len(df0))
        + " rows to cdbHourlyStorageMetricsDf for "
        + str(len(overriddenCdbsDf))
        + " cdb overrides in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    df0, df1 = [], []

    # ---

    lg("\nReplacing instance hourly metrics using cdb overrides")

    df0 = pd.merge(
        left=instanceHourlyMetricsDf[
            instanceHourlyMetricsDf["cdb_target_guid"].isin(
                overriddenCdbInstancesDf["cdb_target_guid_new"]
            )
        ],
        right=overriddenCdbInstancesDf,
        how="left",
        left_on="cdb_target_guid",
        right_on="cdb_target_guid_new",
    )

    df0["cdb_cohort"] = df0["cdb_cohort_old"]
    df0["cdb"] = df0["cdb_old"]
    df0["cdb_type"] = df0["cdb_type_new"]
    df0["cdb_target_guid"] = df0["cdb_target_guid_old"]
    #
    #   Reduce all metrics by the same amount if scope = 'All'
    #
    df0.loc[df0["cdb_scope_ovr"] == "All", "AVERAGE"] = df0["AVERAGE"] * (
        df0["cdb_percentage_ovr"] / 100
    )

    colsToDrop = [c for c in df0.columns if c not in instanceHourlyMetricsDf.columns]
    df0.drop(columns=colsToDrop, inplace=True)
    #
    #   Prevent the copies of overridden instances from being excluded if their original parent database is excluded
    #
    df0["TARGET_GUID"] = df0["TARGET_GUID"] + "-overridden"
    df0["db_target_guid"] = df0["db_target_guid"] + "-overridden"

    df1 = instanceHourlyMetricsDf[
        ~instanceHourlyMetricsDf["cdb_target_guid"].isin(
            overriddenCdbInstancesDf["cdb_target_guid_old"]
        )
    ].copy()
    instanceHourlyMetricsDf = pd.concat([df0, df1], ignore_index=True)

    lg(
        "\nAdded "
        + str(len(df0))
        + " rows to instanceHourlyMetricsDf for "
        + str(len(overriddenCdbInstancesDf))
        + " cdb overrides in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    df0, df1 = [], []

# ---

priPlusStdHourlyMetricsDf = []

if len(aggregateCdbInstancesDf) > 0:
    tb = time.time()

    lg("\nReplacing storage hourly metrics using cdb replacements")

    if WRITE_DEBUG_FILES:
        df = (
            cdbHourlyStorageMetricsDf.groupby(["cdb", "metric"], as_index=False)[
                "AVERAGE"
            ]
            .agg(["sum", "max", "count"])
            .reset_index()
        )
        filename = (
            sizingFilePath + os.sep + "cdb_Hourly_Storage_Metrics.gb." + ln() + ".csv"
        )
        df.sort_values(["cdb", "metric"]).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df0 = pd.merge(
        left=cdbHourlyStorageMetricsDf[
            cdbHourlyStorageMetricsDf["TARGET_GUID"].isin(
                aggregateCdbInstancesDf["cdb_target_guid_new"]
            )
        ],
        right=aggregateCdbInstancesDf,
        how="left",
        left_on="TARGET_GUID",
        right_on="cdb_target_guid_new",
    )

    df0["TARGET_NAME"] = df0["cdb_old"]
    df0["TARGET_GUID"] = df0["cdb_target_guid_old"]
    df0["TARGET_TYPE"] = df0["cdb_type_new"]
    df0["cdb_cohort"] = df0["cdb_cohort_old"]
    df0["cdb"] = df0["cdb_old"]
    df0["cdb_type"] = df0["cdb_type_new"]
    df0["cdb_target_guid"] = df0["cdb_target_guid_old"]

    colsToDrop = [c for c in df0.columns if c not in cdbHourlyStorageMetricsDf.columns]

    df0.drop(columns=colsToDrop, inplace=True)
    df1 = cdbHourlyStorageMetricsDf[
        ~cdbHourlyStorageMetricsDf["TARGET_GUID"].isin(
            aggregateCdbInstancesDf["cdb_target_guid_old"]
        )
    ].copy()
    cdbHourlyStorageMetricsDf = pd.concat([df0, df1], ignore_index=True)

    lg(
        "\nAdded "
        + str(len(df0))
        + " rows to cdbHourlyStorageMetricsDf for "
        + str(len(overriddenCdbsDf))
        + " cdb replacements in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    df0, df1 = [], []

    # ---

    lg("\nAdding primary instance hourly metrics using cdb replacements")
    #
    #   The SGA telemetry for standby databases is ignored
    #
    instanceHourlyMetricsDf.loc[
        (
            instanceHourlyMetricsDf["cdb_target_guid"].isin(
                aggregateCdbInstancesDf["cdb_target_guid_old"]
            )
        )
        & (instanceHourlyMetricsDf["metric"] == SGA_METRIC),
        "AVERAGE",
    ] = 0

    df0 = instanceHourlyMetricsDf[
        (
            instanceHourlyMetricsDf["cdb_target_guid"].isin(
                aggregateCdbInstancesDf["cdb_target_guid_new"]
            )
        )
        & (instanceHourlyMetricsDf["metric"].isin([CPU_METRIC, IOPS_METRIC]))
    ].copy()

    if 1 == 0:
        filename = sizingFilePath + os.sep + "df0." + ln() + ".csv"
        df0.sort_values(
            ["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df0 = pd.merge(
        left=df0,
        right=aggregateCdbInstancesDf,
        how="left",
        left_on="cdb_target_guid",
        right_on="cdb_target_guid_new",
    )

    if 1 == 0:
        filename = sizingFilePath + os.sep + "df0." + ln() + ".csv"
        df0.sort_values(
            ["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df0["cdb_cohort"] = df0["cdb_cohort_old"]
    df0["cdb"] = df0["cdb_old"]
    df0["cdb_type"] = df0["cdb_type_new"]
    df0["cdb_target_guid"] = df0["cdb_target_guid_old"]

    colsToDrop = [c for c in df0.columns if c not in instanceHourlyMetricsDf.columns]
    df0.drop(columns=colsToDrop, inplace=True)

    if 1 == 0:
        filename = sizingFilePath + os.sep + "df0." + ln() + ".csv"
        df0.sort_values(
            ["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    priPlusStdHourlyMetricsDf = pd.concat(
        [
            instanceHourlyMetricsDf[
                (
                    instanceHourlyMetricsDf["cdb_target_guid"].isin(
                        aggregateCdbInstancesDf["cdb_target_guid_old"]
                    )
                )
                & (instanceHourlyMetricsDf["metric"].isin([CPU_METRIC, IOPS_METRIC]))
            ],
            df0,
        ],
        ignore_index=True,
    )

    lg(
        "\nCreated "
        + str(len(priPlusStdHourlyMetricsDf))
        + " rows in priPlusStdHourlyMetricsDf for "
        + str(len(aggregateCdbInstancesDf))
        + " cdb replacements in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.pri_Plus_Std_Hourly_Metrics."
            + ln()
            + ".csv"
        )
        priPlusStdHourlyMetricsDf[
            priPlusStdHourlyMetricsDf["cdb"].isin(DEBUG_CDB)
        ].sort_values(["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )

    # ---

    df0 = instanceHourlyMetricsDf[
        instanceHourlyMetricsDf["cdb_target_guid"].isin(
            aggregateCdbInstancesDf["cdb_target_guid_new"]
        )
    ].copy()
    #
    #   CPU & IOPS telemetry for the Primary is ignored
    #
    df0.loc[df0["metric"].isin([CPU_METRIC, IOPS_METRIC]), "AVERAGE"] = 0
    df0 = pd.merge(
        left=df0,
        right=aggregateCdbInstancesDf,
        how="left",
        left_on="cdb_target_guid",
        right_on="cdb_target_guid_new",
    )

    df0["cdb_cohort"] = df0["cdb_cohort_old"]
    df0["cdb"] = df0["cdb_old"]
    df0["cdb_type"] = df0["cdb_type_new"]
    df0["cdb_target_guid"] = df0["cdb_target_guid_old"]

    colsToDrop = [c for c in df0.columns if c not in instanceHourlyMetricsDf.columns]
    df0.drop(columns=colsToDrop, inplace=True)

    instanceHourlyMetricsDf = pd.concat(
        [instanceHourlyMetricsDf, df0], ignore_index=True
    )

    lg(
        "\nAdded "
        + str(len(df0))
        + " rows to instanceHourlyMetricsDf for "
        + str(len(aggregateCdbInstancesDf))
        + " cdb replacements in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    df0 = []

# ---

counts3Df = getMetricStageCounts("3. After Database Replacements", "stage.3", True)

if len(overriddenCdbInstancesDf) > 0:
    removedDbs = dbPlacementsDf[
        dbPlacementsDf["cdb_target_guid"].isin(
            overriddenCdbInstancesDf["cdb_target_guid_old"]
        )
    ]["db_target_guid"].values
    counts3Df = counts3Df[~counts3Df["db_target_guid"].isin(removedDbs)]

lg("Finished computing stage 3 metric counts.")
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

countsFinalDf = pd.concat(
    [counts0Df, counts1Df, counts2Df, counts3Df], ignore_index=True
)
counts0Df, counts1Df, counts2Df, counts3Df = [], [], [], []

countsFinalDf["missing_database_metric_count"] = countsFinalDf.apply(
    missingDatabaseMetricCount, axis=1
)
countsFinalDf["missing_instance_metric_count"] = countsFinalDf.apply(
    missingInstanceMetricCount, axis=1
)

countsFinalDf["missing_database_metric"] = 0
countsFinalDf.loc[
    countsFinalDf["missing_database_metric_count"] > 0, "missing_database_metric"
] = 1

countsFinalDf["missing_instance_metric"] = 0
countsFinalDf.loc[
    countsFinalDf["missing_instance_metric_count"] > 0, "missing_instance_metric"
] = 1

if len(DEBUG_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "debug_cdb.instance_hourly_metrics." + ln() + ".csv"
    )
    instanceHourlyMetricsDf[instanceHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

# ----------------------------------------------------------------------------------------------------------------------
#
# Add instance-level derived metrics
#

tb = time.time()

instanceHourlyMetricsDf["cdb_cohort"] = instanceHourlyMetricsDf["cdb_cohort"].fillna("")

sgapgaDf = (
    instanceHourlyMetricsDf[
        instanceHourlyMetricsDf["metric"].isin([PGA_METRIC, SGA_METRIC])
    ]
    .groupby(
        [
            "TARGET_GUID",
            "TARGET_NAME",
            "TARGET_TYPE",
            "METRIC_LABEL",
            "COLUMN_LABEL",
            "METRIC_NAME",
            "METRIC_COLUMN",
            "ROLLUP_TIMESTAMP_UTC",
            "cdb",
            "db",
            "cdb_target_guid",
            "db_target_guid",
            "db_cpu_count_limit",
            "total_cpu_cores",
            "cpu_type",
            "cdb_cohort",
        ],
        as_index=False,
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]]
    .sum(numeric_only=True)
)
sgapgaDf["metric"] = SGAPGA_DERIVED_METRIC

sgapgaDf = sgapgaDf[instanceHourlyMetricsDf.columns]

instanceHourlyMetricsDf = pd.concat(
    [instanceHourlyMetricsDf, sgapgaDf], ignore_index=True
)
instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["metric"] == CPU_METRIC, "metric"
] = CPU_DERIVED_METRIC

lg(
    "\nCreated "
    + str(len(sgapgaDf))
    + " sga+pga metrics in "
    + str(round(time.time() - tb, 3))
    + " s"
)
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

metricsDf, sgapgaDf = [], []

# ----------------------------------------------------------------------------------------------------------------------

# Produce dataframe that captures structure & inclusion status
#
databasesDf = structureDf[
    [
        "cdb_cohort",
        "cdb",
        "cdb_size_allocated_ovr",
        "cdb_size_used_ovr",
        "cdb_ovr",
        "cdb_scope_ovr",
        "cdb_percentage_ovr",
        "cdb_instance_count",
        "dbms_vendor",
        "cdb_version",
        "cdb_version_sizing",
        "clustered",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_type_version",
        "cdb_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
].drop_duplicates()
#
# The following logic is needed because values of cdb_last_load_time_utc can cause duplicates
#
dupDf = databasesDf.groupby(["cdb_target_guid"], as_index=False)["cdb"].count()
dupDf.columns = ["cdb_target_guid", "count"]
dupDf = dupDf[dupDf["count"] > 1]

if len(dupDf) > 0:
    databasesDf["cdb_index"] = databasesDf.groupby("cdb_target_guid").cumcount() + 1
    databasesDf = databasesDf[databasesDf["cdb_index"] == 1]
    databasesDf.drop(columns=["cdb_index"], inplace=True)

databasesDf["excluded"] = ""
databasesDf["excluded_reason"] = ""

databasesDf.loc[databasesDf["cdb_cohort"] == "excluded", "excluded"] = "excluded"
databasesDf.loc[databasesDf["cdb_cohort"] == "excluded", "excluded_reason"] = (
    '( Cohort = "excluded" )'
)

databasesDf.loc[databasesDf["cdb_cohort"] == "", "excluded"] = "excluded"
databasesDf.loc[databasesDf["cdb_cohort"] == "", "excluded_reason"] = (
    "( Missing cohort )"
)
databasesDf.loc[databasesDf["cdb_cohort"] == "", "cdb_cohort"] = "excluded"

databasesDf.loc[
    databasesDf["cdb_target_guid"].isin(
        countsFinalDf[
            (countsFinalDf["final"] == 1)
            & (countsFinalDf["missing_database_metric"] == 1)
        ]["cdb_target_guid"]
    ),
    "excluded",
] = "excluded"
databasesDf.loc[
    databasesDf["cdb_target_guid"].isin(
        countsFinalDf[
            (countsFinalDf["final"] == 1)
            & (countsFinalDf["missing_database_metric"] == 1)
        ]["cdb_target_guid"]
    ),
    "excluded_reason",
] += "( Database is missing a required field(s) )"

databasesDf["cdb_size_allocated_gb_telemetry"] = ""
databasesDf["cdb_size_used_gb_telemetry"] = ""
databasesDf["Server List"] = ""
databasesDf["init_processes_total"] = ""
databasesDf["init_sessions_total"] = ""
databasesDf["init_sga_max_size_mb_total"] = ""
databasesDf["init_sga_target_mb_total"] = ""
databasesDf["init_pga_aggr_limit_mb_total"] = ""
databasesDf["init_pga_aggr_target_mb_total"] = ""

databasesDf["STOP"] = "STOP"
databasesDf = databasesDf[
    [
        "excluded",
        "excluded_reason",
        "cdb_cohort",
        "cdb",
        "cdb_size_allocated_ovr",
        "cdb_size_used_ovr",
        "cdb_ovr",
        "cdb_scope_ovr",
        "cdb_percentage_ovr",
        "STOP",
        "cdb_size_allocated_gb_telemetry",
        "cdb_size_used_gb_telemetry",
        "init_sessions_total",
        "init_processes_total",
        "init_sga_max_size_mb_total",
        "init_sga_target_mb_total",
        "init_pga_aggr_limit_mb_total",
        "init_pga_aggr_target_mb_total",
        "cdb_instance_count",
        "clustered",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "Server List",
        "cdb_version",
        "cdb_status",
        "cdb_last_load_time_utc",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "cdb_target_guid",
        "cdb_type_version",
        "cdb_version_sizing",
        "dbms_vendor",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
].copy()
databasesDf.rename(
    columns={
        "cdb_size_used_ovr": "Total Database Size (GB)",
        "cdb_size_allocated_ovr": "Allocated Database Size (GB)",
        "cdb_ovr": "Use Values from Database Name",
        "cdb_scope_ovr": "Use Values Scope",
        "cdb_percentage_ovr": "Use Values Pct",
    },
    inplace=True,
)

# ---

instancesDf = structureDf[
    [
        "cdb_cohort",
        "cdb",
        "db",
        "cdb_ovr",
        "cdb_scope_ovr",
        "cdb_percentage_ovr",
        "host",
        "sga_size_gb",
        "pga_size_gb",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "init_sessions",
        "init_processes",
        "init_sga_max_size_gb",
        "init_sga_target_gb",
        "init_pga_aggregate_limit_gb",
        "init_pga_aggregate_target_gb",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "db_status",
        "db_last_load_time_utc",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "db_vcpu_ovr",
        "db_sga_mb_ovr",
        "db_pga_mb_ovr",
        "db_iops_ovr",
        "db_logons_ovr",
        "db_ovr",
        "host_subscr_pct",
        "host_status",
        "host_last_load_time_utc",
        "physical_cpu_count",
        "cores_per_chip",
        "logical_cpu_count",
        "total_cpu_cores",
        "mem_gb",
        "nr_huge_pages",
        "host_db_cpu_count_limit",
        "vendor_name",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "dist_version",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "cdb_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "init_cpu_count",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
].drop_duplicates()

databasesDf.loc[
    databasesDf["cdb_target_guid"].isin(
        countsFinalDf[
            (countsFinalDf["final"] == 1)
            & (countsFinalDf["missing_instance_metric"] == 1)
        ]["cdb_target_guid"]
    ),
    "excluded",
] = "excluded"
databasesDf.loc[
    databasesDf["cdb_target_guid"].isin(
        countsFinalDf[
            (countsFinalDf["final"] == 1)
            & (countsFinalDf["missing_instance_metric"] == 1)
        ]["cdb_target_guid"]
    ),
    "excluded_reason",
] += "( At least one instance is missing a required field(s) )"

instancesDf["excluded"] = ""
instancesDf["excluded_reason"] = ""

instancesDf.loc[
    instancesDf["cdb_target_guid"].isin(
        databasesDf[databasesDf["excluded"] == "excluded"]["cdb_target_guid"]
    ),
    "excluded",
] = "excluded"
instancesDf.loc[instancesDf["excluded"] == "excluded", "excluded_reason"] = (
    "( Parent database is excluded )"
)

instancesDf.loc[
    instancesDf["db_target_guid"].isin(
        countsFinalDf[
            (countsFinalDf["final"] == 1)
            & (countsFinalDf["missing_instance_metric"] == 1)
        ]["db_target_guid"]
    ),
    "excluded",
] = "excluded"
instancesDf.loc[
    instancesDf["db_target_guid"].isin(
        countsFinalDf[
            (countsFinalDf["final"] == 1)
            & (countsFinalDf["missing_instance_metric"] == 1)
        ]["db_target_guid"]
    ),
    "excluded_reason",
] += "( Instance is missing a required field(s) )"

instancesDf["db_vcpu_telemetry"] = ""
instancesDf["db_sga_mb_telemetry"] = ""
instancesDf["db_pga_mb_telemetry"] = ""
instancesDf["db_iops_telemetry"] = ""
instancesDf["db_logons_telemetry"] = ""
instancesDf["STOP"] = "STOP"

instancesDf = instancesDf[
    [
        "excluded",
        "excluded_reason",
        "cdb_cohort",
        "cdb",
        "db",
        "cdb_ovr",
        "cdb_scope_ovr",
        "cdb_percentage_ovr",
        "db_vcpu_ovr",
        "db_sga_mb_ovr",
        "db_pga_mb_ovr",
        "db_iops_ovr",
        "db_logons_ovr",
        "db_ovr",
        "STOP",
        "db_vcpu_telemetry",
        "db_sga_mb_telemetry",
        "db_pga_mb_telemetry",
        "db_iops_telemetry",
        "db_logons_telemetry",
        "init_sessions",
        "init_processes",
        "init_sga_max_size_gb",
        "init_sga_target_gb",
        "init_pga_aggregate_limit_gb",
        "init_pga_aggregate_target_gb",
        "cluster",
        "host",
        "dbmachine",
        "dbmachine_owner",
        "db_status",
        "db_last_load_time_utc",
        "sga_size_gb",
        "pga_size_gb",
        "cdb_owner",
        "cdb_standby_type",
        "cdb_status",
        "cdb_last_load_time_utc",
        "init_use_large_pages",
        "db_cpu_count_guarantee",
        "db_cpu_count_limit",
        "host_subscr_pct",
        "host_status",
        "host_last_load_time_utc",
        "physical_cpu_count",
        "cores_per_chip",
        "logical_cpu_count",
        "total_cpu_cores",
        "mem_gb",
        "nr_huge_pages",
        "host_db_cpu_count_limit",
        "vendor_name",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "dist_version",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "cpu_type",
        "ma",
        "system_config",
        "h_cpu_type_ovr",
        "h_cores_per_chip_ovr",
        "h_physical_cpu_count_ovr",
        "h_total_cpu_cores_ovr",
        "cdb_type",
        "cdb_cost_center",
        "cdb_department",
        "cdb_lifecycle_status",
        "cdb_line_of_bus",
        "cdb_location",
        "db_cost_center",
        "db_department",
        "db_cohort",
        "db_lifecycle_status",
        "db_line_of_bus",
        "db_location",
        "init_cpu_count",
        "cdb_type_version",
        "db_type_version",
        "host_type_version",
        "cdb_target_guid",
        "db_target_guid",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
].drop_duplicates()

instancesDf["init_sga_max_size_gb"] *= 1024
instancesDf["init_sga_target_gb"] *= 1024
instancesDf["init_pga_aggregate_limit_gb"] *= 1024
instancesDf["init_pga_aggregate_target_gb"] *= 1024

instancesDf.rename(
    columns={
        "cdb_ovr": "Use Values from Database Name",
        "cdb_scope_ovr": "Use Values Scope",
        "cdb_percentage_ovr": "Use Values Pct",
        "db_ovr": "Use Values from Instance",
        "db_vcpu_ovr": "vCPU",
        "db_sga_mb_ovr": "SGA (MB)",
        "db_pga_mb_ovr": "PGA (MB)",
        "db_iops_ovr": "IOPS",
        "db_logons_ovr": "Logons",
        "init_sga_max_size_gb": "init_sga_max_size_mb",
        "init_sga_target_gb": "init_sga_target_mb",
        "init_pga_aggregate_limit_gb": "init_pga_aggr_limit_mb",
        "init_pga_aggregate_target_gb": "init_pga_aggr_target_mb",
    },
    inplace=True,
)
# ---

cdbHourlyStorageMetricsDf.drop_duplicates(inplace=True)
cdbHourlyStorageMetricsDf["row_index"] = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"]
)["AVERAGE"].rank(method="dense", ascending=False)

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdb_Hourly_Storage_Metrics." + ln() + ".csv"
    cdbHourlyStorageMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

cdbHourlyStorageMetricsDf = cdbHourlyStorageMetricsDf[
    cdbHourlyStorageMetricsDf["row_index"] == 1
]

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdb_Hourly_Storage_Metrics." + ln() + ".csv"
    cdbHourlyStorageMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

cdbHourlyStorageMetricsDf.drop(columns=["row_index"], inplace=True)

# ---

rc = {}


def addOrChangeName(df, old, new):
    if old in df:
        rc[old] = new
    else:
        df[new] = ""


df = pd.pivot_table(
    cdbHourlyStorageMetricsDf,
    index="cdb_target_guid",
    columns="metric",
    values="AVERAGE",
    aggfunc="max",
).reset_index()
addOrChangeName(df, STORAGE_ALLOCATED_METRIC, "cdb_size_allocated_gb_t")
addOrChangeName(df, STORAGE_USED_METRIC, "cdb_size_used_gb_t")

if len(rc) > 0:
    df.rename(columns=rc, inplace=True)

databasesDf = pd.merge(
    left=databasesDf,
    right=df,
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
databasesDf["cdb_size_allocated_gb_telemetry"] = databasesDf["cdb_size_allocated_gb_t"]
databasesDf["cdb_size_used_gb_telemetry"] = databasesDf["cdb_size_used_gb_t"]

databasesDf.drop(
    columns=["cdb_size_allocated_gb_t", "cdb_size_used_gb_t"], inplace=True
)
#
# Get list of servers hosting a database
#
df = instancesDf[["cdb_target_guid", "host"]].drop_duplicates()
df = df.groupby("cdb_target_guid", as_index=False).agg(lambda x: ",".join(set(x)))
df.columns = ["cdb_target_guid", "server_list"]
databasesDf = pd.merge(
    left=databasesDf,
    right=df,
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
databasesDf["Server List"] = databasesDf["server_list"]
databasesDf.drop(columns="server_list", inplace=True)

# ---

df = instancesDf.groupby(["cdb_target_guid"], as_index=False)[
    [
        "init_sessions",
        "init_processes",
        "init_sga_max_size_mb",
        "init_sga_target_mb",
        "init_pga_aggr_limit_mb",
        "init_pga_aggr_target_mb",
    ]
].sum()
databasesDf = pd.merge(
    left=databasesDf,
    right=df,
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
databasesDf["init_sessions_total"] = databasesDf["init_sessions"]
databasesDf["init_processes_total"] = databasesDf["init_processes"]
databasesDf["init_sga_max_size_mb_total"] = databasesDf["init_sga_max_size_mb"]
databasesDf["init_sga_target_mb_total"] = databasesDf["init_sga_target_mb"]
databasesDf["init_pga_aggr_limit_mb_total"] = databasesDf["init_pga_aggr_limit_mb"]
databasesDf["init_pga_aggr_target_mb_total"] = databasesDf["init_pga_aggr_target_mb"]

databasesDf.drop(
    columns=[
        "init_sessions",
        "init_processes",
        "init_sga_max_size_mb",
        "init_sga_target_mb",
        "init_pga_aggr_limit_mb",
        "init_pga_aggr_target_mb",
    ],
    inplace=True,
)

# ---

rc = {}
df = pd.pivot_table(
    instanceHourlyMetricsDf,
    index="db_target_guid",
    columns="metric",
    values="AVERAGE",
    aggfunc="max",
).reset_index()

addOrChangeName(df, CPU_DERIVED_METRIC, "vcpu_t")
addOrChangeName(df, IOPS_METRIC, "iops_t")
addOrChangeName(df, LOGONS_METRIC, "logons_t")
addOrChangeName(df, PGA_METRIC, "pga_mb_t")
addOrChangeName(df, SGA_METRIC, "sga_mb_t")

if len(rc) > 0:
    df.rename(columns=rc, inplace=True)

instancesDf = pd.merge(
    left=instancesDf,
    right=df,
    left_on="db_target_guid",
    right_on="db_target_guid",
    how="left",
)
instancesDf["db_vcpu_telemetry"] = instancesDf["vcpu_t"]
instancesDf["db_iops_telemetry"] = instancesDf["iops_t"]
instancesDf["db_logons_telemetry"] = instancesDf["logons_t"]
instancesDf["db_sga_mb_telemetry"] = instancesDf["sga_mb_t"]
instancesDf["db_pga_mb_telemetry"] = instancesDf["pga_mb_t"]

instancesDf.drop(
    columns=["vcpu_t", "sga_mb_t", "pga_mb_t", "iops_t", "logons_t"], inplace=True
)
if SGAPGA_DERIVED_METRIC in df:
    instancesDf.drop(columns=SGAPGA_DERIVED_METRIC, inplace=True)

# ---

hostsDf["STOP"] = "STOP"

hostsDf = hostsDf[
    [
        "host",
        "h_cpu_type_ovr",
        "h_physical_cpu_count_ovr",
        "h_cores_per_chip_ovr",
        "h_description_ovr",
        "STOP",
        "cpu_type",
        "physical_cpu_count",
        "cores_per_chip",
        "dbmachine",
        "dbmachine_owner",
        "cluster",
        "host_type_version",
        "host_status",
        "host_last_load_time_utc",
        "h_cost_center",
        "h_department",
        "h_lifecycle_status",
        "h_line_of_bus",
        "h_location",
        "total_cpu_cores",
        "logical_cpu_count",
        "mem_gb",
        "nr_huge_pages",
        "ecache_in_mb",
        "impl",
        "revision",
        "is_hyperthread_enabled",
        "freq",
        "ma",
        "system_config",
        "vendor_name",
        "dist_version",
        "host_db_cpu_count_limit",
        "host_subscr_pct",
        "host_target_guid",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]
]

hostsDf.rename(
    columns={
        "h_cpu_type_ovr": "CPU Type",
        "h_physical_cpu_count_ovr": "Chip Count (Actual)",
        "h_cores_per_chip_ovr": "Cores Per Chip (Actual)",
        "h_description_ovr": "Description",
    },
    inplace=True,
)

# ---

DEBUG_COHORT = (
    []
    if len(DEBUG_CDB) == 0
    else databasesDf[databasesDf["cdb"].isin(DEBUG_CDB)]["cdb_cohort"].unique()
)

if len(DEBUG_CDB) > 0:
    lg("\nDebugging with the following values")
    lg("-------------------------------------")
    lg("DEBUG_CDB        : " + str(DEBUG_CDB))
    lg("DEBUG_COHORT     : " + str(DEBUG_COHORT))
    lg("METRIC_CDB       : " + str(METRIC_CDB))
    lg("WRITE_DEBUG_FILES: " + str(WRITE_DEBUG_FILES))

filename = sizingFilePath + os.sep + "databases.csv"
databasesDf.sort_values(["cdb"]).to_csv(filename, index=False)
lg("\nWrote file " + filename)

filename = sizingFilePath + os.sep + "instances.csv"
instancesDf.sort_values(["cdb", "db"]).to_csv(filename, index=False)
lg("\nWrote file " + filename)

filename = sizingFilePath + os.sep + "servers.csv"
hostsDf.sort_values(["host"]).to_csv(filename, index=False)
lg("\nWrote file " + filename)

# ---

countsFinalDf.drop(
    columns=["final", "missing_database_metric_count", "missing_instance_metric_count"],
    inplace=True,
)

colsToRename = {}
colsMiddle = []
for _ in countsFinalDf.columns:
    if _ in EMCC_METRIC_COULMN_ALIASES:
        colsToRename[_] = EMCC_METRIC_COULMN_ALIASES[_] + "_ok"
        colsMiddle.append(EMCC_METRIC_COULMN_ALIASES[_] + "_ok")

if len(colsToRename) > 0:
    countsFinalDf.rename(columns=colsToRename, inplace=True)

# ---

colsToAdd = [d for d in databasesDf.columns if d not in countsFinalDf.columns]
colsToAdd.append("cdb_target_guid")
countsFinalDf = pd.merge(
    left=countsFinalDf,
    right=databasesDf[colsToAdd],
    how="left",
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
)
countsFinalDf.rename(
    columns={
        "excluded": "database_excluded",
        "excluded_reason": "database_excluded_reason",
    },
    inplace=True,
)

# ---

colsToAdd = [d for d in instancesDf.columns if d not in countsFinalDf.columns]
colsToAdd.append("db_target_guid")
countsFinalDf = pd.merge(
    left=countsFinalDf,
    right=instancesDf[colsToAdd],
    how="left",
    left_on="db_target_guid",
    right_on="db_target_guid",
)
countsFinalDf.rename(
    columns={
        "excluded": "instance_excluded",
        "excluded_reason": "instance_excluded_reason",
    },
    inplace=True,
)
countsFinalDf["cdb_"] = countsFinalDf["cdb"]
countsFinalDf["db_"] = countsFinalDf["db"]

# ---

colsEnd = [
    "cdb_target_guid",
    "db_target_guid",
    "host_target_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "source",
    "version",
]

colsMiddleOrdered = []  # order the columns the same as in instancesDf
if "Allocated Storage (GB)_ok" in colsMiddle:
    colsMiddleOrdered.append("Allocated Storage (GB)_ok")
if "Used Storage (GB)_ok" in colsMiddle:
    colsMiddleOrdered.append("Used Storage (GB)_ok")
if "DB vCPU_ok" in colsMiddle:
    colsMiddleOrdered.append("DB vCPU_ok")
if "DB SGA (MB)_ok" in colsMiddle:
    colsMiddleOrdered.append("DB SGA (MB)_ok")
if "DB PGA (MB)_ok" in colsMiddle:
    colsMiddleOrdered.append("DB PGA (MB)_ok")
if "DB IOPS_ok" in colsMiddle:
    colsMiddleOrdered.append("DB IOPS_ok")
if "DB Logons_ok" in colsMiddle:
    colsMiddleOrdered.append("DB Logons_ok")

colsStart = (
    ["stage", "cdb_cohort", "cdb", "db"]
    + colsMiddleOrdered
    + [
        "database_excluded",
        "database_excluded_reason",
        "instance_excluded",
        "instance_excluded_reason",
        "missing_database_metric",
        "missing_instance_metric",
        "cdb_cohort",
        "cdb_",
        "Allocated Database Size (GB)",
        "Total Database Size (GB)",
        "Use Values from Database Name",
        "Use Values Scope",
        "Use Values Pct",
        "STOP",
        "db_",
        "vCPU",
        "SGA (MB)",
        "PGA (MB)",
        "IOPS",
        "Logons",
        "Use Values from Instance",
        "STOP",
    ]
)

colsMiddle = [
    c for c in countsFinalDf.columns if c not in colsStart and c not in colsEnd
]

countsFinalDf = countsFinalDf[colsStart + colsMiddle + colsEnd]
filename = sizingFilePath + os.sep + "metric_presence_by_stage.csv"
countsFinalDf.sort_values(["stage", "cdb", "db"], ascending=[False, True, True]).to_csv(
    filename, index=False
)
lg("\nWrote file " + filename)

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---
#
# Get aggregate cpu counts that will be used for computation for ADWs below
#
dbCPUCountsDf = countsFinalDf[
    countsFinalDf["stage"] == "3. After Database Replacements"
][["cdb", "db"]].copy()
dbCPUCountsDf = pd.merge(
    left=dbCPUCountsDf,
    right=instancesDf[["db", "db_cpu_count_limit"]],
    how="left",
    left_on=["db"],
    right_on=["db"],
)
dbCPUCountsDf["db_cpu_count_limit"] = dbCPUCountsDf["db_cpu_count_limit"].fillna(0)
dbCPUCountsDf = dbCPUCountsDf.groupby(["cdb"], as_index=False)[
    "db_cpu_count_limit"
].sum()

# ---

if len(DEBUG_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "debug_cdb.instance_hourly_metrics." + ln() + ".csv"
    )
    instanceHourlyMetricsDf[instanceHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

# ---

excludedCdbs = databasesDf[databasesDf["excluded"] == "excluded"][
    "cdb_target_guid"
].unique()

cdbHourlyStorageMetricsDf.loc[
    cdbHourlyStorageMetricsDf["cdb_target_guid"].isin(excludedCdbs), "cdb_cohort"
] = "excluded"
cdbHourlyStorageMetricsDf["cdb_count_avg"] = 1

if len(COHORTS) > 0:
    cdbHourlyStorageMetricsDf = cdbHourlyStorageMetricsDf[
        cdbHourlyStorageMetricsDf["cdb_cohort"].isin(COHORTS)
    ]
#
# Note we convert the cdb_count_avg to the sum() value for the cohort & metric
#
cdbHourlyStorageMetricsDf["cdb_count_avg"] = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"]
)["cdb_count_avg"].transform("sum")
cdbHourlyStorageMetricsDf["cdb_count_avg"] = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "metric"]
)["cdb_count_avg"].transform("mean")
cdbCohortHourlyStorageMetricsDf = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC", "cdb_count_avg"], as_index=False
)[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

excludedDbs = instancesDf[instancesDf["excluded"] == "excluded"][
    "db_target_guid"
].unique()
instanceHourlyMetricsDf.loc[
    instanceHourlyMetricsDf["db_target_guid"].isin(excludedDbs), "cdb_cohort"
] = "excluded"

if len(COHORTS) > 0:
    instanceHourlyMetricsDf = instanceHourlyMetricsDf[
        instanceHourlyMetricsDf["cdb_cohort"].isin(COHORTS)
    ]

cdbHourlyMetricsDf = instanceHourlyMetricsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
    as_index=False,
)[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()
cdbHourlyMetricsDf["cdb_count_avg"] = 1

if len(priPlusStdHourlyMetricsDf) > 0:
    cdbHourlyPriPlusStdMetricsDf = priPlusStdHourlyMetricsDf.groupby(
        ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
        as_index=False,
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()
    cdbHourlyPriPlusStdMetricsDf["cdb_count_avg"] = 1
else:
    cdbHourlyPriPlusStdMetricsDf = []

# ---

if len(DEBUG_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "debug_cdb.instance_hourly_metrics." + ln() + ".csv"
    )
    instanceHourlyMetricsDf[instanceHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

    filename = sizingFilePath + os.sep + "debug_cdb.cdb_hourly_metrics." + ln() + ".csv"
    cdbHourlyMetricsDf[cdbHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

    if len(cdbHourlyPriPlusStdMetricsDf) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.cdb_hourly_pri_plus_std_metrics."
            + ln()
            + ".csv"
        )
        cdbHourlyPriPlusStdMetricsDf[
            cdbHourlyPriPlusStdMetricsDf["cdb"].isin(DEBUG_CDB)
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )

# ---

if WRITE_DEBUG_FILES:
    df = (
        cdbHourlyMetricsDf.groupby(["cdb", "metric"], as_index=False)["AVERAGE"]
        .agg(["sum", "max", "count"])
        .reset_index()
    )
    df.columns = ["cdb", "metric", "sum", "max", "count"]
    filename = sizingFilePath + os.sep + "cdb_Cohort_Hourly_Metrics.gb." + ln() + ".csv"
    df.sort_values(["cdb", "metric"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

df0 = cdbHourlyMetricsDf[
    cdbHourlyMetricsDf["metric"].isin([CPU_DERIVED_METRIC, IOPS_METRIC])
].copy()
df0.loc[df0["metric"] == CPU_DERIVED_METRIC, "metric"] = CPU_DERIVED_METRIC_STANDBY
df0.loc[df0["metric"] == IOPS_METRIC, "metric"] = IOPS_METRIC_STANDBY

if len(cdbHourlyPriPlusStdMetricsDf) > 0:
    cdbHourlyPriPlusStdMetricsDf.loc[
        cdbHourlyPriPlusStdMetricsDf["metric"] == CPU_METRIC, "metric"
    ] = CPU_DERIVED_METRIC

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.cdb_hourly_metrics.df0."
            + ln()
            + ".csv"
        )
        df0[df0["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)

        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.cdb_hourly_pri_plus_std_metrics."
            + ln()
            + ".csv"
        )
        cdbHourlyPriPlusStdMetricsDf[
            cdbHourlyPriPlusStdMetricsDf["cdb"].isin(DEBUG_CDB)
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )

    df0 = pd.concat([df0, cdbHourlyPriPlusStdMetricsDf], ignore_index=True)

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.cdb_hourly_metrics.df0."
            + ln()
            + ".csv"
        )
        df0[df0["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)


def marks_value_for_propertie_files(current_row : pd.Series,output_df,columm_target,column_val_return_A,column_val_return_B,propertie_column_key : str):
    """

    Parameters
    ----------
    current_row : row
    output_df : the output/[database|instances].csv
    columm_target : [cdb|db]
    column_val_return_A :  Use Values Scope
    column_val_return_B :  columns that is being compared

    Returns
    -------

    """
    # cdb : D
    # 'Use Values Scope' column: H

    value_to_replace = current_row[propertie_column_key]

    if pd.notna(pd.to_numeric(value_to_replace, errors='coerce')):
        return value_to_replace

    colname = current_row.index[1].strip() #$B2 representing Database Name | Instance name
    key_value = current_row[colname]
    #Checks the Uses values scope is it's defined and is not 0, don't write anything
    first_search = output_df.loc[output_df[columm_target] == key_value, column_val_return_A]
    if not first_search.empty and pd.notna(first_search.values[0]) and first_search.iloc[0] != 0:
        return ""
    else:
        # if uses values scope is not defined :
        second_search = output_df.loc[output_df[columm_target] == key_value, column_val_return_B]
        if second_search.empty or second_search.iloc[0] is None or pd.isna(second_search.iloc[0]) or second_search.iloc[0]==0:
            return -1
        else:
            return ""

# 'excluded' in dbdf.excluded.values  #db DF file
# 'excluded' in insdf.excluded.values #instances DF file
fp = FilePaths()
prop_db_df = pd.read_csv(fp.EMCC_PROPERTIES_DB)
prop_ins_df = pd.read_csv(fp.EMCC_PROPERTIES_INSTANCE)
lg("Processing missing metrics".center(50,'*'))
lg(f'Reading total rows for properties database  {len(prop_db_df)}')
lg(f'Reading total rows for properties instances {len(prop_ins_df)}')

mask_db_proc = prop_db_df['Cohort'].str.lower() != 'excluded'
mask_ins_proc = prop_ins_df['Database Name'].isin(prop_db_df.loc[mask_db_proc,'Database Name'])


#Creating a backup from properties files
suffix='.'+datetime.datetime.strftime(datetime.datetime.now(datetime.timezone.utc), "%Y%m%d_%H%M%S") + "_UTC"
prop_db_dst = fp.EMCC_PROPERTIES_DB.with_stem(fp.EMCC_PROPERTIES_DB.stem + suffix)
if not prop_db_dst.exists():
    shutil.copy2(fp.EMCC_PROPERTIES_DB , prop_db_dst)

prop_ins_dst = fp.EMCC_PROPERTIES_INSTANCE.with_stem(fp.EMCC_PROPERTIES_INSTANCE.stem + suffix)
if not prop_ins_dst.exists():
    shutil.copy2(fp.EMCC_PROPERTIES_INSTANCE, prop_ins_dst)


dbdf = pd.read_csv(fp.EMCC_OUTPUT_DATABASE)
instancesdf = pd.read_csv(fp.EMCC_OUTPUT_INSTANCE)

#Ignore the cdb-cohort = excluded
dbdf = dbdf[dbdf['cdb_cohort'].str.lower() != 'excluded']
instancesdf = instancesdf[instancesdf['cdb_cohort'].str.lower() != 'excluded']


has_db_excluded = dbdf.index[dbdf.excluded == 'excluded'].tolist()
has_instances_excluded = instancesdf.index[instancesdf.excluded == 'excluded'].tolist()

DB_COLUMNS_MAP = {
    'Allocated Database Size (GB)':'cdb_size_allocated_gb_telemetry',
    'Total Database Size (GB)':'cdb_size_used_gb_telemetry',
}

INSTANCES_MAP = {
    'vCPU':'db_vcpu_telemetry',
    'SGA (MB)':'db_sga_mb_telemetry',
    'PGA (MB)':'db_pga_mb_telemetry',
    'IOPS':'db_iops_telemetry',
    'Logons':'db_logons_telemetry',
}

if has_db_excluded or has_instances_excluded:
    # Database Name,Allocated Database Size (GB)

    # DB_COLUMNS = ['Allocated Database Size (GB)','Total Database Size (GB)']
    for column_to_fill in DB_COLUMNS_MAP.keys():
        prop_db_df[column_to_fill] = prop_db_df.loc[mask_db_proc].apply(lambda row:marks_value_for_propertie_files(
            row,  # current row
            dbdf,  # output DF
            'cdb',  # output key-cohort
            'Use Values Scope',  # primarykey
            DB_COLUMNS_MAP[column_to_fill],  # Selector
            column_to_fill),  # key to see if has val
                                                                        axis=1)

    # INSTANCES_COLUMNS = ['vCPU','SGA (MB)','PGA (MB)','IOPS','Logons']
    for column_to_fill in INSTANCES_MAP.keys():
        prop_ins_df[column_to_fill] = prop_ins_df.loc[mask_ins_proc].apply(
            lambda row:marks_value_for_propertie_files(
                row,
                instancesdf,
                'db',
                'Use Values Scope',
                INSTANCES_MAP[column_to_fill],
                column_to_fill),
            axis=1)

    prop_db_df.to_csv(fp.EMCC_PROPERTIES_DB,index=False)
    prop_ins_df.to_csv(fp.EMCC_PROPERTIES_INSTANCE,index=False)

    missing_metric_for_prop_db = (
        (prop_db_df[list(DB_COLUMNS_MAP.keys())].apply(pd.to_numeric, errors='coerce') <= -1).any(axis=1).sum().item()
    )

    missing_metric_for_prop_ins = (
        (prop_ins_df[list(INSTANCES_MAP.keys())].apply(pd.to_numeric, errors='coerce') <= -1).any(axis=1).sum().item()
    )
    files_needed = ""
    files_needed+=f'\tRows with missing metrics for properties_database.csv : {missing_metric_for_prop_db}' if has_incorrect_values(prop_db_df.loc[mask_db_proc],list(DB_COLUMNS_MAP.keys())) else ''
    files_needed+=f'\n\tRows with missing metrics for properties_instances.csv : {missing_metric_for_prop_ins}' if has_incorrect_values(prop_ins_df.loc[mask_ins_proc],list(INSTANCES_MAP.keys())) else ''
    ez_miner_error = f""" ERROR:
    <Need user input> Some databases and instances were excluded. Please review the following before continuing:
    Some databases and/or instances were implicitly excluded because required metrics were missing. User input is required!
    Please review the following files before continuing:
       {files_needed} 
    Override fields where required metrics are missing are marked as '-1'. 
    Correct these override values with a non-negative value or explicitly exclude the databases.
    Once the issues are resolved, re-run the following steps:
        --add-properties
        --run-metric-analysis
    """
    lg(ez_miner_error)
    raise_error_when_run_from_api("EMCC: ",ez_miner_error)
    quit()

def check_values(df,columns, file_name):
    if has_incorrect_values(df,columns):
        msg =f"There are some values on file {file_name} that need to be filled, vales less than 0 are not valid.".center(103, "=")
        lg(msg)
        exit()

check_values(prop_db_df.loc[mask_db_proc],DB_COLUMNS_MAP.keys(),fp.EMCC_PROPERTIES_DB.name)
check_values(prop_ins_df.loc[mask_ins_proc],INSTANCES_MAP.keys() ,fp.EMCC_PROPERTIES_INSTANCE.name)

if len(overriddenCdbInstancesDf) > 0:
    tb = time.time()

    df0 = pd.merge(
        left=df0,
        right=overriddenCdbInstancesDf,
        how="left",
        left_on="cdb_target_guid",
        right_on="cdb_target_guid_old",
    )
    df0["cdb_scope_ovr"] = df0["cdb_scope_ovr"].fillna("All")
    df0["cdb_percentage_ovr"] = df0["cdb_percentage_ovr"].fillna(100)
    #
    #   Reduce Standby CPU & IOPs metrics by the specified percentage
    #
    df0.loc[df0["cdb_scope_ovr"] == PHYSICAL_STANDBY, "AVERAGE"] *= (
        df0["cdb_percentage_ovr"] / 100
    )
    df0["cdb_count_avg"] = 1

    colsToDrop = [c for c in df0.columns if c not in cdbHourlyMetricsDf.columns]
    df0.drop(columns=colsToDrop, inplace=True)

lg(
    "\nAdded "
    + str(len(df0))
    + " standby CPU & IOPS rows in cdbHourlyMetricsDf for "
    + str(len(df0))
    + " override cdbs in "
    + str(round(time.time() - tb, 3))
    + " s"
)

if len(cdbHourlyPriPlusStdMetricsDf) == 0:
    cdbHourlyMetricsDf = pd.concat([cdbHourlyMetricsDf, df0], ignore_index=True)
else:
    cdbHourlyMetricsDf = pd.concat(
        [
            cdbHourlyMetricsDf[
                ~(
                    (
                        cdbHourlyMetricsDf["cdb_target_guid"].isin(
                            cdbHourlyPriPlusStdMetricsDf["cdb_target_guid"]
                        )
                    )
                    & (
                        cdbHourlyMetricsDf["metric"].isin(
                            [CPU_DERIVED_METRIC, IOPS_METRIC]
                        )
                    )
                )
            ],
            df0,
        ],
        ignore_index=True,
    )
df0 = []

if len(DEBUG_CDB) > 0:
    filename = sizingFilePath + os.sep + "debug_cdb.cdb_hourly_metrics." + ln() + ".csv"
    cdbHourlyMetricsDf[cdbHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

if WRITE_DEBUG_FILES:
    df = (
        cdbHourlyMetricsDf.groupby(["cdb", "metric"], as_index=False)["AVERAGE"]
        .agg(["sum", "max", "count"])
        .reset_index()
    )
    df.columns = ["cdb", "metric", "sum", "max", "count"]
    filename = sizingFilePath + os.sep + "cdb_Cohort_Hourly_Metrics.gb." + ln() + ".csv"
    df.sort_values(["cdb", "metric"]).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

#
# Note we convert the cdb_count_avg to the sum() value for the cohort & metric
#

cdbHourlyMetricsDf["cdb_count_avg"] = cdbHourlyMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"]
)["cdb_count_avg"].transform("sum")
cdbHourlyMetricsDf["cdb_count_avg"] = cdbHourlyMetricsDf.groupby(
    ["cdb_cohort", "metric"]
)["cdb_count_avg"].transform("mean")

cdbCohortHourlyMetricsDf = cdbHourlyMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC", "cdb_count_avg"], as_index=False
)[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

if len(METRIC_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "metric_cdb.hourly_instance_metrics.1processed.csv"
    )
    instanceHourlyMetricsDf[
        instanceHourlyMetricsDf["cdb"].isin(METRIC_CDB)
    ].sort_values(["cdb", "TARGET_NAME", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

    filename = (
        sizingFilePath
        + os.sep
        + "metric_cdb.hourly_instance_metrics_by_cdb.1processed.csv"
    )
    cdbHourlyMetricsDf[cdbHourlyMetricsDf["cdb"].isin(METRIC_CDB)].sort_values(
        ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    if len(cdbHourlyStorageMetricsDf) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "metric_cdb.hourly_cdb_storage_metrics.1processed.csv"
        )
        cdbHourlyStorageMetricsDf[
            cdbHourlyStorageMetricsDf["cdb"].isin(METRIC_CDB)
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

if len(DEBUG_CDB) > 0:
    filename = sizingFilePath + os.sep + "debug_cdb.cdb_hourly_metrics." + ln() + ".csv"
    cdbHourlyMetricsDf[cdbHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

    if len(cdbHourlyStorageMetricsDf) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.cdb_hourly_storage_metrics."
            + ln()
            + ".csv"
        )
        cdbHourlyStorageMetricsDf[
            cdbHourlyStorageMetricsDf["cdb"].isin(DEBUG_CDB)
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )

# ---

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdb_Hourly_Metrics." + ln() + ".csv"
    cdbHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

if 1 == 0:
    filename = sizingFilePath + os.sep + "cdb_Cohort_Hourly_Metrics." + ln() + ".csv"
    cdbCohortHourlyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

cdbCohortInstanceCountsDf = (
    instancesDf[instancesDf["excluded"] == ""]
    .groupby("cdb_cohort", as_index=False)["db_target_guid"]
    .nunique()
)
cdbCohortInstanceCountsDf.columns = ["cdb_cohort", "instance_count"]

df = (
    instancesDf[instancesDf["excluded"] != ""]
    .groupby("excluded", as_index=False)["db_target_guid"]
    .nunique()
)

if len(df) > 0:
    df.columns = ["cdb_cohort", "instance_count"]
    cdbCohortInstanceCountsDf = pd.concat(
        [cdbCohortInstanceCountsDf, df], ignore_index=True
    )

# ---

if args.checkmetrics is not None:
    quit()

# ---

if True and (PLOT_HTML or PLOT_PNG):
    unadjusted_path = Path(outputFilePath) / "plots" / "unadjusted"
    if Path.is_dir(unadjusted_path):
        lg(f"    Deleting existing directory : {unadjusted_path}")
        shutil.rmtree(unadjusted_path, ignore_errors=True)
    plotMetrics(cdbHourlyMetricsDf)
    plotMetrics(cdbHourlyStorageMetricsDf)
    _ = 0

cdbHourlyMetricsPeaksDf = cdbHourlyMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)["AVERAGE"].sum()
cdbHourlyMetricsPeaksDf = cdbHourlyMetricsPeaksDf.groupby(
    ["cdb_cohort", "metric"], as_index=False
)["AVERAGE"].max()
cdbHourlyMetricsPeaksDf["AVERAGE"] = round(
    cdbHourlyMetricsPeaksDf["AVERAGE"], PRECISION
)
cdbHourlyMetricsPeaksDf.rename(columns={"AVERAGE": "peak"}, inplace=True)

cdb_hourly_metrics_peak_db_df = cdbHourlyMetricsDf.groupby(
    ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)["AVERAGE"].sum()
cdb_hourly_metrics_peak_db_df = cdb_hourly_metrics_peak_db_df.groupby(
    ["cdb", "metric"], as_index=False
)["AVERAGE"].max()
cdb_hourly_metrics_peak_db_df["AVERAGE"] = round(
    cdb_hourly_metrics_peak_db_df["AVERAGE"], PRECISION
)
cdb_hourly_metrics_peak_db_df.rename(columns={"AVERAGE": "peak"}, inplace=True)

cdbHourlyStorageMetricsPeaksDf = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)["AVERAGE"].sum()
cdbHourlyStorageMetricsPeaksDf = cdbHourlyStorageMetricsPeaksDf.groupby(
    ["cdb_cohort", "metric"], as_index=False
)["AVERAGE"].max()
cdbHourlyStorageMetricsPeaksDf["AVERAGE"] = round(
    cdbHourlyStorageMetricsPeaksDf["AVERAGE"], PRECISION
)
cdbHourlyStorageMetricsPeaksDf.rename(columns={"AVERAGE": "peak"}, inplace=True)

cdb_hourly_storage_metrics_peaks_db_df = cdbHourlyStorageMetricsDf.groupby(
    ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)["AVERAGE"].sum()
cdb_hourly_storage_metrics_peaks_db_df = cdb_hourly_storage_metrics_peaks_db_df.groupby(
    ["cdb", "metric"], as_index=False
)["AVERAGE"].max()
cdb_hourly_storage_metrics_peaks_db_df["AVERAGE"] = round(
    cdb_hourly_storage_metrics_peaks_db_df["AVERAGE"], PRECISION
)
cdb_hourly_storage_metrics_peaks_db_df.rename(columns={"AVERAGE": "peak"}, inplace=True)

cdbHourlyMetricsPeaksDf = pd.concat(
    [cdbHourlyMetricsPeaksDf, cdbHourlyStorageMetricsPeaksDf], ignore_index=True
)
cdb_hourly_metrics_peak_db_df = pd.concat(
    [cdb_hourly_metrics_peak_db_df, cdb_hourly_storage_metrics_peaks_db_df],
    ignore_index=True,
)
cdbHourlyStorageMetricsPeaksDf = []

# ----------------------------------------------------------------------------------------------------------------------

(
    cdbDailyMetricsDf,
    cdbCohortDailyMetricsDf,
    cdbCohortDailyCdbCountsDf,
    instanceDailyMetricsDf,
    storageDailyMetricsDf,
) = (pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
cdbCohortDailyCdbMetricCountsDf = []

tb0 = time.time()

lg("\nLoading db daily metrics...")

# Populates the variables
# instanceDailyMetricsDf
# storageDailyMetricsDf
for time_period in TIME_PERIODS:
    lg("\n     Loading db daily metrics for time period: " + time_period + "...")
    filename = (
        extractFilePath
        + os.sep
        + "emcc_sizing_metrics_db_daily_"
        + time_period
        + "_months.csv"
    )

    if not os.path.exists(filename):
        lg(
            "     Telemetry file "
            + filename
            + " is missing; continuing with next time period"
        )
        continue

    tb = time.time()

    metricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])

    if len(metricsDf) == 0 or metricsDf.empty:
        lg(
            "     Telemetry file "
            + filename
            + " is empty; continuing with next time period"
        )
        continue

    metricsDf = prepare_em_df(metricsDf)
    metricsDf = remove_duplicate_dates_from_EM_df(metricsDf)
    storageMetricsDf                         = metricsDf[(metricsDf['metric'].isin(EMCC_STORAGE_METRICS) &
                                                          metricsDf['TARGET_GUID'].isin(cdbsDf['cdb_target_guid']))].copy()
    storageMetricsDf['ROLLUP_TIMESTAMP_UTC'] = storageMetricsDf['ROLLUP_TIMESTAMP_UTC'].dt.normalize()

    metricsDf = metricsDf[metricsDf["metric"].isin(EMCC_INSTANCE_METRICS)]
    metricsDf["ROLLUP_TIMESTAMP_UTC"] = metricsDf["ROLLUP_TIMESTAMP_UTC"].dt.normalize()

    lg(
        "     Loaded "
        + str(len(metricsDf))
        + " instance metrics from "
        + filename
        + " in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg(
        "     Loaded "
        + str(len(storageMetricsDf))
        + " storage metrics from "
        + filename
        + " in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("     Time since start " + str(round(time.time() - startTime, 3)) + " s\n")

    if len(metricsDf) == 0:
        lg("     Telemetry file " + filename + " has no instance daily metrics")

    if len(storageMetricsDf) == 0:
        lg("     Telemetry file " + filename + " has no storage daily metrics")

    # ---

    if len(metricsDf) > 0:
        tb = time.time()

        sgapgaDf = (
            metricsDf[metricsDf["metric"].isin([PGA_METRIC, SGA_METRIC])]
            .groupby(
                [
                    "TARGET_GUID",
                    "TARGET_NAME",
                    "TARGET_TYPE",
                    "METRIC_LABEL",
                    "COLUMN_LABEL",
                    "METRIC_NAME",
                    "METRIC_COLUMN",
                    "ROLLUP_TIMESTAMP_UTC",
                ],
                as_index=False,
            )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]]
            .sum()
        )
        sgapgaDf["metric"] = SGAPGA_DERIVED_METRIC

        sgapgaDf = sgapgaDf[
            [
                "TARGET_GUID",
                "TARGET_NAME",
                "TARGET_TYPE",
                "METRIC_LABEL",
                "COLUMN_LABEL",
                "METRIC_NAME",
                "METRIC_COLUMN",
                "ROLLUP_TIMESTAMP_UTC",
                "MINIMUM",
                "AVERAGE",
                "MAXIMUM",
                "STANDARD_DEVIATION",
                "SAMPLE_COUNT",
                "metric",
            ]
        ]

        lg(
            "     Created "
            + str(len(sgapgaDf))
            + " sga+pga metrics in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        metricsDf = pd.concat([metricsDf, sgapgaDf], ignore_index=True)
        sgapgaDf = []

        # --

        tb = time.time()

        metricsDf = pd.merge(
            left=metricsDf[metricsDf["TARGET_TYPE"] == "oracle_database"],
            right=dbPlacementsDf[
                [
                    "cdb_cohort",
                    "cdb",
                    "cdb_target_guid",
                    "db_target_guid",
                    "cpu_type",
                    "total_cpu_cores",
                    "init_cpu_count",
                ]
            ],
            how="left",
            left_on=["TARGET_GUID"],
            right_on=["db_target_guid"],
        )
        lg(
            "     Created "
            + str(len(metricsDf))
            + " instance daily metrics in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        # ---

        tb = time.time()

        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "MINIMUM"] = round(
            metricsDf["MINIMUM"] / 100, PRECISION
        )
        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "AVERAGE"] = round(
            metricsDf["AVERAGE"] / 100, PRECISION
        )
        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "MAXIMUM"] = round(
            metricsDf["MAXIMUM"] / 100, PRECISION
        )

        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
            "MINIMUM",
        ] = round(metricsDf["MINIMUM"] * AIX_DEFLATION, PRECISION)
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
            "AVERAGE",
        ] = round(metricsDf["AVERAGE"] * AIX_DEFLATION, PRECISION)
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
            "MAXIMUM",
        ] = round(metricsDf["MAXIMUM"] * AIX_DEFLATION, PRECISION)

        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC)
            & (metricsDf["MINIMUM"] > metricsDf["init_cpu_count"]),
            "MINIMUM",
        ] = metricsDf["init_cpu_count"]
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC)
            & (metricsDf["AVERAGE"] > metricsDf["init_cpu_count"]),
            "AVERAGE",
        ] = metricsDf["init_cpu_count"]
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC)
            & (metricsDf["MAXIMUM"] > metricsDf["init_cpu_count"]),
            "MAXIMUM",
        ] = metricsDf["init_cpu_count"]

        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "metric"] = CPU_DERIVED_METRIC

        lg(
            "     Reduced instance daily metrics to "
            + str(len(metricsDf))
            + " rows in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        metricsDf = metricsDf[
            [
                "cdb_cohort",
                "cdb",
                "TARGET_NAME",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "MINIMUM",
                "AVERAGE",
                "MAXIMUM",
                "STANDARD_DEVIATION",
                "SAMPLE_COUNT",
                "cdb_target_guid",
                "db_target_guid",
            ]
        ]
        metricsDf.rename(columns={"TARGET_NAME": "inst"}, inplace=True)

        if 1 == 0:
            printDf("metricsDf." + ln(), metricsDf, rows=10, showTail=False)

        instanceDailyMetricsDf = (
            metricsDf
            if len(instanceDailyMetricsDf) == 0
            else pd.concat([instanceDailyMetricsDf, metricsDf], ignore_index=True)
        )

    # ---

    if len(storageMetricsDf) > 0:
        tb = time.time()

        storageMetricsDf = pd.merge(
            left=storageMetricsDf,
            right=cdbsDf[["cdb_cohort", "cdb", "cdb_target_guid"]],
            how="left",
            left_on=["TARGET_GUID"],
            right_on=["cdb_target_guid"],
        )

        lg(
            "     Created "
            + str(len(storageMetricsDf))
            + " storage daily metrics in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )

        storageDailyMetricsDf = (
            storageMetricsDf
            if len(storageDailyMetricsDf) == 0
            else pd.concat([storageMetricsDf, storageDailyMetricsDf], ignore_index=True)
        )

# ---

metricsDf, storageMetricsDf = pd.DataFrame(), pd.DataFrame()

lg(
    "\nLoaded "
    + str(len(instanceDailyMetricsDf))
    + " instance daily metrics in "
    + str(round(time.time() - tb0, 3))
    + " s"
)
lg(
    "Loaded "
    + str(len(storageDailyMetricsDf))
    + " storage daily metrics in  "
    + str(round(time.time() - tb0, 3))
    + " s"
)

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if len(METRIC_CDB) > 0:
    filename = sizingFilePath + os.sep + "metric_cdb.daily_instance_metrics.0raw.csv"
    instanceDailyMetricsDf[instanceDailyMetricsDf["cdb"].isin(METRIC_CDB)].sort_values(
        ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    if len(storageDailyMetricsDf) > 0:
        filename = (
            sizingFilePath + os.sep + "metric_cdb.daily_cdb_storage_metrics.0raw.csv"
        )
        storageDailyMetricsDf[
            storageDailyMetricsDf["cdb"].isin(METRIC_CDB)
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

# ---

if WRITE_DEBUG_FILES:
    if len(instanceDailyMetricsDf) > 0:
        _ = (
            instanceDailyMetricsDf.groupby(["cdb", "inst", "metric"], as_index=False)[
                "AVERAGE"
            ]
            .agg(["sum", "max", "count"])
            .reset_index()
        )
        _.columns = ["cdb", "inst", "metric", "sum", "max", "count"]
        filename = (
            sizingFilePath + os.sep + "instance_Daily_Metrics.gb." + ln() + ".csv"
        )
        _.sort_values(["inst", "metric"]).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

# ---
#
# Decided to NOT have override values contribute to adjustment multipliers, 12/06/2021
#
if 1 == 0 and len(overriddenInstanceMetricsDf) and len(instanceDailyMetricsDf) > 0:
    #
    #   Replace daily metrics with override metrics
    #
    indicators = overriddenInstanceMetricsDf["indicator"].unique()
    timeStampsDf = instanceDailyMetricsDf[["ROLLUP_TIMESTAMP_UTC"]].drop_duplicates()

    if 1 == 0:
        lg("indicators")
        lg("----------")
        lg(str(indicators))

    instanceDailyMetricsDf["indicator"] = instanceDailyMetricsDf[
        "db_target_guid"
    ].str.cat(instanceDailyMetricsDf["metric"], sep="$$$")

    df = pd.merge(
        left=overriddenInstanceMetricsDf,
        right=dbPlacementsDf[
            ["cdb_cohort", "cdb", "cdb_target_guid", "db_target_guid"]
        ],
        how="left",
        left_on=["db_target_guid"],
        right_on=["db_target_guid"],
    )

    df["MINIMUM"] = df["value"]
    df["AVERAGE"] = df["value"]
    df["MAXIMUM"] = df["value"]
    df["STANDARD_DEVIATION"] = 0
    df["SAMPLE_COUNT"] = 1

    df.rename(columns={"db": "inst", "name": "metric"}, inplace=True)
    df.drop(columns=["indicator", "value"], inplace=True)

    overrideInstanceMetricsWithTSDf = df.merge(timeStampsDf, how="cross")
    overrideInstanceMetricsWithTSDf = overrideInstanceMetricsWithTSDf[
        [
            "cdb_cohort",
            "cdb",
            "inst",
            "metric",
            "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM",
            "MAXIMUM",
            "AVERAGE",
            "STANDARD_DEVIATION",
            "SAMPLE_COUNT",
            "cdb_target_guid",
            "db_target_guid",
        ]
    ]

    instanceDailyMetricsDf = instanceDailyMetricsDf[
        ~instanceDailyMetricsDf["indicator"].isin(indicators)
    ].copy()
    instanceDailyMetricsDf.drop(columns=["indicator"], inplace=True)

    if 1 == 0:
        lg(
            "\nxxx len(instanceDailyMetricsDf).00         : "
            + str(len(instanceDailyMetricsDf))
        )
        lg(
            "xxx instanceDailyMetricsDf.columns           : "
            + str(instanceDailyMetricsDf.columns)
        )
        lg(
            "xxx overrideInstanceMetricsWithTSDf.columns.1: "
            + str(overrideInstanceMetricsWithTSDf.columns)
        )

    instanceDailyMetricsDf = pd.concat(
        [instanceDailyMetricsDf, overrideInstanceMetricsWithTSDf], ignore_index=True
    )

    lg(
        "\nAdded "
        + str(len(overrideInstanceMetricsWithTSDf))
        + " override metrics to instanceDailyMetricsDf"
    )

    if 1 == 0:
        lg("\nxxx len(instanceDailyMetricsDf).01: " + str(len(instanceDailyMetricsDf)))

    df, overrideInstanceMetricsWithTSDf = [], []
    #
    #   Add derived sga+pga metric
    #
    if (
        PGA_METRIC in overriddenInstanceMetricsDf["name"].unique()
        or SGA_METRIC in overriddenInstanceMetricsDf["name"].unique()
    ):
        tb = time.time()

        sgapgaDf = (
            instanceDailyMetricsDf[
                (
                    instanceDailyMetricsDf["db_target_guid"].isin(
                        overriddenInstanceMetricsDf["db_target_guid"].unique()
                    )
                )
                & (instanceDailyMetricsDf["metric"].isin([PGA_METRIC, SGA_METRIC]))
            ]
            .groupby(
                [
                    "cdb_cohort",
                    "cdb",
                    "inst",
                    "metric",
                    "ROLLUP_TIMESTAMP_UTC",
                    "cdb_target_guid",
                    "db_target_guid",
                ],
                as_index=False,
            )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]]
            .sum()
        )
        sgapgaDf["metric"] = SGAPGA_DERIVED_METRIC

        sgapgaDf = sgapgaDf[
            [
                "cdb_cohort",
                "cdb",
                "inst",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "MINIMUM",
                "MAXIMUM",
                "AVERAGE",
                "STANDARD_DEVIATION",
                "SAMPLE_COUNT",
                "cdb_target_guid",
                "db_target_guid",
            ]
        ]

        instanceDailyMetricsDf = pd.concat(
            [
                instanceDailyMetricsDf[
                    (
                        ~instanceDailyMetricsDf["db_target_guid"].isin(
                            overriddenInstanceMetricsDf["db_target_guid"].unique()
                        )
                    )
                    | (instanceDailyMetricsDf["metric"] != SGAPGA_DERIVED_METRIC)
                ],
                sgapgaDf,
            ],
            ignore_index=True,
        )

        if 1 == 0:
            lg(
                "\nxxx len(instanceDailyMetricsDf).03: "
                + str(len(instanceDailyMetricsDf))
            )

        lg(
            "\nAdded "
            + str(len(sgapgaDf))
            + " updated sga+pga metrics in instanceDailyMetricsDf in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        sgapgaDf = []

        lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

excludedDbs = instancesDf[instancesDf["excluded"] == "excluded"][
    "db_target_guid"
].unique()

if len(instanceDailyMetricsDf) > 0:
    if len(aggregateCdbInstancesDf) > 0 and USE_CDB_HOURLY_OVERRIDES:
        tb = time.time()

        lg("\nAdding primary instance daily metrics using cdb replacements")
        #
        #       The SGA telemetry for standby databases is ignored
        #
        instanceDailyMetricsDf.loc[
            (
                instanceDailyMetricsDf["cdb_target_guid"].isin(
                    aggregateCdbInstancesDf["cdb_target_guid_old"]
                )
            )
            & (instanceDailyMetricsDf["metric"] == SGA_METRIC),
            "AVERAGE",
        ] = 0

        # ---

        df0 = instanceDailyMetricsDf[
            instanceDailyMetricsDf["cdb_target_guid"].isin(
                aggregateCdbInstancesDf["cdb_target_guid_new"]
            )
        ].copy()

        if 1 == 0:
            filename = (
                sizingFilePath + os.sep + "instance_daily_metrics.df0." + ln() + ".csv"
            )
            df0.sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )
            lg("\nWrote file " + filename)
        #
        #       CPU & IOPS telemetry for the Primary is ignored
        #
        df0.loc[df0["metric"].isin([CPU_DERIVED_METRIC, IOPS_METRIC]), "AVERAGE"] = 0
        df0 = pd.merge(
            left=df0,
            right=aggregateCdbInstancesDf,
            how="left",
            left_on="cdb_target_guid",
            right_on="cdb_target_guid_new",
        )

        df0["cdb_cohort"] = df0["cdb_cohort_old"]
        df0["cdb"] = df0["cdb_old"]
        df0["cdb_type"] = df0["cdb_type_new"]
        df0["cdb_target_guid"] = df0["cdb_target_guid_old"]

        colsToDrop = [c for c in df0.columns if c not in instanceDailyMetricsDf.columns]
        df0.drop(columns=colsToDrop, inplace=True)

        if 1 == 0:
            filename = (
                sizingFilePath + os.sep + "instance_daily_metrics.df0." + ln() + ".csv"
            )
            df0.sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )
            lg("\nWrote file " + filename)

        instanceDailyMetricsDf = pd.concat(
            [instanceDailyMetricsDf, df0], ignore_index=True
        )

        lg(
            "\nAdded "
            + str(len(df0))
            + " rows to instanceDailyMetricsDf for "
            + str(len(aggregateCdbInstancesDf))
            + " cdb replacements in "
            + str(round(time.time() - tb, 3))
            + " s"
        )
        lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

        df0 = []

        if len(DEBUG_CDB) > 0:
            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb.instance_daily_metrics."
                + ln()
                + ".csv"
            )
            instanceDailyMetricsDf[
                instanceDailyMetricsDf["cdb"].isin(DEBUG_CDB)
            ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )

    # ---

    if len(overriddenCdbInstancesDf) > 0 and USE_CDB_HOURLY_OVERRIDES:
        tb = time.time()

        lg("\nReplacing instance daily metrics using cdb replacements")

        df0 = pd.merge(
            left=instanceDailyMetricsDf[
                instanceDailyMetricsDf["cdb_target_guid"].isin(
                    overriddenCdbInstancesDf["cdb_target_guid_new"]
                )
            ],
            right=overriddenCdbInstancesDf,
            how="left",
            left_on="cdb_target_guid",
            right_on="cdb_target_guid_new",
        )

        df0["cdb_cohort"] = df0["cdb_cohort_old"]
        df0["cdb"] = df0["cdb_old"]
        df0["cdb_type"] = df0["cdb_type_new"]
        df0["cdb_target_guid"] = df0["cdb_target_guid_old"]

        colsToDrop = [c for c in df0.columns if c not in instanceDailyMetricsDf.columns]
        df0.drop(columns=colsToDrop, inplace=True)

        df1 = instanceDailyMetricsDf[
            ~instanceDailyMetricsDf["cdb_target_guid"].isin(
                overriddenCdbInstancesDf["cdb_target_guid_old"]
            )
        ].copy()
        instanceDailyMetricsDf = pd.concat([df0, df1], ignore_index=True)

        lg(
            "\nAdded "
            + str(len(df0))
            + " rows to instanceDailyMetricsDf for "
            + str(len(overriddenCdbInstancesDf))
            + " cdb replacements in "
            + str(round(time.time() - tb, 3))
            + " s"
        )
        lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

        df0, df1 = [], []

    # ---

    instanceDailyMetricsDf.loc[
        instanceDailyMetricsDf["db_target_guid"].isin(excludedDbs), "cdb_cohort"
    ] = "excluded"

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.instance_daily_metrics."
            + ln()
            + ".csv"
        )
        instanceDailyMetricsDf[
            instanceDailyMetricsDf["cdb"].isin(DEBUG_CDB)
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )

    # ---

    cdbDailyMetricsDf = instanceDailyMetricsDf.groupby(
        ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
        as_index=False,
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()
    cdbCohortDailyMetricsDf = cdbDailyMetricsDf.groupby(
        ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

    cdbCohortDailyCdbCountsDf = cdbDailyMetricsDf.groupby(
        ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
    )["cdb_target_guid"].nunique()
    cdbCohortDailyCdbCountsDf.columns = [
        "cdb_cohort",
        "metric",
        "ROLLUP_TIMESTAMP_UTC",
        "cdb_count",
    ]

    cdbCohortDailyCdbMetricCountsDf = cdbDailyMetricsDf.groupby(
        ["cdb_cohort", "cdb", "metric"], as_index=False
    )["ROLLUP_TIMESTAMP_UTC"].count()
    cdbCohortDailyCdbMetricCountsDf.columns = ["cdb_cohort", "cdb", "metric", "count"]

    area_plot.load_args(df=cdbDailyMetricsDf)
    MetricPlotBuilder.plot_metrics(area_plot)

    if storageDailyMetricsDf.empty:
        lg("WARNING: storageDailyMetricsDf is empty, creating empty Dataset for this.")
        storageDailyMetricsDf = pd.DataFrame(columns=[
            "cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC",
            "MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"
        ])
    # Storage Plots
    storage_daily_metrics_plot = storageDailyMetricsDf.groupby(
        ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
        as_index=False,
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()

    storage_area_plot = PlotFactory.create_plot("area")
    storage_area_plot.load_args(data_frequency="Daily", erase_existing_plots=False)
    storage_area_plot.load_args(df=storage_daily_metrics_plot)
    MetricPlotBuilder.plot_metrics(storage_area_plot)

lg(
    "\nCreated "
    + str(len(instanceDailyMetricsDf))
    + " instance daily metrics in "
    + str(round(time.time() - tb0, 3))
    + " s"
)

# ---

if len(storageDailyMetricsDf) > 0:
    if len(aggregateCdbInstancesDf) > 0 and USE_CDB_HOURLY_OVERRIDES:
        tb = time.time()

        lg("\nReplacing storage hourly metrics using cdb replacements")

        df0 = pd.merge(
            left=storageDailyMetricsDf[
                storageDailyMetricsDf["TARGET_GUID"].isin(
                    aggregateCdbInstancesDf["cdb_target_guid_new"]
                )
            ],
            right=aggregateCdbInstancesDf,
            how="left",
            left_on="TARGET_GUID",
            right_on="cdb_target_guid_new",
        )

        df0["TARGET_NAME"] = df0["cdb_old"]
        df0["TARGET_GUID"] = df0["cdb_target_guid_old"]
        df0["TARGET_TYPE"] = df0["cdb_type_new"]
        df0["cdb_cohort"] = df0["cdb_cohort_old"]
        df0["cdb"] = df0["cdb_old"]
        df0["cdb_type"] = df0["cdb_type_new"]
        df0["cdb_target_guid"] = df0["cdb_target_guid_old"]

        colsToDrop = [
            c for c in df0.columns if c not in cdbHourlyStorageMetricsDf.columns
        ]
        df0.drop(columns=colsToDrop, inplace=True)

        df1 = storageDailyMetricsDf[
            ~storageDailyMetricsDf["TARGET_GUID"].isin(
                aggregateCdbInstancesDf["cdb_target_guid_old"]
            )
        ].copy()
        storageDailyMetricsDf = pd.concat([df0, df1], ignore_index=True)

        lg(
            "\nAdded "
            + str(len(df0))
            + " rows to storageDailyMetricsDf for "
            + str(len(aggregateCdbInstancesDf))
            + " cdb replacements in "
            + str(round(time.time() - tb, 3))
            + " s"
        )
        lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

        df0, df1 = [], []

        if len(DEBUG_CDB) > 0:
            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb.storage_daily_metrics."
                + ln()
                + ".csv"
            )
            storageDailyMetricsDf[
                storageDailyMetricsDf["cdb"].isin(DEBUG_CDB)
            ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )

    # ---

    if len(overriddenCdbsDf) > 0 and USE_CDB_HOURLY_OVERRIDES:
        tb = time.time()

        lg("\nReplacing storage hourly metrics using cdb overrides")

        df0 = pd.merge(
            left=storageDailyMetricsDf[
                storageDailyMetricsDf["TARGET_GUID"].isin(
                    overriddenCdbsDf["cdb_target_guid_new"]
                )
            ],
            right=overriddenCdbsDf,
            how="left",
            left_on="TARGET_GUID",
            right_on="cdb_target_guid_new",
        )

        df0["TARGET_NAME"] = df0["cdb_old"]
        df0["TARGET_GUID"] = df0["cdb_target_guid_old"]
        df0["TARGET_TYPE"] = df0["cdb_type_new"]
        df0["cdb_cohort"] = df0["cdb_cohort_old"]
        df0["cdb"] = df0["cdb_old"]
        df0["cdb_type"] = df0["cdb_type_new"]
        df0["cdb_target_guid"] = df0["cdb_target_guid_old"]

        colsToDrop = [
            c for c in df0.columns if c not in cdbHourlyStorageMetricsDf.columns
        ]
        df0.drop(columns=colsToDrop, inplace=True)

        df1 = storageDailyMetricsDf[
            ~storageDailyMetricsDf["TARGET_GUID"].isin(
                overriddenCdbsDf["cdb_target_guid_old"]
            )
        ].copy()
        storageDailyMetricsDf = pd.concat([df0, df1], ignore_index=True)

        lg(
            "\nAdded "
            + str(len(df0))
            + " rows to storageDailyMetricsDf for "
            + str(len(overriddenCdbsDf))
            + " cdb overrides in "
            + str(round(time.time() - tb, 3))
            + " s"
        )
        lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

        df0, df1 = [], []

    # ---

    storageDailyMetricsDf.loc[
        storageDailyMetricsDf["cdb_target_guid"].isin(excludedCdbs), "cdb_cohort"
    ] = "excluded"

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath + os.sep + "debug_cdb.storage_daily_metrics." + ln() + ".csv"
        )
        storageDailyMetricsDf[storageDailyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)

    # ---

    df0 = storageDailyMetricsDf.groupby(
        ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
        as_index=False,
    )[["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]].sum()
    df1 = df0.groupby(["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False)[
        ["MINIMUM", "AVERAGE", "MAXIMUM", "STANDARD_DEVIATION", "SAMPLE_COUNT"]
    ].sum()

    df2 = df0.groupby(["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False)[
        "cdb_target_guid"
    ].nunique()
    df2.columns = ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC", "cdb_count"]

    cdbDailyMetricsDf = (
        df0
        if len(cdbDailyMetricsDf) == 0
        else pd.concat([cdbDailyMetricsDf, df0], ignore_index=True)
    )
    cdbCohortDailyMetricsDf = (
        df1
        if len(cdbCohortDailyMetricsDf) == 0
        else pd.concat([cdbCohortDailyMetricsDf, df1], ignore_index=True)
    )
    cdbCohortDailyCdbCountsDf = (
        df2
        if len(cdbCohortDailyCdbCountsDf) == 0
        else pd.concat([cdbCohortDailyCdbCountsDf, df2], ignore_index=True)
    )

    df2 = storageDailyMetricsDf.groupby(
        ["cdb_cohort", "cdb", "metric"], as_index=False
    )["ROLLUP_TIMESTAMP_UTC"].count()
    df2.columns = ["cdb_cohort", "cdb", "metric", "count"]

    cdbCohortDailyCdbMetricCountsDf = (
        df2
        if len(cdbCohortDailyCdbMetricCountsDf) == 0
        else pd.concat([cdbCohortDailyCdbMetricCountsDf, df2], ignore_index=True)
    )

    df0, df1, df2 = [], [], []

# ---

if len(cdbCohortDailyMetricsDf) > 0:
    cdbCohortDailyMetricsDf = pd.merge(
        left=cdbCohortDailyMetricsDf,
        right=cdbCohortDailyCdbCountsDf,
        how="left",
        left_on=["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"],
        right_on=["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"],
    )
    cdbCohortDailyMetricsDf["cdb_count"] = cdbCohortDailyMetricsDf["cdb_count"].fillna(
        0
    )

    lg(
        "Created "
        + str(len(cdbDailyMetricsDf))
        + " cdb daily metrics in "
        + str(round(time.time() - tb0, 3))
        + " s"
    )
    lg(
        "Created "
        + str(len(cdbCohortDailyMetricsDf))
        + " cdb daily cohort metrics in "
        + str(round(time.time() - tb0, 3))
        + " s"
    )

# ---

if len(METRIC_CDB) > 0:
    filename = (
        sizingFilePath + os.sep + "metric_cdb.daily_instance_metrics.1processed.csv"
    )
    instanceDailyMetricsDf[instanceDailyMetricsDf["cdb"].isin(METRIC_CDB)].sort_values(
        ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    if len(storageDailyMetricsDf) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "metric_cdb.daily_cdb_storage_metrics.1processed.csv"
        )
        storageDailyMetricsDf[
            storageDailyMetricsDf["cdb"].isin(METRIC_CDB)
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

# ---

if len(DEBUG_CDB) > 0:
    if len(cdbDailyMetricsDf) > 0:
        filename = (
            sizingFilePath + os.sep + "debug_cdb.cdb_daily_metrics." + ln() + ".csv"
        )
        cdbDailyMetricsDf[cdbDailyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)

        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.cdb_cohort_daily_metrics."
            + ln()
            + ".csv"
        )
        cdbCohortDailyMetricsDf[
            cdbCohortDailyMetricsDf["cdb_cohort"].isin(DEBUG_COHORT)
        ].sort_values(["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )

if WRITE_DEBUG_FILES:
    if len(cdbCohortDailyCdbCountsDf) > 0:
        filename = (
            sizingFilePath + os.sep + "cdb_Cohort_Daily_Cdb_Counts." + ln() + ".csv"
        )
        cdbCohortDailyCdbCountsDf.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    filename = sizingFilePath + os.sep + "cdb_Daily_Metrics." + ln() + ".csv"
    cdbDailyMetricsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    if len(cdbCohortDailyMetricsDf) > 0:
        filename = (
            sizingFilePath + os.sep + "cdb_Cohort_Daily_Metrics.gb." + ln() + ".csv"
        )
        cdbCohortDailyMetricsDf.groupby(["cdb_cohort", "metric"], as_index=False)[
            "AVERAGE"
        ].agg(["max", "sum", "count"]).reset_index().sort_values(
            ["cdb_cohort", "metric"]
        ).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

# ----------------------------------------------------------------------------------------------------------------------

adjustedValuesDf, cdbCohortDailyAdjustmentsDf, timeGroupAlignedAvgDf = [], [], []

if len(instanceDailyMetricsDf) == 0:
    lg(
        "\n\nNo db daily metrics have been loaded. Skipping computation of hourly adjustments..."
    )

else:
    dailyDays = sorted(
        instanceDailyMetricsDf["ROLLUP_TIMESTAMP_UTC"].unique(), reverse=True
    )
    timeStampGroup, timeStampGroups = 0, {}

    if 1 == 0:
        lg(
            "min(hourlyDays), max(hourlyDays), len(hourlyDays): "
            + str((min(hourlyDays), max(hourlyDays), len(hourlyDays)))
        )
        lg(
            "min(dailyDays),  max(dailyDays),  len(dailyDays) : "
            + str((min(dailyDays), max(dailyDays), len(dailyDays)))
        )

    for ctr, day in enumerate(dailyDays):
        timeStampGroup = -1 * math.floor(ctr / len(hourlyDays))

        if 1 == 0:
            if ctr < 30:
                lg("Placing " + str(day) + " in group " + str(timeStampGroup))

        timeStampGroups[day] = timeStampGroup

    # ---

    if 1 == 0:
        for ctr, _ in enumerate(sorted(timeStampGroups.keys())):
            if not (
                ctr <= len(hourlyDays) * 2
                or ctr >= len(timeStampGroups) - len(hourlyDays) * 2
            ):
                continue

            lg("timeStampGroups[" + str(_) + "]: " + str(timeStampGroups[_]))

    timeStampGroupsDf = pd.DataFrame.from_dict(
        timeStampGroups, orient="index", columns=["time_stamp_group"]
    )

    cdbDailyMetricsDf = pd.merge(
        left=cdbDailyMetricsDf,
        right=timeStampGroupsDf,
        how="left",
        left_on="ROLLUP_TIMESTAMP_UTC",
        right_index=True,
    )
    cdbCohortDailyMetricsDf = pd.merge(
        left=cdbCohortDailyMetricsDf,
        right=timeStampGroupsDf,
        how="left",
        left_on="ROLLUP_TIMESTAMP_UTC",
        right_index=True,
    )

    cdbCohortDailyMetricsDf["cdb_count_avg"] = cdbCohortDailyMetricsDf.groupby(
        ["cdb_cohort", "metric", "time_stamp_group"]
    )["cdb_count"].transform("mean")

    if WRITE_DEBUG_FILES:
        if len(cdbCohortDailyCdbCountsDf) > 0:
            filename = (
                sizingFilePath + os.sep + "cdb_Cohort_Daily_Metrics.gb." + ln() + ".csv"
            )
            cdbCohortDailyMetricsDf.groupby(["cdb_cohort", "metric"], as_index=False)[
                "AVERAGE"
            ].agg(["max", "sum", "count"]).reset_index().sort_values(
                ["cdb_cohort", "metric"]
            ).to_csv(
                filename, index=False
            )
            lg("\nWrote file " + filename)

    # ---

    tb = time.time()

    timeStampGroup0MetricsDf = (
        cdbDailyMetricsDf[cdbDailyMetricsDf["time_stamp_group"] == 0]
        .groupby(["cdb_target_guid", "metric"], as_index=False)[["AVERAGE"]]
        .agg(["mean", "max"])
        .reset_index()[["cdb_target_guid", "metric", "AVERAGE"]]
    )
    timeStampGroup0MetricsDf.columns = [
        "cdb_target_guid",
        "metric",
        "DAILY_AVERAGE_avg_group_0",
        "DAILY_AVERAGE_max_group_0",
    ]

    if 1 == 0:
        lg("cdbDailyMetricsDf.ccc.columns: " + str(cdbDailyMetricsDf.columns))
        printDf("cdbDailyMetricsDf." + ln(), cdbDailyMetricsDf, rows=10, showTail=False)

    cdbDailyAdjustmentsDf = cdbDailyMetricsDf.groupby(
        ["cdb_target_guid", "cdb_cohort", "cdb", "metric", "time_stamp_group"],
        as_index=False,
    )[["AVERAGE", "ROLLUP_TIMESTAMP_UTC"]].agg(
        {"AVERAGE": ["mean", "max"], "ROLLUP_TIMESTAMP_UTC": ["min", "max"]}
    )

    if 1 == 0:
        lg(
            "cdbDailyAdjustmentsDf."
            + ln()
            + ".columns: "
            + str(cdbDailyAdjustmentsDf.columns)
        )
        printDf(
            "cdbDailyAdjustmentsDf." + ln(),
            cdbDailyAdjustmentsDf,
            rows=10,
            showTail=False,
        )

    cdbDailyAdjustmentsDf.columns = [
        "cdb_target_guid",
        "cdb_cohort",
        "cdb",
        "metric",
        "time_stamp_group",
        "DAILY_AVERAGE_avg",
        "DAILY_AVERAGE_max",
        "ROLLUP_TIMESTAMP_min",
        "ROLLUP_TIMESTAMP_max",
    ]

    if 1 == 0:
        printDf(
            "cdbDailyAdjustmentsDf." + ln(),
            cdbDailyAdjustmentsDf,
            rows=10,
            showTail=False,
        )
        printDf(
            "timeStampGroup0MetricsDf." + ln(),
            timeStampGroup0MetricsDf,
            rows=10,
            showTail=False,
        )

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.cdb_daily_adjusted_values."
            + ln()
            + ".csv"
        )
        cdbDailyAdjustmentsDf[cdbDailyAdjustmentsDf["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric"]
        ).to_csv(filename, index=False)

    cdbDailyAdjustmentsDf = pd.merge(
        left=cdbDailyAdjustmentsDf,
        right=timeStampGroup0MetricsDf,
        how="left",
        left_on=["cdb_target_guid", "metric"],
        right_on=["cdb_target_guid", "metric"],
    )

    cdbDailyAdjustmentsDf["AVERAGE_avg_multiplier"] = (
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_avg"]
        / cdbDailyAdjustmentsDf["DAILY_AVERAGE_avg_group_0"]
    )
    cdbDailyAdjustmentsDf.loc[
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_avg_group_0"] == 0,
        "AVERAGE_avg_multiplier",
    ] = 0

    cdbDailyAdjustmentsDf["AVERAGE_max_multiplier"] = (
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_max"]
        / cdbDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"]
    )
    cdbDailyAdjustmentsDf.loc[
        cdbDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"] == 0,
        "AVERAGE_max_multiplier",
    ] = 0

    cdbDailyAdjustmentsDf["days_to_subtract_from_g0"] = (
        -1 * cdbDailyAdjustmentsDf["time_stamp_group"] * len(hourlyDays)
    )

    cdbDailyAdjustmentsDf["cdb_count_avg"] = 1
    cdbDailyAdjustmentsDf = cdbDailyAdjustmentsDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "time_stamp_group",
            "days_to_subtract_from_g0",
            "ROLLUP_TIMESTAMP_min",
            "ROLLUP_TIMESTAMP_max",
            "cdb_count_avg",
            "DAILY_AVERAGE_avg",
            "DAILY_AVERAGE_avg_group_0",
            "AVERAGE_avg_multiplier",
            "DAILY_AVERAGE_max",
            "DAILY_AVERAGE_max_group_0",
            "AVERAGE_max_multiplier",
            "cdb_target_guid",
        ]
    ]

    # ---

    cdbDailyAdjustmentsDf["AVERAGE_avg_multiplier_group_max"] = (
        cdbDailyAdjustmentsDf.groupby(["cdb", "metric"])[
            "AVERAGE_avg_multiplier"
        ].transform("max")
    )
    cdbDailyAdjustmentsDf["AVERAGE_max_multiplier_group_max"] = (
        cdbDailyAdjustmentsDf.groupby(["cdb", "metric"])[
            "AVERAGE_max_multiplier"
        ].transform("max")
    )

    lg(
        "Computed cdb daily time stamp group adjustments from "
        + str(len(cdbDailyMetricsDf))
        + " rows in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    cdbDailyAdjustmentsDf["summary_of"] = "cdb"
    cdbDailyAdjustmentsDf["version"] = __version__

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath + os.sep + "debug_cdb.cdb_daily_adjustments." + ln() + ".csv"
        )
        cdbDailyAdjustmentsDf[cdbDailyAdjustmentsDf["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric"]
        ).to_csv(filename, index=False)

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "cdb_Daily_Adjustments." + ln() + ".csv"
        cdbDailyAdjustmentsDf.sort_values(["cdb", "metric", "time_stamp_group"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    # ---

    tb = time.time()

    timeStampGroup0MetricsDf = (
        cdbCohortDailyMetricsDf[cdbCohortDailyMetricsDf["time_stamp_group"] == 0]
        .groupby(["cdb_cohort", "metric"], as_index=False)[["AVERAGE"]]
        .agg(["mean", "max"])
        .reset_index()[["cdb_cohort", "metric", "AVERAGE"]]
    )
    timeStampGroup0MetricsDf.columns = [
        "cdb_cohort",
        "metric",
        "DAILY_AVERAGE_avg_group_0",
        "DAILY_AVERAGE_max_group_0",
    ]

    if 1 == 0:
        printDf(
            "cdbCohortDailyMetricsDf." + ln(),
            cdbCohortDailyMetricsDf,
            rows=10,
            showTail=False,
        )

    cdbCohortDailyAdjustmentsDf = cdbCohortDailyMetricsDf.groupby(
        ["cdb_cohort", "metric", "time_stamp_group", "cdb_count_avg"], as_index=False
    )[["AVERAGE", "ROLLUP_TIMESTAMP_UTC"]].agg(
        {"AVERAGE": ["mean", "max"], "ROLLUP_TIMESTAMP_UTC": ["min", "max"]}
    )
    cdbCohortDailyAdjustmentsDf.columns = [
        "cdb_cohort",
        "metric",
        "time_stamp_group",
        "cdb_count_avg",
        "DAILY_AVERAGE_avg",
        "DAILY_AVERAGE_max",
        "ROLLUP_TIMESTAMP_min",
        "ROLLUP_TIMESTAMP_max",
    ]

    cdbCohortDailyAdjustmentsDf["cdb_target_guid"] = "All"
    cdbCohortDailyAdjustmentsDf["cdb"] = "All"

    if 1 == 0:
        printDf(
            "cdbCohortDailyAdjustmentsDf." + ln(),
            cdbCohortDailyAdjustmentsDf,
            rows=10,
            showTail=False,
        )
        printDf(
            "timeStampGroup0MetricsDf." + ln(),
            timeStampGroup0MetricsDf,
            rows=10,
            showTail=False,
        )

    cdbCohortDailyAdjustmentsDf = pd.merge(
        left=cdbCohortDailyAdjustmentsDf,
        right=timeStampGroup0MetricsDf,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )

    cdbCohortDailyAdjustmentsDf["AVERAGE_avg_multiplier"] = (
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_avg"]
        / cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"]
    )
    cdbCohortDailyAdjustmentsDf.loc[
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_avg_group_0"] == 0,
        "AVERAGE_avg_multiplier",
    ] = 0

    cdbCohortDailyAdjustmentsDf["AVERAGE_max_multiplier"] = (
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max"]
        / cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"]
    )
    cdbCohortDailyAdjustmentsDf.loc[
        cdbCohortDailyAdjustmentsDf["DAILY_AVERAGE_max_group_0"] == 0,
        "AVERAGE_max_multiplier",
    ] = 0

    cdbCohortDailyAdjustmentsDf["days_to_subtract_from_g0"] = (
        -1 * cdbCohortDailyAdjustmentsDf["time_stamp_group"] * len(hourlyDays)
    )

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "cohort_Daily_Adjustments." + ln() + ".csv"
        cdbCohortDailyAdjustmentsDf.sort_values(
            ["cdb", "metric", "time_stamp_group"]
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    cdbCohortDailyAdjustmentsDf = cdbCohortDailyAdjustmentsDf[
        [
            "cdb_cohort",
            "cdb",
            "metric",
            "time_stamp_group",
            "days_to_subtract_from_g0",
            "ROLLUP_TIMESTAMP_min",
            "ROLLUP_TIMESTAMP_max",
            "cdb_count_avg",
            "DAILY_AVERAGE_avg",
            "DAILY_AVERAGE_avg_group_0",
            "AVERAGE_avg_multiplier",
            "DAILY_AVERAGE_max",
            "DAILY_AVERAGE_max_group_0",
            "AVERAGE_max_multiplier",
            "cdb_target_guid",
        ]
    ]
    #
    #   The following logic is needed just in case no hourly metrics were available to compute an adjustment multiplier
    #
    cdbDailyAdjustmentsDf.loc[
        cdbDailyAdjustmentsDf["AVERAGE_avg_multiplier"] == 0, "AVERAGE_avg_multiplier"
    ] = 1
    cdbDailyAdjustmentsDf.loc[
        cdbDailyAdjustmentsDf["AVERAGE_max_multiplier"] == 0, "AVERAGE_max_multiplier"
    ] = 1
    cdbDailyAdjustmentsDf["AVERAGE_avg_multiplier"] = cdbDailyAdjustmentsDf[
        "AVERAGE_avg_multiplier"
    ].fillna(1)
    cdbDailyAdjustmentsDf["AVERAGE_max_multiplier"] = cdbDailyAdjustmentsDf[
        "AVERAGE_max_multiplier"
    ].fillna(1)

    cdbCohortDailyAdjustmentsDf.loc[
        cdbCohortDailyAdjustmentsDf["AVERAGE_avg_multiplier"] == 0,
        "AVERAGE_avg_multiplier",
    ] = 1
    cdbCohortDailyAdjustmentsDf.loc[
        cdbCohortDailyAdjustmentsDf["AVERAGE_max_multiplier"] == 0,
        "AVERAGE_max_multiplier",
    ] = 1
    cdbCohortDailyAdjustmentsDf["AVERAGE_avg_multiplier"] = cdbCohortDailyAdjustmentsDf[
        "AVERAGE_avg_multiplier"
    ].fillna(1)
    cdbCohortDailyAdjustmentsDf["AVERAGE_max_multiplier"] = cdbCohortDailyAdjustmentsDf[
        "AVERAGE_max_multiplier"
    ].fillna(1)

    cdbCohortDailyAdjustmentsDf["AVERAGE_avg_multiplier_group_max"] = (
        cdbCohortDailyAdjustmentsDf.groupby(["cdb_cohort", "metric"])[
            "AVERAGE_avg_multiplier"
        ].transform("max")
    )
    cdbCohortDailyAdjustmentsDf["AVERAGE_max_multiplier_group_max"] = (
        cdbCohortDailyAdjustmentsDf.groupby(["cdb_cohort", "metric"])[
            "AVERAGE_max_multiplier"
        ].transform("max")
    )

    lg(
        "Computed cdb cohort daily time stamp group adjustments from "
        + str(len(cdbDailyMetricsDf))
        + " rows in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    cdbCohortDailyAdjustmentsDf["summary_of"] = "cdb_cohort"
    cdbCohortDailyAdjustmentsDf["version"] = __version__

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "cohort_Daily_Adjustments." + ln() + ".csv"
        cdbCohortDailyAdjustmentsDf.sort_values(
            ["cdb", "metric", "time_stamp_group"]
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    # ----------------------------------------------------------------------------------------------------------------------

    tb = time.time()

    _ = {g for g in list(timeStampGroups.values())}  # use a set to get unique values
    _ = [g for g in _]

    lg(
        "\nAdding time_groups....time since start "
        + str(round(time.time() - startTime, 3))
        + " s"
    )

    for ctr, groups in enumerate(sorted(_)):
        #
        #       Adjust the hourly data by each of the daily maximum multipliers in case we ever want to plot them
        #
        lg(
            ("     Adding time_stamp_group: " + str(groups)).ljust(35)
            + "; time since start "
            + str(round(time.time() - startTime, 3))
            + " s"
        )

        if groups == 0:
            df1 = cdbHourlyMetricsDf[
                ~cdbHourlyMetricsDf["metric"].isin(
                    [CPU_DERIVED_METRIC_STANDBY, IOPS_METRIC_STANDBY]
                )
            ].copy()
            df1["AVERAGE_max_multiplier"] = 1
            df1["AVERAGE_max_multiplier_group_max"] = 1

            df1s = cdbHourlyStorageMetricsDf
            df1s["AVERAGE_max_multiplier"] = 1
            df1s["AVERAGE_max_multiplier_group_max"] = 1

            df2 = cdbCohortHourlyMetricsDf[
                ~cdbCohortHourlyMetricsDf["metric"].isin(
                    [CPU_DERIVED_METRIC_STANDBY, IOPS_METRIC_STANDBY]
                )
            ].copy()
            df2["AVERAGE_max_multiplier"] = 1
            df2["AVERAGE_max_multiplier_group_max"] = 1

            df2s = cdbCohortHourlyStorageMetricsDf
            df2s["AVERAGE_max_multiplier"] = 1
            df2s["AVERAGE_max_multiplier_group_max"] = 1

        else:
            df1 = pd.merge(
                left=cdbHourlyMetricsDf[
                    [
                        "cdb_cohort",
                        "cdb",
                        "cdb_target_guid",
                        "metric",
                        "ROLLUP_TIMESTAMP_UTC",
                        "AVERAGE",
                    ]
                ],
                right=cdbDailyAdjustmentsDf[
                    cdbDailyAdjustmentsDf["time_stamp_group"] == groups
                ][
                    [
                        "cdb_target_guid",
                        "metric",
                        "days_to_subtract_from_g0",
                        "AVERAGE_avg_multiplier",
                        "AVERAGE_max_multiplier",
                        "cdb_count_avg",
                        "AVERAGE_max_multiplier_group_max",
                    ]
                ],
                left_on=["cdb_target_guid", "metric"],
                right_on=["cdb_target_guid", "metric"],
                how="left",
            )
            df1["ROLLUP_TIMESTAMP_UTC"] -= df1[
                "days_to_subtract_from_g0"
            ].values.astype("timedelta64[D]")
            df1["AVERAGE"] = df1["AVERAGE"] * df1["AVERAGE_max_multiplier"]

            df1s = pd.merge(
                left=cdbHourlyStorageMetricsDf[
                    [
                        "cdb_cohort",
                        "cdb",
                        "cdb_target_guid",
                        "metric",
                        "ROLLUP_TIMESTAMP_UTC",
                        "AVERAGE",
                    ]
                ],
                right=cdbDailyAdjustmentsDf[
                    cdbDailyAdjustmentsDf["time_stamp_group"] == groups
                ][
                    [
                        "cdb_target_guid",
                        "metric",
                        "days_to_subtract_from_g0",
                        "AVERAGE_avg_multiplier",
                        "AVERAGE_max_multiplier",
                        "cdb_count_avg",
                        "AVERAGE_max_multiplier_group_max",
                    ]
                ],
                left_on=["cdb_target_guid", "metric"],
                right_on=["cdb_target_guid", "metric"],
                how="left",
            )
            df1s["ROLLUP_TIMESTAMP_UTC"] -= df1s[
                "days_to_subtract_from_g0"
            ].values.astype("timedelta64[D]")
            df1s["AVERAGE"] = df1s["AVERAGE"] * df1s["AVERAGE_max_multiplier"]

            # ---

            df2 = pd.merge(
                left=cdbCohortHourlyMetricsDf[
                    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC", "AVERAGE"]
                ],
                right=cdbCohortDailyAdjustmentsDf[
                    cdbCohortDailyAdjustmentsDf["time_stamp_group"] == groups
                ][
                    [
                        "cdb_cohort",
                        "metric",
                        "days_to_subtract_from_g0",
                        "AVERAGE_avg_multiplier",
                        "AVERAGE_max_multiplier",
                        "cdb_count_avg",
                        "AVERAGE_max_multiplier_group_max",
                    ]
                ],
                left_on=["cdb_cohort", "metric"],
                right_on=["cdb_cohort", "metric"],
                how="left",
            )
            df2["ROLLUP_TIMESTAMP_UTC"] -= df2[
                "days_to_subtract_from_g0"
            ].values.astype("timedelta64[D]")
            df2["AVERAGE"] = df2["AVERAGE"] * df2["AVERAGE_max_multiplier"]

            df2s = pd.merge(
                left=cdbHourlyStorageMetricsDf[
                    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC", "AVERAGE"]
                ],
                right=cdbCohortDailyAdjustmentsDf[
                    cdbCohortDailyAdjustmentsDf["time_stamp_group"] == groups
                ][
                    [
                        "cdb_cohort",
                        "metric",
                        "days_to_subtract_from_g0",
                        "AVERAGE_avg_multiplier",
                        "AVERAGE_max_multiplier",
                        "cdb_count_avg",
                        "AVERAGE_max_multiplier_group_max",
                    ]
                ],
                left_on=["cdb_cohort", "metric"],
                right_on=["cdb_cohort", "metric"],
                how="left",
            )
            df2s["ROLLUP_TIMESTAMP_UTC"] -= df2s[
                "days_to_subtract_from_g0"
            ].values.astype("timedelta64[D]")
            df2s["AVERAGE"] = df2s["AVERAGE"] * df2s["AVERAGE_max_multiplier"]

        df2["cdb"] = "All"
        df2["cdb_target_guid"] = "All"

        df2s["cdb"] = "All"
        df2s["cdb_target_guid"] = "All"

        # ---

        if len(DEBUG_CDB) > 0:
            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb.df1."
                + ln()
                + ".group_"
                + str(groups).zfill(2)
                + ".csv"
            )
            df1[df1["cdb"].isin(DEBUG_CDB)].sort_values(
                ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
            ).to_csv(filename, index=False)

            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb.df2."
                + ln()
                + ".group_"
                + str(groups).zfill(2)
                + ".csv"
            )
            df2[df2["cdb"].isin(DEBUG_CDB)].sort_values(
                ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
            ).to_csv(filename, index=False)

            if len(timeGroupAlignedAvgDf) > 0:
                filename = (
                    sizingFilePath
                    + os.sep
                    + "debug_cdb.time_group_aligned_avg."
                    + ln()
                    + ".group_"
                    + str(groups).zfill(2)
                    + ".csv"
                )
                timeGroupAlignedAvgDf[
                    timeGroupAlignedAvgDf["cdb"].isin(DEBUG_CDB)
                ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                    filename, index=False
                )

                filename = (
                    sizingFilePath
                    + os.sep
                    + "debug_cdb_cohort.time_group_aligned_avg."
                    + ln()
                    + ".group_"
                    + str(groups).zfill(2)
                    + ".csv"
                )
                timeGroupAlignedAvgDf[
                    timeGroupAlignedAvgDf["cdb_cohort"].isin(DEBUG_COHORT)
                ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                    filename, index=False
                )

        # ---

        df = df1.groupby(
            [
                "cdb_cohort",
                "cdb",
                "cdb_target_guid",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "AVERAGE_max_multiplier",
                "AVERAGE_max_multiplier_group_max",
            ],
            as_index=False,
        )[["AVERAGE", "cdb_count_avg"]].sum()
        df["time_stamp_group"] = groups
        df["summary_of"] = "cdb"
        timeGroupAlignedAvgDf = (
            df
            if len(timeGroupAlignedAvgDf) == 0
            else pd.concat([timeGroupAlignedAvgDf, df])
        )

        df = df1s.groupby(
            [
                "cdb_cohort",
                "cdb",
                "cdb_target_guid",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "AVERAGE_max_multiplier",
                "AVERAGE_max_multiplier_group_max",
            ],
            as_index=False,
        )[["AVERAGE", "cdb_count_avg"]].sum()
        df["time_stamp_group"] = groups
        df["summary_of"] = "cdb"
        timeGroupAlignedAvgDf = (
            df
            if len(timeGroupAlignedAvgDf) == 0
            else pd.concat([timeGroupAlignedAvgDf, df])
        )

        if len(DEBUG_CDB) > 0:
            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb.time_group_aligned_avg."
                + ln()
                + ".group_"
                + str(groups).zfill(2)
                + ".csv"
            )
            timeGroupAlignedAvgDf[
                timeGroupAlignedAvgDf["cdb"].isin(DEBUG_CDB)
            ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )

            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb_cohort.time_group_aligned_avg."
                + ln()
                + ".group_"
                + str(groups).zfill(2)
                + ".csv"
            )
            timeGroupAlignedAvgDf[
                timeGroupAlignedAvgDf["cdb_cohort"].isin(DEBUG_COHORT)
            ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )

        # ---

        df = df2.groupby(
            [
                "cdb_cohort",
                "cdb",
                "cdb_target_guid",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "cdb_count_avg",
                "AVERAGE_max_multiplier",
                "AVERAGE_max_multiplier_group_max",
            ],
            as_index=False,
        )[["AVERAGE"]].sum()
        df["time_stamp_group"] = groups
        df["summary_of"] = "cdb_cohort"
        timeGroupAlignedAvgDf = (
            df
            if len(timeGroupAlignedAvgDf) == 0
            else pd.concat([timeGroupAlignedAvgDf, df])
        )

        df = df2s.groupby(
            [
                "cdb_cohort",
                "cdb",
                "cdb_target_guid",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "cdb_count_avg",
                "AVERAGE_max_multiplier",
                "AVERAGE_max_multiplier_group_max",
            ],
            as_index=False,
        )[["AVERAGE"]].sum()
        df["time_stamp_group"] = groups
        df["summary_of"] = "cdb_cohort"
        timeGroupAlignedAvgDf = (
            df
            if len(timeGroupAlignedAvgDf) == 0
            else pd.concat([timeGroupAlignedAvgDf, df])
        )

        if len(DEBUG_CDB) > 0:
            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb.time_group_aligned_avg."
                + ln()
                + ".group_"
                + str(groups).zfill(2)
                + ".csv"
            )
            timeGroupAlignedAvgDf[
                timeGroupAlignedAvgDf["cdb"].isin(DEBUG_CDB)
            ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )

            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb_cohort.time_group_aligned_avg."
                + ln()
                + ".group_"
                + str(groups).zfill(2)
                + ".csv"
            )
            timeGroupAlignedAvgDf[
                timeGroupAlignedAvgDf["cdb_cohort"].isin(DEBUG_COHORT)
            ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
                filename, index=False
            )

        # ---

        df1, df1s, df2, df2s = [], [], [], []

    # ---

    if WRITE_DEBUG_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + "time_Group_Aligned_Avg.cdb_cohort."
            + ln()
            + ".csv"
        )
        timeGroupAlignedAvgDf[
            timeGroupAlignedAvgDf["summary_of"] == "cdb_cohort"
        ].to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    if len(DEBUG_CDB) > 0:
        filename = (
            sizingFilePath
            + os.sep
            + "debug_cdb.time_group_aligned_avg."
            + ln()
            + ".csv"
        )
        timeGroupAlignedAvgDf[timeGroupAlignedAvgDf["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)
    #
    #   Select the row with the largest multiplier
    #
    df = timeGroupAlignedAvgDf[
        (timeGroupAlignedAvgDf["summary_of"] == "cdb")
        & (
            timeGroupAlignedAvgDf["AVERAGE_max_multiplier"]
            == timeGroupAlignedAvgDf["AVERAGE_max_multiplier_group_max"]
        )
    ].copy()

    if len(DEBUG_CDB) > 0:
        filename = sizingFilePath + os.sep + "debug_cdb.df." + ln() + ".csv"
        df[df["cdb"].isin(DEBUG_CDB)].sort_values(
            ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
        ).to_csv(filename, index=False)
    #
    #   This is needed just in case more than one metric has the maximum multiplier
    #
    df["time_stamp_group_min"] = df.groupby(["cdb", "metric"])[
        "time_stamp_group"
    ].transform("min")
    df = df[df["time_stamp_group"] == df["time_stamp_group_min"]]

    hrsDf = df.groupby(["cdb_target_guid", "metric"], as_index=False)[
        "ROLLUP_TIMESTAMP_UTC"
    ].nunique()
    hrsDf.columns = ["cdb_target_guid", "metric", "hrs"]
    hrsDf.loc[
        hrsDf["metric"].isin([STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]), "hrs"
    ] = (hrsDf["hrs"] * 24)

    df0 = (
        df.groupby(
            [
                "cdb_cohort",
                "cdb",
                "cdb_target_guid",
                "metric",
                "summary_of",
                "time_stamp_group",
                "AVERAGE_max_multiplier",
            ],
            as_index=False,
        )[["cdb_count_avg", "AVERAGE"]]
        .agg(["max", "sum"])
        .reset_index()[
            [
                "cdb_cohort",
                "cdb",
                "cdb_target_guid",
                "metric",
                "summary_of",
                "time_stamp_group",
                "AVERAGE_max_multiplier",
                "cdb_count_avg",
                "AVERAGE",
            ]
        ]
    )
    df0.columns = [
        "cdb_cohort",
        "cdb",
        "cdb_target_guid",
        "metric",
        "summary_of",
        "time_stamp_group",
        "AVERAGE_max_multiplier",
        "cdb_count_avg_max",
        "cdb_count_avg_sum",
        "peak",
        "sum_metric_x_hrs",
    ]

    df0 = pd.merge(
        left=df0,
        right=cdbInstanceCountsDf[["cdb_target_guid", "cdb_type", "instance_count"]],
        how="left",
        left_on="cdb_target_guid",
        right_on="cdb_target_guid",
    )
    df0 = pd.merge(
        left=df0,
        right=hrsDf,
        how="left",
        left_on=["cdb_target_guid", "metric"],
        right_on=["cdb_target_guid", "metric"],
    )

    df0 = df0[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "peak",
            "sum_metric_x_hrs",
            "hrs",
            "time_stamp_group",
            "AVERAGE_max_multiplier",
            "cdb_count_avg_max",
            "cdb_target_guid",
        ]
    ]
    df0.rename(columns={"cdb_count_avg_max": "cdb_count_avg"}, inplace=True)

    if len(DEBUG_CDB) > 0:
        filename = sizingFilePath + os.sep + "debug_cdb.df0." + ln() + ".csv"
        df0[df0["cdb"].isin(DEBUG_CDB)].sort_values(["cdb"]).to_csv(
            filename, index=False
        )

    if WRITE_DEBUG_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + "time_Group_Aligned_Avg.cdb_cohort.df0."
            + ln()
            + ".csv"
        )
        df0.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    # ---
    #
    #   Select the row with the largest multiplier
    #
    df = timeGroupAlignedAvgDf[
        (timeGroupAlignedAvgDf["summary_of"] == "cdb_cohort")
        & (
            timeGroupAlignedAvgDf["AVERAGE_max_multiplier"]
            == timeGroupAlignedAvgDf["AVERAGE_max_multiplier_group_max"]
        )
    ].copy()
    #
    #   This is needed just in case more than one metric has the maximum multiplier
    #
    df["time_stamp_group_min"] = df.groupby(["cdb_cohort", "metric"])[
        "time_stamp_group"
    ].transform("min")
    df = df[df["time_stamp_group"] == df["time_stamp_group_min"]]

    hrsDf = df.groupby(["cdb_cohort", "metric"], as_index=False)[
        "ROLLUP_TIMESTAMP_UTC"
    ].nunique()
    hrsDf.columns = ["cdb_cohort", "metric", "hrs"]
    hrsDf.loc[
        hrsDf["metric"].isin([STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]), "hrs"
    ] = (hrsDf["hrs"] * 24)

    df1 = (
        df.groupby(
            [
                "cdb_cohort",
                "metric",
                "summary_of",
                "time_stamp_group",
                "AVERAGE_max_multiplier",
            ],
            as_index=False,
        )[["cdb_count_avg", "AVERAGE"]]
        .agg(["max", "sum"])
        .reset_index()[
            [
                "cdb_cohort",
                "metric",
                "summary_of",
                "time_stamp_group",
                "AVERAGE_max_multiplier",
                "cdb_count_avg",
                "AVERAGE",
            ]
        ]
    )

    if WRITE_DEBUG_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + "time_Group_Aligned_Avg.cdb_cohort.df1."
            + ln()
            + ".csv"
        )
        df1.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df1.columns = [
        "cdb_cohort",
        "metric",
        "summary_of",
        "time_stamp_group",
        "AVERAGE_max_multiplier",
        "cdb_count_avg_max",
        "cdb_count_avg_sum",
        "peak",
        "sum_metric_x_hrs",
    ]

    if WRITE_DEBUG_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + "time_Group_Aligned_Avg.cdb_cohort.df1."
            + ln()
            + ".csv"
        )
        df1.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df1 = pd.merge(
        left=df1,
        right=cdbCohortInstanceCountsDf,
        how="left",
        left_on="cdb_cohort",
        right_on="cdb_cohort",
    )
    df1 = pd.merge(
        left=df1,
        right=hrsDf,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )

    df1["cdb"] = "All"
    df1["cdb_type"] = "All"
    df1["cdb_target_guid"] = "All"

    df1 = df1[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "peak",
            "sum_metric_x_hrs",
            "hrs",
            "time_stamp_group",
            "AVERAGE_max_multiplier",
            "cdb_count_avg_max",
            "cdb_target_guid",
        ]
    ]
    df1.rename(columns={"cdb_count_avg_max": "cdb_count_avg"}, inplace=True)

    if WRITE_DEBUG_FILES:
        filename = (
            sizingFilePath
            + os.sep
            + "time_Group_Aligned_Avg.cdb_cohort.df1."
            + ln()
            + ".csv"
        )
        df1.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    adjustedValuesDf = pd.concat([df0, df1])
    adjustedValuesDf["cdb_count_avg"] = round(
        adjustedValuesDf["cdb_count_avg"], PRECISION
    )

    df0, df1 = [], []

# ---

if len(adjustedValuesDf) > 0:
    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "adjusted_Values." + ln() + ".csv"
        adjustedValuesDf.sort_values(
            ["summary_of", "cdb", "cdb_cohort", "metric"],
            ascending=[False, True, True, True],
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)
    #
    #   Get the multiplier for CPU & IOPs -- it is the multiplier we will use for the standby metrics
    #
    df0 = adjustedValuesDf[
        (adjustedValuesDf["metric"].isin([CPU_DERIVED_METRIC, IOPS_METRIC]))
        & (adjustedValuesDf["summary_of"] == "cdb")
    ][
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "time_stamp_group",
            "AVERAGE_max_multiplier",
            "cdb_count_avg",
            "cdb_target_guid",
        ]
    ]

    df0.loc[df0["metric"] == CPU_DERIVED_METRIC, "metric"] = CPU_DERIVED_METRIC_STANDBY
    df0.loc[df0["metric"] == IOPS_METRIC, "metric"] = IOPS_METRIC_STANDBY

    df1 = cdbHourlyMetricsDf[
        cdbHourlyMetricsDf["metric"].isin(
            [CPU_DERIVED_METRIC_STANDBY, IOPS_METRIC_STANDBY]
        )
    ][["cdb", "metric", "AVERAGE"]]
    df1 = (
        df1.groupby(["cdb", "metric"], as_index=False)["AVERAGE"]
        .agg(["max", "sum", "count"])
        .reset_index()
    )
    df1 = df1.rename(columns={"max": "peak", "sum": "sum_metric_x_hrs", "count": "hrs"})

    df0 = pd.merge(
        left=df0,
        right=df1,
        how="left",
        left_on=["cdb", "metric"],
        right_on=["cdb", "metric"],
    )
    df0["peak"] = df0["peak"] * df0["AVERAGE_max_multiplier"]
    df0["sum_metric_x_hrs"] = df0["sum_metric_x_hrs"] * df0["AVERAGE_max_multiplier"]

    df0 = df0[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "peak",
            "sum_metric_x_hrs",
            "hrs",
            "time_stamp_group",
            "AVERAGE_max_multiplier",
            "cdb_count_avg",
            "cdb_target_guid",
        ]
    ]

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "adjusted_Values.df0." + ln() + ".csv"
        df0.sort_values(
            ["summary_of", "cdb", "cdb_cohort", "metric"],
            ascending=[False, True, True, True],
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    adjustedValuesDf = pd.concat([adjustedValuesDf, df0], ignore_index=True)

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "adjusted_Values." + ln() + ".csv"
        adjustedValuesDf.sort_values(
            ["summary_of", "cdb", "cdb_cohort", "metric"],
            ascending=[False, True, True, True],
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    #   --------------------------------------------------------------------------------------------------------------------
    #
    #   Repeat the process for cohort-level rollups
    #
    #   Get the cohort multiplier for CPU & IOPs -- it is the multiplier we will use for the standby metrics
    #
    df0 = adjustedValuesDf[
        (adjustedValuesDf["metric"].isin([CPU_DERIVED_METRIC, IOPS_METRIC]))
        & (adjustedValuesDf["summary_of"] == "cdb_cohort")
    ][
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "time_stamp_group",
            "AVERAGE_max_multiplier",
            "cdb_count_avg",
            "cdb_target_guid",
        ]
    ]

    df0.loc[df0["metric"] == CPU_DERIVED_METRIC, "metric"] = CPU_DERIVED_METRIC_STANDBY
    df0.loc[df0["metric"] == IOPS_METRIC, "metric"] = IOPS_METRIC_STANDBY

    df1 = cdbCohortHourlyMetricsDf[
        cdbCohortHourlyMetricsDf["metric"].isin(
            [CPU_DERIVED_METRIC_STANDBY, IOPS_METRIC_STANDBY]
        )
    ][["cdb_cohort", "metric", "AVERAGE"]]
    df1 = (
        df1.groupby(["cdb_cohort", "metric"], as_index=False)["AVERAGE"]
        .agg(["max", "sum", "count"])
        .reset_index()
    )
    df1 = df1.rename(columns={"max": "peak", "sum": "sum_metric_x_hrs", "count": "hrs"})

    df0 = pd.merge(
        left=df0,
        right=df1,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )
    df0["peak"] = df0["peak"] * df0["AVERAGE_max_multiplier"]
    df0["sum_metric_x_hrs"] = df0["sum_metric_x_hrs"] * df0["AVERAGE_max_multiplier"]

    df0 = df0[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "summary_of",
            "peak",
            "sum_metric_x_hrs",
            "hrs",
            "time_stamp_group",
            "AVERAGE_max_multiplier",
            "cdb_count_avg",
            "cdb_target_guid",
        ]
    ]

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "adjusted_Values.df0." + ln() + ".csv"
        df0.sort_values(
            ["summary_of", "cdb", "cdb_cohort", "metric"],
            ascending=[False, True, True, True],
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    adjustedValuesDf = pd.concat([adjustedValuesDf, df0], ignore_index=True)

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "adjusted_Values." + ln() + ".csv"
        adjustedValuesDf.sort_values(
            ["summary_of", "cdb", "cdb_cohort", "metric"],
            ascending=[False, True, True, True],
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    df0, df1 = [], []

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if WRITE_DEBUG_FILES:
    if len(cdbCohortDailyAdjustmentsDf) > 0:
        filename = (
            sizingFilePath + os.sep + "cdb_Cohort_Daily_Adjustments." + ln() + ".csv"
        )
        cdbCohortDailyAdjustmentsDf.sort_values(
            ["cdb_cohort", "metric", "time_stamp_group"]
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    if len(cdbHourlyMetricsPeaksDf) > 0:
        filename = sizingFilePath + os.sep + "cdb_Hourly_Metrics_Peaks." + ln() + ".csv"
        cdbHourlyMetricsPeaksDf.sort_values(["cdb_cohort", "metric"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

adjusted_path = Path(outputFilePath) / "plots" / "adjusted"
if Path.is_dir(adjusted_path):
    lg(f"    Deleting existing directory : {adjusted_path}")
    shutil.rmtree(adjusted_path, ignore_errors=True)
if len(cdbCohortDailyAdjustmentsDf) > 0 and (PLOT_HTML or PLOT_PNG):
    # 444
    plotAdjustments(
        cdbCohortDailyAdjustmentsDf,
        cdbHourlyMetricsPeaksDf,
        cdbDailyAdjustmentsDf,
        cdb_hourly_metrics_peak_db_df,
    )
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")
    _ = 0

computeStatistics(adjusted=False)

# ---

hrsDf = cdbHourlyMetricsDf.groupby("cdb_target_guid", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_target_guid", "hrs"]

if len(DEBUG_CDB) > 0:
    filename = sizingFilePath + os.sep + "debug_cdb.cdb_hourly_metrics." + ln() + ".csv"
    cdbHourlyMetricsDf[cdbHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
        ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)

df = cdbHourlyMetricsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
    as_index=False,
)["AVERAGE"].sum()
df0 = (
    df.groupby(["cdb_cohort", "cdb", "cdb_target_guid", "metric"], as_index=False)[
        "AVERAGE"
    ]
    .agg(["max", "sum"])
    .reset_index()
)
df0 = df0.rename(columns={"max": "peak", "sum": "sum_metric_x_hrs"})

df0 = pd.merge(
    left=df0,
    right=cdbInstanceCountsDf[["cdb_target_guid", "cdb_type", "instance_count"]],
    how="left",
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
)
df0 = pd.merge(
    left=df0,
    right=hrsDf,
    how="left",
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
)

df0["summary_of"] = "cdb"

if len(DEBUG_CDB) > 0:
    filename = sizingFilePath + os.sep + "debug_cdb.df0." + ln() + ".csv"
    df0[df0["cdb"].isin(DEBUG_CDB)].sort_values(["cdb", "metric"]).to_csv(
        filename, index=False
    )

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = df0.copy()

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "final." + ln() + ".csv"
    finalDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

hrsDf = cdbHourlyStorageMetricsDf.groupby("cdb_target_guid", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_target_guid", "hrs"]

df = cdbHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"],
    as_index=False,
)["AVERAGE"].sum()
df0 = (
    df.groupby(["cdb_cohort", "cdb", "cdb_target_guid", "metric"], as_index=False)[
        "AVERAGE"
    ]
    .agg(["max", "sum"])
    .reset_index()
)
df0 = df0.rename(columns={"max": "peak", "sum": "sum_metric_x_hrs"})

df0 = pd.merge(
    left=df0,
    right=cdbInstanceCountsDf[["cdb_target_guid", "cdb_type", "instance_count"]],
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
    how="left",
)
df0 = pd.merge(
    left=df0,
    right=hrsDf,
    how="left",
    left_on="cdb_target_guid",
    right_on="cdb_target_guid",
)

df0["summary_of"] = "cdb"
#
# Storage metrics are captured at the daily level
#
df0["hrs"] *= 24
df0["sum_metric_x_hrs"] *= 24

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = pd.concat([finalDf, df0])

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "final." + ln() + ".csv"
    finalDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

df = cdbCohortHourlyMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)["AVERAGE"].sum()

hrsDf = cdbCohortHourlyMetricsDf.groupby("cdb_cohort", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_cohort", "hrs"]

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "cdb_Cohort_Hourly_Metrics." + ln() + ".csv"
    cdbCohortHourlyMetricsDf.sort_values(
        ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"]
    ).to_csv(filename, index=False)
    lg("\nWrote file " + filename)

    filename = sizingFilePath + os.sep + "hrs." + ln() + ".csv"
    hrsDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

df0 = (
    df.groupby(["cdb_cohort", "metric"], as_index=False)["AVERAGE"]
    .agg(["max", "sum"])
    .reset_index()
)
df0 = df0.rename(columns={"max": "peak", "sum": "sum_metric_x_hrs"})

df0 = pd.merge(
    left=df0,
    right=cdbCohortInstanceCountsDf,
    how="left",
    left_on="cdb_cohort",
    right_on="cdb_cohort",
)
df0 = pd.merge(
    left=df0, right=hrsDf, how="left", left_on="cdb_cohort", right_on="cdb_cohort"
)

df0["cdb"] = "All"
df0["cdb_type"] = "All"
df0["cdb_target_guid"] = "All"
df0["summary_of"] = "cdb_cohort"

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = pd.concat([finalDf, df0])

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "final." + ln() + ".csv"
    finalDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

df = cdbCohortHourlyStorageMetricsDf.groupby(
    ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
)["AVERAGE"].sum()

hrsDf = cdbCohortHourlyStorageMetricsDf.groupby("cdb_cohort", as_index=False)[
    "ROLLUP_TIMESTAMP_UTC"
].nunique()
hrsDf.columns = ["cdb_cohort", "hrs"]

df0 = (
    df.groupby(["cdb_cohort", "metric"], as_index=False)["AVERAGE"]
    .agg(["max", "sum"])
    .reset_index()
)
df0 = df0.rename(columns={"max": "peak", "sum": "sum_metric_x_hrs"})

df0 = pd.merge(
    left=df0,
    right=cdbCohortInstanceCountsDf,
    left_on="cdb_cohort",
    right_on="cdb_cohort",
    how="left",
)
df0 = pd.merge(
    left=df0, right=hrsDf, how="left", left_on="cdb_cohort", right_on="cdb_cohort"
)

df0["cdb"] = "All"
df0["cdb_type"] = "All"
df0["cdb_target_guid"] = "All"
df0["summary_of"] = "cdb_cohort"
#
# Storage metrics are captured at the daily level
#
df0["hrs"] *= 24
df0["sum_metric_x_hrs"] *= 24

df0 = df0[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "summary_of",
        "peak",
        "sum_metric_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf = pd.concat([finalDf, df0])

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "final." + ln() + ".csv"
    finalDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---

finalDf["adjusted"] = 0
finalDf["sum_peak_x_hrs"] = finalDf["peak"] * finalDf["hrs"]
finalDf["sum_peak_x_hrs_m_sum_metric_x_hrs"] = (
    finalDf["sum_peak_x_hrs"] - finalDf["sum_metric_x_hrs"]
)
finalDf["sum_metric_x_hrs_o_sum_peak_x_hrs"] = (
    finalDf["sum_metric_x_hrs"] / finalDf["sum_peak_x_hrs"]
)
finalDf.loc[finalDf["sum_peak_x_hrs"] == 0, "sum_metric_x_hrs_o_sum_peak_x_hrs"] = 1

# ---

if len(adjustedValuesDf) > 0:
    adjustedValuesDf["adjusted"] = 1
    adjustedValuesDf["sum_peak_x_hrs"] = (
        adjustedValuesDf["peak"] * adjustedValuesDf["hrs"]
    )
    adjustedValuesDf["sum_peak_x_hrs_m_sum_metric_x_hrs"] = (
        adjustedValuesDf["sum_peak_x_hrs"] - adjustedValuesDf["sum_metric_x_hrs"]
    )
    adjustedValuesDf["sum_metric_x_hrs_o_sum_peak_x_hrs"] = (
        adjustedValuesDf["sum_metric_x_hrs"] / adjustedValuesDf["sum_peak_x_hrs"]
    )
    adjustedValuesDf.loc[
        adjustedValuesDf["sum_peak_x_hrs"] == 0, "sum_metric_x_hrs_o_sum_peak_x_hrs"
    ] = 1

    adjustedValuesDf = adjustedValuesDf[
        [
            "cdb_cohort",
            "cdb",
            "cdb_type",
            "instance_count",
            "metric",
            "adjusted",
            "summary_of",
            "peak",
            "sum_peak_x_hrs",
            "sum_metric_x_hrs",
            "sum_peak_x_hrs_m_sum_metric_x_hrs",
            "sum_metric_x_hrs_o_sum_peak_x_hrs",
            "hrs",
            "cdb_target_guid",
        ]
    ]

    finalDf = pd.concat([finalDf, adjustedValuesDf])

    if WRITE_DEBUG_FILES:
        filename = sizingFilePath + os.sep + "adjusted_Values." + ln() + ".csv"
        adjustedValuesDf.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

        filename = sizingFilePath + os.sep + "final." + ln() + ".csv"
        finalDf.to_csv(filename, index=False)
        lg("\nWrote file " + filename)

# ---

finalDf["peak"] = round(finalDf["peak"], PRECISION)
finalDf["sum_peak_x_hrs"] = round(finalDf["sum_peak_x_hrs"], PRECISION)
finalDf["sum_metric_x_hrs"] = round(finalDf["sum_metric_x_hrs"], PRECISION)
finalDf["sum_peak_x_hrs_m_sum_metric_x_hrs"] = round(
    finalDf["sum_peak_x_hrs_m_sum_metric_x_hrs"], PRECISION
)
finalDf["sum_metric_x_hrs_o_sum_peak_x_hrs"] = round(
    finalDf["sum_metric_x_hrs_o_sum_peak_x_hrs"], PRECISION
)
finalDf["average"] = round(finalDf["sum_metric_x_hrs"] / finalDf["hrs"], PRECISION)

finalDf = finalDf[
    [
        "cdb_cohort",
        "cdb",
        "cdb_type",
        "instance_count",
        "metric",
        "adjusted",
        "summary_of",
        "peak",
        "average",
        "sum_peak_x_hrs",
        "sum_metric_x_hrs",
        "sum_peak_x_hrs_m_sum_metric_x_hrs",
        "sum_metric_x_hrs_o_sum_peak_x_hrs",
        "hrs",
        "cdb_target_guid",
    ]
]

finalDf["cwd"] = cwd
finalDf["platform"] = platformName
finalDf["extract_dttm_utc"] = extract_dttm_utc
finalDf["create_dttm_utc"] = now
finalDf["source"] = SOURCE
finalDf["version"] = __version__

filename = sizingFilePath + os.sep + "sizing.csv"
sizingDf = finalDf.copy()
sizingDf["metric"] = sizingDf["metric"].apply(getMetricAlias)
sizingDf.sort_values(["cdb_cohort", "cdb", "metric", "adjusted", "summary_of"]).to_csv(
    filename, index=False
)
sizingDf = []
lg("\nWrote file " + filename)

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

if len(DEBUG_CDB) > 0:
    filename = sizingFilePath + os.sep + "debug_cdb.cdb_final_values." + ln() + ".csv"
    finalDf[finalDf["cdb"].isin(DEBUG_CDB)].sort_values(["cdb", "adjusted"]).to_csv(
        filename, index=False
    )
    lg("\nWrote file " + filename)

if WRITE_DEBUG_FILES:
    filename = sizingFilePath + os.sep + "TimeGroup_TimeAligned_Avg.csv"
    timeGroupAlignedAvgDf["version"] = __version__
    timeGroupAlignedAvgDf.to_csv(filename, index=False)
    lg("\nWrote file " + filename)

# ---
#
# Produce rollup files
#

databasesDf.loc[databasesDf["excluded"] == "", "excluded"] = "included"

cDf = pd.pivot_table(
    databasesDf,
    index=["cdb_cohort", "cdb"],
    columns="excluded",
    values="cdb_instance_count",
    aggfunc="sum",
    fill_value=0,
).reset_index()

rc = {"cdb_cohort": "Cohort", "cdb": "Name"}

addOrChangeName(cDf, "excluded", "Instances Excluded")
addOrChangeName(cDf, "included", "Instances Included")

cDf.rename(columns=rc, inplace=True)

# ---

pDf = pd.pivot_table(
    finalDf[finalDf["summary_of"] == "cdb"],
    index=["cdb", "adjusted"],
    columns="metric",
    values="peak",
).reset_index()

rc = {"cdb": "Name", "adjusted": "Adjusted Values"}

addOrChangeName(
    pDf, STORAGE_ALLOCATED_METRIC, EMCC_METRIC_COULMN_ALIASES[STORAGE_ALLOCATED_METRIC]
)
addOrChangeName(
    pDf, STORAGE_USED_METRIC, EMCC_METRIC_COULMN_ALIASES[STORAGE_USED_METRIC]
)
addOrChangeName(pDf, CPU_DERIVED_METRIC, EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC])
addOrChangeName(
    pDf,
    CPU_DERIVED_METRIC_STANDBY,
    EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC_STANDBY],
)
addOrChangeName(pDf, PGA_METRIC, EMCC_METRIC_COULMN_ALIASES[PGA_METRIC])
addOrChangeName(pDf, SGA_METRIC, EMCC_METRIC_COULMN_ALIASES[SGA_METRIC])
addOrChangeName(
    pDf, SGAPGA_DERIVED_METRIC, EMCC_METRIC_COULMN_ALIASES[SGAPGA_DERIVED_METRIC]
)
addOrChangeName(pDf, IOPS_METRIC, EMCC_METRIC_COULMN_ALIASES[IOPS_METRIC])
addOrChangeName(
    pDf, IOPS_METRIC_STANDBY, EMCC_METRIC_COULMN_ALIASES[IOPS_METRIC_STANDBY]
)
addOrChangeName(pDf, LOGONS_METRIC, EMCC_METRIC_COULMN_ALIASES[LOGONS_METRIC])

pDf.rename(columns=rc, inplace=True)

# Cast 'Adjusted Values' column to become a string
pDf[["Adjusted Values"]] = pDf[["Adjusted Values"]].astype(str)
pDf.loc[pDf["Adjusted Values"] == "0", "Adjusted Values"] = "N"
pDf.loc[pDf["Adjusted Values"] == "1", "Adjusted Values"] = "Y"

cDf = pd.merge(left=cDf, right=pDf, how="left", left_on="Name", right_on="Name")

# ---

if len(DEBUG_CDB) > 0:
    filename = sizingFilePath + os.sep + "debug_cdb.finalDf." + ln() + ".csv"
    finalDf[finalDf["cdb"].isin(DEBUG_CDB)].sort_values(["cdb", "metric"]).to_csv(
        filename, index=False
    )

pDf = (
    finalDf[finalDf["summary_of"] == "cdb"]
    .groupby(["cdb", "adjusted"], as_index=False)["hrs"]
    .max()
)
pDf.rename(
    columns={"cdb": "Name", "adjusted": "Adjusted Values", "hrs": "Hours"}, inplace=True
)
# Cast 'Adjusted Values' column to become a string
pDf[["Adjusted Values"]] = pDf[["Adjusted Values"]].astype(str)
pDf.loc[pDf["Adjusted Values"] == "0", "Adjusted Values"] = "N"
pDf.loc[pDf["Adjusted Values"] == "1", "Adjusted Values"] = "Y"

cDf = pd.merge(
    left=cDf,
    right=pDf,
    how="left",
    left_on=["Name", "Adjusted Values"],
    right_on=["Name", "Adjusted Values"],
)

# ---

cDf["Rollup Type"] = "AVERAGE"
cDf["Time Unit"] = "HOURLY"
cDf["Time Period"] = 3

cDf = cDf[
    [
        "Cohort",
        "Name",
        "Rollup Type",
        "Time Unit",
        "Time Period",
        "Adjusted Values",
        "Instances Included",
        "Instances Excluded",
        "Hours",
        "Allocated Storage (GB)",
        "Used Storage (GB)",
        "DB vCPU",
        "DB vCPU for Standby",
        "DB PGA (MB)",
        "DB SGA (MB)",
        "DB Memory (MB)",
        "DB IOPS",
        "DB IOPS for Standby",
        "DB Logons",
    ]
]

cDf["cwd"] = cwd
cDf["platform"] = platformName
cDf["extract_dttm_utc"] = extract_dttm_utc
cDf["create_dttm_utc"] = now
cDf["source"] = SOURCE
cDf["version"] = __version__

filename = sizingFilePath + os.sep + "database_rollups.csv"

# Drop from database_rollups.csv cohorts stated in ROLLUP_CSV_FILES_SUPRESSED_COHORTS
for cohort in ROLLUP_CSV_FILES_SUPRESSED_COHORTS:
    cDf = cDf[(cDf.Cohort != cohort)]

cDf.sort_values(["Name", "Adjusted Values"], ascending=[True, False]).to_csv(
    filename, index=False
)
lg("\nWrote file " + filename)
lg("   Excluding cohorts " + ",".join(ROLLUP_CSV_FILES_SUPRESSED_COHORTS))

# ---

cDf = pd.pivot_table(
    databasesDf,
    index="cdb_cohort",
    columns="excluded",
    values=["cdb", "cdb_instance_count"],
    aggfunc={"cdb": "count", "cdb_instance_count": "sum"},
    fill_value=0,
).reset_index()

cDf.columns = [c[0] + c[1] for c in cDf.columns]

rc = {"cdb_cohort": "Name"}

addOrChangeName(cDf, "cdbexcluded", "Databases Excluded")
addOrChangeName(cDf, "cdbincluded", "Databases Included")
addOrChangeName(cDf, "cdb_instance_countexcluded", "Instances Excluded")
addOrChangeName(cDf, "cdb_instance_countincluded", "Instances Included")

cDf.rename(columns=rc, inplace=True)

# ---

pDf = pd.pivot_table(
    finalDf[finalDf["summary_of"] == "cdb_cohort"],
    index=["cdb_cohort", "adjusted"],
    columns="metric",
    values="peak",
).reset_index()

rc = {"cdb_cohort": "Name", "adjusted": "Adjusted Values"}

addOrChangeName(
    pDf, STORAGE_ALLOCATED_METRIC, EMCC_METRIC_COULMN_ALIASES[STORAGE_ALLOCATED_METRIC]
)
addOrChangeName(
    pDf, STORAGE_USED_METRIC, EMCC_METRIC_COULMN_ALIASES[STORAGE_USED_METRIC]
)
addOrChangeName(pDf, CPU_DERIVED_METRIC, EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC])
addOrChangeName(
    pDf,
    CPU_DERIVED_METRIC_STANDBY,
    EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC_STANDBY],
)
addOrChangeName(pDf, PGA_METRIC, EMCC_METRIC_COULMN_ALIASES[PGA_METRIC])
addOrChangeName(pDf, SGA_METRIC, EMCC_METRIC_COULMN_ALIASES[SGA_METRIC])
addOrChangeName(
    pDf, SGAPGA_DERIVED_METRIC, EMCC_METRIC_COULMN_ALIASES[SGAPGA_DERIVED_METRIC]
)
addOrChangeName(pDf, IOPS_METRIC, EMCC_METRIC_COULMN_ALIASES[IOPS_METRIC])
addOrChangeName(
    pDf, IOPS_METRIC_STANDBY, EMCC_METRIC_COULMN_ALIASES[IOPS_METRIC_STANDBY]
)
addOrChangeName(pDf, LOGONS_METRIC, EMCC_METRIC_COULMN_ALIASES[LOGONS_METRIC])

pDf.rename(columns=rc, inplace=True)

# Cast 'Adjusted Values' column to become a string
pDf[["Adjusted Values"]] = pDf[["Adjusted Values"]].astype(str)
pDf.loc[pDf["Adjusted Values"] == "0", "Adjusted Values"] = "N"
pDf.loc[pDf["Adjusted Values"] == "1", "Adjusted Values"] = "Y"

cDf = pd.merge(left=cDf, right=pDf, how="left", left_on="Name", right_on="Name")

# ---

pDf = (
    finalDf[finalDf["summary_of"] == "cdb_cohort"]
    .groupby(["cdb_cohort", "adjusted"], as_index=False)["hrs"]
    .max()
)
pDf.rename(
    columns={"cdb_cohort": "Name", "adjusted": "Adjusted Values", "hrs": "Hours"},
    inplace=True,
)
# Cast 'Adjusted Values' column to become a string
pDf[["Adjusted Values"]] = pDf[["Adjusted Values"]].astype(str)
pDf.loc[pDf["Adjusted Values"] == "0", "Adjusted Values"] = "N"
pDf.loc[pDf["Adjusted Values"] == "1", "Adjusted Values"] = "Y"

cDf = pd.merge(
    left=cDf,
    right=pDf,
    how="left",
    left_on=["Name", "Adjusted Values"],
    right_on=["Name", "Adjusted Values"],
)

# ---

cDf["Rollup Type"] = "AVERAGE"
cDf["Time Unit"] = "HOURLY"
cDf["Time Period"] = 3

cDf = cDf[
    [
        "Name",
        "Rollup Type",
        "Time Unit",
        "Time Period",
        "Adjusted Values",
        "Databases Included",
        "Databases Excluded",
        "Instances Included",
        "Instances Excluded",
        "Hours",
        "Allocated Storage (GB)",
        "Used Storage (GB)",
        "DB vCPU",
        "DB vCPU for Standby",
        "DB PGA (MB)",
        "DB SGA (MB)",
        "DB Memory (MB)",
        "DB IOPS",
        "DB IOPS for Standby",
        "DB Logons",
    ]
]

cDf["cwd"] = cwd
cDf["platform"] = platformName
cDf["extract_dttm_utc"] = extract_dttm_utc
cDf["create_dttm_utc"] = now
cDf["source"] = SOURCE
cDf["version"] = __version__

filename = sizingFilePath + os.sep + "cohort_rollups.csv"

# Drop from cohort_rollups.csv cohorts stated in ROLLUP_CSV_FILES_SUPRESSED_COHORTS
for cohort in ROLLUP_CSV_FILES_SUPRESSED_COHORTS:
    cDf = cDf[(cDf.Name != cohort)]

cDf.sort_values(["Name", "Adjusted Values"], ascending=[True, False]).to_csv(
    filename, index=False
)
lg("\nWrote file " + filename)
lg("   Excluding cohorts " + ",".join(ROLLUP_CSV_FILES_SUPRESSED_COHORTS))
lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

cpuDf = cdbHourlyMetricsDf[cdbHourlyMetricsDf["metric"] == CPU_DERIVED_METRIC][
    ["cdb", "ROLLUP_TIMESTAMP_UTC", "AVERAGE"]
].copy()
aboveCountDf = []
missingDbs = []

if len(cpuDf[["AVERAGE"]] > 0):
    for cpu in range(0, int((cpuDf[["AVERAGE"]].max() + 2).iloc[0])):
        for incr in range(10):
            if cpu > MAX_INTEGER_VCPU - 1 and incr > 0:
                continue

            cpuMin = (cpu * 1.0) + (incr / 10.0)
            cpuDbsDf = dbCPUCountsDf[dbCPUCountsDf["db_cpu_count_limit"] >= cpuMin][
                ["cdb"]
            ]

            if len(cpuDbsDf) == 0:
                break

            if cpuMin == 0:
                lg(
                    "\nCounting core hours for a list of "
                    + str(len(cpuDbsDf))
                    + " databases..."
                )

            countDf = (
                cpuDf[
                    (cpuDf["cdb"].isin(cpuDbsDf["cdb"])) & (cpuDf["AVERAGE"] > cpuMin)
                ]
                .groupby(["cdb"], as_index=False)["AVERAGE"]
                .count()
            )

            if len(countDf) == 0:
                countDf = cpuDbsDf[~cpuDbsDf["cdb"].isin(missingDbs)][["cdb"]].copy()
                if len(countDf) > 0:
                    countDf["AVERAGE"] = 0
            else:
                missingDf = cpuDbsDf[
                    ~cpuDbsDf["cdb"].isin(countDf["cdb"])
                ].drop_duplicates()
                missingDf = missingDf[~missingDf["cdb"].isin(missingDbs)]

                if len(missingDf) > 0:
                    missingDbs += missingDf["cdb"].tolist()
                    missingDf["AVERAGE"] = 0
                    countDf = pd.concat([countDf, missingDf], ignore_index=True)

            if len(countDf) > 0:
                countDf.rename(columns={"cdb": "Name", "AVERAGE": "Hrs"}, inplace=True)
                countDf["GT vCPU Count"] = cpuMin
                aboveCountDf = (
                    countDf
                    if len(aboveCountDf) == 0
                    else pd.concat([aboveCountDf, countDf])
                )

if len(aboveCountDf) > 0:
    aboveCountDf["Adjusted Values"] = "N"
    aboveCountDf["Rollup Type"] = "AVERAGE"
    aboveCountDf["Time Unit"] = "HOURLY"
    aboveCountDf["Time Period"] = 3

    aboveCountDf = aboveCountDf[
        [
            "Name",
            "Rollup Type",
            "Time Unit",
            "Time Period",
            "Adjusted Values",
            "GT vCPU Count",
            "Hrs",
        ]
    ]
    aboveCountDf["cwd"] = cwd
    aboveCountDf["platform"] = platformName
    aboveCountDf["extract_dttm_utc"] = extract_dttm_utc
    aboveCountDf["create_dttm_utc"] = now
    aboveCountDf["source"] = SOURCE
    aboveCountDf["version"] = __version__

    filename = sizingFilePath + os.sep + "database_vcpu_hours.csv"
    aboveCountDf.sort_values(["Name", "Adjusted Values", "GT vCPU Count"]).to_csv(
        filename, index=False
    )

    lg("\nWrote file " + filename)
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

filename = sizingFilePath + os.sep + "adjustments.csv"

if len(cdbCohortDailyAdjustmentsDf) > 0:
    df = pd.concat(
        [cdbDailyAdjustmentsDf, cdbCohortDailyAdjustmentsDf], ignore_index=True
    )
    #
    #   Multipliers for standby metrics are identical to the non-standby metrics
    #
    df1 = df[df["metric"].isin([CPU_DERIVED_METRIC, IOPS_METRIC])].copy()
    df1.loc[df1["metric"] == CPU_DERIVED_METRIC, "metric"] = CPU_DERIVED_METRIC_STANDBY
    df1.loc[df1["metric"] == IOPS_METRIC, "metric"] = IOPS_METRIC_STANDBY

    df = pd.concat([df, df1], ignore_index=True)

    df1 = []

    # ---

    df.drop(
        columns=[
            "days_to_subtract_from_g0",
            "DAILY_AVERAGE_avg",
            "DAILY_AVERAGE_avg_group_0",
            "AVERAGE_avg_multiplier",
        ],
        inplace=True,
    )
    df.rename(columns={"AVERAGE_max_multiplier": "multiplier"}, inplace=True)
    df["cdb_count_avg"] = round(df["cdb_count_avg"], PRECISION)

    df["multiplier"] = round(df["multiplier"], PRECISION)

    df["cwd"] = cwd
    df["platform"] = platformName
    df["extract_dttm_utc"] = extract_dttm_utc
    df["create_dttm_utc"] = now
    df["source"] = SOURCE
    #
    #   The following is needed to get proper column ordering
    #
    if "version" in df:
        df.drop(columns=["version"], inplace=True)
    df["version"] = __version__

    dfTranslatedDf = df.copy()
    dfTranslatedDf["metric"] = dfTranslatedDf["metric"].apply(getMetricAlias)
    dfTranslatedDf.sort_values(
        ["summary_of", "cdb", "cdb_cohort", "metric", "time_stamp_group"],
        ascending=[False, True, True, True, True],
    ).to_csv(filename, index=False)
    dfTranslatedDf = []
    lg("\nWrote file " + filename)
    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")
    #
    #   Use database multiplier for database-level statistics
    #
    cdbHourlyMetricsOriginalDf = cdbHourlyMetricsDf.copy()
    cdbHourlyStorageMetricsOriginalDf = cdbHourlyStorageMetricsDf.copy()

    df0 = (
        df[df["summary_of"] == "cdb"]
        .groupby(["cdb", "metric"], as_index=False)["multiplier"]
        .max()
    )

    cdbHourlyMetricsDf = pd.merge(
        left=cdbHourlyMetricsDf,
        right=df0,
        how="left",
        left_on=["cdb", "metric"],
        right_on=["cdb", "metric"],
    )

    cdbHourlyStorageMetricsDf = pd.merge(
        left=cdbHourlyStorageMetricsDf,
        right=df0,
        how="left",
        left_on=["cdb", "metric"],
        right_on=["cdb", "metric"],
    )

    cdbHourlyMetricsDf["AVERAGE"] *= cdbHourlyMetricsDf["multiplier"]
    cdbHourlyStorageMetricsDf["AVERAGE"] *= cdbHourlyStorageMetricsDf["multiplier"]

    computeStatistics(adjusted=True, which="cdb")

    # ---

    cpuDf = cdbHourlyMetricsDf[cdbHourlyMetricsDf["metric"] == CPU_DERIVED_METRIC][
        ["cdb", "ROLLUP_TIMESTAMP_UTC", "AVERAGE"]
    ].copy()
    aboveCountDf = []
    missingDbs = []

    if len(cpuDf[["AVERAGE"]] > 0) and (cpuDf[["AVERAGE"]].max().iloc[0] > 0):
        for cpu in range(0, int(cpuDf[["AVERAGE"]].max().iloc[0] + 2)):
            for incr in range(10):
                if cpu > MAX_INTEGER_VCPU - 1 and incr > 0:
                    continue

                cpuMin = (cpu * 1.0) + (incr / 10.0)
                cpuDbsDf = dbCPUCountsDf[dbCPUCountsDf["db_cpu_count_limit"] >= cpuMin][
                    ["cdb"]
                ]

                if len(cpuDbsDf) == 0:
                    break

                if cpuMin == 0:
                    lg(
                        "\nCounting adjusted core hours for a list of "
                        + str(len(cpuDbsDf))
                        + " databases..."
                    )

                countDf = (
                    cpuDf[
                        (cpuDf["cdb"].isin(cpuDbsDf["cdb"]))
                        & (cpuDf["AVERAGE"] > cpuMin)
                    ]
                    .groupby(["cdb"], as_index=False)["AVERAGE"]
                    .count()
                )

                if len(countDf) == 0:
                    countDf = cpuDbsDf[~cpuDbsDf["cdb"].isin(missingDbs)][
                        ["cdb"]
                    ].copy()
                    if len(countDf) > 0:
                        countDf["AVERAGE"] = 0
                else:
                    missingDf = cpuDbsDf[
                        ~cpuDbsDf["cdb"].isin(countDf["cdb"])
                    ].drop_duplicates()
                    missingDf = missingDf[~missingDf["cdb"].isin(missingDbs)]

                    if len(missingDf) > 0:
                        missingDbs += missingDf["cdb"].tolist()
                        missingDf["AVERAGE"] = 0
                        countDf = pd.concat([countDf, missingDf], ignore_index=True)

                if len(countDf) > 0:
                    countDf.rename(
                        columns={"cdb": "Name", "AVERAGE": "Hrs"}, inplace=True
                    )
                    countDf["GT vCPU Count"] = cpuMin
                    aboveCountDf = (
                        countDf
                        if len(aboveCountDf) == 0
                        else pd.concat([aboveCountDf, countDf])
                    )

    if len(aboveCountDf) > 0:
        aboveCountDf["Adjusted Values"] = "Y"
        aboveCountDf["Rollup Type"] = "AVERAGE"
        aboveCountDf["Time Unit"] = "HOURLY"
        aboveCountDf["Time Period"] = 3

        aboveCountDf = aboveCountDf[
            [
                "Name",
                "Rollup Type",
                "Time Unit",
                "Time Period",
                "Adjusted Values",
                "GT vCPU Count",
                "Hrs",
            ]
        ]
        aboveCountDf["cwd"] = cwd
        aboveCountDf["platform"] = platformName
        aboveCountDf["extract_dttm_utc"] = extract_dttm_utc
        aboveCountDf["create_dttm_utc"] = now
        aboveCountDf["source"] = SOURCE
        aboveCountDf["version"] = __version__

        filename = sizingFilePath + os.sep + "database_adjusted_vcpu_hours.csv"
        aboveCountDf.sort_values(["Name", "Adjusted Values", "GT vCPU Count"]).to_csv(
            filename, index=False
        )

        lg("\nWrote file " + filename)
        lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    # ---

    f1name = sizingFilePath + os.sep + "database_vcpu_hours.csv"
    f2name = sizingFilePath + os.sep + "database_adjusted_vcpu_hours.csv"

    df1, df2 = [], []

    if os.path.exists(f1name):
        df1 = pd.read_csv(f1name)

    if os.path.exists(f2name):
        df2 = pd.read_csv(f2name)

    if len(df1) > 0 and len(df2) > 0:
        df3 = pd.concat([df1, df2], ignore_index=True)

    elif len(df1) > 0:
        df3 = df1

    elif len(df2) > 0:
        df3 = df2

    else:
        df3 = []

    if len(df3) > 0:
        df3.sort_values(["Name", "Adjusted Values", "GT vCPU Count"]).to_csv(
            f1name, index=False
        )

        lg("\nWrote file " + f1name + " & " + f2name)

    if len(df2) > 0:
        os.remove(f2name)

    df1, df2, df3 = [], [], []

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    # ---

    f1name = sizingFilePath + os.sep + "database_statistics.csv"
    f2name = sizingFilePath + os.sep + "database_adjusted_statistics.csv"

    df1, df2 = [], []

    if os.path.exists(f1name):
        df1 = pd.read_csv(f1name)
    else:
        log(f"\n{f1name} is missing -- continuing")

    if os.path.exists(f2name):
        df2 = pd.read_csv(f2name)
    else:
        log(f"\n{f2name} is missing -- continuing")

    if len(df1) > 0 and len(df2) > 0:
        df3 = pd.concat([df1, df2], ignore_index=True)

        targetsMissingAdjustedValues = df3[
            (df3["count"] == 0) & (df3["adjusted"] == 1)
        ]["cdb_target_guid"].unique()
        # lg('targetsMissingAdjustedValues\n' + str(targetsMissingAdjustedValues))

        if len(targetsMissingAdjustedValues) > 0:
            keepDf = df3[
                (df3["adjusted"] == 0)
                | (~df3["cdb_target_guid"].isin(targetsMissingAdjustedValues))
            ].copy()
            replaceDf = df3[
                (df3["adjusted"] == 0)
                & (df3["cdb_target_guid"].isin(targetsMissingAdjustedValues))
            ].copy()
            replaceDf["adjusted"] = 1

            # printDf('keepDf',    keepDf,    showTail=False)
            # printDf('replaceDf', replaceDf, showTail=False)

            df3 = pd.concat([keepDf, replaceDf], ignore_index=True)

    elif len(def1) > 0:
        df3 = df1

    elif len(df2) > 0:
        df3 = df2

    else:
        df3 = []

    if len(df3) > 0:
        df3["metric"] = df3["metric"].apply(getMetricAlias)
        df3.sort_values(["cdb", "metric", "adjusted"]).to_csv(f1name, index=False)

        lg("\nWrote file " + f1name + " & " + f2name)

    if len(df2) > 0:
        os.remove(f2name)

    df1, df2, df3 = [], [], []

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    #
    #   Use cohort multiplier for cohort-level statistics
    #
    cdbHourlyMetricsDf = cdbHourlyMetricsOriginalDf.copy()
    cdbHourlyStorageMetricsDf = cdbHourlyStorageMetricsOriginalDf.copy()

    DEBUG_ADJUSTMENT_COHORT = ""
    # DEBUG_ADJUSTMENT_COHORT='DC2_Uat'

    df0 = (
        df[df["summary_of"] == "cdb_cohort"]
        .groupby(["cdb_cohort", "metric"], as_index=False)["multiplier"]
        .max()
    )

    cdbHourlyMetricsDf = pd.merge(
        left=cdbHourlyMetricsDf,
        right=df0,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )

    cdbHourlyStorageMetricsDf = pd.merge(
        left=cdbHourlyStorageMetricsDf,
        right=df0,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )

    cdbHourlyMetricsDf["AVERAGE"] *= cdbHourlyMetricsDf["multiplier"]
    cdbHourlyStorageMetricsDf["AVERAGE"] *= cdbHourlyStorageMetricsDf["multiplier"]

    if DEBUG_ADJUSTMENT_COHORT != "":
        filename = sizingFilePath + os.sep + "debug_adjustments." + ln() + ".csv"
        cdbHourlyMetricsDf[
            (cdbHourlyMetricsDf["cdb_cohort"] == DEBUG_ADJUSTMENT_COHORT)
            & (
                cdbHourlyMetricsOriginalDf["metric"].isin(
                    [CPU_DERIVED_METRIC, CPU_DERIVED_METRIC_STANDBY]
                )
            )
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    computeStatistics(adjusted=True, which="cohort")

    # ---

    f1name = sizingFilePath + os.sep + "cohort_statistics.csv"
    f2name = sizingFilePath + os.sep + "cohort_adjusted_statistics.csv"

    df1, df2 = [], []

    if os.path.exists(f1name):
        df1 = pd.read_csv(f1name)

    if os.path.exists(f2name):
        df2 = pd.read_csv(f2name)

    if len(df1) > 0 and len(df2) > 0:
        df3 = pd.concat([df1, df2], ignore_index=True)

    elif len(def1) > 0:
        df3 = df1

    elif len(df2) > 0:
        df3 = df2

    else:
        df3 = []

    if len(df3) > 0:
        df3["metric"] = df3["metric"].apply(getMetricAlias)
        df3.sort_values(["cdb_cohort", "metric", "adjusted"]).to_csv(
            f1name, index=False
        )

        lg("\nWrote file " + f1name + " & " + f2name)

    if len(df2) > 0:
        os.remove(f2name)

    df1, df2, df3 = [], [], []

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    # ---

    if PLOT_HTML or PLOT_PNG:
        # 444

        if len(DEBUG_CDB) > 0:
            filename = (
                sizingFilePath
                + os.sep
                + "debug_cdb.cdb_hourly_metrics."
                + ln()
                + ".csv"
            )
            cdbHourlyMetricsDf[cdbHourlyMetricsDf["cdb"].isin(DEBUG_CDB)].sort_values(
                ["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]
            ).to_csv(filename, index=False)

        _ = 0

        plotMetrics(cdbHourlyMetricsDf, metricType="adjusted")
        plotMetrics(cdbHourlyStorageMetricsDf, metricType="adjusted")

    # ---

    cdbHourlyMetricsDf = cdbHourlyMetricsOriginalDf[
        cdbHourlyMetricsOriginalDf["metric"].isin(
            [CPU_DERIVED_METRIC, CPU_DERIVED_METRIC_STANDBY]
        )
    ].copy()
    cdbHourlyMetricsDf["diff_hrs"] = (
        cdbHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC"]
        - cdbHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC"].min()
    ).dt.total_seconds() / (60 * 60)

    if DEBUG_ADJUSTMENT_COHORT != "":
        filename = sizingFilePath + os.sep + "debug_adjustments." + ln() + ".csv"
        cdbHourlyMetricsDf[
            cdbHourlyMetricsDf["cdb_cohort"] == DEBUG_ADJUSTMENT_COHORT
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    cdbHourlyMetricsDf = cdbHourlyMetricsDf[
        [
            "cdb_cohort",
            "cdb_target_guid",
            "cdb",
            "metric",
            "ROLLUP_TIMESTAMP_UTC",
            "diff_hrs",
            "AVERAGE",
        ]
    ].copy()
    df0 = df[
        (df["summary_of"] == "cdb_cohort")
        & (df["metric"]).isin([CPU_DERIVED_METRIC, CPU_DERIVED_METRIC_STANDBY])
    ][
        [
            "cdb_cohort",
            "metric",
            "time_stamp_group",
            "ROLLUP_TIMESTAMP_min",
            "ROLLUP_TIMESTAMP_max",
            "multiplier",
        ]
    ]

    if DEBUG_ADJUSTMENT_COHORT != "":
        filename = sizingFilePath + os.sep + "debug_adjustments.df0." + ln() + ".csv"
        df0[df0["cdb_cohort"] == DEBUG_ADJUSTMENT_COHORT].sort_values(
            ["cdb_cohort", "metric", "ROLLUP_TIMESTAMP_min"]
        ).to_csv(filename, index=False)
        lg("\nWrote file " + filename)

    cdbHourlyMetricsDf = pd.merge(
        left=cdbHourlyMetricsDf,
        right=df0,
        how="left",
        left_on=["cdb_cohort", "metric"],
        right_on=["cdb_cohort", "metric"],
    )

    cdbHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC_new"] = cdbHourlyMetricsDf[
        "ROLLUP_TIMESTAMP_min"
    ] + pd.to_timedelta(cdbHourlyMetricsDf["diff_hrs"], unit="h")
    cdbHourlyMetricsDf = cdbHourlyMetricsDf[
        cdbHourlyMetricsDf["ROLLUP_TIMESTAMP_UTC_new"]
        < cdbHourlyMetricsDf["ROLLUP_TIMESTAMP_max"]
    ]
    cdbHourlyMetricsDf["AVERAGE_new"] = (
        cdbHourlyMetricsDf["AVERAGE"] * cdbHourlyMetricsDf["multiplier"]
    )

    if DEBUG_ADJUSTMENT_COHORT != "":
        filename = sizingFilePath + os.sep + "debug_adjustments." + ln() + ".csv"
        cdbHourlyMetricsDf[
            cdbHourlyMetricsDf["cdb_cohort"] == DEBUG_ADJUSTMENT_COHORT
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC_new"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    cdbHourlyMetricsDf.drop(columns=["AVERAGE", "ROLLUP_TIMESTAMP_UTC"], inplace=True)
    cdbHourlyMetricsDf.rename(
        columns={
            "AVERAGE_new": "AVERAGE",
            "ROLLUP_TIMESTAMP_UTC_new": "ROLLUP_TIMESTAMP_UTC",
        },
        inplace=True,
    )

    if DEBUG_ADJUSTMENT_COHORT != "":
        filename = sizingFilePath + os.sep + "debug_adjustments." + ln() + ".csv"
        cdbHourlyMetricsDf[
            cdbHourlyMetricsDf["cdb_cohort"] == DEBUG_ADJUSTMENT_COHORT
        ].sort_values(["cdb", "metric", "ROLLUP_TIMESTAMP_UTC"]).to_csv(
            filename, index=False
        )
        lg("\nWrote file " + filename)

    if PLOTS_ADJUSTED_YEARLY_VALUES and (PLOT_HTML or PLOT_PNG):
        # 444
        _ = 0
        plotMetrics(cdbHourlyMetricsDf, metricType="adjusted_yearly")

else:
    if os.path.exists(filename):
        lg("\nAdjustments not computed; removed file " + filename)
        os.remove(filename)

    filename = sizingFilePath + os.sep + "cohort_adjusted_statistics.csv"
    if os.path.exists(filename):
        os.remove(filename)

    filename = sizingFilePath + os.sep + "database_adjusted_statistics.csv"
    if os.path.exists(filename):
        os.remove(filename)

# ----------------------------------------------------------------------------------------------------------------------

Duplicate_Tests.emitDuplicateTestResults(duplicateTestResults, logFile)

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nThe processing of "
    + str(len(structureDf))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
