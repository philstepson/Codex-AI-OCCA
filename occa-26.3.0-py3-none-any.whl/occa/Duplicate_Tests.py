import os
import pandas as pd
from occa_Shared import *
import version

DUPLICATES_PATH = "duplicate_tests"

# ----------------------------------------------------------------------------------------------------------------------


def lg(logFile, t):

    print(t)
    if logFile is not None:
        logFile.write(t + "\n")


# ----------------------------------------------------------------------------------------------------------------------


def duplicateTests(structureDf, callingScript, outputFilePath):
    results = {}

    os.makedirs(outputFilePath + os.sep + DUPLICATES_PATH, exist_ok=True)

    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + ".00.before_duplicate_tests.csv"
    )
    structureDf.to_csv(filename, index=False)

    # ---
    #
    #   The following logic is needed just in case we are creating spreadsheets from a combined file that was produced by
    #   an earlier version of the extracts
    #

    if "cdb_type_version" not in structureDf:
        structureDf["cdb_type_version"] = ""

    if "cluster_last_load_time_utc" not in structureDf:
        structureDf["cluster_last_load_time_utc"] = ""
    if "cluster_owner" not in structureDf:
        structureDf["cluster_owner"] = ""
    if "cluster_status" not in structureDf:
        structureDf["cluster_status"] = ""
    if "cluster_target_guid" not in structureDf:
        structureDf["cluster_target_guid"] = ""

    if "db_owner" not in structureDf:
        structureDf["db_owner"] = ""
    if "db_type" not in structureDf:
        structureDf["db_type"] = ""
    if "db_type_version" not in structureDf:
        structureDf["db_type_version"] = ""

    if "dbmachine_target_guid" not in structureDf:
        structureDf["dbmachine_target_guid"] = ""
    if "dbmachine_type" not in structureDf:
        structureDf["dbmachine_type"] = ""
    if "dbmachine_type_version" not in structureDf:
        structureDf["dbmachine_type_version"] = ""

    if "host_type_version" not in structureDf:
        structureDf["host_type_version"] = ""

    testSeq = 0

    # ---
    #
    #   Handle the case where a cluster is associated with two or more non-NULL dbmachines
    #
    testSeq += 1
    testName = "cluster_gt2_dbmachine"
    testDescription = (
        "This test identifies clusters associated with two or more non-NULL dbmachines"
    )
    testAction = "Cluster removed from dataset"
    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + "."
        + str(testSeq).zfill(2)
        + "."
        + testName
    )

    clusterDBMachineCountsDf = (
        structureDf[structureDf.cluster != "none"][["cluster", "dbmachine"]]
        .drop_duplicates()
        .groupby(["cluster"])
        .count()
        .reset_index()
    )
    clusterDupDBMachinesDf = clusterDBMachineCountsDf[
        clusterDBMachineCountsDf.dbmachine >= 2
    ]

    if len(clusterDupDBMachinesDf) > 0:
        results[testName] = {
            "description": testDescription,
            "count": len(clusterDupDBMachinesDf),
            "action": testAction,
            "before": filename + ".A.before.csv",
        }

        structureDf.to_csv(filename + ".A.before.csv", index=False)

        clusterDBMachinesDf = structureDf[
            (structureDf.cluster.isin(clusterDupDBMachinesDf["cluster"]))
        ][
            [
                "dbmachine",
                "cluster",
                "cluster_owner",
                "cluster_status",
                "cluster_last_load_time_utc",
                "cluster_target_guid",
            ]
        ].drop_duplicates()
        structureDf = structureDf[
            (~structureDf.cluster.isin(clusterDBMachinesDf["cluster"]))
        ]

        clusterDBMachinesDf.to_csv(filename + ".B.clusterDBMachinesDf.csv", index=False)
        structureDf.to_csv(filename + ".C.after.csv", index=False)

        results[testName]["items"] = filename + ".B.clusterDBMachinesDf.csv"
        results[testName]["after"] = filename + ".C.after.csv"

    else:
        if os.path.exists(filename + ".A.before.csv"):
            os.remove(filename + ".A.before.csv")
        if os.path.exists(filename + ".B.hostClustersDf.csv"):
            os.remove(filename + ".B.hostClustersDf.csv")
        if os.path.exists(filename + ".C.after.csv"):
            os.remove(filename + ".C.after.csv")

    # ---
    #
    #    Handle the case where a cluster is assigned to a non-NULL and NULL database machine
    #
    testSeq += 1
    testName = "cluster_dup_dbmachine"
    testDescription = "This test identifies clusters associated with one or more dbmachines, one of which is non-NULL"
    testAction = "dbmachine columns are mapped to not NULL dbmachine"
    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + "."
        + str(testSeq).zfill(2)
        + "."
        + testName
    )

    clusterDBMachineCountsDf = (
        structureDf[structureDf.cluster != "none"][["cluster", "dbmachine"]]
        .drop_duplicates()
        .fillna("none")
        .groupby(["cluster"])
        .count()
        .reset_index()
    )
    clusterDupDBMachinesDf = clusterDBMachineCountsDf[
        clusterDBMachineCountsDf.dbmachine > 1
    ]

    if len(clusterDupDBMachinesDf) > 0:
        results[testName] = {
            "description": testDescription,
            "count": len(clusterDupDBMachinesDf),
            "action": testAction,
            "before": filename + ".A.before.csv",
        }

        structureDf.to_csv(filename + ".A.before.csv", index=False)

        clusterDBMachinesDf = structureDf[
            (structureDf.cluster.isin(clusterDupDBMachinesDf["cluster"]))
            & (structureDf.cluster != "none")
            & (structureDf.dbmachine != "none")
        ][
            [
                "cluster",
                "dbmachine",
                "dbmachine_owner",
                "dbmachine_type",
                "dbmachine_type_version",
                "dbmachine_target_guid",
            ]
        ].drop_duplicates()
        clusterDBMachinesDf = clusterDBMachinesDf.fillna(value="none")

        clusterDBMachinesDf.columns = [
            "cluster",
            "dbmachine_n",
            "dbmachine_owner_n",
            "dbmachine_type_n",
            "dbmachine_type_version_n",
            "dbmachine_target_guid_n",
        ]
        clusterDBMachinesDf = clusterDBMachinesDf[
            (clusterDBMachinesDf.dbmachine_n != "none")
        ]

        structureDf = pd.merge(
            left=structureDf,
            right=clusterDBMachinesDf,
            how="left",
            left_on="cluster",
            right_on="cluster",
        )

        structureDf["dbmachine"] = structureDf["dbmachine_n"].fillna(
            structureDf.dbmachine
        )
        structureDf["dbmachine_owner"] = structureDf["dbmachine_owner_n"].fillna(
            structureDf.dbmachine_owner
        )
        structureDf["dbmachine_type"] = structureDf["dbmachine_type_n"].fillna(
            structureDf.dbmachine_type
        )
        structureDf["dbmachine_type_version"] = structureDf[
            "dbmachine_type_version_n"
        ].fillna(structureDf.dbmachine_type_version)
        structureDf["dbmachine_target_guid"] = structureDf[
            "dbmachine_target_guid_n"
        ].fillna(structureDf.dbmachine_target_guid)

        structureDf = structureDf.drop(
            [
                "dbmachine_n",
                "dbmachine_owner_n",
                "dbmachine_type_n",
                "dbmachine_type_version_n",
                "dbmachine_target_guid_n",
            ],
            axis=1,
        ).drop_duplicates()

        clusterDBMachinesDf.to_csv(filename + ".B.clusterDBMachinesDf.csv", index=False)
        structureDf.to_csv(filename + ".C.after.csv", index=False)

        results[testName]["items"] = filename + ".B.clusterDBMachinesDf.csv"
        results[testName]["after"] = filename + ".C.after.csv"

    else:
        if os.path.exists(filename + ".A.before.csv"):
            os.remove(filename + ".A.before.csv")
        if os.path.exists(filename + ".B.clusterDBMachinesDf.csv"):
            os.remove(filename + ".B.clusterDBMachinesDf.csv")
        if os.path.exists(filename + ".C.after.csv"):
            os.remove(filename + ".C.after.csv")

    # ---
    #
    #   Handle the case where a host is associated with more than two non-NULL clusters
    #
    testSeq += 1
    testName = "host_gt2_cluster"
    testDescription = (
        "This test identifies hosts associated with two or more non-NULL clusters"
    )
    testAction = "Host removed from dataset"
    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + "."
        + str(testSeq).zfill(2)
        + "."
        + testName
    )

    hostClusterCountsDf = (
        structureDf[structureDf.cluster != "none"][["host", "cluster"]]
        .drop_duplicates()
        .groupby(["host"])
        .count()
        .reset_index()
    )
    hostDupClustersDf = hostClusterCountsDf[hostClusterCountsDf.cluster > 2]

    if len(hostDupClustersDf) > 0:
        results[testName] = {
            "description": testDescription,
            "count": len(hostDupClustersDf),
            "action": testAction,
            "before": filename + ".A.before.csv",
        }

        structureDf.to_csv(filename + ".A.before.csv", index=False)

        hostClustersDf = structureDf[
            (structureDf.host.isin(hostDupClustersDf["host"]))
        ][
            [
                "host",
                "cluster",
                "cluster_owner",
                "cluster_status",
                "cluster_last_load_time_utc",
                "cluster_target_guid",
            ]
        ].drop_duplicates()
        structureDf = structureDf[(~structureDf.host.isin(hostClustersDf["host"]))]

        hostClustersDf.to_csv(filename + ".B.hostClustersDf.csv", index=False)
        structureDf.to_csv(filename + ".C.after.csv", index=False)

        results[testName]["items"] = filename + ".B.hostClustersDf.csv"
        results[testName]["after"] = filename + ".C.after.csv"

    else:
        if os.path.exists(filename + ".A.before.csv"):
            os.remove(filename + ".A.before.csv")
        if os.path.exists(filename + ".B.hostClustersDf.csv"):
            os.remove(filename + ".B.hostClustersDf.csv")
        if os.path.exists(filename + ".C.after.csv"):
            os.remove(filename + ".C.after.csv")

    # ---
    #
    #    Handle the case where a host might have both clustered databases AND standalone databases
    #
    testSeq += 1
    testName = "host_dup_cluster"
    testDescription = "This test identifies hosts associated with two or more clusters, one of which is none"
    testAction = "cluster column mapped to non-none cluster"
    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + "."
        + str(testSeq).zfill(2)
        + "."
        + testName
    )

    hostClusterCountsDf = (
        structureDf[["host", "cluster"]]
        .drop_duplicates()
        .groupby(["host"])
        .count()
        .reset_index()
    )
    hostDupClustersDf = hostClusterCountsDf[hostClusterCountsDf.cluster > 1]

    if len(hostDupClustersDf) > 0:
        results[testName] = {
            "description": testDescription,
            "count": len(hostDupClustersDf),
            "action": testAction,
            "before": filename + ".A.before.csv",
        }

        structureDf.to_csv(filename + ".A.before.csv", index=False)

        hostClustersDf = structureDf[
            (structureDf.host.isin(hostDupClustersDf["host"]))
            & (structureDf.cluster != "none")
        ][
            [
                "host",
                "cluster",
                "cluster_owner",
                "cluster_status",
                "cluster_last_load_time_utc",
                "cluster_target_guid",
            ]
        ].drop_duplicates()
        hostClustersDf = hostClustersDf.fillna(value="none")

        hostClustersDf.columns = [
            "host",
            "cluster_n",
            "cluster_owner_n",
            "cluster_status_n",
            "cluster_last_load_time_utc_n",
            "cluster_target_guid_n",
        ]
        hostClustersDf = hostClustersDf[(hostClustersDf.cluster_n != "none")]

        structureDf = pd.merge(
            left=structureDf,
            right=hostClustersDf,
            how="left",
            left_on="host",
            right_on="host",
        )

        structureDf["cluster"] = structureDf["cluster_n"].fillna(structureDf.cluster)
        structureDf["cluster_owner"] = structureDf["cluster_owner_n"].fillna(
            structureDf.cluster_owner
        )
        structureDf["cluster_status"] = structureDf["cluster_status_n"].fillna(
            structureDf.cluster_status
        )
        structureDf["cluster_last_load_time_utc"] = structureDf[
            "cluster_last_load_time_utc_n"
        ].fillna(structureDf.cluster_last_load_time_utc)

        structureDf = structureDf.drop(
            [
                "cluster_n",
                "cluster_owner_n",
                "cluster_status_n",
                "cluster_last_load_time_utc_n",
                "cluster_target_guid_n",
            ],
            axis=1,
        ).drop_duplicates()

        hostClustersDf.to_csv(filename + ".B.hostClustersDf.csv", index=False)
        structureDf.to_csv(filename + ".C.after.csv", index=False)

        results[testName]["items"] = filename + ".B.hostClustersDf.csv"
        results[testName]["after"] = filename + ".C.after.csv"

    else:
        if os.path.exists(filename + ".A.before.csv"):
            os.remove(filename + ".A.before.csv")
        if os.path.exists(filename + ".B.hostClustersDf.csv"):
            os.remove(filename + ".B.hostClustersDf.csv")
        if os.path.exists(filename + ".C.after.csv"):
            os.remove(filename + ".C.after.csv")

    # ---
    #
    #   Handle the case where a host is associated with two or more non-NULL dbmachines
    #
    testSeq += 1
    testName = "host_gt2_dbmachine"
    testDescription = (
        "This test identifies hosts associated with two or more non-NULL dbmachines"
    )
    testAction = "Host removed from dataset"
    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + "."
        + str(testSeq).zfill(2)
        + "."
        + testName
    )

    hostDBMachineCountsDf = (
        structureDf[["host", "dbmachine"]]
        .drop_duplicates()
        .groupby(["host"])
        .count()
        .reset_index()
    )
    hostDupDBMachinesDf = hostDBMachineCountsDf[hostDBMachineCountsDf.dbmachine > 1]

    if len(hostDupDBMachinesDf) > 0:
        results[testName] = {
            "description": testDescription,
            "count": len(hostDupDBMachinesDf),
            "action": testAction,
            "before": filename + ".A.before.csv",
        }

        structureDf.to_csv(filename + ".A.before.csv", index=False)

        hostDBMachinesDf = structureDf[
            (structureDf.host.isin(hostDupDBMachinesDf["host"]))
        ][
            [
                "host",
                "dbmachine",
                "dbmachine_type_version",
                "dbmachine_type",
                "dbmachine_owner",
                "dbmachine_target_guid",
            ]
        ].drop_duplicates()
        structureDf = structureDf[(~structureDf.host.isin(hostDupDBMachinesDf["host"]))]

        hostDBMachinesDf.to_csv(filename + ".B.hostDBMachinesDf.csv", index=False)
        structureDf.to_csv(filename + ".C.after.csv", index=False)

        results[testName]["items"] = filename + ".B.hostDBMachinesDf.csv"
        results[testName]["after"] = filename + ".C.after.csv"

    else:
        if os.path.exists(filename + ".A.before.csv"):
            os.remove(filename + ".A.before.csv")
        if os.path.exists(filename + ".B.hostDBMachinesDf.csv"):
            os.remove(filename + ".B.hostDBMachinesDf.csv")
        if os.path.exists(filename + ".C.after.csv"):
            os.remove(filename + ".C.after.csv")

    # ---
    #
    #   Handle the case where a host might have both clustered databases on a dbmachine AND standalone databases that are not
    #
    testSeq += 1
    testName = "host_dup_dbmachine"
    testDescription = "This test identifies hosts associated with two or more dbmachines, one of which is NULL"
    testAction = "dbmachine column mapped to non-NULL dbmachine"
    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + "."
        + str(testSeq).zfill(2)
        + "."
        + testName
    )

    hostDBMachineCountsDf = (
        structureDf[["host", "dbmachine"]]
        .fillna(value="none")
        .drop_duplicates()
        .groupby(["host"])
        .count()
        .reset_index()
    )
    hostDupDBMachinesDf = hostDBMachineCountsDf[hostDBMachineCountsDf.dbmachine > 1]

    if len(hostDupDBMachinesDf) > 0:
        results[testName] = {
            "description": testDescription,
            "count": len(hostDupDBMachinesDf),
            "action": testAction,
            "before": filename + ".A.before.csv",
        }

        structureDf.to_csv(filename + ".A.before.csv", index=False)

        hostDBMachinesDf = structureDf[
            (structureDf.host.isin(hostDupDBMachinesDf["host"]))
            & (structureDf.dbmachine != "none")
        ][
            [
                "host",
                "dbmachine",
                "dbmachine_type_version",
                "dbmachine_type",
                "dbmachine_owner",
                "dbmachine_target_guid",
            ]
        ].drop_duplicates()
        hostDBMachinesDf = hostDBMachinesDf.fillna(value="none")

        hostDBMachinesDf.columns = [
            "host",
            "dbmachine_n",
            "dbmachine_type_version_n",
            "dbmachine_type_n",
            "dbmachine_owner_n",
            "dbmachine_target_guid_n",
        ]
        hostDBMachinesDf = hostDBMachinesDf[(hostDBMachinesDf.dbmachine_n != "none")]

        structureDf = pd.merge(
            left=structureDf,
            right=hostDBMachinesDf,
            how="left",
            left_on="host",
            right_on="host",
        )

        structureDf["dbmachine"] = structureDf["dbmachine_n"].fillna(
            structureDf.dbmachine
        )
        structureDf["dbmachine_type_version"] = structureDf[
            "dbmachine_type_version_n"
        ].fillna(structureDf.dbmachine_type_version)
        structureDf["dbmachine_type"] = structureDf["dbmachine_type_n"].fillna(
            structureDf.dbmachine_type
        )
        structureDf["dbmachine_owner"] = structureDf["dbmachine_owner_n"].fillna(
            structureDf.dbmachine_owner
        )
        structureDf["dbmachine_target_guid"] = structureDf[
            "dbmachine_target_guid_n"
        ].fillna(structureDf.dbmachine_target_guid)

        structureDf = structureDf.drop(
            [
                "dbmachine_n",
                "dbmachine_type_version_n",
                "dbmachine_type_n",
                "dbmachine_owner_n",
                "dbmachine_target_guid_n",
            ],
            axis=1,
        ).drop_duplicates()

        hostDBMachinesDf.to_csv(filename + ".B.hostDBMachinesDf.csv", index=False)
        structureDf.to_csv(filename + ".C.after.csv", index=False)

        results[testName]["items"] = filename + ".B.hostDBMachinesDf.csv"
        results[testName]["after"] = filename + ".C.after.csv"

    else:
        if os.path.exists(filename + ".A.before.csv"):
            os.remove(filename + ".A.before.csv")
        if os.path.exists(filename + ".B.hostDBMachinesDf.csv"):
            os.remove(filename + ".B.hostDBMachinesDf.csv")
        if os.path.exists(filename + ".C.after.csv"):
            os.remove(filename + ".C.after.csv")

    # ---
    #
    #   Handle the case where a database is placed on two or more hosts
    #
    testSeq += 1
    testName = "duplicated_placements"
    testDescription = "This test identifies a database placed on two or more hosts"
    testAction = "Placement removed from dataset"
    filename = (
        outputFilePath
        + os.sep
        + DUPLICATES_PATH
        + os.sep
        + callingScript
        + "."
        + str(testSeq).zfill(2)
        + "."
        + testName
    )

    dbCountsDf = structureDf.groupby("db_target_guid")["db"].agg("count").reset_index()
    dbDupDf = dbCountsDf[dbCountsDf["db"] > 1]["db_target_guid"].drop_duplicates()

    if len(dbDupDf) > 0:
        results[testName] = {
            "description": testDescription,
            "count": len(dbDupDf),
            "action": testAction,
            "before": filename + ".A.before.csv",
        }

        structureDf.to_csv(filename + ".A.before.csv", index=False)

        dbsDf = structureDf[structureDf["db_target_guid"].isin(dbDupDf)][
            [
                "db",
                "dbmachine",
                "cluster",
                "cdb",
                "host",
                "db_target_guid",
                "dbmachine_target_guid",
                "cluster_target_guid",
                "cdb_target_guid",
                "host_target_guid",
            ]
        ].drop_duplicates()

        structureDf = structureDf[~structureDf["db_target_guid"].isin(dbDupDf)]

        dbsDf.to_csv(filename + ".B.dbsDf.csv", index=False)
        structureDf.to_csv(filename + ".C.after.csv", index=False)

        results[testName]["items"] = filename + ".B.dbsDf.csv"
        results[testName]["after"] = filename + ".C.after.csv"

    else:
        if os.path.exists(filename + ".A.before.csv"):
            os.remove(filename + ".A.before.csv")
        if os.path.exists(filename + ".B.dbsDf.csv"):
            os.remove(filename + ".B.dbsDf.csv")
        if os.path.exists(filename + ".C.after.csv"):
            os.remove(filename + ".C.after.csv")

    # ---

    if len(results) > 0:
        filename = (
            outputFilePath
            + os.sep
            + DUPLICATES_PATH
            + os.sep
            + callingScript
            + ".99.after_duplicate_tests.csv"
        )
        structureDf.to_csv(filename, index=False)

    else:
        os.remove(
            outputFilePath
            + os.sep
            + DUPLICATES_PATH
            + os.sep
            + callingScript
            + ".00.before_duplicate_tests.csv"
        )

    # ---

    return results, structureDf


# ----------------------------------------------------------------------------------------------------------------------


def emitDuplicateTestResults(duplicateTestResults, logFile=None):
    for d in duplicateTestResults:
        lg(
            logFile,
            "\n***********************************************************************************************",
        )
        lg(logFile, "")
        lg(logFile, "Test Name           : " + d)
        lg(logFile, "Description         : " + duplicateTestResults[d]["description"])
        lg(logFile, "")
        lg(
            logFile,
            "Action Taken        : "
            + duplicateTestResults[d]["action"]
            + " for "
            + str(duplicateTestResults[d]["count"])
            + " rows",
        )
        lg(logFile, "")
        lg(logFile, "Before file         : " + duplicateTestResults[d]["before"])
        lg(logFile, "Items file          : " + duplicateTestResults[d]["items"])
        lg(logFile, "After file          : " + duplicateTestResults[d]["after"])
        lg(
            logFile,
            "\n***********************************************************************************************",
        )
