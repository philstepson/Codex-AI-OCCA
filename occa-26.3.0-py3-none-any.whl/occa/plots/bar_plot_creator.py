import plotly.express as px

from plots.plot_factory_base import PlotBase


class BarPlotCreator(PlotBase):
    """Class for creating bar plots."""

    def __init__(self, **kwargs):
        super().__init__()
        # self.x_column = "ROLLUP_TIMESTAMP_max"
        self.load_args(**kwargs)

    def create_plot(self, data_df, x_column, y_column, **plot_args):
        """Create a bar plot."""
        fig = px.bar(data_df, x=x_column, y=y_column, **plot_args)
        return fig
