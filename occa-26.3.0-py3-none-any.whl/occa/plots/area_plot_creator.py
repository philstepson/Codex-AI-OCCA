import pandas as pd
import plotly.express as px
from plotly.graph_objs import Figure

from plots.plot_factory_base import PlotBase


class AreaPlotCreator(PlotBase):
    """Class for creating area plots."""

    def __init__(self, **kwargs):
        super().__init__()
        # So far all area plots has in common these vars
        self.x_column = "ROLLUP_TIMESTAMP_UTC"
        self.y_column = "AVERAGE"
        self.color = "cdb"
        self.load_args(**kwargs)

    def create_plot(self, df: pd.DataFrame = None, **plot_args) -> Figure:
        """Create an area plot.
        Args:
            df: pd.DataFrame
            **plot_args: Any

        Returns:
            PlotlyFigure
        """
        df_to_use = df if df is not None else self.df_to_plot
        fig = px.area(df_to_use,
                      x=self.x_column,
                      y=self.y_column,
                      color=self.color,
                      title=self.title,
                      width=self.width,
                      height=self.height,
                      template=self.template,
                      **plot_args)
        return fig
