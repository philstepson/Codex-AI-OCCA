from plots.plot_factory_base import PlotBase


def build_title(plot_object: PlotBase, **kwargs):
    """
    Constructs the title using the arguments provided in kwargs.

    Args:
        plot_object : PlotBase
        **kwargs: Key-value arguments used to construct the title.
            It should contain the following fields:
                - plot_object : PlotBase
                - **kwargs

    Returns:
        title : str
    """
    customer = plot_object.get("customer")
    cohort = plot_object.get("cohort")
    data_frequency = plot_object.get("data_frequency")

    metric_type = kwargs.get("metric_type").title()
    metric_title = kwargs.get("metric_title")
    chart_version = kwargs.get("__version__")

    title = f"{customer}: {cohort} {data_frequency} Average {metric_type} {metric_title} (Chart Version {chart_version})"
    return title


def build_subtitle(plot_creator: PlotBase, **kwargs):
    """
    Constructs the subtitle using the arguments provided in kwargs.

    Args:
        plot_creator : PlotBase
        **kwargs: Key-value arguments used to construct the subtitle.
            It could contain the following fields:
                - 'cb_count': int: Number of databases.
                - 'sum_of_max': float.
                - 'peak': float: Peak.
                - 'p95': float
                - 'p90': float
                - 'p80': float
                - 'average': float
                - 'hrs': int
                - 'uom': str: Unit of measurement.

    Returns:
        str: The constructed subtitle.
    """

    cdb_count = kwargs.get('cdb_count', 0)
    sum_of_max = kwargs.get('sum_of_max')
    peak = kwargs.get('peak')

    average = kwargs.get('average')
    hrs = kwargs.get('hrs')
    uom = kwargs.get('uom')

    # Construct the subtitle
    subtitle_parts = []

    if cdb_count > plot_creator.plot_instance_count_limit:
        subtitle_parts.append(f"(Top {plot_creator.plot_instance_count_limit} of {cdb_count} database(s) shown)")
    else:
        subtitle_parts.append(f"({cdb_count} database(s) shown)")

    if plot_creator.plot_sum_of_max:
        subtitle_parts.append(f"Sum(Max)={sum_of_max:,} (dashed black)")

    subtitle_parts.append(f"Peak={peak: ,} (solid red)")

    if plot_creator.plot_percentiles:
        p95 = kwargs.get('p95')
        p90 = kwargs.get('p90')
        p80 = kwargs.get('p80')
        subtitle_parts.append(f"95, 90, 80={p95:,}, {p90:,}, {p80:,} (dotted blue)")

    subtitle_parts.append(f"Average={average:,} (solid green), Hrs={hrs:,}")

    if uom == 'vCPU':
        subtitle_parts.append(", 1 OCPU = 2 vCPU")

    subtitle = ', '.join(subtitle_parts)
    return subtitle


def format_title(title, subtitle=None, subtitle_font_size=14):
    title = f'<b>{title}</b>'

    if not subtitle:
        return title

    subtitle = f'<span style="font-size: {subtitle_font_size}px;">{subtitle}</span>'

    return f'{title}<br>{subtitle}'
