from pathlib import Path

import pandas as pd
from plotly.graph_objs import Figure

from constants.Paths import FilePaths
from file_manager.FileSystemHandler import DirectoryHandler
from occa_Shared import lg
from plots.plot_factory_base import PlotBase


def valid_metric_type(metric_type):
    """
    Validate the metric type.

    Args:
        metric_type (str): Type of metrics to plot.

    Returns:
        bool: True if the metric type is valid, False otherwise.
    """
    valid_metric_types = ["adjusted", "adjusted_yearly", "unadjusted"]
    if metric_type not in valid_metric_types:
        lg(f"Unknown value for metricType: {metric_type}")
        lg(f"Valid metric types: {valid_metric_types}")
        return False
    return True


def calculate_percentiles(plot_object: PlotBase, time_aligned_df: pd.DataFrame):
    """
    Calculate and return percentiles.

    Args:
        plot_object : PlotBase
        time_aligned_df (pd.DataFrame)

    Returns:
        Dict[str, float]: A dictionary containing the calculated percentiles.
    """
    statistics = time_aligned_df["AVERAGE"].describe(percentiles=[0.80, 0.90, 0.95])
    percentiles = {
        "p80":round(statistics["80%"], plot_object.precision),
        "p90":round(statistics["90%"], plot_object.precision),
        "p95":round(statistics["95%"], plot_object.precision)
    }
    return percentiles


def add_percentile_lines(plot_object: PlotBase, fig: Figure, percentiles) -> None:
    """
    Add percentile lines to the plot.

    Args:
        plot_object : PlotBase
        fig : PlotlyFigure
        percentiles : Dict[str, float]
    """
    if plot_object.plot_percentiles:
        fig.add_hline(y=percentiles["p80"], line_width=3, line_color="blue", line_dash="dot")
        fig.add_hline(y=percentiles["p90"], line_width=3, line_color="blue", line_dash="dot")
        fig.add_hline(y=percentiles["p95"], line_width=3, line_color="blue", line_dash="dot")


def update_fig_data(fig: Figure):
    """
    Update figure data with custom attributes.

    Args:
        fig: PlotlyFigure
    """
    for index in range(len(fig.data)):
        cdb = fig.data[index].name
        if not cdb: continue
        cdb = cdb[cdb.find("$$$") + 3:]
        fig.data[index].name = cdb
        fig.data[index].legendgroup = cdb
        fig.data[index].hovertemplate = cdb


def save_plots(plot_object: PlotBase, fig: Figure, dashboard, file_name_png: str) -> int:
    """
    Save plots as HTML and/or PNG files and return the number of plots saved.

    Args:
        - fig: Plotly Figure object.
        - plot_object: AreaPlotCreator object.
        - dashboard: File
        - filenamePNG: str

    Returns:
        int
    """
    plot_counter = 0
    if plot_object.plot_html:
        save_plot_as_html(fig, dashboard)
        plot_counter += 1
        dashboard.close()

    if plot_object.plot_png:
        save_plot_as_png(fig, file_name_png)
        plot_counter += 1

    return plot_counter


def save_plot_as_html(fig: Figure, dashboard) -> None:
    """
    Save plot as HTML file.

    Args:
        - fig: Figure
        - dashboard: File

    Returns:
        None
    """
    inner_html = fig.to_html(include_plotlyjs=True).split("<body>")[1].split("</body>")[0]
    dashboard.write(inner_html)
    dashboard.write("</body></html>\n")


def save_plot_as_png(fig: Figure, file_name_png: str) -> None:
    """
    Save plot as PNG file.

    Args:
        - fig: Figure
        - filenamePNG: str
    Returns:
        None
    """
    fig.write_image(file_name_png)


def create_files(plot_object, folder_path: Path, cohort: str,
                 metric_title: str, metric_type: str, customer: str, version: int):
    """
        Create HTML and PNG files.

        Args:
            plot_object : PlotBase
            folder_path: Path
            cohort: str
            metric_title: str
            metric_type: str
            customer: str
            version : int

        Returns:
            Tuple[FileIO, str]
        """
    file_name_prefix = f"{cohort}_{metric_title.replace(' ', '_')}_{metric_type}"
    filename_png = ""
    dashboard = ""
    if plot_object.plot_html:
        filename_html = folder_path.joinpath(cohort, "html", f"{file_name_prefix}.html")
        dashboard = open(filename_html, "w", encoding="UTF-8")
        html_head = f"{customer}: {cohort}, {plot_object.data_frequency} Average {metric_title} (occa_Run_Metric_Analysis, Chart Version {version})"
        dashboard.write(f"<html><head><title>{html_head}</title></head><body>\n")
    if plot_object.plot_png:
        filename_png = folder_path.joinpath(cohort, "png", f"{file_name_prefix}.png")

    return dashboard, filename_png


def create_output_directories(plot_object: PlotBase, folder_path: Path, cohort_as_str: str) -> None:
    """
        Create HTML and PNG directories if necessary.

        Args:
            plot_object: PlotBase object.
            folder_path: str
            cohort_as_str: str

        Returns:
            None
        """
    if plot_object.plot_html:
        file_path_html = folder_path.joinpath(cohort_as_str, "html")
        DirectoryHandler.make_directories(file_path_html)
    if plot_object.plot_png:
        file_path_png = folder_path.joinpath(cohort_as_str, "png")
        DirectoryHandler.make_directories(file_path_png)


def prepare_folder_path(plot_object: PlotBase, metric_type: str) -> Path:
    if metric_type == "unadjusted" and plot_object.is_daily:
        folder_path = FilePaths.plotFilePath / f"{plot_object.data_frequency}{metric_type.title()}"
    else:
        folder_path = FilePaths.plotFilePath / metric_type

    return folder_path


import os
import json
from plotly.io import to_json


@staticmethod
def serialize_plots(plots_per_cohort: dict, output_file: str, remove: bool = False):
    """

    Help to serialize plots Generated on the fly converted and appended on json to
    later insert into tables

    Parameters
    ----------
    plots_per_cohort dict : plots info
    remove :  first call needs to remove the file | other calls append to it

    Returns
    -------

    """
    print('Serializing plots'.center(50, '-'))

    if os.path.exists(output_file) and not remove:
        with open(output_file, "r") as f:
            existing_data = json.load(f)
    else:
        existing_data = {}

    for cohort, metrics in plots_per_cohort.items():
        if cohort not in existing_data:
            existing_data[cohort] = {}

        for metric_type, plot_info in metrics.items():
            plots = plot_info["figures"]
            cohort_name = plot_info["COHORT_NAME"]
            index_start = 0

            if metric_type not in existing_data[cohort]:
                existing_data[cohort][metric_type] = []
            else:
                index_start = len(existing_data[cohort][metric_type])
            new_figures = [
                {"page":idx + index_start, "fig":to_json(p["fig"]), "COHORT_NAME":cohort_name}
                for idx, p in enumerate(plots)
            ]

            existing_data[cohort][metric_type].extend(new_figures)

        print(f"EM Serverside Added {len(new_figures)} plots under {cohort} / {metric_type}".center(50, '-'))

    with open(output_file, "w") as f:
        json.dump(existing_data, f)

    print(f'Plots saved in -> {output_file}'.center(50, '-'))
