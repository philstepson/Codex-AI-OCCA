import functools
from abc import ABC, abstractmethod

import pandas as pd


class PlotBase(ABC):
    """Abstract class for creating plots."""

    def __init__(self):
        self._DEFAULT_VALUES = {
            "width":1920,
            "height":1185,

            "data_frequency":"Hourly",
            "precision":3,
            "template":"seaborn",
            "size":16,  # Font size
            "title":"PlotBase : Default Title",

            "plot_sum_of_max":False,
            "plot_percentiles":True,
            "plot_instance_count_limit":50,
            "plot_html":True,
            "plot_png":False,
            "plot_suppressed_cohorts":["excluded", "unassigned"],

            "erase_existing_plots": True
        }
        self._load_default_properties()

    @abstractmethod
    def create_plot(self, df_to_plot, x_column, y_column, **args):
        """Abstract method to create a plot."""
        pass

    def _load_default_properties(self):
        """Load default properties."""
        for prop_name, default_value in self._DEFAULT_VALUES.items():
            setattr(self, prop_name, default_value)

    def load_args(self, **kwargs):
        """Load arguments into the _DEFAULT_VALUES."""
        for key, value in kwargs.items():
            # if key not in self._DEFAULT_VALUES:
            self._DEFAULT_VALUES[key] = value
            setattr(self, key, value)

    @property
    def is_daily(self) -> bool:
        """Check if data frequency is daily."""
        return self.data_frequency == "Daily"

    @property
    def is_hourly(self) -> bool:
        """Check if data frequency is hourly."""
        return self.data_frequency == "Hourly"

    def _format_attributes(self):
        """Format attributes for string representation."""
        instance_attributes = []
        for prop in self._DEFAULT_VALUES:
            value = getattr(self, prop)
            if isinstance(value, pd.DataFrame):
                instance_attributes.append(f"{prop}=DataFrame {value.shape} columns: [{','.join(value.columns)}]")
            elif value is None:
                instance_attributes.append(f"{prop}=None")
            else:
                instance_attributes.append(f"{prop}={repr(value)}")
        return ", ".join(instance_attributes)

    def __str__(self):
        """String representation of the object."""
        return self._format_attributes()

    def __repr__(self):
        """Representation of the object."""
        return self._format_attributes()

    def __setattr__(self, name, value):
        """Set attribute value."""
        if not name.startswith("_"):  # We don"t need to show the "private" vars
            self._DEFAULT_VALUES[name] = value

        super().__setattr__(name, value)

    def __getitem__(self, key):
        return getattr(self, key, None)

    def get(self, key, default=None):
        return getattr(self, key, default)
