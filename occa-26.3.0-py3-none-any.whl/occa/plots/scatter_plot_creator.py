import plotly.express as px

from plots.plot_factory_base import PlotBase


class ScatterPlotCreator(PlotBase):
    """Class for creating scatter plots."""

    def __init__(self, **kwargs):
        super().__init__()
        self.load_args(**kwargs)

    def create_plot(self, data_df, x_column, y_column, **plot_args):
        """Create a scatter plot."""
        fig = px.scatter(data_df, x=x_column, y=y_column, **plot_args)
        return fig
