__version__ = '1.34' #Run metrics analysis

import os
import shutil
import time

import plotly.graph_objs as go

from occa_Shared import *
from plots.area_plot_creator import AreaPlotCreator
from plots.description_builder import build_title, build_subtitle, format_title
from plots.plot_utils import *


class MetricPlotBuilder:
    """
    Class responsible for building specific METRIC-AREA plots

    """

    @staticmethod
    def plot_metrics(plot_object: AreaPlotCreator, metric_type: str = "unadjusted"):
        """
        Method to plot EMCC metrics.

        Args:
            plot_object (AreaPlotCreator): An instance of AreaPlotCreator for creating area plots.
            metric_type (str, optional): Type of metrics to plot. Defaults to "unadjusted".

        Returns:
            None

        #Commented lines can be used in future or when extended to awr
        """

        startTime = time.time()

        df = plot_object.df
        if not valid_metric_type(metric_type): return

        lg(f"\nBeginning {metric_type} metric plots...time since start {round(time.time() - startTime, 3)} s")

        folder_path = prepare_folder_path(plot_object, metric_type)
        if Path.is_dir(Path(folder_path)):
            if plot_object.erase_existing_plots:
                lg(f'    Deleting existing directory : {folder_path}')
                shutil.rmtree(folder_path, ignore_errors=True)
        else:
            DirectoryHandler.make_directories(folder_path)
        if plot_object.is_daily:
            metric_type = metric_type.title()

        customer = os.getcwd().split(os.sep)[-1]
        plots_per_cohort = {}
        for cohort in sorted(df.cdb_cohort.unique()):
            figs = []

            cohort_as_str = str(cohort)
            if cohort in plot_object.plot_suppressed_cohorts:
                lg(f"Skipping plot suppressed cohort {cohort}...")
                continue
            plot_object.load_args(customer=customer, cohort=cohort_as_str)
            lg(f"Beginning cohort {cohort}...time since start {round(time.time() - startTime, 3)} s")

            cdb_count = len(df[df["cdb_cohort"] == cohort]["cdb"].unique())

            if cdb_count > plot_object.plot_instance_count_limit:
                lg(f"{cohort}'s instance count {cdb_count} exceeds limit {plot_object.plot_instance_count_limit} set by parameter PLOT_INSTANCE_COUNT_LIMIT; plotting top databases only")

            tb = time.time()

            create_output_directories(plot_object, folder_path, cohort_as_str)

            plot_counter = 0

            for metric in sorted(df.metric.unique()):
                aDf = df[(df["cdb_cohort"] == cohort)&(df["metric"] == metric)].copy()

                if len(aDf) == 0:
                    lg(f"Skipping 0-length cohort: {cohort}, metric: {metric}")
                    continue

                metric_title = EMCC_METRIC_COULMN_ALIASES.get(metric, f"Unknown: {metric}")
                uom = EMCC_METRIC_COULMN_UOMS.get(metric, f"Unknown: {metric}")
                aDf["metric"] = metric_title

                lg(f"Beginning plot for metric {metric_title.ljust(40)}; time since start {round(time.time() - startTime, 3)} s")

                dashboard, filenamePNG = create_files(plot_object, folder_path, cohort_as_str, metric_title,
                                                      metric_type,
                                                      customer, __version__)

                maxDf = aDf.groupby(["cdb_target_guid"], as_index=False)["AVERAGE"].max()
                timeAlignedDf = aDf.groupby(["ROLLUP_TIMESTAMP_UTC"], as_index=False)["AVERAGE"].sum()

                peak = round(timeAlignedDf["AVERAGE"].max(), plot_object.precision)
                sum_of_max = round(maxDf["AVERAGE"].sum(), plot_object.precision)

                timeAlignedDf["MAX"] = peak
                timeAlignedDf["DIFF"] = peak - timeAlignedDf["AVERAGE"]

                percentiles = calculate_percentiles(plot_object, timeAlignedDf)

                hrs = len(timeAlignedDf)
                # sum_peak_x_hrs = round(timeAlignedDf["MAX"].sum(), plot_object.precision)
                sum_metric_x_hrs = round(timeAlignedDf["AVERAGE"].sum(), plot_object.precision)
                # sumOfDiff = round(timeAlignedDf["DIFF"].sum(), plot_object.precision)

                average = round(sum_metric_x_hrs / hrs, plot_object.precision)

                aDf["total"] = aDf.groupby(["cdb"])["AVERAGE"].transform("sum")
                aDf["rank"] = aDf["total"].rank(method="dense").astype(str)
                aDf["sort"] = aDf["rank"].str.zfill(5) + "$$$" + aDf["cdb"]

                aDf.rename(columns={"cdb":" cdb_original", "sort":"cdb"}, inplace=True)

                if metric in [STORAGE_ALLOCATED_METRIC, STORAGE_USED_METRIC]:
                    hrs *= hrs
                    # sum_peak_x_hrs = round(sum_peak_x_hrs * 24, plot_object.precision)
                    # sum_metric_x_hrs = round(sum_metric_x_hrs * 24, plot_object.precision)
                    # sumOfDiff = round(sumOfDiff * 24, plot_object.precision)

                aDf.sort_values(["cdb", "ROLLUP_TIMESTAMP_UTC"], ascending=[False, True], inplace=True)

                if cdb_count > plot_object.plot_instance_count_limit:
                    aDf = aDf[aDf["cdb"].isin(
                        sorted(aDf["cdb"].unique(), reverse=True)[:plot_object.plot_instance_count_limit])]

                title_data = {
                    "metric_type":metric_type,
                    "metric_title":metric_title,
                    "__version__":__version__
                }
                subtitle_data = {
                    "cdb_count":cdb_count,
                    "sum_of_max":sum_of_max,
                    "peak":peak,
                    "average":average,
                    "hrs":hrs,
                    "uom":uom
                }

                title = build_title(plot_object, **title_data)
                subtitle = build_subtitle(plot_object, **subtitle_data, **percentiles)

                formatted_title = format_title(title, subtitle)

                labels = {"ROLLUP_TIMESTAMP_UTC":"Date (UTC)", "AVERAGE":uom, **percentiles}

                plot_object.load_args(df_to_plot=aDf, title=formatted_title, **labels)
                fig = plot_object.create_plot()

                fig.add_trace(
                    go.Scatter(x=timeAlignedDf["ROLLUP_TIMESTAMP_UTC"], y=timeAlignedDf["AVERAGE"], mode="lines",
                               line=dict(color="black", width=6)))

                if plot_object.plot_sum_of_max:
                    fig.add_hline(y=sum_of_max, line_width=3, line_color="black", line_dash="dash")
                    fig.update_layout(yaxis_range=[0, sum_of_max * 1.1])
                else:
                    fig.update_layout(yaxis_range=[0, peak * 1.1])

                fig.add_hline(y=peak, line_width=3, line_color="red")
                fig.add_hline(y=average, line_width=10, line_color="green")

                add_percentile_lines(plot_object, fig, percentiles)

                fig.update_layout(legend_font_size=12, autosize=False, margin=dict(t=150))

                update_fig_data(fig)

                plot_counter += save_plots(plot_object, fig, dashboard, filenamePNG)
                figs.append({"page":plot_counter, "fig":fig})
            lg(f"     Created {plot_counter} plots for {cohort} in directories rooted at {FilePaths.plotFilePath} in {round(time.time() - tb, 3)} s\n")

            plots_per_cohort[cohort] = {metric_type.lower():{"figures":figs, "COHORT_NAME":cohort}}

        # os.environ["RUN_FROM_API"] = "True"
        if os.getenv("RUN_FROM_API", "False") == "True":
            root_user_folder = os.getcwd()
            print('root_user_folder -> ',root_user_folder)
            plots_file_path = os.path.join(root_user_folder, "plots.json")
            serialize_plots(plots_per_cohort, plots_file_path,remove=plot_object.erase_existing_plots)