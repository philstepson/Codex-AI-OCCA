import re

from plots.area_plot_creator import AreaPlotCreator
from plots.bar_plot_creator import BarPlotCreator
from plots.line_plot_creator import LinePlotCreator
from plots.scatter_plot_creator import ScatterPlotCreator


class PlotFactory:
    @staticmethod
    def create_plot(plot_type, **kwargs):
        """Create a plot of the specified type."""
        if re.match(r'bar', plot_type, re.IGNORECASE):
            return BarPlotCreator(**kwargs)
        elif re.match(r'line', plot_type, re.IGNORECASE):
            return LinePlotCreator(**kwargs)
        elif re.match(r'scatter', plot_type, re.IGNORECASE):
            return ScatterPlotCreator(**kwargs)
        elif re.match(r'area', plot_type, re.IGNORECASE):
            return AreaPlotCreator(**kwargs)
        else:
            raise ValueError("Unsupported plot type")
