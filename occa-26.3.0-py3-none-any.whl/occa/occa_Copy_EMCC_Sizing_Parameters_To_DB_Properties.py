import argparse
import datetime
import os
import numpy as np
import pandas as pd
import platform
import sys
import time
from version import version, __version__

from occa_Shared import *

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Copy_EMCC_Sizing_Parameters_To_DB_Properties.py",
    description="Copies emcc_sizing_properties to the occa property files",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="'Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="'Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + " version: " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
#
# Values for these parameters will be read from the parameter file
#

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------

emccFilePath = ROOT_DIR + os.sep + "emcc_sizing_output"
emccPropertiesPath = ROOT_DIR + os.sep + "emcc_sizing_properties"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
propertiesFilePath = ROOT_DIR + os.sep + "occa_sizing_properties"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("numpy.__version__ : " + np.__version__)
lg("pandas.__version__: " + pd.__version__)

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

# ----------------------------------------------------------------------------------------------------------------------

cwd = os.getcwd().split(os.sep)[-1]
startTime = time.time()
fileTS = (
    datetime.datetime.strftime(
        datetime.datetime.now(datetime.timezone.utc), "%Y%m%d_%H%M%S"
    )
    + "_UTC"
)

lg(
    "Copying properties from files in "
    + emccFilePath
    + " to files in "
    + propertiesFilePath
    + "..."
)

if not os.path.exists(emccFilePath):
    lg("Directory " + emccFilePath + " is missing; cannot continue")

    quit()


# ---

emccFilename = emccFilePath + os.sep + "emcc_sizing_structure_db_combined.csv"

if not os.path.exists(emccFilename):
    lg(
        "File "
        + emccFilename
        + " is missing; please be sure to run <<emcc_src_dir>>/Create_Property_Files.py before running this script"
    )

    quit()

try:
    emccStructureDf = pd.read_csv(emccFilename)
except Exception as fc:
    lg_cannotReadCSVFile(emccFilename, fc)
    quit()

if len(emccStructureDf) == 0:
    lg("File " + emccStructureDf + " is empty; cannot contunue")
    quit()

emccStructureDf.columns = [c.strip() for c in emccStructureDf.columns]

# ---

if "cdb_target_guid" not in emccStructureDf:
    lg(
        "File "
        + emccFilename
        + ' is missing column "cdb_target_guid"; unable to continue'
    )
    quit()

# ---

propertyFilename = propertiesFilePath + os.sep + "properties_database.csv"

if not os.path.exists(propertyFilename):
    lg(
        "File "
        + propertyFilename
        + " is missing; please be sure to run occa_Create_Property_Files.py before running this script"
    )

    quit()

try:
    dbPropsDf = pd.read_csv(propertyFilename)
except Exception as fc:
    lg_cannotReadCSVFile(propertyFilename, fc)
    quit()

dbPropsDf.columns = [c.strip() for c in dbPropsDf.columns]

if "target_guid" not in dbPropsDf:
    if (
        "cdb_target_guid" in dbPropsDf
    ):  # needed just in case they have copied the AUDIT spreadsheet to properties
        dbPropsDf.rename(columns={"cdb_target_guid": "target_guid"}, inplace=True)
    else:
        lg(
            "File "
            + propertyFilename
            + ' is missing column "target_guid"; unable to continue'
        )
        quit()

# ---

len0 = len(dbPropsDf)

if len0 == 0:
    lg("File " + propertyFilename + " is empty; cannot contunue")
    quit()

# ---

cdbsDf = emccStructureDf[
    [
        "cdb_target_guid",
        "cdb_environment",
        "cdb_size_allocated_ovr",
        "cdb_size_used_ovr",
    ]
].drop_duplicates()
cdbsDf = cdbsDf[
    (cdbsDf["cdb_environment"].notnull())
    | (cdbsDf["cdb_size_allocated_ovr"].notnull())
    | (cdbsDf["cdb_size_used_ovr"].notnull())
]

if len(cdbsDf) == 0:
    lg("\nNo override values for databases were set in file " + emccFilename)
    lg("Check file " + emccPropertiesPath + os.sep + "properties_databases.csv")

else:
    cdbsDf.columns = [
        "cdb_target_guid",
        "cdb_environment_new",
        "allocated_new",
        "used_new",
    ]

    dbPropsDf = pd.merge(
        left=dbPropsDf,
        right=cdbsDf,
        how="left",
        left_on="target_guid",
        right_on="cdb_target_guid",
    )

    dbPropsDf.loc[dbPropsDf["cdb_environment_new"].notnull(), "Cohort"] = dbPropsDf[
        "cdb_environment_new"
    ]
    dbPropsDf.loc[
        dbPropsDf["allocated_new"].notnull(), "Allocated Database Size (GB)"
    ] = dbPropsDf["allocated_new"]
    dbPropsDf.loc[dbPropsDf["used_new"].notnull(), "Total Database Size (GB)"] = (
        dbPropsDf["used_new"]
    )

    dbPropsDf.drop(
        columns=["cdb_target_guid", "cdb_environment_new", "allocated_new", "used_new"],
        inplace=True,
    )

    os.rename(propertyFilename, propertyFilename.rstrip(".csv") + "." + fileTS + ".csv")
    dbPropsDf.sort_values(["Database Name"]).to_csv(propertyFilename, index=False)

    lg("\nCopied properties for " + str(len(cdbsDf)) + " databases")

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nThe processing of "
    + str(len(dbPropsDf))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
