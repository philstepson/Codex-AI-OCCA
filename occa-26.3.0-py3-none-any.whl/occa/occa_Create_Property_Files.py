import argparse
import datetime
import os
import numpy as np
import pandas as pd
import platform
import sys
import time

import Duplicate_Tests
from occa_Shared import *
from occa_storage import read_csv, to_csv
from version import version, __version__

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Create_Property_Files.py",
    description="Create property files needed for occa sizing",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="'Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="'Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + " version: " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
# Values for these parameters will be read from the parameter file
#

FIXED = False

# ----------------------------------------------------------------------------------------------------------------------

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------
if os.environ.get("RUN_FROM_API", "False") == "True":
    ROOT_DIR = os.getcwd()
extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
propertiesFilePath = ROOT_DIR + os.sep + "occa_sizing_properties"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("numpy.__version__ : " + np.__version__)
lg("pandas.__version__: " + pd.__version__)

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n=======================================================================================================\n"
)

lg("FIXED: " + str(FIXED))

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

if not os.path.exists(extractFilePath):
    lg("Directory " + extractFilePath + " is missing; cannot continue")

    quit()

structureFilename = extractFilePath + os.sep + "emcc_sizing_structure_db.csv"

if not os.path.exists(structureFilename):
    lg("File " + structureFilename + " is missing; cannot continue")

    quit()

os.makedirs(propertiesFilePath, exist_ok=True)

# ----------------------------------------------------------------------------------------------------------------------


def addCol(name, df):
    if name not in df:
        df[name] = ""


def normalize_structure_db(structure_db_df : pd.DataFrame) -> pd.DataFrame:
    """

    Solves problem of duplication [host-cluster-cdb-db]
    Cluster being registered to more than 1 host is not  possible.
    "none" values to clusters when there's a mode in the group need to teplace that none to mode value.

    Parameters
    ----------
    structure_db_df : the original structure_db DataFrame


    Returns
    -------
    DataFrame : returns a dataframe fixed
    """
    df_sorted = structure_db_df.sort_values(by=["host", "cluster", "dbmachine", "cdb"]).copy()

    # Group by host-cluster 1st problem here
    # For each host, compute the mode of 'cluster' and replace only the literal "none" <- shouldn't be none
    # values in that host with that mode. If no non-"none" mode exists
    # leave "none" as is
    # this does not affect NaN/None or non-"none" values.
    df_sorted["cluster"] = (
        df_sorted.groupby("host")["cluster"]
        .transform(lambda x:x.replace("none", x.mode().iloc[0] if not x.mode().empty else "none"))
    )

    def fill_dbmachine(gr):
        """

        Parameters
        ----------
        gr : group

        Returns
        -------

        """
        # Valid values within the group (non-null and non-empty strings)
        # The white spaces from the csv file are "nan" values "NaN", not "", or empty-None
        valid = gr[gr.notna()&(gr.astype(str).str.strip() != "")]
        if valid.empty:
            return gr

        mode_val = valid.mode().iloc[0]

        # Explicitly handle downcasting to suppress the warning <- omg # took a time to quit the "warning" message.
        return gr.replace(["", " "], np.nan).fillna(mode_val).infer_objects(copy=False)

    # Apply the function
    df_sorted["dbmachine"] = (
        df_sorted.groupby(["host", "cluster"])["dbmachine"]
        .transform(fill_dbmachine)
    )

    # print(df_sorted[df_sorted.db == 'abpira20']) # mm
    # print(df_sorted.shape)

    # Count distinct clusters per host, excluding "none".
    # a cluster can't be registered to another host.
    host_cluster_count = (
        df_sorted[df_sorted['cluster'] != 'none']
        .groupby('host')['cluster']
        .nunique()
        .reset_index()
    )

    hosts_multi_cluster = host_cluster_count[host_cluster_count['cluster'] > 1]['host']

    # "leave_first_valid_cluster" delete the posibility of encountering the first row that is valid
    # but also can be another cluster that has more cdb in the same scenario
    # that's why using most populated cluster that violates the constraint of host-cluster
    # approaches more to the patched.csv provided by Matt
    def leave_most_populated_cluster(group):

        if group['cluster'].nunique() == 1:
            return group

        cluster_counts = group['cluster'].value_counts()
        dominant_cluster = cluster_counts.idxmax() #first ocurrence - max value

        return group[group['cluster'] == dominant_cluster]

    #applying the function
    df_fixed = df_sorted.groupby('host', group_keys=False)[df_sorted.columns].apply(
        lambda x:leave_most_populated_cluster(x) if x.name in set(hosts_multi_cluster) else x
    )
    
    return df_fixed
# ----------------------------------------------------------------------------------------------------------------------

startTime = time.time()
lg("Processing files in " + extractFilePath + "...")

try:
    structureDf = pd.read_csv(structureFilename)
except:
    try:
        structureDf = pd.read_csv(structureFilename, encoding="ISO-8859-1")
    except Exception as fc:
        lg_cannotReadCSVFile(structureFilename, fc)
        quit()

structureDf.columns = [c.strip() for c in structureDf.columns]

structureDf = normalize_structure_db(structureDf)


# we need to count how many cdb are per host and cluster
# in case of duplicated we will grab the ones that has more hostxclusterxcdb
counter= (
    structureDf[structureDf['cluster'] != 'none']
    .groupby(['host', 'cluster'])['cdb']
    .nunique()
    .reset_index(name='count_cdb')
)

# there's host with 1 cluster, we will remove those to avoid noise also above none are ignored
duplicated_hosts = counter['host'].value_counts()
duplicated_hosts = duplicated_hosts[duplicated_hosts > 1].index

# we will grab the host with max value (head - 1 - because is sorted )
preferred=(
    counter[counter.host.isin(duplicated_hosts)]
    .sort_values(['host','count_cdb'],ascending=[True,False])
    .groupby('host')
    .head(1)
)
preferred_dict = dict(zip(preferred['host'], preferred['cluster'])) #I had it on the loop, take it out to avoid more time to process
valid = [] #this is like series of boolean to then apply loc to the DF

#Execute only if we have duplicated
if preferred_dict:
    for _,row in structureDf.iterrows():
        host = row['host']
        cluster = row['cluster']
        cdb = row['cdb']

        #register the cdb x cluster, if the host-cluster in the preferred values
        if host not in preferred_dict or cluster == 'none':
            # valid because is  no duplicated
            valid.append(True)
            continue

        if  cluster == preferred_dict[host]:
            valid.append(True)
        else:
            # this is not preferred
            valid.append(False)

    filtered_df = structureDf[valid]
    structureDf = filtered_df

structureDf["STOP"] = "STOP"

structureDf.loc[structureDf["clustered"] == "yes", "clustered"] = "CLUSTERED"
structureDf.loc[structureDf["clustered"] == "no", "clustered"] = "NON-CLUSTERED"

cdbColumnsFromExisting = [
    "cdb_cohort",
    "cdb_size_allocated_ovr",
    "cdb_size_used_ovr",
    "cdb_ovr",
    "cdb_scope_ovr",
    "cdb_percentage_ovr",
]

dbColumnsFromExisting = [
    "db_vcpu_ovr",
    "db_sga_mb_ovr",
    "db_pga_mb_ovr",
    "db_iops_ovr",
    "db_logons_ovr",
    "db_ovr",
]

hostColumnsFromExisting = [
    "h_cpu_type_ovr",
    "h_physical_cpu_count_ovr",
    "h_cores_per_chip_ovr",
    "h_description_ovr",
]

# ---

if os.path.exists(outputFilePath + os.sep + "occa_sizing_structure_db_combined.csv"):
    existingStructureDf = pd.read_csv(
        outputFilePath + os.sep + "occa_sizing_structure_db_combined.csv"
    )

    for c in cdbColumnsFromExisting:
        addCol(c, existingStructureDf)
    for c in dbColumnsFromExisting:
        addCol(c, existingStructureDf)
    for c in hostColumnsFromExisting:
        addCol(c, existingStructureDf)

else:
    existingStructureDf = []

# ----------------------------------------------------------------------------------------------------------------------

try:
    df = pd.read_csv(extractFilePath + os.sep + "emcc_sizing_structure_db_props.csv")
except:
    try:
        df = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_db_props.csv",
            encoding="ISO-8859-1",
        )
    except Exception as fc:
        lg_cannotReadCSVFile(
            extractFilePath + os.sep + "emcc_sizing_structure_db_props.csv", fc
        )
        quit()

df.columns = [c.strip() for c in df.columns]

try:
    df = pd.pivot(df, index="TARGET_GUID", columns="NAME", values="VALUE").reset_index()
except Exception as fc:
    lg_notLikelyCSVFile(
        extractFilePath + os.sep + "emcc_sizing_structure_db_props.csv", fc
    )
    quit()

cols = df.columns.values

# ---

colsNew = [
    "cdb_" + i[9:] if i[0:8] == "orcl_gtp" else "cdb_version" if i == "Version" else i
    for i in cols
]
df.columns = colsNew

len0 = len(structureDf)

try:
    structureDf = pd.merge(
        left=structureDf,
        right=df,
        how="left",
        left_on="cdb_target_guid",
        right_on="TARGET_GUID",
    )
    structureDf.drop("TARGET_GUID", axis=1, inplace=True)
except Exception as fc:
    lg(
        "\nThe following exception was raised processing file "
        + structureFilename
        + "\n"
    )
    lg(str(fc))
    lg(
        "\nPlease check files in directory emcc_sizing_extracts for errors; cannot continue."
    )

    quit()

len1 = len(structureDf)

# ---

colsNew = [
    "db_" + i[9:] if i[0:8] == "orcl_gtp" else "db_version" if i == "Version" else i
    for i in cols
]
df.columns = colsNew

structureDf = pd.merge(
    left=structureDf,
    right=df,
    how="left",
    left_on="db_target_guid",
    right_on="TARGET_GUID",
)
structureDf.drop("TARGET_GUID", axis=1, inplace=True)

len2 = len(structureDf)

# ---

if "cdb_cost_center" not in structureDf:
    structureDf["cdb_cost_center"] = ""
if "cdb_department" not in structureDf:
    structureDf["cdb_department"] = ""
if "cdb_cohort" not in structureDf:
    structureDf["cdb_cohort"] = ""
if "cdb_lifecycle_status" not in structureDf:
    structureDf["cdb_lifecycle_status"] = ""
if "cdb_line_of_bus" not in structureDf:
    structureDf["cdb_line_of_bus"] = ""
if "cdb_location" not in structureDf:
    structureDf["cdb_location"] = ""
if "cdb_version" not in structureDf:
    structureDf["cdb_version"] = ""

if "db_cost_center" not in structureDf:
    structureDf["db_cost_center"] = ""
if "db_department" not in structureDf:
    structureDf["db_department"] = ""
if "db_cohort" not in structureDf:
    structureDf["db_cohort"] = ""
if "db_lifecycle_status" not in structureDf:
    structureDf["db_lifecycle_status"] = ""
if "db_line_of_bus" not in structureDf:
    structureDf["db_line_of_bus"] = ""
if "db_location" not in structureDf:
    structureDf["db_location"] = ""
if "db_version" not in structureDf:
    structureDf["db_version"] = ""

if "h_cost_center" not in structureDf:
    structureDf["h_cost_center"] = ""
if "h_department" not in structureDf:
    structureDf["h_department"] = ""
if "h_lifecycle_status" not in structureDf:
    structureDf["h_lifecycle_status"] = ""
if "h_line_of_bus" not in structureDf:
    structureDf["h_line_of_bus"] = ""
if "h_location" not in structureDf:
    structureDf["h_location"] = ""
if "host_type_version" not in structureDf:
    structureDf["host_type_version"] = ""

# ---

for c in cdbColumnsFromExisting:
    addCol(c, structureDf)
for c in dbColumnsFromExisting:
    addCol(c, structureDf)
for c in hostColumnsFromExisting:
    addCol(c, structureDf)

# ----------------------------------------------------------------------------------------------------------------------

if len(existingStructureDf) == 0:
    len3, len4, len5 = len2, len2, len2

else:

    cdbExistingDf = existingStructureDf[
        ["cdb_target_guid"] + cdbColumnsFromExisting
    ].drop_duplicates()
    cdbExistingDf.columns = [
        (c + "_new" if c != "cdb_target_guid" else c) for c in cdbExistingDf
    ]

    structureDf = pd.merge(
        left=structureDf,
        right=cdbExistingDf,
        how="left",
        left_on="cdb_target_guid",
        right_on="cdb_target_guid",
    )

    len3 = len(structureDf)

    if 1 == 0:
        for c in cdbColumnsFromExisting:
            lg("\nxxx unique values of " + c + " before")
            lg("---------------------------------------")
            lg(str(structureDf[[c]].drop_duplicates()))

    for c in structureDf.columns:
        if c[-4:] == "_new":
            structureDf[c[:-4]] = structureDf[c]
            structureDf.drop(c, axis=1, inplace=True)

    if 1 == 0:
        for c in cdbColumnsFromExisting:
            lg("\nxxx unique values of " + c + " before")
            lg("---------------------------------------")
            lg(str(structureDf[[c]].drop_duplicates()))
    # ---

    dbExistingDf = existingStructureDf[
        ["db_target_guid"] + dbColumnsFromExisting
    ].drop_duplicates()
    dbExistingDf.columns = [
        (c + "_new" if c != "db_target_guid" else c) for c in dbExistingDf
    ]

    structureDf = pd.merge(
        left=structureDf,
        right=dbExistingDf,
        how="left",
        left_on="db_target_guid",
        right_on="db_target_guid",
    )

    len4 = len(structureDf)

    if 1 == 0:
        for c in dbColumnsFromExisting:
            lg("\nxxx unique values of " + c + " before")
            lg("---------------------------------------")
            lg(str(structureDf[[c]].drop_duplicates()))

    for c in structureDf.columns:
        if c[-4:] == "_new":
            structureDf[c[:-4]] = structureDf[c]
            structureDf.drop(c, axis=1, inplace=True)

    if 1 == 0:
        for c in dbColumnsFromExisting:
            lg("\nxxx unique values of " + c + " before")
            lg("---------------------------------------")
            lg(str(structureDf[[c]].drop_duplicates()))

    # ---

    hExistingDf = existingStructureDf[
        ["host_target_guid"] + hostColumnsFromExisting
    ].drop_duplicates()
    hExistingDf.columns = [
        (c + "_new" if c != "host_target_guid" else c) for c in hExistingDf
    ]

    structureDf = pd.merge(
        left=structureDf,
        right=hExistingDf,
        how="left",
        left_on="host_target_guid",
        right_on="host_target_guid",
    )

    len5 = len(structureDf)

    if 1 == 0:
        for c in hostColumnsFromExisting:
            lg("\nxxx 2 unique values of " + c + " after")
            lg("----------------------------------------")
            lg(str(structureDf[[c]].drop_duplicates()))

    for c in structureDf.columns:
        if c[-4:] == "_new":
            structureDf[c[:-4]] = structureDf[c]
            structureDf.drop(c, axis=1, inplace=True)

    if 1 == 0:
        for c in hostColumnsFromExisting:
            lg("\nxxx 2 unique values of " + c + " after")
            lg("----------------------------------------")
            lg(str(structureDf[[c]].drop_duplicates()))

# ----------------------------------------------------------------------------------------------------------------------

if FIXED:
    __version__ = "fixed"
    cwd = "fixed"
    now = "1989-07-09 00:00:00"
    extract_dttm_utc = "1989-07-09 00:00:00"
    structureDf["extract_dttm_utc"] = extract_dttm_utc
    platformName = "fixed"
else:
    cwd = os.getcwd().split(os.sep)[-1]
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    extract_dttm_utc = structureDf["extract_dttm_utc"].unique()[0]
    platformName = platform.system()

structureDf["cwd"] = cwd
structureDf["platform"] = platformName
structureDf["create_dttm_utc"] = now
structureDf["version"] = __version__

structureDf["Cohort"] = structureDf["cdb_cohort"]
structureDf["Database Name"] = structureDf["cdb"]
structureDf["Instance"] = structureDf["db"]
structureDf["Server Name"] = structureDf["host"]

# ---

structureDf["Cohort"] = structureDf["cdb_cohort"]
#
# Get list of servers hosting a database
#
df = structureDf[["Database Name", "Server Name"]].drop_duplicates()
df = df.groupby("Database Name", as_index=False).agg(lambda x: ",".join(set(x)))
df.columns = ["Database Name", "Server List"]
structureDf = pd.merge(
    left=structureDf,
    right=df,
    how="left",
    left_on="Database Name",
    right_on="Database Name",
)

# Sort the values in 'Server List' in reverse
structureDf["Server List"] = structureDf["Server List"].apply(
    lambda x: ",".join(sorted(x.split(","), reverse=True))
)

propsDf = (
    structureDf[
        [
            "Cohort",
            "Database Name",
            "cdb_size_used_ovr",
            "cdb_size_allocated_ovr",
            "cdb_ovr",
            "cdb_scope_ovr",
            "cdb_percentage_ovr",
            "STOP",
            "cdb_instance_count",
            "clustered",
            "dbmachine",
            "dbmachine_owner",
            "cluster",
            "Server List",
            "cdb_version",
            "cdb_status",
            "cdb_last_load_time_utc",
            "cdb_owner",
            "cdb_standby_type",
            "cdb_cost_center",
            "cdb_department",
            "cdb_lifecycle_status",
            "cdb_line_of_bus",
            "cdb_location",
            "cdb_target_guid",
            "cwd",
            "platform",
            "extract_dttm_utc",
            "create_dttm_utc",
            "version",
        ]
    ]
    .drop_duplicates()
    .sort_values(["Database Name"])
)

propsDf.columns = [
    "Cohort",
    "Database Name",
    "Allocated Database Size (GB)",
    "Total Database Size (GB)",
    "Use Values from Database Name",
    "Use Values Scope",
    "Use Values Pct",
    "STOP",
    "Number of Instances",
    "Clustered Database?",
    "dbmachine",
    "dbmachine_owner",
    "cluster",
    "Server List",
    "cdb_version",
    "cdb_status",
    "cdb_last_load_time_utc",
    "cdb_owner",
    "cdb_standby_type",
    "cdb_cost_center",
    "cdb_department",
    "cdb_lifecycle_status",
    "cdb_line_of_bus",
    "cdb_location",
    "target_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

# ---

propsDf.drop_duplicates(inplace=True)

dupDf = propsDf.groupby(["target_guid"], as_index=False)["STOP"].count()
dupDf.columns = ["target_guid", "count"]
dupDf = dupDf[dupDf["count"] > 1]

duplicateDatabases = False
dupDatabaseFilename = "properties_database_duplicates.csv"

if len(dupDf) > 0:
    duplicateDatabases = True

    propsDf["cdb_index"] = propsDf.groupby("target_guid").cumcount() + 1
    cols = ["cdb_index"] + [_ for _ in propsDf.columns if _ != "cdb_index"]
    propsDf = propsDf[cols]
    propsDf[propsDf["target_guid"].isin(dupDf["target_guid"])].sort_values(
        "Database Name"
    )
    to_csv(propsDf, propertiesFilePath + os.sep + dupDatabaseFilename, index=False)

    propsDf = propsDf[propsDf["cdb_index"] == 1]
    propsDf.drop(columns=["cdb_index"], inplace=True)

elif os.path.exists(propertiesFilePath + os.sep + dupDatabaseFilename):
    os.remove(propertiesFilePath + os.sep + dupDatabaseFilename)

# ---

# Strip all column values that are strings
# 'applymap' has been deprecated since version 2.1.0
# TODO: Once compatibility with Pandas version 1.5.3 is no longer required, 'applymap' can be removed
if "map" not in dir(propsDf):
    propsDf = propsDf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
else:
    propsDf = propsDf.map(lambda x: x.strip() if isinstance(x, str) else x)

propsDf.sort_values(["Database Name"])
to_csv(
    propsDf,
    propertiesFilePath + os.sep + "properties_database_original.csv",
    index=False,
)
lg("\nWrote file " + propertiesFilePath + os.sep + "properties_database_original.csv")

# ---

propsDf = (
    structureDf[
        [
            "Database Name",
            "Instance",
            "db_vcpu_ovr",
            "db_sga_mb_ovr",
            "db_pga_mb_ovr",
            "db_iops_ovr",
            "db_logons_ovr",
            "db_ovr",
            "STOP",
            "cluster",
            "Server Name",
            "dbmachine",
            "dbmachine_owner",
            "db_status",
            "db_last_load_time_utc",
            "cdb_owner",
            "cdb_standby_type",
            "clustered",
            "cdb_instance_count",
            "db_version",
            "db_cost_center",
            "db_department",
            "db_lifecycle_status",
            "db_location",
            "db_target_guid",
            "cdb_target_guid",
            "cwd",
            "platform",
            "extract_dttm_utc",
            "create_dttm_utc",
            "version",
        ]
    ]
    .drop_duplicates()
    .sort_values(["Database Name", "Instance"])
)

propsDf.columns = [
    "Database Name",
    "Instance",
    "vCPU",
    "SGA (MB)",
    "PGA (MB)",
    "IOPS",
    "Logons",
    "Use Values from Instance",
    "STOP",
    "Cluster",
    "Server Name",
    "dbmachine",
    "dbmachine_owner",
    "status",
    "last_load_time_utc",
    "owner",
    "standby_type",
    "clustered",
    "instance_count",
    "version",
    "cost_center",
    "department",
    "lifecycle_status",
    "location",
    "target_guid",
    "cdb_target_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

# ---

propsDf.drop_duplicates(inplace=True)

dupDf = propsDf.groupby(["target_guid"], as_index=False)["STOP"].count()
dupDf.columns = ["target_guid", "count"]
dupDf = dupDf[dupDf["count"] > 1]

duplicateInstances = False
dupInstanceFilename = "properties_instance_duplicates.csv"

if len(dupDf) > 0:
    duplicateInstances = True

    propsDf["instance_index"] = propsDf.groupby("target_guid").cumcount() + 1
    cols = ["instance_index"] + [_ for _ in propsDf.columns if _ != "instance_index"]
    propsDf = propsDf[cols]
    propsDf[propsDf["target_guid"].isin(dupDf["target_guid"])].sort_values("Instance")
    to_csv(propsDf, propertiesFilePath + os.sep + dupInstanceFilename, index=False)

    propsDf = propsDf[propsDf["instance_index"] == 1]
    propsDf.drop(columns=["instance_index"], inplace=True)

elif os.path.exists(propertiesFilePath + os.sep + dupInstanceFilename):
    os.remove(propertiesFilePath + os.sep + dupInstanceFilename)

# ---

# Strip all column values that are strings
# 'applymap' has been deprecated since version 2.1.0
# TODO: Once compatibility with Pandas version 1.5.3 is no longer required, 'applymap' can be removed
if "map" not in dir(propsDf):
    propsDf = propsDf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
else:
    propsDf = propsDf.map(lambda x: x.strip() if isinstance(x, str) else x)

propsDf.sort_values(["Database Name", "Instance"])
to_csv(
    propsDf,
    propertiesFilePath + os.sep + "properties_instance_original.csv",
    index=False,
)
lg("\nWrote file " + propertiesFilePath + os.sep + "properties_instance_original.csv")

# ---

structureDf.loc[structureDf["physical_cpu_count"].isnull(), "cores_per_chip"] = 0
structureDf.loc[structureDf["physical_cpu_count"].notnull(), "cores_per_chip"] = (
    structureDf["total_cpu_cores"] / structureDf["physical_cpu_count"]
)
structureDf.loc[structureDf["cores_per_chip"].isnull(), "cores_per_chip"] = 0
structureDf["cores_per_chip"] = structureDf["cores_per_chip"].astype(int)

# Set total_cpu_cores for Intel X86 Architechture when the value is 0
structureDf.loc[
    (structureDf["ma"] == "GenuineIntel x86_64")
    & (structureDf["total_cpu_cores"] == 0)
    & (structureDf["physical_cpu_count"] == structureDf["logical_cpu_count"]),
    "total_cpu_cores",
] = structureDf["physical_cpu_count"]

structureDf.loc[
    (structureDf["ma"] == "GenuineIntel x86_64")
    & (structureDf["total_cpu_cores"] == 0)
    & (structureDf["physical_cpu_count"] != structureDf["logical_cpu_count"]),
    "total_cpu_cores",
] = (
    structureDf["logical_cpu_count"] / 2
)

# propsDf=structureDf[structureDf['cdb'] != 'none']

len6 = len(structureDf)

# ---

if os.path.exists(extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"):
    try:
        cpuDf = pd.read_csv(
            extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv"
        )
    except:
        try:
            cpuDf = pd.read_csv(
                extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv",
                encoding="ISO-8859-1",
            )
        except Exception as fc:
            lg_cannotReadCSVFile(
                extractFilePath + os.sep + "emcc_sizing_structure_host_cpu.csv", fc
            )
            quit()

    cpuDf.columns = [c.strip() for c in cpuDf.columns]
    cpuDf = cpuDf[
        ["target_guid", "ecache_in_mb", "impl", "revision", "is_hyperthread_enabled"]
    ]

    structureDf = pd.merge(
        left=structureDf,
        right=cpuDf,
        how="left",
        left_on="host_target_guid",
        right_on="target_guid",
    )


else:
    structureDf["ecache_in_mb"] = -1
    structureDf["impl"] = "not_loaded"
    structureDf["revision"] = "not_loaded"
    structureDf["is_hyperthread_enabled"] = -1

# ---

structureDf["ma"] = structureDf["ma"].fillna("")
structureDf["cpu_type"] = structureDf.apply(
    lambda r: getCPUType(r["ma"], r["impl"]), axis=1
)

len7 = len(structureDf)

propsDf = (
    structureDf[
        [
            "Server Name",
            "h_cpu_type_ovr",
            "h_physical_cpu_count_ovr",
            "h_cores_per_chip_ovr",
            "h_description_ovr",
            "STOP",
            "dbmachine",
            "dbmachine_owner",
            "cluster",
            "host_type_version",
            "host_status",
            "host_last_load_time_utc",
            "h_cost_center",
            "h_department",
            "h_lifecycle_status",
            "h_line_of_bus",
            "h_location",
            "physical_cpu_count",
            "total_cpu_cores",
            "logical_cpu_count",
            "ecache_in_mb",
            "impl",
            "revision",
            "is_hyperthread_enabled",
            "freq",
            "cpu_type",
            "ma",
            "system_config",
            "vendor_name",
            "dist_version",
            "host_target_guid",
            "cwd",
            "platform",
            "extract_dttm_utc",
            "create_dttm_utc",
            "version",
        ]
    ]
    .drop_duplicates()
    .sort_values(["Server Name"])
)

propsDf.columns = [
    "Server Name",
    "CPU Type",
    "Chip Count (Actual)",
    "Cores Per Chip (Actual)",
    "Description",
    "STOP",
    "dbmachine",
    "dbmachine_owner",
    "cluster",
    "host_type_version",
    "h_status",
    "h_last_load_time_utc",
    "h_cost_center",
    "h_department",
    "h_lifecycle_status",
    "h_line_of_bus",
    "h_location",
    "h_physical_cpu_count",
    "h_total_cpu_cores",
    "h_logical_cpu_count",
    "h_ecache_in_mb",
    "h_impl",
    "h_revision",
    "h_is_hyperthread_enabled",
    "h_freq",
    "h_cpu_type",
    "h_ma",
    "h_system_config",
    "h_vendor_name",
    "h_dist_version",
    "target_guid",
    "cwd",
    "platform",
    "extract_dttm_utc",
    "create_dttm_utc",
    "version",
]

# ---

propsDf.drop_duplicates(inplace=True)

dupDf = propsDf.groupby(["target_guid"], as_index=False)["STOP"].count()
dupDf.columns = ["target_guid", "count"]
dupDf = dupDf[dupDf["count"] > 1]

duplicateServers = False
dupServerFilename = "properties_server_duplicates.csv"

if len(dupDf) > 0:
    duplicateServers = True

    propsDf["server_index"] = propsDf.groupby("target_guid").cumcount() + 1
    cols = ["server_index"] + [_ for _ in propsDf.columns if _ != "server_index"]
    propsDf = propsDf[cols]
    propsDf[propsDf["target_guid"].isin(dupDf["target_guid"])].sort_values(
        "Server Name"
    )
    to_csv(propsDf, propertiesFilePath + os.sep + dupServerFilename, index=False)

    propsDf = propsDf[propsDf["server_index"] == 1]
    propsDf.drop(columns=["server_index"], inplace=True)

elif os.path.exists(propertiesFilePath + os.sep + dupServerFilename):
    os.remove(propertiesFilePath + os.sep + dupServerFilename)

# Strip all column values that are strings
# 'applymap' has been deprecated since version 2.1.0
# TODO: Once compatibility with Pandas version 1.5.3 is no longer required, 'applymap' can be removed
if "map" not in dir(propsDf):
    propsDf = propsDf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
else:
    propsDf = propsDf.map(lambda x: x.strip() if isinstance(x, str) else x)

propsDf.sort_values(["Server Name"])
to_csv(
    propsDf, propertiesFilePath + os.sep + "properties_server_original.csv", index=False
)
lg("\nWrote file " + propertiesFilePath + os.sep + "properties_server_original.csv")

# ----------------------------------------------------------------------------------------------------------------------

duplicateTestResults, structureDf = Duplicate_Tests.duplicateTests(
    structureDf, "Create_Property_Files", outputFilePath
)

# ----------------------------------------------------------------------------------------------------------------------

if (
    len0 != len1
    or len1 != len2
    or len2 != len3
    or len3 != len4
    or len4 != len5
    or len5 != len6
    or len6 != len7
):
    lg("\nThere is a suspicious change in the number of rows")
    lg("--------------------------------------------------")
    lg("len0: " + str(len0))
    lg("len1: " + str(len1))
    lg("len2: " + str(len2))
    lg("len3: " + str(len3))
    lg("len4: " + str(len4))
    lg("len5: " + str(len5))
    lg("len6: " + str(len6))
    lg("len7: " + str(len7))

# ----------------------------------------------------------------------------------------------------------------------

Duplicate_Tests.emitDuplicateTestResults(duplicateTestResults, logFile)

if duplicateInstances:
    lg(
        "\nDuplicated instances have been written to file "
        + propertiesFilePath
        + os.sep
        + dupInstanceFilename
    )
    lg("Rows with instance_index > 1 will be removed")

if duplicateDatabases:
    lg(
        "\nDuplicated databases have been written to file "
        + propertiesFilePath
        + os.sep
        + dupDatabaseFilename
    )
    lg("Rows with cdb_index > 1 will be removed")

if duplicateServers:
    lg(
        "\nDuplicated servers have been written to file "
        + propertiesFilePath
        + os.sep
        + dupServerFilename
    )
    lg("Rows with server_index > 1 will be removed")

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nThe processing of "
    + str(len(structureDf))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
