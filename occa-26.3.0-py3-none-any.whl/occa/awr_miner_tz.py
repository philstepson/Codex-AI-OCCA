from collections import defaultdict
from datetime import datetime

import pytz

dt = datetime.now(pytz.utc)  # current time in UTC
zone_names = defaultdict(list)

for tz in pytz.common_timezones:
    zone_names[dt.astimezone(pytz.timezone(tz)).utcoffset()].append(tz)

for offset, zone in sorted(zone_names.items()):
    for _ in zone:
        print("%.1f %s" % (offset.total_seconds() / 60, _))
