import argparse
import datetime
import os
import platform
import sys
import time

import numpy as np
import pandas as pd

from occa_Shared import *
from version import version, __version__

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Copy_Primary_DB_Name_To_DB_Properties.py",
    description="Copy DB Name from primary databases to property files",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="'Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="'Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + " version: " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
#
# Values for these parameters will be read from the parameter file
#

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
propertiesFilePath = ROOT_DIR + os.sep + "occa_sizing_properties"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("numpy.__version__ : " + np.__version__)
lg("pandas.__version__: " + pd.__version__)

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

# ----------------------------------------------------------------------------------------------------------------------

cwd = os.getcwd().split(os.sep)[-1]
startTime = time.time()
fileTS = (
    datetime.datetime.strftime(
        datetime.datetime.now(datetime.timezone.utc), "%Y%m%d_%H%M%S"
    )
    + "_UTC"
)

lg("Processing files in " + extractFilePath + "...")

if not os.path.exists(extractFilePath):
    lg("Directory " + extractFilePath + " is missing; cannot continue")

    quit()

# ---

propertyFilename = propertiesFilePath + os.sep + "properties_database.csv"

if not os.path.exists(propertyFilename):
    lg(
        "File "
        + propertyFilename
        + " is missing; please be sure to run occa_Create_Property_Files.py before running this script"
    )

    quit()

# ---

drFilename = extractFilePath + os.sep + "emcc_sizing_structure_db_dr.csv"

if not os.path.exists(drFilename):
    lg("File " + drFilename + " is missing; cannot continue")

    quit()


# ---

hourlyFilename = (
    extractFilePath + os.sep + "emcc_sizing_metrics_db_hourly_03_months.csv"
)

if not os.path.exists(hourlyFilename):
    lg("File " + hourlyFilename + " is missing; cannot continue")

    quit()

# ---

structureFilename = extractFilePath + os.sep + "emcc_sizing_structure_db.csv"

# --- moved up to use it for duplicated finding in this DataFrame
try:
    structureDf = pd.read_csv(structureFilename)
except Exception as fc:
    lg_cannotReadCSVFile(structureFilename, fc)
    quit()

if not os.path.exists(structureFilename):
    lg("File " + structureFilename + " is missing; cannot continue")

    quit()

# ----------------------------------------------------------------------------------------------------------------------

try:
    dbPropsDf = pd.read_csv(propertyFilename)
except Exception as fc:
    lg_cannotReadCSVFile(propertyFilename, fc)
    quit()

dbPropsDf.columns = [c.strip() for c in dbPropsDf.columns]

if "target_guid" not in dbPropsDf:
    if (
        "cdb_target_guid" in dbPropsDf
    ):  # needed just in case they have copied the AUDIT spreadsheet to properties
        dbPropsDf.rename(columns={"cdb_target_guid": "target_guid"}, inplace=True)
    else:
        lg(
            "File "
            + propertyFilename
            + ' is missing column "target_guid"; unable to continue'
        )
        quit()

# ---

len0 = len(dbPropsDf)

if len0 == 0:
    lg("File " + propertyFilename + " is empty; cannot continue")
    quit()

# --

try:
    drDf = pd.read_csv(drFilename)
except Exception as fc:
    lg_cannotReadCSVFile(drFilename, fc)
    quit()

drDf.columns = [c.strip() for c in drDf.columns]


# IF the primary target name it's NOT in the structure_db file
# we can also have PRI_TARGET_NAME but not sure if ignoring/deleting the nan,null blank cell values
# would bring an error
drDf = drDf[drDf["PRI_TARGET_NAME"].isin(structureDf["cdb"]) | drDf["PRI_TARGET_NAME"].isna() | (drDf["PRI_TARGET_NAME"] == "" )]


if len(drDf) == 0:
    lg("File " + drFilename + " is empty; cannot continue")
    quit()

# ---

lg("\nLoading file " + hourlyFilename + "...")

tb = time.time()

try:
    hourlyDf = pd.read_csv(hourlyFilename)
except Exception as fc:
    lg_cannotReadCSVFile(hourlyFilename, fc)
    quit()

hourlyDf.columns = [c.strip() for c in hourlyDf.columns]

if len(hourlyDf) == 0:
    lg("File " + hourlyFilename + " is empty; cannot continue")
    quit()

hourlyDf["metric"] = hourlyDf["METRIC_NAME"] + "." + hourlyDf["METRIC_COLUMN"]
hourlyDf = hourlyDf[hourlyDf["metric"].isin(EMCC_INSTANCE_METRICS)]
hourlyDf = hourlyDf[hourlyDf["metric"] != LOGONS_METRIC]

lg(
    "Loaded "
    + str(len(hourlyDf))
    + " rows in "
    + str(round(time.time() - tb, 3))
    + " s"
)

if len(hourlyDf) == 0:
    lg("File " + hourlyFilename + " contains no instance metrics; cannot continue")
    quit()


structureDf.columns = [c.strip() for c in structureDf.columns]

if len(structureDf) == 0:
    lg("File " + hourlyFilename + " is empty; cannot continue")
    quit()

structureDf = structureDf[["cdb_target_guid", "db_target_guid"]].drop_duplicates()

# ---

hourlyDf = pd.merge(
    left=hourlyDf,
    right=structureDf,
    how="left",
    left_on=["TARGET_GUID"],
    right_on=["db_target_guid"],
)

cdbHourlyCountsDf = hourlyDf.groupby(["cdb_target_guid"], as_index=False)[
    "metric"
].count()
instanceHourlyCountsDf = hourlyDf.groupby(["db_target_guid"], as_index=False)[
    "metric"
].count()

cdbHourlyCountsDf.columns = ["TARGET_GUID", "count"]
instanceHourlyCountsDf.columns = ["TARGET_GUID", "count"]

countsDf = pd.concat([cdbHourlyCountsDf, instanceHourlyCountsDf], ignore_index=True)
countsDf = countsDf.drop_duplicates()

# ---

drDf = drDf[
    ["PRI_TARGET_NAME", "STDBY_TARGET_NAME", "PRI_TARGET_GUID", "STDBY_TARGET_GUID"]
].drop_duplicates()

missingPrimariesDf = drDf[
    ~drDf["PRI_TARGET_GUID"].isin(dbPropsDf["target_guid"])
].copy()
missingStandbysDf = drDf[
    ~drDf["STDBY_TARGET_GUID"].isin(dbPropsDf["target_guid"])
].copy()

if len(missingPrimariesDf) > 0:
    drDf = drDf[drDf["PRI_TARGET_GUID"].isin(dbPropsDf["target_guid"])]

    if len(drDf) > 0:
        drDf = pd.merge(
            left=drDf,
            right=dbPropsDf[["target_guid", "Database Name"]],
            how="left",
            left_on="PRI_TARGET_GUID",
            right_on="target_guid",
        )

        drDf["PRI_TARGET_NAME"] = drDf["Database Name"]
        drDf.drop(columns=["Database Name", "target_guid"], inplace=True)

if len(missingStandbysDf) > 0:
    drDf = drDf[drDf["STDBY_TARGET_GUID"].isin(dbPropsDf["target_guid"])]

    if len(drDf) > 0:
        drDf = pd.merge(
            left=drDf,
            right=dbPropsDf[["target_guid", "Database Name"]],
            how="left",
            left_on="STDBY_TARGET_GUID",
            right_on="target_guid",
        )

        drDf["STDBY_TARGET_NAME"] = drDf["Database Name"]
        drDf.drop(columns=["Database Name", "target_guid"], inplace=True)

if len(drDf) == 0:
    lg("All of the entries in " + drFilename + " have been eliminated; cannot continue")

gbDf = drDf.groupby(["STDBY_TARGET_NAME", "STDBY_TARGET_GUID"], as_index=False)[
    "PRI_TARGET_GUID"
].count()
gbDf = gbDf[gbDf["PRI_TARGET_GUID"] > 1]

dupDf = drDf[drDf["STDBY_TARGET_GUID"].isin(gbDf["STDBY_TARGET_GUID"])].copy()
dupDf["primary_index"] = dupDf.groupby(["STDBY_TARGET_GUID"])["PRI_TARGET_NAME"].rank(
    "dense"
)

if 1 == 0:
    filename = propertiesFilePath + os.sep + "dup.csv"
    dupDf.sort_values(["STDBY_TARGET_GUID", "primary_index"]).to_csv(
        filename, index=False
    )

dupDf = dupDf[dupDf["primary_index"] > 1][["STDBY_TARGET_GUID", "PRI_TARGET_GUID"]]
dupDf["drop"] = dupDf["STDBY_TARGET_GUID"] + "." + dupDf["PRI_TARGET_GUID"]

filename = (
    propertiesFilePath
    + os.sep
    + "properties_database_duplicate_primaries_for_a_standby.csv"
)

if len(gbDf) > 1:
    lg(
        "\n"
        + str(len(gbDf))
        + " standbys have more than one primary in file "
        + drFilename
    )

    dbPropsDf[dbPropsDf["target_guid"].isin(gbDf["STDBY_TARGET_GUID"])].sort_values(
        ["Database Name"]
    ).to_csv(filename, index=False)

    drDf["drop"] = drDf["STDBY_TARGET_GUID"] + "." + drDf["PRI_TARGET_GUID"]
    drDf = drDf[~drDf["drop"].isin(dupDf["drop"])]
    drDf.drop(columns=["drop"], inplace=True)

    lg("The duplicate relationships have been written to file " + filename)
    lg(
        "\nA single primary-standby relationship has been selected for each of the standby databases and has been copied to file properties_database.csv."
    )

elif os.path.exists(filename):
    os.remove(filename)

# ---

dbPropsDf = pd.merge(
    left=dbPropsDf,
    right=drDf,
    how="left",
    left_on="target_guid",
    right_on="STDBY_TARGET_GUID",
)

# Find possible duplicates -> if there's duplicate remove the ones that has invalid cdb status
# and drop the ones that are blackout or down

# Blackout -> An administrator has disabled metric collection by placing the target  database in a “blackout” status.
# Pending/Unknown Setup of the EMCC agent is in process but hasn’t yet completed.
# Target Down The target database or instance is not running.
# Unreachable The “unreachable” message indicates a network problem, or the
# server has been disabled or turned off."

# Get the duplicated if any
duplicated = dbPropsDf[dbPropsDf.duplicated(subset=["target_guid"], keep=False)]
if not duplicated.empty:
    # Getting the cdbs that are blackout or Down
    invalid_status_rows = dbPropsDf.loc[
        dbPropsDf["cdb_status"].isin(["Blackout", "Target Down"])
    ]
    # find the duplicated rows that that 'PRI_TARGET_GUID' it's in 'target_guid and it's blackout
    duplicated_with_invalid_status = duplicated[
        duplicated["PRI_TARGET_GUID"].isin(invalid_status_rows["target_guid"])
    ]
    # Remove the indices that
    dbPropsDf.drop(duplicated_with_invalid_status.index, inplace=True)

dbPropsDf["Use Values from Database Name"] = dbPropsDf[
    "Use Values from Database Name"
].fillna("")
dbPropsDf["PRI_TARGET_NAME"] = dbPropsDf["PRI_TARGET_NAME"].fillna("")

dbPropsDf.loc[(dbPropsDf["PRI_TARGET_NAME"] != ""), "Use Values from Database Name"] = (
    dbPropsDf["PRI_TARGET_NAME"]
)

dbPropsDf = pd.merge(
    left=dbPropsDf,
    right=countsDf,
    how="left",
    left_on=["STDBY_TARGET_GUID"],
    right_on=["TARGET_GUID"],
)
dbPropsDf["count"] = dbPropsDf["count"].fillna(0)

dbPropsDf["Use Values Scope"] = dbPropsDf["Use Values Scope"].fillna("").astype(str)
dbPropsDf.loc[dbPropsDf["Use Values from Database Name"] != "", "Use Values Scope"] = (
    PHYSICAL_STANDBY
)
dbPropsDf.loc[dbPropsDf["count"] > 0, "Use Values Scope"] = PRIMARY_PLUS_STANDBY

# ---

colsToDrop = [
    c
    for c in [
        "STDBY_TARGET_GUID",
        "STDBY_TARGET_NAME",
        "PRI_TARGET_GUID",
        "PRI_TARGET_NAME",
        "TARGET_GUID",
        "count",
    ]
    if c in dbPropsDf
]

if len(colsToDrop) > 0:
    dbPropsDf.drop(columns=colsToDrop, inplace=True)
len1 = len(dbPropsDf)

drFilename = propertiesFilePath + os.sep + "dr.csv"

if len0 != len1:
    lg(
        "\nOriginal length of file "
        + propertyFilename
        + ": "
        + str(len0)
        + " does not match final length: "
        + str(len1)
    )

    drDf.sort_values(["STDBY_TARGET_NAME"]).to_csv(drFilename, index=False)
    lg(
        "Duplicate standby -> primary relationship(s) have been written to file "
        + drFilename
    )

    quit()

elif os.path.exists(drFilename):
    os.remove(drFilename)

# ---

os.rename(propertyFilename, propertyFilename.rstrip(".csv") + "." + fileTS + ".csv")
dbPropsDf.sort_values(["Database Name"]).to_csv(propertyFilename, index=False)
lg("\nAdded " + str(len(drDf)) + " properties to file " + propertyFilename)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg(
    "\nThe processing of "
    + str(len(dbPropsDf))
    + " rows completed in "
    + str(round(time.time() - startTime, 3))
    + " s"
)

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
