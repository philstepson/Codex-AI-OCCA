DB_METRICS_FILE = "emcc_sizing_metrics_db_hourly_03_months.csv"

HEIGHT = 1185
WIDTH = 1920

PERCENTILES = [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 0.99]

# ----------------------------------------------------------------------------------------------------------------------

import argparse
import datetime
import os
import pandas as pd
import platform
import sys
import time

from occa_Shared import *
from version import version, __version__

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="occa_Reduce_DB_Metrics.py",
    description="Reduces DB hourly & daily metrics for easy visualization",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="'Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="'Print the parameters used by the script",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + ", version " + __version__)
    quit()

# ----------------------------------------------------------------------------------------------------------------------

print(
    "=======================================================================================================\n"
)
print(sys.argv[0] + ", version " + __version__)
print(
    "\n======================================================================================================="
)

COHORTS = []

PLOT_HTML = True
PLOT_PNG = False

PRECISION = 3
TIME_PERIODS = ["03", "06", "09", "12"]

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = (
    os.environ["OCCA_SIZING_DATA_FILES_ROOT_DIR"]
    if "OCCA_SIZING_DATA_FILES_ROOT_DIR" in os.environ
    else "."
)

#
# This script depends on a setting for the parameters below
# Values for these parameters will be read from the parameter file
#

FIXED = False

# ----------------------------------------------------------------------------------------------------------------------

scriptDir = os.path.dirname(os.path.realpath(__file__))

if os.path.exists(ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = ROOT_DIR + os.sep + "occa_Sizing_Parameters.py"

elif os.path.exists(scriptDir + os.sep + "occa_Sizing_Parameters.py"):
    PARAM_FILE = scriptDir + os.sep + "occa_Sizing_Parameters.py"

else:
    print(
        "Parameter file occa_Sizing_Parameters.py cannot be found in either the current working directory or the src directory; cannot continue"
    )

    quit()

# ---

print("\nReading parameters from file " + PARAM_FILE)
with open(PARAM_FILE, "r", encoding="utf-8") as file:
    exec(file.read())

# ----------------------------------------------------------------------------------------------------------------------


def format_title(title, subtitle=None, subtitle_font_size=14):
    title = f"<b>{title}</b>"

    if not subtitle:
        return title

    subtitle = f'<span style="font-size: {subtitle_font_size}px;">{subtitle}</span>'

    return f"{title}<br>{subtitle}"


# ----------------------------------------------------------------------------------------------------------------------


def plotMetrics(df):
    FACET_COLS = 2

    lg("\nBeginning cdf plots...")

    customer = os.getcwd().split(os.sep)[-1]

    df = df[(df["used_by_database_cnt"] > 1) & (df["measure"] == "AVERAGE")]

    for cdb in sorted(df["Use Values from Database Name"].unique()):
        lg("     Beginning cdb " + str(cdb) + "...")

        tb = time.time()

        pDf = df[(df["Use Values from Database Name"] == cdb)].copy()

        if len(pDf) == 0:
            lg("          Skipping 0-length cdb: " + str(cdb))
            continue

        if PLOT_HTML:
            filePathHTML = (
                plotFilePath + os.sep + "primary_standby_cdf" + os.sep + "html"
            )
            os.makedirs(filePathHTML, exist_ok=True)

        if PLOT_PNG:
            filePathPNG = plotFilePath + os.sep + "primary_standby_cdf" + os.sep + "png"
            os.makedirs(filePathPNG, exist_ok=True)

        plotCtr = 0

        pDf.sort_values(
            ["time_unit", "metric", "cdb_label"],
            ascending=[True, True, False],
            inplace=True,
        )

        fig = px.line(
            pDf,
            x="value",
            y="pct",
            facet_row="metric",
            facet_col="time_unit",
            color="cdb_label",
            facet_col_wrap=FACET_COLS,
            labels={"value": "Metric Value", "pct": "%"},
            title=format_title(
                customer
                + " : "
                + str(cdb)
                + " : Primary/Standby Average Metric Value Distribution (Chart Version "
                + __version__
                + ")",
                "1 OCPU = 2 vCPU",
                20,
            ),
            template="seaborn",
            width=WIDTH,
            height=HEIGHT,
        )

        fig.update_layout(
            font={"size": 16},
            legend_font_size=12,
            autosize=False,
            width=WIDTH,
            height=HEIGHT,
            margin=dict(t=150),
        )
        fig.update_xaxes(matches=None, showticklabels=True)
        fig.update_traces(mode="lines+markers")
        fig.update_xaxes(rangemode="tozero")

        for t in fig.layout.annotations:
            if "text" in t:
                p1, p2 = t["text"].split("=")
                if p1 == "metric":
                    t["text"] = p2

        if PLOT_HTML:
            filenameHTML = (
                filePathHTML + os.sep + str(cdb) + "_primary_standby_cdf.html"
            )
            dashboard = open(filenameHTML, "w")
            HTMLhead = (
                customer
                + " : "
                + str(cdb)
                + " (occa_Rduce_DB_Metrics, Chart Version "
                + __version__
                + ")"
            )

            dashboard.write(
                "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
            )

        if PLOT_PNG:
            filenamePNG = filePathPNG + os.sep + str(cdb) + "_primary_standby_cdf.png"

        if PLOT_HTML:
            inner_html = (
                fig.to_html(include_plotlyjs=True)
                .split("<body>")[1]
                .split("</body>")[0]
            )
            dashboard.write(inner_html)

            dashboard.write("</body></html>" + "\n")
            dashboard.close()

            plotCtr += 1

        if PLOT_PNG:
            fig.write_image(filenamePNG)

            plotCtr += 1

        lg(
            "     Created "
            + str(plotCtr)
            + " plots for "
            + str(cdb)
            + " in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )


# ----------------------------------------------------------------------------------------------------------------------


def plotPercentileHistograms(df):
    FACET_COLS = 2

    lg("\nBeginning percentile histogram plots...")

    customer = os.getcwd().split(os.sep)[-1]

    df = df[df["measure"] == "AVERAGE"]

    # for pct in sorted(df['pct'].unique()):
    for pct in [50, 100]:
        lg("     Beginning " + str(pct) + "th percentile...")

        tb = time.time()

        pDf = df[(df["pct"] == pct)].copy()

        if len(pDf) == 0:
            lg("          Skipping 0-length pct: " + str(pct))
            continue

        if PLOT_HTML:
            filePathHTML = (
                plotFilePath
                + os.sep
                + "primary_standby_cdf_percentile_histograms"
                + os.sep
                + "html"
            )
            os.makedirs(filePathHTML, exist_ok=True)

        if PLOT_PNG:
            filePathPNG = (
                plotFilePath
                + os.sep
                + "primary_standby_cdf_percentile_histograms"
                + os.sep
                + "png"
            )
            os.makedirs(filePathPNG, exist_ok=True)

        plotCtr = 0

        pDf.sort_values(["time_unit", "metric"], ascending=[True, True], inplace=True)

        fig = px.histogram(
            pDf,
            x="standby_pct",
            facet_row="metric",
            facet_col="time_unit",
            facet_col_wrap=FACET_COLS,
            labels={"standby_pct": "(Standby Value / Primary Value) * 100"},
            title=format_title(
                customer
                + " : Count of (Standby Avg. Metric Value / Primary Avg. Metric Value) * 100 for "
                + str(pct)
                + "th percentile (Chart Version "
                + __version__
                + ")",
                "Bin Width = 20%, Percentages > 400% are truncated, 1 OCPU = 2 vCPU",
                20,
            ),
            template="seaborn",
            width=WIDTH,
            height=HEIGHT,
        )

        fig.update_layout(
            font={"size": 16},
            legend_font_size=12,
            autosize=False,
            width=WIDTH,
            height=HEIGHT,
            margin=dict(t=150),
        )
        fig.update_traces(xbins=dict(start=0.0, end=400.0, size=20))
        fig.update_yaxes(matches=None, showticklabels=True)
        fig.add_vline(
            x=100,
            line_width=6,
            line_dash="dash",
            line_color="red",
            row="all",
            col="all",
        )

        for t in fig.layout.annotations:
            if "text" in t:
                p1, p2 = t["text"].split("=")
                if p1 == "metric":
                    t["text"] = p2

        if PLOT_HTML:
            filenameHTML = (
                filePathHTML
                + os.sep
                + "p"
                + str(pct).zfill(3)
                + "_primary_standby_cdf_percentile_histograms.html"
            )
            dashboard = open(filenameHTML, "w")
            HTMLhead = (
                customer
                + " : p "
                + str(pct)
                + " (occa_Rduce_DB_Metrics, Chart Version "
                + __version__
                + ")"
            )

            dashboard.write(
                "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
            )

        if PLOT_PNG:
            filenamePNG = (
                filePathPNG
                + os.sep
                + "p"
                + str(pct).zfill(3)
                + "_primary_standby_cdf_percentile_histograms.png"
            )

        if PLOT_HTML:
            inner_html = (
                fig.to_html(include_plotlyjs=True)
                .split("<body>")[1]
                .split("</body>")[0]
            )
            dashboard.write(inner_html)

            dashboard.write("</body></html>" + "\n")
            dashboard.close()

            plotCtr += 1

        if PLOT_PNG:
            fig.write_image(filenamePNG)

            plotCtr += 1

        lg(
            "     Created "
            + str(plotCtr)
            + " plots for "
            + str(pct)
            + "th percentile in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )


# ----------------------------------------------------------------------------------------------------------------------


def plotTotalHistograms(df):
    FACET_COLS = 2

    lg("\nBeginning total histogram plots...")

    customer = os.getcwd().split(os.sep)[-1]

    pDf = df[df["measure"] == "AVERAGE"].copy()

    tb = time.time()

    if PLOT_HTML:
        filePathHTML = (
            plotFilePath
            + os.sep
            + "primary_standby_totals_histograms"
            + os.sep
            + "html"
        )
        os.makedirs(filePathHTML, exist_ok=True)

    if PLOT_PNG:
        filePathPNG = (
            plotFilePath + os.sep + "primary_standby_totals_histograms" + os.sep + "png"
        )
        os.makedirs(filePathPNG, exist_ok=True)

    pDf.sort_values(["time_unit", "metric"], ascending=[True, True], inplace=True)

    fig = px.histogram(
        pDf,
        x="standby_pct",
        facet_row="metric",
        facet_col="time_unit",
        facet_col_wrap=FACET_COLS,
        labels={"standby_pct": "(Standby Value / Primary Value) * 100"},
        title=format_title(
            customer
            + " : Count of (Total Daily Standby Avg. Metric Value / Total Daily Primary Avg. Metric Value) * 100 (Chart Version "
            + __version__
            + ")",
            "Bin Width = 20%, Percentages > 400% are truncated, 1 OCPU = 2 vCPU",
            20,
        ),
        template="seaborn",
        width=WIDTH,
        height=HEIGHT,
    )

    fig.update_layout(
        font={"size": 16},
        legend_font_size=12,
        autosize=False,
        width=WIDTH,
        height=HEIGHT,
        margin=dict(t=150),
    )
    fig.update_traces(xbins=dict(start=0.0, end=400.0, size=20))
    fig.update_yaxes(matches=None, showticklabels=True)
    fig.add_vline(
        x=100, line_width=6, line_dash="dash", line_color="red", row="all", col="all"
    )

    for t in fig.layout.annotations:
        if "text" in t:
            p1, p2 = t["text"].split("=")
            if p1 == "metric":
                t["text"] = p2

    if PLOT_HTML:
        filenameHTML = filePathHTML + os.sep + "primary_standby_totals_histograms.html"
        dashboard = open(filenameHTML, "w")
        HTMLhead = (
            customer + " (occa_Rduce_DB_Metrics, Chart Version " + __version__ + ")"
        )

        dashboard.write(
            "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
        )

    if PLOT_PNG:
        filenamePNG = filePathPNG + os.sep + "primary_standby_totals_histograms.png"

    if PLOT_HTML:
        inner_html = (
            fig.to_html(include_plotlyjs=True).split("<body>")[1].split("</body>")[0]
        )
        dashboard.write(inner_html)

        dashboard.write("</body></html>" + "\n")
        dashboard.close()

    if PLOT_PNG:
        fig.write_image(filenamePNG)

    lg(
        "     Created plot in directories rooted at "
        + plotFilePath
        + " in "
        + str(round(time.time() - tb, 3))
        + " s\n"
    )


# ----------------------------------------------------------------------------------------------------------------------


def plotMetricTotals(df):
    FACET_COLS = 2

    lg("\nBeginning total plots...")

    customer = os.getcwd().split(os.sep)[-1]

    df = df[
        (df["used_by_database_cnt"] > 1)
        & (df["measure"].isin(["AVERAGE", "DAY_COUNT"]))
    ]

    for cdb in sorted(df["Use Values from Database Name"].unique()):
        lg("     Beginning cdb " + str(cdb) + "...")

        tb = time.time()

        pDf = df[(df["Use Values from Database Name"] == cdb)].copy()

        if len(pDf) == 0:
            lg("          Skipping 0-length cdb: " + str(cdb))
            continue

        if PLOT_HTML:
            filePathHTML = (
                plotFilePath + os.sep + "primary_standby_totals" + os.sep + "html"
            )
            os.makedirs(filePathHTML, exist_ok=True)

        if PLOT_PNG:
            filePathPNG = (
                plotFilePath + os.sep + "primary_standby_totals" + os.sep + "png"
            )
            os.makedirs(filePathPNG, exist_ok=True)

        plotCtr = 0

        pDf.sort_values(
            ["measure", "metric", "cdb_label"],
            ascending=[True, True, False],
            inplace=True,
        )

        fig = px.bar(
            pDf,
            x="cdb_label",
            y="value",
            facet_row="metric",
            color="cdb_label",
            facet_col="measure",
            facet_col_wrap=FACET_COLS,
            title=format_title(
                customer
                + " : "
                + str(cdb)
                + " : Primary/Standby Average Metric Value Totals & Day Counts (Chart Version "
                + __version__
                + ")",
                "1 OCPU = 2 vCPU",
                20,
            ),
            template="seaborn",
            width=WIDTH,
            height=HEIGHT,
        )

        fig.update_layout(
            font={"size": 16},
            legend_font_size=12,
            autosize=False,
            width=WIDTH,
            height=HEIGHT,
            margin=dict(t=150),
        )
        fig.update_xaxes(matches=None, visible=False)
        fig.update_yaxes(matches=None, showticklabels=True)

        for t in fig.layout.annotations:
            if "text" in t:
                p1, p2 = t["text"].split("=")
                if p1 == "metric":
                    t["text"] = p2

        if PLOT_HTML:
            filenameHTML = (
                filePathHTML + os.sep + str(cdb) + "_primary_standby_totals.html"
            )
            dashboard = open(filenameHTML, "w")
            HTMLhead = (
                customer
                + " : "
                + str(cdb)
                + " (occa_Rduce_DB_Metrics, Chart Version "
                + __version__
                + ")"
            )

            dashboard.write(
                "<html><head><title>" + HTMLhead + "</title></head><body>" + "\n"
            )

        if PLOT_PNG:
            filenamePNG = (
                filePathPNG + os.sep + str(cdb) + "_primary_standby_totals.png"
            )

        if PLOT_HTML:
            inner_html = (
                fig.to_html(include_plotlyjs=True)
                .split("<body>")[1]
                .split("</body>")[0]
            )
            dashboard.write(inner_html)

            dashboard.write("</body></html>" + "\n")
            dashboard.close()

            plotCtr += 1

        if PLOT_PNG:
            fig.write_image(filenamePNG)

            plotCtr += 1

        lg(
            "     Created "
            + str(plotCtr)
            + " plots for "
            + str(cdb)
            + " in directories rooted at "
            + plotFilePath
            + " in "
            + str(round(time.time() - tb, 3))
            + " s\n"
        )


# ----------------------------------------------------------------------------------------------------------------------

extractFilePath = ROOT_DIR + os.sep + "emcc_sizing_extracts"
outputFilePath = ROOT_DIR + os.sep + "occa_sizing_output"
plotFilePath = outputFilePath + os.sep + "plots"

h, t = os.path.split(sys.argv[0])
logFilename = outputFilePath + os.sep + "log" + os.sep + t + ".log"
os.makedirs(outputFilePath + os.sep + "log", exist_ok=True)
logFile = open_log(logFilename)

lg(
    "\n=======================================================================================================\n"
)
lg(
    "Begin @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)
lg(sys.argv[0] + ", version " + __version__ + "\n")
lg("sys.version_info  : " + str(sys.version_info))
lg("platform.system() : " + str(platform.system()))

lg("pandas.__version__: " + pd.__version__)

if PLOT_HTML or PLOT_PNG:
    import plotly as plt
    import plotly.express as px

    lg("plotly.__version__: " + plt.__version__)

lg(
    "\n=======================================================================================================\n"
)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n=======================================================================================================\n"
)

lg("FIXED                      : " + str(FIXED))
lg("PLOT_HTML                  : " + str(PLOT_HTML))
lg("PLOT_PNG                   : " + str(PLOT_PNG))
lg("PRECISION                  : " + str(PRECISION))
lg("TIME_PERIODS               : " + str(TIME_PERIODS))

lg(
    "\n=======================================================================================================\n"
)

if args.parameters is not None:
    quit()

# ----------------------------------------------------------------------------------------------------------------------

if FIXED:
    cwd = "fixed"
    now = "1989-07-09 00:00:00"
    platformName = "fixed"
    __version__ = "fixed"
else:
    cwd = os.getcwd().split(os.sep)[-1]
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    platformName = platform.system()

startTime = time.time()

# ---

filename = outputFilePath + os.sep + "sizing" + os.sep + "databases.csv"

if not os.path.exists(filename):
    lg("File " + filename + " does not exist; cannot continue")
    quit()

lg("Loading file " + filename + "...")
cdbsDf = pd.read_csv(filename)
lg("Loaded " + str(len(cdbsDf)) + " rows")

extract_dttm_utc = cdbsDf["extract_dttm_utc"].unique()[0]

cdbsDf = cdbsDf[
    [
        "excluded",
        "cdb_cohort",
        "cdb",
        "cdb_standby_type",
        "Use Values from Database Name",
        "Use Values Scope",
        "Use Values Pct",
        "cdb_target_guid",
    ]
]
cdbsDf["excluded"].fillna("", inplace=True)
cdbsDf["Use Values from Database Name"].fillna("", inplace=True)
cdbsDf["cdb_standby_type"].fillna("unknown", inplace=True)
cdbsDf["cdb_label"] = cdbsDf["cdb_standby_type"] + "." + cdbsDf["cdb"]

cdbsDf.loc[
    cdbsDf["Use Values from Database Name"] == "", "Use Values from Database Name"
] = cdbsDf["cdb"]
cdbsDf["used_by_database_cnt"] = cdbsDf.groupby(["Use Values from Database Name"])[
    "cdb"
].transform("count")

cdbsDf["primary_flag"] = 0
cdbsDf.loc[cdbsDf["cdb"] == cdbsDf["Use Values from Database Name"], "primary_flag"] = 1

# ---

filename = outputFilePath + os.sep + "sizing" + os.sep + "instances.csv"

if not os.path.exists(filename):
    lg("File " + filename + " does not exist; cannot continue")
    quit()

lg("\nLoading file " + filename + "...")
instancesDf = pd.read_csv(filename)
lg("Loaded " + str(len(instancesDf)) + " rows")

dbDf = instancesDf[
    [
        "excluded",
        "cdb",
        "db",
        "ma",
        "db_cpu_count_limit",
        "logical_cpu_count",
        "total_cpu_cores",
        "cdb_target_guid",
        "db_target_guid",
    ]
].drop_duplicates()
dbDf["excluded"].fillna("", inplace=True)

# Process database metrics

tb = time.time()
hourlyMetricsDf = []

filename = extractFilePath + os.sep + DB_METRICS_FILE

if not os.path.exists(filename):
    lg("File " + filename + " does not exist; cannot continue")
    quit()

lg("\nLoading file " + filename + "...")
metricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])
metricsDf.columns = [c.strip() for c in metricsDf.columns]
metricsDf["metric"] = metricsDf["METRIC_NAME"] + "." + metricsDf["METRIC_COLUMN"]

storageMetricsDf = metricsDf[
    (
        metricsDf["metric"].isin(EMCC_STORAGE_METRICS)
        & metricsDf["TARGET_GUID"].isin(cdbsDf["cdb_target_guid"])
    )
].copy()

if len(storageMetricsDf) == 0:
    lg("Telemetry file " + filename + " has no storage hourly metrics")
else:
    #
    # Round storage metric timestamps to the nearest day & eliminate duplicates
    #
    storageMetricsDf["ROLLUP_TIMESTAMP_UTC_normalized"] = storageMetricsDf[
        "ROLLUP_TIMESTAMP_UTC"
    ].dt.normalize()
    storageMetricsDf["ROLLUP_TIMESTAMP_UTC_max"] = storageMetricsDf.groupby(
        ["TARGET_GUID", "metric", "ROLLUP_TIMESTAMP_UTC_normalized"]
    )["ROLLUP_TIMESTAMP_UTC"].transform(max)

    storageMetricsDf = storageMetricsDf[
        storageMetricsDf["ROLLUP_TIMESTAMP_UTC"]
        == storageMetricsDf["ROLLUP_TIMESTAMP_UTC_max"]
    ]
    storageMetricsDf["ROLLUP_TIMESTAMP_UTC"] = storageMetricsDf[
        "ROLLUP_TIMESTAMP_UTC_normalized"
    ]
    storageMetricsDf["SAMPLE_COUNT"] = 1

    storageMetricsDf.rename(
        columns={"TARGET_GUID": "cdb_target_guid", "TARGET_NAME": "cdb"}, inplace=True
    )

    if 1 == 0:
        filename = (
            outputFilePath + os.sep + "sizing" + os.sep + "storage_hourly_metrics.csv"
        )
        storageMetricsDf.to_csv(filename, index=False)

        lg("\nWrote " + str(len(storageMetricsDf)) + " rows to file " + filename)

    storageMetricsDf = (
        storageMetricsDf.groupby(["cdb", "cdb_target_guid", "metric"])[
            ["AVERAGE", "SAMPLE_COUNT"]
        ]
        .describe(percentiles=PERCENTILES)
        .reset_index()
    )
    storageMetricsDf.columns = [
        c[0] if c[1] == "" else c[0] + "_" + c[1] for c in storageMetricsDf.columns
    ]

    hourlyMetricsDf = storageMetricsDf

# ---

metricsDf = metricsDf[metricsDf["metric"].isin(EMCC_INSTANCE_METRICS)].copy()

lg(
    "Loaded "
    + str(len(metricsDf))
    + " instance metrics from "
    + filename
    + " in "
    + str(round(time.time() - tb, 3))
    + " s"
)
lg(
    "Loaded "
    + str(len(storageMetricsDf))
    + " storage metrics from "
    + filename
    + " in "
    + str(round(time.time() - tb, 3))
    + " s"
)
lg("Time since start " + str(round(time.time() - startTime, 3)) + " s\n")

# ---

if len(metricsDf) == 0:
    lg("Telemetry file " + filename + " has no instance hourly metrics")
else:
    tb = time.time()

    metricsDf = pd.merge(
        left=metricsDf,
        right=dbDf[
            [
                "cdb",
                "cdb_target_guid",
                "db_target_guid",
                "db_cpu_count_limit",
                "total_cpu_cores",
                "ma",
            ]
        ],
        how="right",
        left_on="TARGET_GUID",
        right_on="db_target_guid",
    )

    if "impl" not in metricsDf:
        metricsDf["cpu_type"] = metricsDf.apply(
            lambda r: getCPUType(r["ma"], ""), axis=1
        )
    else:
        metricsDf["cpu_type"] = metricsDf.apply(
            lambda r: getCPUType(r["ma"], r["impl"]), axis=1
        )

    lg(
        "Created "
        + str(len(metricsDf))
        + " instance hourly metrics in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "MINIMUM"] = round(
        metricsDf["MINIMUM"] / 100, PRECISION
    )
    metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "AVERAGE"] = round(
        metricsDf["AVERAGE"] / 100, PRECISION
    )
    metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "MAXIMUM"] = round(
        metricsDf["MAXIMUM"] / 100, PRECISION
    )

    # Adjust for how IBM captures core consumption

    metricsDf.loc[
        (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
        "MINIMUM",
    ] = round(metricsDf["MINIMUM"] * AIX_DEFLATION, PRECISION)
    metricsDf.loc[
        (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
        "AVERAGE",
    ] = round(metricsDf["AVERAGE"] * AIX_DEFLATION, PRECISION)
    metricsDf.loc[
        (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
        "MAXIMUM",
    ] = round(metricsDf["MAXIMUM"] * AIX_DEFLATION, PRECISION)

    # Throw out metrics that are clearly anomalous

    metricsDf.loc[
        (metricsDf["metric"] == CPU_METRIC)
        & (metricsDf["MINIMUM"] > metricsDf["db_cpu_count_limit"]),
        "MINIMUM",
    ] = metricsDf["db_cpu_count_limit"]
    metricsDf.loc[
        (metricsDf["metric"] == CPU_METRIC)
        & (metricsDf["AVERAGE"] > metricsDf["db_cpu_count_limit"]),
        "AVERAGE",
    ] = metricsDf["db_cpu_count_limit"]
    metricsDf.loc[
        (metricsDf["metric"] == CPU_METRIC)
        & (metricsDf["MAXIMUM"] > metricsDf["db_cpu_count_limit"]),
        "MAXIMUM",
    ] = metricsDf["db_cpu_count_limit"]

    metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "metric"] = CPU_DERIVED_METRIC

    lg(
        "Reduced instance hourly metrics to "
        + str(len(metricsDf))
        + " rows in "
        + str(round(time.time() - tb, 3))
        + " s"
    )

    # ---

    cdbMetricsDf = metricsDf.groupby(
        ["cdb", "cdb_target_guid", "metric", "ROLLUP_TIMESTAMP_UTC"], as_index=False
    )[["AVERAGE", "SAMPLE_COUNT"]].sum()

    if 1 == 0:
        filename = (
            outputFilePath + os.sep + "sizing" + os.sep + "cdb_hourly_metrics.csv"
        )
        cdbMetricsDf.to_csv(filename, index=False)

        lg("\nWrote " + str(len(cdbMetricsDf)) + " rows to file " + filename)

    cdbMetricsDf = (
        cdbMetricsDf.groupby(["cdb", "cdb_target_guid", "metric"])[
            ["AVERAGE", "SAMPLE_COUNT"]
        ]
        .describe(percentiles=PERCENTILES)
        .reset_index()
    )
    cdbMetricsDf.columns = [
        c[0] if c[1] == "" else c[0] + "_" + c[1] for c in cdbMetricsDf.columns
    ]

    metricsDf = []

    hourlyMetricsDf = (
        cdbMetricsDf
        if len(hourlyMetricsDf) == 0
        else pd.concat([cdbMetricsDf, hourlyMetricsDf], ignore_index=True)
    )

if len(hourlyMetricsDf) > 0:
    hourlyMetricsDf["time_unit"] = "HOURLY"

    if 1 == 0:
        filename = (
            outputFilePath
            + os.sep
            + "sizing"
            + os.sep
            + "reduced_db_hourly_metrics.csv"
        )
        hourlyMetricsDf.to_csv(filename, index=False)

        lg("\nWrote " + str(len(hourlyMetricsDf)) + " rows to file " + filename)

cdbMetricsDf, storageMetricsDf = [], []

# ----------------------------------------------------------------------------------------------------------------------

tb0 = time.time()
dailyMetricsDf = []

lg("\nLoading db daily metrics...")

for time_period in TIME_PERIODS:
    lg("\n     Loading db daily metrics for time period: " + time_period + "...")
    filename = (
        extractFilePath
        + os.sep
        + "emcc_sizing_metrics_db_daily_"
        + time_period
        + "_months.csv"
    )

    if not os.path.exists(filename):
        lg(
            "     Telemetry file "
            + filename
            + " is missing; continuing with next time period"
        )
        continue

    tb = time.time()

    metricsDf = pd.read_csv(filename, parse_dates=["ROLLUP_TIMESTAMP_UTC"])

    if len(metricsDf) == 0:
        lg(
            "     Telemetry file "
            + filename
            + " is empty; continuing with next time period"
        )
        continue

    metricsDf.columns = [c.strip() for c in metricsDf.columns]
    metricsDf["metric"] = metricsDf["METRIC_NAME"] + "." + metricsDf["METRIC_COLUMN"]

    # ---

    storageMetricsDf = metricsDf[
        (
            metricsDf["metric"].isin(EMCC_STORAGE_METRICS)
            & metricsDf["TARGET_GUID"].isin(cdbsDf["cdb_target_guid"])
        )
    ].copy()

    if len(storageMetricsDf) > 0:
        storageMetricsDf["ROLLUP_TIMESTAMP_UTC"] = storageMetricsDf[
            "ROLLUP_TIMESTAMP_UTC"
        ].dt.normalize()
        storageMetricsDf.rename(
            columns={"TARGET_GUID": "cdb_target_guid", "TARGET_NAME": "cdb"},
            inplace=True,
        )

        storageMetricsDf = storageMetricsDf[
            [
                "cdb",
                "cdb_target_guid",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "AVERAGE",
                "SAMPLE_COUNT",
            ]
        ]
        dailyMetricsDf = (
            storageMetricsDf
            if len(dailyMetricsDf) == 0
            else pd.concat([dailyMetricsDf, storageMetricsDf], ignore_index=True)
        )

    # ---

    metricsDf = metricsDf[metricsDf["metric"].isin(EMCC_INSTANCE_METRICS)]

    lg(
        "     Loaded "
        + str(len(metricsDf))
        + " instance metrics from "
        + filename
        + " in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg(
        "     Loaded "
        + str(len(storageMetricsDf))
        + " storage metrics from "
        + filename
        + " in "
        + str(round(time.time() - tb, 3))
        + " s"
    )
    lg("     Time since start " + str(round(time.time() - startTime, 3)) + " s\n")

    if len(metricsDf) == 0:
        lg("     Telemetry file " + filename + " has no instance daily metrics")

    if len(storageMetricsDf) == 0:
        lg("     Telemetry file " + filename + " has no storage daily metrics")

    if len(metricsDf) == 0 and len(storageMetricsDf) == 0:
        continue

    # ---

    if len(metricsDf) > 0:
        tb = time.time()

        metricsDf["ROLLUP_TIMESTAMP_UTC"] = metricsDf[
            "ROLLUP_TIMESTAMP_UTC"
        ].dt.normalize()

        metricsDf = pd.merge(
            left=metricsDf,
            right=dbDf[
                [
                    "cdb",
                    "cdb_target_guid",
                    "db_target_guid",
                    "db_cpu_count_limit",
                    "total_cpu_cores",
                    "ma",
                ]
            ],
            how="left",
            left_on=["TARGET_GUID"],
            right_on=["db_target_guid"],
        )

        if "impl" not in metricsDf:
            metricsDf["cpu_type"] = metricsDf.apply(
                lambda r: getCPUType(r["ma"], ""), axis=1
            )
        else:
            metricsDf["cpu_type"] = metricsDf.apply(
                lambda r: getCPUType(r["ma"], r["impl"]), axis=1
            )

        lg(
            "     Created "
            + str(len(metricsDf))
            + " instance daily metrics in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        # ---

        tb = time.time()

        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "MINIMUM"] = round(
            metricsDf["MINIMUM"] / 100, PRECISION
        )
        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "AVERAGE"] = round(
            metricsDf["AVERAGE"] / 100, PRECISION
        )
        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "MAXIMUM"] = round(
            metricsDf["MAXIMUM"] / 100, PRECISION
        )

        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
            "MINIMUM",
        ] = round(metricsDf["MINIMUM"] * AIX_DEFLATION, PRECISION)
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
            "AVERAGE",
        ] = round(metricsDf["AVERAGE"] * AIX_DEFLATION, PRECISION)
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC) & (metricsDf["cpu_type"] == "IBM"),
            "MAXIMUM",
        ] = round(metricsDf["MAXIMUM"] * AIX_DEFLATION, PRECISION)

        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC)
            & (metricsDf["MINIMUM"] > metricsDf["db_cpu_count_limit"]),
            "MINIMUM",
        ] = metricsDf["db_cpu_count_limit"]
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC)
            & (metricsDf["AVERAGE"] > metricsDf["db_cpu_count_limit"]),
            "AVERAGE",
        ] = metricsDf["db_cpu_count_limit"]
        metricsDf.loc[
            (metricsDf["metric"] == CPU_METRIC)
            & (metricsDf["MAXIMUM"] > metricsDf["db_cpu_count_limit"]),
            "MAXIMUM",
        ] = metricsDf["db_cpu_count_limit"]

        metricsDf.loc[metricsDf["metric"] == CPU_METRIC, "metric"] = CPU_DERIVED_METRIC

        lg(
            "     Reduced instance daily metrics to "
            + str(len(metricsDf))
            + " rows in "
            + str(round(time.time() - tb, 3))
            + " s"
        )

        # ---

        metricsDf = metricsDf[
            [
                "cdb",
                "cdb_target_guid",
                "metric",
                "ROLLUP_TIMESTAMP_UTC",
                "AVERAGE",
                "SAMPLE_COUNT",
            ]
        ]
        dailyMetricsDf = (
            metricsDf
            if len(dailyMetricsDf) == 0
            else pd.concat([dailyMetricsDf, metricsDf], ignore_index=True)
        )

# ---

dailyTotalsDf = []

if len(dailyMetricsDf) > 0:
    dailyMetricsDf["DAY_COUNT"] = 1

    dailyTotalsDf = (
        dailyMetricsDf.groupby(["cdb_target_guid", "metric"])[
            ["AVERAGE", "DAY_COUNT", "SAMPLE_COUNT"]
        ]
        .sum()
        .reset_index()
    )
    dailyTotalsDf = dailyTotalsDf.melt(id_vars=["cdb_target_guid", "metric"])

    dailyTotalsDf.rename(columns={"variable": "measure"}, inplace=True)

    dailyTotalsDf["rollup_type"] = "AVERAGE"
    dailyTotalsDf["time_unit"] = "DAILY"

    dailyTotalsDf.loc[dailyTotalsDf["metric"] == STORAGE_ALLOCATED_METRIC, "metric"] = (
        EMCC_METRIC_COULMN_ALIASES[STORAGE_ALLOCATED_METRIC]
    )
    dailyTotalsDf.loc[dailyTotalsDf["metric"] == STORAGE_USED_METRIC, "metric"] = (
        EMCC_METRIC_COULMN_ALIASES[STORAGE_USED_METRIC]
    )
    dailyTotalsDf.loc[dailyTotalsDf["metric"] == CPU_DERIVED_METRIC, "metric"] = (
        EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC]
    )
    dailyTotalsDf.loc[dailyTotalsDf["metric"] == PGA_METRIC, "metric"] = (
        EMCC_METRIC_COULMN_ALIASES[PGA_METRIC]
    )
    dailyTotalsDf.loc[dailyTotalsDf["metric"] == SGA_METRIC, "metric"] = (
        EMCC_METRIC_COULMN_ALIASES[SGA_METRIC]
    )
    dailyTotalsDf.loc[dailyTotalsDf["metric"] == IOPS_METRIC, "metric"] = (
        EMCC_METRIC_COULMN_ALIASES[IOPS_METRIC]
    )
    dailyTotalsDf.loc[dailyTotalsDf["metric"] == LOGONS_METRIC, "metric"] = (
        EMCC_METRIC_COULMN_ALIASES[LOGONS_METRIC]
    )

    dailyTotalsDf = dailyTotalsDf.round(PRECISION)

    dailyTotalsDf = pd.merge(
        left=cdbsDf,
        right=dailyTotalsDf,
        how="left",
        left_on=["cdb_target_guid"],
        right_on=["cdb_target_guid"],
    )

    dailyTotalsDf["cwd"] = cwd
    dailyTotalsDf["platform"] = platformName
    dailyTotalsDf["extract_dttm_utc"] = extract_dttm_utc
    dailyTotalsDf["create_dttm_utc"] = now
    dailyTotalsDf["version"] = __version__

    filename = (
        outputFilePath
        + os.sep
        + "sizing"
        + os.sep
        + "reduced_db_metrics_daily_totals.csv"
    )
    dailyTotalsDf.sort_values(
        ["Use Values from Database Name", "cdb_label", "metric", "measure"],
        ascending=[True, False, True, True],
    ).to_csv(filename, index=False)

    lg("\nWrote " + str(len(dailyTotalsDf)) + " rows to file " + filename)

    # ---

    dailyMetricsDf = (
        dailyMetricsDf.groupby(["cdb", "cdb_target_guid", "metric"])[
            ["AVERAGE", "SAMPLE_COUNT"]
        ]
        .describe(percentiles=PERCENTILES)
        .reset_index()
    )
    dailyMetricsDf.columns = [
        c[0] if c[1] == "" else c[0] + "_" + c[1] for c in dailyMetricsDf.columns
    ]

    dailyMetricsDf["time_unit"] = "DAILY"

    if 1 == 0:
        filename = (
            outputFilePath + os.sep + "sizing" + os.sep + "reduced_db_daily_metrics.csv"
        )
        dailyMetricsDf.to_csv(filename, index=False)

        lg("\nWrote " + str(len(dailyMetricsDf)) + " rows to file " + filename)

# ---

metricsDf, storageMetricsDf = [], []

if len(hourlyMetricsDf) > 0:
    metricsDf = hourlyMetricsDf

if len(metricsDf) == 0:
    metricsDf = dailyMetricsDf
elif len(dailyMetricsDf) > 0:
    metricsDf = pd.concat([metricsDf, dailyMetricsDf])

metricsDf = metricsDf.melt(id_vars=["cdb_target_guid", "metric", "time_unit"])

metricsDf["measure"] = "SAMPLE_COUNT"
metricsDf.loc[metricsDf["variable"].str.find("AVERAGE") > -1, "measure"] = "AVERAGE"

metricsDf["variable"] = metricsDf["variable"].str.strip("AVERAGE_")
metricsDf["variable"] = metricsDf["variable"].str.strip("SAMPLE_COUNT_")

metricsDf.loc[metricsDf["variable"] == "min", "variable"] = "0%"
metricsDf.loc[metricsDf["variable"] == "max", "variable"] = "100%"

metricsDf = metricsDf[metricsDf["variable"].str.find("%") > -1]
metricsDf.loc[:, "variable"] = metricsDf["variable"].str.rstrip("%")
metricsDf["variable"] = metricsDf["variable"].astype(int) / 100
metricsDf["rollup_type"] = "AVERAGE"
metricsDf.rename(columns={"variable": "pct"}, inplace=True)

metricsDf.loc[metricsDf["metric"] == STORAGE_ALLOCATED_METRIC, "metric"] = (
    EMCC_METRIC_COULMN_ALIASES[STORAGE_ALLOCATED_METRIC]
)
metricsDf.loc[metricsDf["metric"] == STORAGE_USED_METRIC, "metric"] = (
    EMCC_METRIC_COULMN_ALIASES[STORAGE_USED_METRIC]
)
metricsDf.loc[metricsDf["metric"] == CPU_DERIVED_METRIC, "metric"] = (
    EMCC_METRIC_COULMN_ALIASES[CPU_DERIVED_METRIC]
)
metricsDf.loc[metricsDf["metric"] == PGA_METRIC, "metric"] = EMCC_METRIC_COULMN_ALIASES[
    PGA_METRIC
]
metricsDf.loc[metricsDf["metric"] == SGA_METRIC, "metric"] = EMCC_METRIC_COULMN_ALIASES[
    SGA_METRIC
]
metricsDf.loc[metricsDf["metric"] == IOPS_METRIC, "metric"] = (
    EMCC_METRIC_COULMN_ALIASES[IOPS_METRIC]
)
metricsDf.loc[metricsDf["metric"] == LOGONS_METRIC, "metric"] = (
    EMCC_METRIC_COULMN_ALIASES[LOGONS_METRIC]
)

finalDf = pd.merge(
    left=cdbsDf,
    right=metricsDf,
    how="left",
    left_on=["cdb_target_guid"],
    right_on=["cdb_target_guid"],
)
finalDf["pct"] = finalDf["pct"] * 100

finalDf = finalDf.round(PRECISION)

finalDf["cwd"] = cwd
finalDf["platform"] = platformName
finalDf["extract_dttm_utc"] = extract_dttm_utc
finalDf["create_dttm_utc"] = now
finalDf["version"] = __version__

filename = outputFilePath + os.sep + "sizing" + os.sep + "reduced_db_metrics.csv"
finalDf.sort_values(
    [
        "Use Values from Database Name",
        "cdb_label",
        "metric",
        "measure",
        "time_unit",
        "pct",
    ],
    ascending=[True, False, True, True, True, True],
).to_csv(filename, index=False)

lg("\nWrote " + str(len(finalDf)) + " rows to file " + filename)

lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

ratiosDf = finalDf[finalDf["used_by_database_cnt"] > 1].copy()

if len(ratiosDf) > 0:
    ratiosDf["value"] = ratiosDf["value"].astype(float)

    ratiosPrimaryDf = ratiosDf[ratiosDf["cdb_standby_type"] == "Primary"].copy()
    ratiosStandByDf = ratiosDf[ratiosDf["cdb_standby_type"] != "Primary"]

    ratiosPrimaryDf = ratiosPrimaryDf[
        [
            "excluded",
            "cdb_cohort",
            "cdb",
            "Use Values from Database Name",
            "cdb_target_guid",
            "cdb_label",
            "metric",
            "time_unit",
            "pct",
            "value",
            "measure",
        ]
    ]
    ratiosPrimaryDf.columns = [
        "excluded_primary",
        "cdb_cohort_primary",
        "cdb_primary",
        "Use Values from Database Name",
        "cdb_target_guid_primary",
        "cdb_label_primary",
        "metric",
        "time_unit",
        "pct",
        "value_primary",
        "measure",
    ]

    ratiosDf = pd.merge(
        left=ratiosPrimaryDf,
        right=ratiosStandByDf,
        how="inner",
        left_on=[
            "Use Values from Database Name",
            "metric",
            "time_unit",
            "pct",
            "measure",
        ],
        right_on=[
            "Use Values from Database Name",
            "metric",
            "time_unit",
            "pct",
            "measure",
        ],
    )

    ratiosDf["standby_pct"] = -1.0

    ratiosDf.loc[ratiosDf["value_primary"] > 0, "standby_pct"] = (
        ratiosDf["value"] / ratiosDf["value_primary"]
    ) * 100

    startCols = [
        "cdb_cohort_primary",
        "cdb_primary",
        "cdb_cohort",
        "cdb",
        "cdb_standby_type",
        "metric",
        "measure",
        "time_unit",
        "pct",
        "value_primary",
        "value",
        "standby_pct",
        "Use Values Scope",
        "Use Values Pct",
        "excluded_primary",
        "excluded",
    ]
    finalCols = [
        "rollup_type",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]

    middleCols = [
        c for c in ratiosDf.columns if c not in startCols and c not in finalCols
    ]

    ratiosDf = ratiosDf[startCols + middleCols + finalCols]
    ratiosDf = ratiosDf.round(PRECISION)

    ratiosDf.rename(
        columns={
            "cdb_cohort": "cdb_cohort_standby",
            "cdb": "cdb_standby",
            "cdb_label": "cdb_label_standby",
            "cdb_target_guid": "cdb_target_guid_standby",
            "excluded": "excluded_standby",
            "value": "value_standby",
        },
        inplace=True,
    )
    ratiosDf.drop(columns=["primary_flag"], inplace=True)

    filename = (
        outputFilePath + os.sep + "sizing" + os.sep + "reduced_db_metrics_ratios.csv"
    )
    ratiosDf.sort_values(
        ["cdb_primary", "cdb_standby", "metric", "measure", "time_unit", "pct"]
    ).to_csv(filename, index=False)

    lg("\nWrote " + str(len(ratiosDf)) + " rows to file " + filename)

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

    ratiosPrimaryDf, ratiosStandByDf = [], []

# ---

dailyTotalRatiosDf = []

if len(dailyTotalsDf) > 0:
    dailyTotalRatiosDf = dailyTotalsDf[dailyTotalsDf["used_by_database_cnt"] > 1].copy()

if len(dailyTotalRatiosDf) > 0:
    dailyTotalRatiosDf["value"] = dailyTotalRatiosDf["value"].astype(float)

    totalsPrimaryDf = dailyTotalRatiosDf[
        dailyTotalRatiosDf["cdb_standby_type"] == "Primary"
    ].copy()
    totalsStandByDf = dailyTotalRatiosDf[
        dailyTotalRatiosDf["cdb_standby_type"] != "Primary"
    ]

    totalsPrimaryDf = totalsPrimaryDf[
        [
            "excluded",
            "cdb_cohort",
            "cdb",
            "Use Values from Database Name",
            "cdb_target_guid",
            "cdb_label",
            "metric",
            "time_unit",
            "value",
            "measure",
        ]
    ]
    totalsPrimaryDf.columns = [
        "excluded_primary",
        "cdb_cohort_primary",
        "cdb_primary",
        "Use Values from Database Name",
        "cdb_target_guid_primary",
        "cdb_label_primary",
        "metric",
        "time_unit",
        "value_primary",
        "measure",
    ]

    dailyTotalRatiosDf = pd.merge(
        left=totalsPrimaryDf,
        right=totalsStandByDf,
        how="inner",
        left_on=["Use Values from Database Name", "metric", "time_unit", "measure"],
        right_on=["Use Values from Database Name", "metric", "time_unit", "measure"],
    )

    dailyTotalRatiosDf["standby_pct"] = -1.0

    dailyTotalRatiosDf.loc[dailyTotalRatiosDf["value_primary"] > 0, "standby_pct"] = (
        dailyTotalRatiosDf["value"] / dailyTotalRatiosDf["value_primary"]
    ) * 100

    startCols = [
        "cdb_cohort_primary",
        "cdb_primary",
        "cdb_cohort",
        "cdb",
        "cdb_standby_type",
        "metric",
        "measure",
        "time_unit",
        "value_primary",
        "value",
        "standby_pct",
        "Use Values Scope",
        "Use Values Pct",
        "excluded_primary",
        "excluded",
    ]
    finalCols = [
        "rollup_type",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "version",
    ]

    middleCols = [
        c
        for c in dailyTotalRatiosDf.columns
        if c not in startCols and c not in finalCols
    ]

    dailyTotalRatiosDf = dailyTotalRatiosDf[startCols + middleCols + finalCols]
    dailyTotalRatiosDf = dailyTotalRatiosDf.round(PRECISION)

    dailyTotalRatiosDf.rename(
        columns={
            "cdb_cohort": "cdb_cohort_standby",
            "cdb": "cdb_standby",
            "cdb_label": "cdb_label_standby",
            "cdb_target_guid": "cdb_target_guid_standby",
            "excluded": "excluded_standby",
            "value": "value_standby",
        },
        inplace=True,
    )
    dailyTotalRatiosDf.drop(columns=["primary_flag"], inplace=True)

    filename = (
        outputFilePath
        + os.sep
        + "sizing"
        + os.sep
        + "reduced_db_metrics_daily_totals_ratios.csv"
    )
    dailyTotalRatiosDf.sort_values(
        ["cdb_primary", "cdb_standby", "metric", "measure", "time_unit"]
    ).to_csv(filename, index=False)

    lg("\nWrote " + str(len(dailyTotalRatiosDf)) + " rows to file " + filename)

    lg("\nTime since start " + str(round(time.time() - startTime, 3)) + " s")

# ---

if PLOT_HTML or PLOT_PNG:
    plotMetrics(finalDf)

    if len(ratiosDf) > 0:
        plotPercentileHistograms(ratiosDf)

    if len(dailyTotalRatiosDf) > 0:
        plotTotalHistograms(dailyTotalRatiosDf)

    if len(dailyTotalsDf) > 0:
        plotMetricTotals(dailyTotalsDf)

# ----------------------------------------------------------------------------------------------------------------------

lg(
    "\n\nAll files written to directories rooted @ "
    + (cwd if ROOT_DIR == "." else ROOT_DIR)
)
lg("\nProcessing completed in " + str(round(time.time() - startTime, 3)) + " s")

lg(
    "\nEnd @ "
    + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    + " UTC\n"
)

close_Log()
