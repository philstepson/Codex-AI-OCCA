from constants.Paths import FilePaths as fp

import pandas as pd
from pathlib import Path
import shutil, csv, os
from file_manager.FileSystemHandler import DirectoryHandler


def is_valid_folder_structure(directory: Path) -> bool:
    """
    Checks if the folder structure is valid, meaning if each .out file
    is inside its own folder (Cohort-Structure) , and if there are 2 or more subfolders.
    Parameters
    ----------
    directory : Path

    Returns
    -------
    bool, path
         Returns True if the structure is valid (cohort-structure with 2+ folders), False otherwise.
         and the reformed Path  None if not valid


    For cohort structure, the desired folder structure should be:
    users.zip -> (unzipped creates)
    users/
    └── awr_miner_out/
        ├── CohortA/
        │   └── <somefiles>.out
        ├── CohortB/
        │   └── <somefiles>.out
        └── CohortC/
            └── <somefiles>.out

    Think of it like a "quantum state" where the structure could exist in multiple forms,
    but we want to collapse it into this specific path.

    We need to restructure to move cohort folders inside awr_miner_out. Sometimes we see:
    users/
    └── another_folder/
        └── awr_miner_out/
            ├── CohortA/
            │   └── <somefiles>.out
            ├── CohortB/
            │   └── <somefiles>.out
            └── CohortC/
                └── <somefiles>.out

    In this case, we need to get rid of the "another_folder" and move everything up.
    """
    out_files = list(directory.rglob("*.out"))
    total_out_files = len(out_files)

    subdir_out_files = 0  # Files under folder
    valid_folder = 0  # folders that contain .out files
    awr_miner_out_path = None
    subdirs_with_out_files = []

    # Logic to see if every .out is within a Folder
    for root, dirs, files in os.walk(directory):
        if dirs:  # If there are subfolders, we check them
            for subdir in dirs:
                subdir_path = Path(root) / subdir
                if subdir == "awr_miner_out":
                    awr_miner_out_path = subdir_path

                subdir_path = Path(root) / subdir
                out_files_in_subdir = [
                    file for file in os.listdir(subdir_path) if file.endswith(".out")
                ]
                subdir_out_files += len(out_files_in_subdir)
                if out_files_in_subdir:
                    valid_folder += 1
                    subdirs_with_out_files.append(subdir_path)

    # needed to create the desired path and move subdirs that contain the .out files
    if (
        valid_folder >= 2
        and subdir_out_files > 0
        and subdir_out_files == total_out_files
    ):
        awr_miner_out_path = directory / "awr_miner_out"
        awr_miner_out_path.mkdir(exist_ok=True)  # Create the 'awr_miner_out' directory
        # Move each valid subfolder to directory / 'awr_miner_out'
        for subdir in subdirs_with_out_files:
            target_path = awr_miner_out_path / subdir.name
            if not target_path.exists():
                shutil.move(str(subdir), str(awr_miner_out_path))

        DirectoryHandler.prune_empty_dirs(directory)
        return True, awr_miner_out_path

    return False, None


def move_out_files(base_path: Path, all_out_files: list):
    """
    Moves all .out files from cohort directories in base_path to the base_path root directory,
    and removes the cohort directories after moving the files.

    Parameters
    ----------
    base_path : Path
        The base directory where cohort folders and .out files are expected to be found.

    Returns
    -------
    None
    """

    for out_file in all_out_files:
        destination = base_path / out_file.name
        shutil.move(str(out_file), str(destination))  # Move the file

    # Remove all empty cohort directories
    for cohort_dir in base_path.iterdir():
        if cohort_dir.is_dir() and not any(cohort_dir.iterdir()):
            os.rmdir(cohort_dir)  # Remove the empty directory

    print(
        f"All .out files have been moved to {base_path}, and cohort directories have been removed."
    )


def validate_and_map_out_files(base_path: Path):
    """
    Iterates over cohort directories in the base_path and maps .out files to their respective cohort.
    If an .out file is found in the root of the base_path, the process will stop and notify the user.

    It wll end up like following:
    Cohort    WHICH_DB
    FolderA   db_aloha_mew_miau_1010
    FolderA   db_electric_avenue_song_9999
    FolderB   db_abba_dancing_queen_101
    FolderB   db_biggie_small_hypnotize_123
    FolderC   db_im_god-clams-casino-154

    Parameters
    ----------
    base_path : Path
        The base directory awr_miner_out where cohort folders and .out files are expected to be found.

    Returns
    -------
    None

    Raises
    ------
    ValueError
        If an .out file is found in the root of the base_path.
    """
    # Circular import error when importing from the top
    from awr_miner_parse import get_miner_file_name_pieces

    all_out_files = list(base_path.rglob("*.out"))  # Get all .out files

    valid, awr_miner_out_path = is_valid_folder_structure(base_path)
    if not valid:
        return

    for out_file in all_out_files:
        # Check if the .out file is directly in the base path (meaning it's not in a cohort folder)
        if out_file.parent == base_path:
            print("Skipping cohort-mapping folder structure not found")
            return

    # Proceed with mapping if no .out files are found in the root directory
    file_path = base_path.parent / "cohort_whichdb_mapping.csv"
    if file_path.exists():
        file_path.unlink()

    with open(file_path, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Cohort", "WHICH_DB"])  # CSV Header

        for out_file in all_out_files:
            cohort_name = out_file.parent.name
            # which_db = generate_whichDB_from_filename(out_file.name)
            pieces = get_miner_file_name_pieces(str(out_file))
            which_db = f"db_{pieces['dbname']}_{pieces['dbid']}-{pieces['snap_id_start']}-{pieces['snap_id_end']}"
            writer.writerow([cohort_name, which_db])

    # Remove this line if the files need to move into original way
    # move_out_files(base_path, all_out_files)
    print(f"Mapping complete. Data saved in cohort_whichdb_mapping.csv")


def process_properties_file():
    """
    This function processes the AWR properties file, assigns cohorts based on the WHICH_DB_MAPPING_FILE,
    and generates a new AWR_PROPERTIES file without the "_original" suffix.
    """

    # Check if the cohort whichDB mapping file exists
    if fp.WHICH_DB_MAPPING_FILE.exists():
        mapping_df = pd.read_csv(fp.WHICH_DB_MAPPING_FILE)
        mapping_dict = pd.Series(
            mapping_df.Cohort.values, index=mapping_df.WHICH_DB
        ).to_dict()
        occaDatabasesDf = pd.read_csv(fp.AWR_PROPERTIES_ORIGINAL)

        occaDatabasesDf["Cohort"] = occaDatabasesDf["WHICH_DB"].map(mapping_dict)
        AWR_PROPERTIES_NEW = str(fp.AWR_PROPERTIES_ORIGINAL).replace(
            "_original.csv", ".csv"
        )
        occaDatabasesDf.to_csv(AWR_PROPERTIES_NEW, index=False)

        print(f"New AWR properties file saved at: {AWR_PROPERTIES_NEW}")


def execute_cohort_folder_workflow(path_to_awr_files):
    validate_and_map_out_files(path_to_awr_files)
    # process_properties_file()
