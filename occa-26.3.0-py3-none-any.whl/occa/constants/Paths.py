import os
from pathlib import Path


class FilePaths:
    ROOT_DIR = os.environ.get('OCCA_SIZING_DATA_FILES_ROOT_DIR', '.')

    emcc_extract_fp = Path(ROOT_DIR).joinpath("emcc_sizing_extracts")
    emcc_output_fp = Path(ROOT_DIR).joinpath("occa_sizing_output")
    emcc_properties_fp = Path(ROOT_DIR).joinpath("occa_sizing_properties")
    emcc_plots_fp = emcc_output_fp / 'plots'

    awr_miner_out = Path(ROOT_DIR).joinpath("awr_miner_out")
    awr_miner_parsed = Path(ROOT_DIR).joinpath("awr_miner_parsed")
    awr_miner_occa_fp = Path(ROOT_DIR).joinpath("awr_miner_occa")
    awr_miner_plots_fp = Path(ROOT_DIR).joinpath("awr_miner_plots")

    overrideFilePath = emcc_extract_fp.joinpath('override')
    plotFilePath = emcc_output_fp.joinpath('plots')
    sizingFilePath = emcc_output_fp.joinpath('sizing')

    AWR_PROPERTIES_ORIGINAL = awr_miner_occa_fp / 'properties' / 'awr_properties_database_original.csv'
    AWR_PROPERTIES = awr_miner_occa_fp / 'properties' / 'awr_properties_database.csv'
    AWR_TZ = awr_miner_occa_fp / 'properties' / 'awr_tz_database.csv'
    AWR_TZ_ORIGINAL = awr_miner_occa_fp / 'properties' / 'awr_tz_database_original.csv'
    AWR_SNAP_COVERAGE = awr_miner_occa_fp / 'plot' / 'awr_snap_coverage_all_cohorts.html'
    AWR_ANALYSIS_SNAPS_DATA = awr_miner_occa_fp / 'analysis_snaps_data.csv'
    AWR_COMPOSITE = awr_miner_occa_fp / 'occa_composite.csv'
    AWR_OS_INFORMATION=  awr_miner_plots_fp /'csv'/'OS-INFORMATION.csv'

    EMCC_SIZING_STRUCTURE_DB_CSV = emcc_extract_fp /  'emcc_sizing_structure_db.csv'
    EMCC_SIZING_STRUCTURE_DB_PROPS_CSV = emcc_extract_fp / 'emcc_sizing_structure_db_props.csv'

    EMCC_PROPERTIES_DB = emcc_properties_fp / 'properties_database.csv'
    EMCC_PROPERTIES_INSTANCE = emcc_properties_fp / 'properties_instance.csv'

    EMCC_OUTPUT_DATABASE = sizingFilePath / 'databases.csv'
    EMCC_OUTPUT_INSTANCE = sizingFilePath / 'instances.csv'
    EMCC_OUTPUT_SERVER = sizingFilePath / 'servers.csv'

    AWR_UPLOAD_JSON_PATH = awr_miner_occa_fp / "awr_occa_upload_data.json"
    EMCC_UPLOAD_JSON_PATH = emcc_output_fp / "occa_upload_data.json"

    # required folders to continue the second process for AWR-Easy Miner
    AWR_REQUIRED_FOLDERS = ['awr_miner_occa', 'awr_miner_parsed']
    EMCC_REQUIRED_FOLDERS = ['emcc_sizing_extracts', 'occa_sizing_output', 'occa_sizing_properties']

    WHICH_DB_MAPPING_FILE = Path(ROOT_DIR) / 'cohort_whichdb_mapping.csv'

    @staticmethod
    def resolve_for_awr_emcc(working_dir: Path):
        if (working_dir / FilePaths.AWR_PROPERTIES).exists():
            return True, False
        elif (working_dir / FilePaths.EMCC_PROPERTIES_DB).exists():
            return False, True

        return False, False

    @staticmethod
    def get_plots_path(current_dir, type: str):
        if type == 'AWR':
            plots_path = current_dir / FilePaths.awr_miner_plots_fp / 'html'
        elif type == 'AWR_UNADJUSTED':
            plots_path = current_dir / FilePaths.awr_miner_occa_fp / 'plot' / 'unadjusted'
        elif type == 'EMCC':
            plots_path = current_dir / FilePaths.emcc_plots_fp
        else:
            raise ValueError("plot_type not supported")

        return plots_path
