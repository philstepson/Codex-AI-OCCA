import os
from sys import platform

import pytest
from pathlib import Path

from rich import print
from html2image import Html2Image

import occa.occa_api as occa_api

# DB query to determine number of entries that have WebGL image
# generated:
# select count(*) from PLOTS_HTML
# where length(RENDERED_IMAGE) = 29951;

# Relative from the test code
# testdata_path = (
#     Path(__file__).parent.parent.parent /
#     "testdata/em/Sample1c-NEW/occa_sizing_output/plots/adjusted/DCWEST/html" /
#     "DCWEST_DB_vCPU_adjusted.html"
# ).resolve()
testdir_path = Path(__file__).parent.resolve()
testdata_path = testdir_path / "test.html"

# Determine if we are executed from Jenkins
#JENKINS_ENV = os.environ.get("JENKINS_ENV")

# Determine if we are executed on Linux as Linux usually doesn't have Chrome installed
IS_LINUX = True if platform == "linux" else False

hti = None
if not IS_LINUX:
    hti = Html2Image(
    custom_flags=["--disable-3d-apis"],
    size=(2000, 1200),
    output_path=str(testdir_path),
    )


@pytest.mark.skip(reason="No 'test.html' file available in the repo")
def test_render_image():
    results = occa_api.render_image(testdata_path, testdir_path)
    print(f"{results=}")
    assert "png" in results[0]


def test_render_image_in_db():
    if not IS_LINUX and occa_api.connection:
        test_id = "F4BD25A50E991B51E053BA10000AFB28"
        results = occa_api.render_image_in_db(test_id, testdir_path, hti)
        assert "png" in results[0]


def test_update_rendered_image_in_db():
    if not IS_LINUX and occa_api.connection:
        test_id = "1492AF1D3EB49BEBE0630200580AD3FF"
        results = occa_api.render_image_in_db(test_id, testdir_path, hti)
        occa_api.update_rendered_image_in_db(test_id, testdir_path)


# def test_render_opportunity():
#     opp_id = "01597D5CE9B70ED1E0632A00580AABB8"
#     occa_api.render_opportunity(opp_id)
