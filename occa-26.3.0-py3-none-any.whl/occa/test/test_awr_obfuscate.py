"""
Unit tests for Obfuscate_Awr.py
"""


#
# Version History
#
# 2023-06-22    1.0 pro     Initial version

import pytest

import filecmp
import os
import shutil

from pathlib import Path

# Import Obfuscate_Awr.py
import extracts.Obfuscate_Awr as obs

@pytest.fixture
def testdata_dir() -> Path:
    """
    A Path to the root directory for tests

    Returns
    -------
    Path
        A Path to the root directory for tests

    """
    return Path(os.path.join(Path(__file__).parent.parent.parent, "testdata")).resolve()


@pytest.fixture
def data_dir(testdata_dir) -> Path:
    """
    A Path to the directory containing the needed files for this Unit Test.
    This path will be also used for the generated files as part of the execution
    of this unit test

    Parameters
    ----------
        testdata_dir : Path
            The testdata_dir fixture

    Returns
    -------
    Path
        A Path to the directory for this tests

    """
    return Path(os.path.join(testdata_dir, "awr", "test_awr_obfuscate")).resolve()


@pytest.fixture
def awr_miner_out(data_dir) -> Path:
    """
    A Path to the awr_miner_out dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_out dir

    """
    return Path(os.path.join(data_dir, "awr_miner_out")).resolve()


@pytest.fixture
def awr_miner_out_obfuscated(data_dir) -> Path:
    """
    A Path to the awr_miner_out_obfuscated dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_out dir

    """
    return Path(os.path.join(data_dir, "awr_miner_out_obfuscated")).resolve()


@pytest.fixture
def awr_obfuscated_control_files(data_dir) -> Path:
    """
    A Path to the awr_obfuscated_control_files dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_out dir

    """
    return Path(os.path.join(data_dir, "awr_obfuscated_control_files")).resolve()


@pytest.fixture
def awr_miner_occa(data_dir) -> Path:
    """
    A Path to the awr_miner_occa dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awrawr_miner_occa_miner_out dir

    """
    return Path(os.path.join(data_dir, "awr_miner_occa")).resolve()


@pytest.fixture
def awr_log_dir(awr_miner_occa) -> Path:
    """
    A Path to the awr_miner_occa/log dir

    Parameters
    ----------
        awr_miner_occa : Path
            The awr_miner_occa fixture

    Returns
    -------
        Path
            A Path to the awr_miner_occa/log dir

    """
    return Path(os.path.join(awr_miner_occa, "log")).resolve()


@pytest.fixture
def awr_translation_dir(data_dir) -> Path:
    """
    A Path to the awr_translation_dir dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_translation_dir dir

    """
    return Path(os.path.join(data_dir, "awr_miner_occa")).resolve()


@pytest.fixture
def translation_file_name() -> str:
    """
    The name of the Translation file name

    Returns
    -------
        str: str
            The name of the obfuscated translation file

    """
    return "awr_obfuscated_translation"


@pytest.fixture
def mask_string() -> str:
    """
    The string used to mask values

    Returns
    -------
        str: str
            The replacement string for obfuscated values

    """
    return "XXXXXXXXXXXX"


@pytest.fixture
def mask_char() -> str:
    """
    The character used to mask values

    Returns
    -------
        str: str
            The replacement character for obfuscated values

    """
    return "X"


@pytest.fixture
def masked_db_parameters_list(mask_string):
    """
    A subset of the data present in any DATABASE-PARAMETERS block which has been masked.

    Parameters
    ----------
        mask_string: str
            the mask_string fixture

    Returns
    -------
        list[str] -> list[str]
            A list of strings with the parameters masked

    """
    params_list = [
        f"audit_file_dest {mask_string}",
        f"background_dump_dest {mask_string}",
        f"connection_brokers {mask_string}",
        f"control_files {mask_string}",
        f"core_dump_dest {mask_string}",
        f"db_file_name_convert {mask_string}",
        f"db_name {mask_string}",
        f"db_recovery_file_dest {mask_string}",
        f"db_unique_name {mask_string}",
        f"dg_broker_config_file1 {mask_string}",
        f"dg_broker_config_file2 {mask_string}",
        f"diagnostic_dest {mask_string}",
        f"fal_server {mask_string}",
        f"instance_name {mask_string}",
        f"log_archive_format {mask_string}",
        f"log_file_name_convert {mask_string}",
        f"log_archive_config {mask_string}",
        f"redo_transport_user {mask_string}",
        f"spfile {mask_string}",
        f"user_dump_dest {mask_string}",
        f"log_archive_dest_1 {mask_string}",
        f"log_archive_dest_2 {mask_string}",
    ]
    return params_list


def get_blocks_from_miner_out_file(file: Path, begin_block: str, end_block: str):
    """
    Get the lines from a block of data present in the AWR Miner out file.

    Parameters:
    -----------
        file : Path
            The AWR Miner file
        begin_block : str
            The Sequence of characters indicating the start of a block
        end_block : str
            The Sequence of characters indicating the end of a block

    Returns:
    -------
        list[str] : list[str]
            A list containing the lines between the start an end of the block.

    """
    f = open(file)
    lines = f.read().splitlines()
    start = False
    end = False
    lines_list = []

    for l in lines:
        if begin_block in l:
            start = True
            lines_list.append(l)
        elif end_block in l:
            end = True
            lines_list.append(l)
        elif start and not end:
            lines_list.append(l)

    return lines_list


def test_get_awr_out_dir_path_from_env(data_dir, awr_miner_out, monkeypatch):
    """
    Test normal operation of the get_awr_out_dir_path() routine.

    Given: a string

    When: get_awr_out_dir_path() is invoked

    Then: the path to awr_miner_out directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_miner_out : Path
            The awr_miner_out fixture
        monkeypatch :
            The pytest monkeypath fixture
    """
    # Set the environment variable
    monkeypatch.setenv("EMCC_SIZING_AWR_ROOT_DIR", str(data_dir))

    actual = obs.get_awr_out_dir_path()
    expected = awr_miner_out

    # Assert both paths are equal
    assert actual == expected

    # Remove the var from the env
    monkeypatch.delenv("EMCC_SIZING_AWR_ROOT_DIR")


def test_get_awr_out_dir_path_from_current_dir(data_dir, awr_miner_out):
    """
    Test normal operation of the get_awr_out_dir_path() routine.

    Given: a string

    When: get_awr_out_dir_path() is invoked

    Then: the path to awr_miner_out directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    # Change to the data_dir directory
    os.chdir(data_dir)

    actual = obs.get_awr_out_dir_path()
    expected = awr_miner_out

    # Assert both paths are equal
    assert actual == expected


def test_get_awr_log_dir_path_from_env(data_dir, awr_log_dir, monkeypatch):
    """
    Test normal operation of the get_awr_log_dir_path() routine.

    Given: a string

    When: get_awr_log_dir_path() is invoked

    Then: the path to awr_miner_occa/log directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_log_dir : Path
            The awr_log_dir fixture
        monkeypatch :
            The pytest monkeypath fixture
    """
    # Set the environment variable
    monkeypatch.setenv("EMCC_SIZING_AWR_ROOT_DIR", str(data_dir))

    actual = obs.get_awr_log_dir_path()
    expected = awr_log_dir

    # Assert both paths are equal
    assert actual == expected

    # Remove the var from the env
    monkeypatch.delenv("EMCC_SIZING_AWR_ROOT_DIR")


def test_get_awr_log_dir_path_from_current_dir(data_dir, awr_log_dir):
    """
    Test normal operation of the get_awr_log_dir_path() routine.

    Given: a string

    When: get_awr_log_dir_path() is invoked

    Then: the path to awr_miner_occa/log directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    # Change to the data_dir directory
    os.chdir(data_dir)

    actual = obs.get_awr_log_dir_path()
    expected = awr_log_dir

    # Assert both paths are equal
    assert actual == expected


def test_get_output_dir_path_from_env(data_dir, awr_miner_out_obfuscated, monkeypatch):
    """
    Test normal operation of the get_output_dir_path() routine.

    Given: a string

    When: get_output_dir_path() is invoked

    Then: the path to awr_miner_out_obfuscated directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_miner_out_obfuscated : Path
            The awr_miner_out_obfuscated fixture
        monkeypatch :
            The pytest monkeypath fixture
    """
    # Set the environment variable
    monkeypatch.setenv("EMCC_SIZING_AWR_ROOT_DIR", str(data_dir))

    actual = obs.get_output_dir_path()
    expected = awr_miner_out_obfuscated

    # Assert both paths are equal
    assert actual == expected

    # Remove the var from the env
    monkeypatch.delenv("EMCC_SIZING_AWR_ROOT_DIR")


def test_get_output_dir_path_from_current_dir(data_dir, awr_miner_out_obfuscated):
    """
    Test normal operation of the get_awr_log_dir_path() routine.

    Given: a string

    When: get_awr_log_dir_path() is invoked

    Then: the path to awr_miner_occa/log directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    # Change to the data_dir directory
    os.chdir(data_dir)

    actual = obs.get_output_dir_path()
    expected = awr_miner_out_obfuscated

    # Assert both paths are equal
    assert actual == expected


def test_get_translation_dir_path_from_env(data_dir, awr_translation_dir, monkeypatch):
    """
    Test normal operation of the get_translation_dir_path() routine.

    Given: a string

    When: get_translation_dir_path() is invoked

    Then: the path to awr_obfuscated_translation directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_translation_dir : Path
            The awr_translation_dir fixture
        monkeypatch :
            The pytest monkeypath fixture
    """
    # Set the environment variable
    monkeypatch.setenv("EMCC_SIZING_AWR_ROOT_DIR", str(data_dir))

    actual = obs.get_translation_dir_path()
    expected = awr_translation_dir

    # Assert both paths are equal
    assert actual == expected

    # Remove the var from the env
    monkeypatch.delenv("EMCC_SIZING_AWR_ROOT_DIR")


def test_get_translation_dir_path_from_current_dir(data_dir, awr_translation_dir):
    """
    Test normal operation of the get_translation_dir_path() routine.

    Given: a string

    When: get_translation_dir_path() is invoked

    Then: the path to awr_obfuscated_translation directory is returned

    Parameters:
    -----------
        data_dir  : Path
            The data_dir fixture
        awr_translation_dir : Path
            The awr_translation_dir fixture
    """
    # Change to the data_dir directory
    os.chdir(data_dir)

    actual = obs.get_translation_dir_path()
    expected = awr_translation_dir

    # Assert both paths are equal
    assert actual == expected


def test_debug():
    """
    Test normal operation of the debug() routine.

    Given: a string

    When: debug() is invoked

    Then: the string is added to debug_data list
    """
    # Clean out previous content
    obs.debug_data = []

    debug_text = "debug_text"
    expected = [debug_text + "\n"]

    obs.DEBUG = True
    obs.debug(debug_text)
    assert obs.debug_data == expected


def test_debug_with_dev_mode(capsys):
    """
    Test normal operation of the debug() routine.

    Given: a string and DEV_MODE var set to True

    When: debug() is invoked

    Then: the string is added to debug_data list and a message is written to stdout

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    # Clean out previous content
    obs.debug_data = []

    debug_text = "debug_text"
    expected = [debug_text + "\n"]

    obs.DEBUG = True
    obs.DEV_MODE = True

    obs.debug(debug_text)
    captured = capsys.readouterr()

    # Assert the expected string is added to the list
    assert obs.debug_data == expected

    # Assert the expected string is written to stdout
    expected = debug_text + "\n"
    assert expected in captured.out


def test_log(capsys):
    """
    Test normal operation of the log() routine.

    Given: a string

    When: log() is invoked

    Then: the string is added to log_data list and a message is written to stdout

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    log_text = "log_text"
    expected = [log_text + "\n"]

    obs.log(log_text)
    captured = capsys.readouterr()

    # Assert the expected string is added to the list
    assert obs.log_data == expected

    # Assert the expected string is written to stdout
    expected = log_text + "\n"
    assert expected in captured.out


def test_log_err_to_stdout(capsys):
    """
    Test normal operation of the log_err_to_stdout() routine.

    Given: a string

    When: log() is invoked

    Then: the string is written to stdout

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    log_text = "log_text"
    expected = f"\nERROR: {log_text}\n"

    obs.log_err_to_stdout(log_text)
    captured = capsys.readouterr()

    # Assert the expected string is written to stdout
    assert expected in captured.out


def test_check_dir(awr_miner_out):
    """
    Test normal operation of the check_dir() routine.

    Given: a existing directory

    When: check_dir() is invoked

    Then: True is returned

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    assert obs.check_dir(awr_miner_out)


def test_check_dir_path_does_not_exists(data_dir, capsys):
    """
    Test normal operation of the check_dir() routine.

    Given: an inexistant directory

    When: check_dir() is invoked

    Then: False is returned and a message is written to stdout

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    d = os.path.join(data_dir, "fakedir")

    # Assert returns false
    assert not obs.check_dir(d)
    captured = capsys.readouterr()

    # Assert the message is written to stdout
    expected = f"ERROR: Directory {d} is missing, cannot continue\n"
    assert expected in captured.out


def test_check_dir_path_is_not_a_dir(data_dir, capsys):
    """
    Test normal operation of the check_dir() routine.

    Given: an existing Path but is not a directory

    When: check_dir() is invoked

    Then: False is returned and a message is written to stdout

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    # Create an empty file
    f = os.path.join(data_dir, "empty.txt")
    open(f, "w").close()

    # Assert returns false
    assert not obs.check_dir(f)
    captured = capsys.readouterr()

    # Assert the message is written to stdout
    expected = f"ERROR: Directory {f} is not a directory, cannot continue\n"
    assert expected in captured.out

    # Delete the empty file
    os.remove(f)


def test_check_dir_path_is_not_readable(data_dir, capsys):
    """
    Test normal operation of the check_dir() routine.

    Given: an existing Path but is not readable

    When: check_dir() is invoked

    Then: False is returned and a message is written to stdout

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    # Create a temporary directory
    d = os.path.join(data_dir, "temp_dir")
    os.makedirs(d)

    # Make the file not readable
    os.chmod(d, 0o244)

    # Assert returns false
    assert not obs.check_dir(d)
    captured = capsys.readouterr()

    # Assert the message is written to stdout
    expected = f"ERROR: Directory {d} is not readable, cannot continue\n"
    assert expected in captured.out

    # Delete the empty file
    os.rmdir(d)


def test_check_file(data_dir):
    """
    Test normal operation of the check_file() routine.

    Given: a existing file

    When: check_file() is invoked

    Then: True is returned

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
    """
    # Create an empty file
    f = os.path.join(data_dir, "empty.txt")
    open(f, "w").close()

    assert obs.check_file(f)

    # Delete the empty file
    os.remove(f)


def test_check_file_does_not_exists(data_dir, capsys):
    """
    Test normal operation of the check_file() routine.

    Given: an inexistant directory

    When: check_file() is invoked

    Then: False is returned and a message is written to stdout

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    d = os.path.join(data_dir, "fakefile")

    # Assert returns false
    assert not obs.check_file(d)
    captured = capsys.readouterr()

    # Assert the message is written to stdout
    expected = f"ERROR: File {d} is missing; cannot continue\n"
    assert expected in captured.out


def test_check_file_is_not_a_file(data_dir, capsys):
    """
    Test normal operation of the check_file() routine.

    Given: an existing Path but is not a directory

    When: check_file() is invoked

    Then: False is returned and a message is written to stdout

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    # Create an empty directory
    d = os.path.join(data_dir, "fakedir")
    os.mkdir(d)

    # Assert returns false
    assert not obs.check_file(d)
    captured = capsys.readouterr()

    # Assert the message is written to stdout
    expected = f"ERROR: File {d} is not a regular file; cannot continue\n"
    assert expected in captured.out

    # Delete the empty file
    os.rmdir(d)


def test_check_file_is_not_readable(data_dir, capsys):
    """
    Test normal operation of the check_file() routine.

    Given: an existing file but is not readable

    When: check_file() is invoked

    Then: False is returned and a message is written to stdout

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    # Create an empty file
    f = os.path.join(data_dir, "empty.txt")
    open(f, "w").close()

    # Make the file not readable
    os.chmod(f, 0o244)

    # Assert returns false
    assert not obs.check_file(f)
    captured = capsys.readouterr()

    # Assert the message is written to stdout
    expected = f"ERROR: File {f} is not readable; cannot continue\n"
    assert expected in captured.out

    # Delete the empty file
    os.remove(f)


def test_check_python_version(capsys):
    """
    Test normal operation of the check_python_version() routine.

    Given: a string representing a python version of 3.x

    When: check_python_version() is invoked

    Then: True is returned

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    version = 3

    # Assert returns false
    assert obs.check_python_version(version)


def test_check_python_version_returns_false(capsys):
    """
    Test normal operation of the check_python_version() routine.

    Given: a string representing a python version of 2.x

    When: check_python_version() is invoked

    Then: False is returned and a message is written to stdout

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    version = 2

    # Assert returns false
    assert not obs.check_python_version(version)

    obs.check_python_version(version)
    captured = capsys.readouterr()

    # Assert the message is written to stdout
    expected = "\nThis script requires python 3.x or higher; cannot continue"
    assert expected in captured.out


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_is_valid_file_name(file):
    """
    Test if the file name matches the expected naming convention.

    Given: A file name matching the standard naming convention

    When: is_valid_file_name() is invoked

    Then: True is returned

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = True
    actual = obs.is_valid_file_name(file)
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498-badfilename.out"])
def test_is_valid_file_name_with_bad_filename(file):
    """
    Test if the file name matches the expected naming convention.

    Given: A file name NOT matching the standard naming convention

    When: is_valid_file_name() is invoked

    Then: False is returned

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """

    expected = False
    actual = obs.is_valid_file_name(file)

    # Test returns false
    assert expected == actual


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_get_miner_file_name_pieces(file):
    """
    Test the obtention of dbid,dbname,snap_id_start and snap_id_end from the file name

    Given: A file name matching the standard naming convention

    When: get_miner_file_name_pieces() is invoked

    Then: A dict containing each of the pieces extracted from the file name

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = {
        "dbid": "609708250",
        "dbname": "oracle-database-00000",
        "snap_id_start": "37296",
        "snap_id_end": "37498",
    }
    actual = obs.get_miner_file_name_pieces(file)
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-609708250-oracle-database-00000-37296-37498.out"])
def test_get_miner_file_name_pieces_with_bad_filename(file):
    """
    Test the behaviour of get_miner_file_name_pieces() when the
    file name does not match the standard naming convention

    Given: A file name NOT matching the standard naming convention

    When: get_miner_file_name_pieces() is invoked

    Then: An Empty dict is returned

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = {}
    actual = obs.get_miner_file_name_pieces(file)
    assert actual == expected


@pytest.mark.parametrize("file", ["out_file.out"])
def test_write_file_from_list(awr_miner_out_obfuscated, data_dir, file):
    """
    Test the normal behaviour of write_file_from_list() routine

    Given: A list of strings

    When: write_file_from_list() is invoked

    Then: The list of strings is written to the file

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
        data_dir
            The data_fir fixture
        awr_miner_out_obfuscated
            The awr_miner_out_obfuscated fixture
    """
    # Create OUT_DIR_PATH
    os.mkdir(awr_miner_out_obfuscated)

    # Set the list of strings to be written
    ilist = ["Line1", "line2", "line3", "line4"]
    file_path = os.path.join(data_dir, file)

    obs.write_file_from_list(file_path, ilist)

    # Check the file has been created
    assert os.path.isfile(file_path)

    # Check the file contents
    with open(file_path) as f:
        lines = f.readlines()

    expected = ["Line1\n", "line2\n", "line3\n", "line4"]

    assert lines == expected

    # Remove the file and the OUT_DIR_PATH
    os.remove(file_path)
    os.rmdir(awr_miner_out_obfuscated)


@pytest.mark.parametrize("file", ["awr-hist-609708250-HAEM-37296-37498.out"])
def test_mask_db_parameters_section(awr_miner_out, file, masked_db_parameters_list):
    """
    Test the normal behaviour of mask_db_parameters_section() routine

    Given: A list of strings with the contents of the DATABASE-PARAMETERS block

    When: mask_db_parameters_section() is invoked

    Then: A new list of strings is returned where the value for the strings present in MASK_DATABASE_PARAMETERS
    are masked with the mask_string value.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        masked_db_parameters_list : list[str]
            The masked_db_parameters_list fixture
    """
    # Read the database parameters block from the file
    f_path = Path(os.path.join(awr_miner_out, file))
    begin_str = "~~BEGIN-DATABASE-PARAMETERS~~"
    end_str = "~~END-DATABASE-PARAMETERS~~"
    db_parameters_block = get_blocks_from_miner_out_file(f_path, begin_str, end_str)

    # Get the actual result from the routine
    result = obs.mask_db_parameters_section(db_parameters_block)

    # Filter our the list to get the target values
    actual = []
    for line in result:
        new_line = " ".join(line.split())
        new_line_lst = new_line.split(" ")

        # Get the stat_name column
        if len(new_line_lst) > 1:
            stat_name = new_line_lst[0]
            stat_value = new_line_lst[1]
            if stat_name in obs.MASK_DATABASE_PARAMETERS_TUPLE:
                line = stat_name + " " + stat_value
                actual.append(line)

    # Remove from expected those that are not in actual
    expected = list(set(masked_db_parameters_list) & set(actual))

    # Sort the lists to make the comparison
    actual.sort()
    expected.sort()

    # Assert the lists are the same
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-HAEM-37296-37498.out"])
def test_mask_db_parameters2_section(awr_miner_out, file, masked_db_parameters_list):
    """
    Test the normal behaviour of mask_db_parameters_section() routine

    Given: A list of strings with the contents of the DATABASE-PARAMETERS2 block

    When: mask_db_parameters_section() is invoked

    Then: A new list of strings is returned where the value for the strings present in MASK_DATABASE_PARAMETERS
    are masked with the mask_string value.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        masked_db_parameters_list : list[str]
            The masked_db_parameters_list fixture
    """
    # Read the database parameters block from the file
    f_path = Path(os.path.join(awr_miner_out, file))
    begin_str = "~~BEGIN-DATABASE-PARAMETERS2~~"
    end_str = "~~END-DATABASE-PARAMETERS2~~"
    db_parameters2_block = get_blocks_from_miner_out_file(f_path, begin_str, end_str)

    # Get the actual result from the routine
    result = obs.mask_db_parameters_section(db_parameters2_block)

    # Filter our the list to get the target values
    actual = []
    for line in result:
        new_line = " ".join(line.split())
        new_line_lst = new_line.split(" ")

        # Get the stat_name column
        if len(new_line_lst) > 2:
            instance_num = new_line_lst.pop(0)
            stat_name = new_line_lst[0]
            stat_value = new_line_lst[1]
            if stat_name in obs.MASK_DATABASE_PARAMETERS_TUPLE:
                to_add_line = stat_name + " " + stat_value
                actual.append(to_add_line)

    # Remove duplicates from actual list as it contains values for each of the instances in the block
    dedup_actual = list(dict.fromkeys(actual))

    # Remove from expected those that are not in actual
    expected = list(set(masked_db_parameters_list) & set(actual))

    # Sort the lists to make the comparison
    dedup_actual.sort()
    expected.sort()

    # Assert the lists are the same
    assert dedup_actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-HAEM-37296-37498.out"])
def test_mask_segment_io_section(awr_miner_out, file, mask_char):
    """
    Test the normal behaviour of mask_segment_io_section() routine

    Given: A list of strings with the contents of the SEGMENT-IO block

    When: mask_segment_io_section() is invoked

    Then: A new list of strings is returned where the values for the column OWNER is masked

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        mask_char
            The mask_char fixture
    """
    f_path = Path(os.path.join(awr_miner_out, file))
    begin_str = "~~BEGIN-SEGMENT-IO~~"
    end_str = "~~END-SEGMENT-IO~~"

    # Read the database parameters block
    segment_io_block = get_blocks_from_miner_out_file(f_path, begin_str, end_str)

    # Mask the OWNER column
    expected = []
    for line in segment_io_block:
        new_line = " ".join(line.split())
        new_line_lst = new_line.split(" ")

        if line.startswith("OWNER") or line.startswith("---") or line.startswith("~~"):
            expected.append(line)
        else:
            owner = new_line_lst[0]
            new_value = mask_char * len(owner)
            replaced_line = line.replace(owner, new_value)
            expected.append(replaced_line)

    # Get the actual result from the routine
    actual = obs.mask_segment_io_section(segment_io_block)

    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-HAEM-37296-37498.out"])
def test_mask_top_sql_section(awr_miner_out, file, mask_char):
    """
    Test the normal behaviour of mask_top_sql_section() routine

    Given: A list of strings with the contents of the TOP-SQL-SUMMARY block

    When: mask_top_sql_section() is invoked

    Then: A new list of strings is returned where the values for the column PARSING_SCHEMA_NAME is masked

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        mask_char
            The mask_char fixture
    """
    f_path = Path(os.path.join(awr_miner_out, file))
    begin_str = "~~BEGIN-TOP-SQL-SUMMARY~~"
    end_str = "~~END-TOP-SQL-SUMMARY~~"

    # Read the database parameters block
    top_sql_summary_block = get_blocks_from_miner_out_file(f_path, begin_str, end_str)

    # Mask the OWNER column
    expected = []
    for line in top_sql_summary_block:
        new_line = " ".join(line.split())
        new_line_lst = new_line.split(" ")

        if line.startswith("MODULE") or line.startswith("---") or line.startswith("~~"):
            expected.append(line)
        elif len(new_line_lst[0]) > 0:
            new_line_lst_copy = new_line_lst.copy()
            new_line_lst_copy.reverse()

            parsing_schema = new_line_lst_copy[10]
            new_value = mask_char * len(parsing_schema)
            replaced_line = line.replace(parsing_schema, new_value)
            expected.append(replaced_line)
        else:
            expected.append(line)

    # Get the actual result from the routine
    actual = obs.mask_top_sql_section(top_sql_summary_block)

    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-HAEM-37296-37498.out"])
def test_mask_top_sql_by_snapid_section(awr_miner_out, file, mask_char):
    """
    Test the normal behaviour of mask_top_sql_by_snap_section() routine

    Given: A list of strings with the contents of the TOP-SQL-BY-SNAP-ID block

    When: mask_top_sql_by_snap_section() is invoked

    Then: A new list of strings is returned where the values for the column PARSING_SCHEMA_NAME is masked

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        mask_char
            The mask_char fixture
    """
    f_path = Path(os.path.join(awr_miner_out, file))
    begin_str = "~~BEGIN-TOP-SQL-BY-SNAPID~~"
    end_str = "~~END-TOP-SQL-BY-SNAPID~~"

    # Read the database parameters block
    top_sql_summary_block = get_blocks_from_miner_out_file(f_path, begin_str, end_str)

    # Mask the OWNER column
    expected = []
    for line in top_sql_summary_block:
        new_line = " ".join(line.split())
        new_line_lst = new_line.split(" ")

        if line.startswith("   SNAP_ID") or line.startswith("---") or line.startswith("~~"):
            expected.append(line)
        elif len(new_line_lst[0]) > 0:
            parsing_schema = new_line_lst[1]
            new_value = mask_char * len(parsing_schema)
            replaced_line = line.replace(parsing_schema, new_value)
            expected.append(replaced_line)
        else:
            expected.append(line)

    # Get the actual result from the routine
    actual = obs.mask_top_sql_by_snap_section(top_sql_summary_block)

    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-HAEM-37296-37498.out"])
def test_main(
    data_dir, awr_miner_out, awr_log_dir, awr_miner_out_obfuscated, awr_obfuscated_control_files, awr_miner_occa, monkeypatch, file, capsys
):
    """
    Test the normal behaviour of main() routine

    Given: A file to obfuscate values

    When: main() is invoked

    Then: A new files is created with obfuscated values

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_log_dir : Path
            The awr_log_dir fixture
        awr_miner_out_obfuscated : Path
            The awr_miner_out_obfuscated fixture
        awr_obfuscated_control_files : Path
            The awr_obfuscated_control_files fixture
        awr_miner_occa : Path
            The awr_miner_occa fixture
        monkeypatch :
            The monkeypatch fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    source_file = os.path.join(awr_miner_out, file)
    target_file = os.path.join(awr_miner_out_obfuscated, "awr-hist-609708250-oracle-database-00000-37296-37498.out")

    # Set the environment variable
    monkeypatch.setenv("EMCC_SIZING_AWR_ROOT_DIR", str(data_dir))

    # Call main
    obs.main()
    captured = capsys.readouterr()

    # Assert the expected messages are written to stdout
    translation_file = os.path.join(awr_miner_occa, "awr_obfuscated_translation.csv")
    expected = (
        f"Created directory :{awr_miner_out_obfuscated}\n"
        f"Created directory :{awr_log_dir}\n\n"
        f"Obfuscating {source_file}....\n"
        f" Wrote 22776 rows to file {target_file}....\n\n"
        f"Wrote translation to file: {translation_file}\n"
    )
    assert expected in captured.out

    # Assert the expected file has been created and has content
    assert os.path.isfile(target_file)
    assert os.path.getsize(target_file) > 0

    # Assert the file content is the same
    control_file = os.path.join(awr_obfuscated_control_files, "awr-hist-609708250-HAEM-obfuscated-control-37296-37498.out")
    assert filecmp.cmp(target_file, control_file)

    # Assert the translation file has been created
    assert os.path.isfile(translation_file)
    assert os.path.getsize(translation_file) > 0

    # Assert the file content is the same
    translation_control_file = os.path.join(awr_obfuscated_control_files, "awr_obfuscated_control_translation.csv")
    assert filecmp.cmp(translation_file, translation_control_file)

    # Clean out the file created and directories
    shutil.rmtree(awr_miner_out_obfuscated, ignore_errors=True)
    shutil.rmtree(awr_miner_occa, ignore_errors=True)


def test_main_exit_code(data_dir, awr_miner_out_obfuscated, monkeypatch, capsys):
    """
    Test the normal operation of main() when an error is detected.

    Given: Invoke main() with an existant OUTPUT_DIR_PATH

    When: main() is invoked

    Then: Exit Code 1 should be returned

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        awr_miner_out_obfuscated : Path
            The awr_miner_out_obfuscated fixture
        monkeypatch :
            The monkeypatch fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    # Create a fake directory
    d = os.path.join(data_dir, "fakedir")
    os.mkdir(d)

    # Set the environment to point to the fake directory
    monkeypatch.setenv("EMCC_SIZING_AWR_ROOT_DIR", str(d))

    # Call to main should give an error an exit with code 1
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        obs.main()
    captured = capsys.readouterr()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Assert the expected message is written to stdout
    new_awr_miner_out = os.path.join(d, "awr_miner_out")
    expected = f"ERROR: Directory {new_awr_miner_out} is missing, cannot continue\n"
    assert expected in captured.out

    # Remove the created directory
    shutil.rmtree(d, ignore_errors=True)


def test_tear_down(awr_miner_out_obfuscated, awr_miner_occa):
    """
    WorkAround to delete directories created along the process in case of test failure
    """
    shutil.rmtree(awr_miner_out_obfuscated, ignore_errors=True)
    shutil.rmtree(awr_miner_occa, ignore_errors=True)
