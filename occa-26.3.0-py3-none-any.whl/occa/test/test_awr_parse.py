"""
Unit tests for awr_miner_parse.py
"""

#
# Version History
#
# 2023-06-07    1.0 pro     Initial version

import pytest

import os
import shutil
import sys
import pandas as pd

from pathlib import Path
from pandas.testing import assert_frame_equal
from occa import occa
# Import awr_miner_parse
import occa.awr_miner_parse as parse


@pytest.fixture
def testdata_dir() -> Path:
    """
    A Path to the root directory for tests

    Returns
    -------
    Path
        A Path to the root directory for tests

    """
    return Path(os.path.join(Path(__file__).parent.parent.parent, "testdata")).resolve()


@pytest.fixture
def data_dir(testdata_dir) -> Path:
    """
    A Path to the directory containing the needed files for this Unit Test.
    This path will be also used for the generated files as part of the execution
    of this unit test

    Parameters
    ----------
        testdata_dir : Path
            The testdata_dir fixture

    Returns
    -------
    Path
        A Path to the directory for this tests

    """
    return Path(os.path.join(testdata_dir, "awr", "test_awr_parse")).resolve()


@pytest.fixture
def testdata_files():
    """
    The list of data files used by this unit tests

    Returns
    -------
    list[str] : list[str]
        A list of the files used by this test

    """
    data_files = [
        "DATABASE-PARAMETERS.txt",
        "SQL-METRICS-rollover-SNAP_ID.txt",
        "SQL-METRICS-rollover-snap.txt",
        "TOP-SQL-BY-SNAPID.txt",
        "awr-hist-609708250-oracle-database-00000-11111-11111.out",
        "awr-hist-609708250-oracle-database-00000-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-37296-37498-20030525.out",
        "awr-hist-609708250-oracle-database-00000-test1-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-test2-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-test3-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-test4-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-test5-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-test6-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-test7-37296-37498.out",
        "awr-hist-609708250-oracle-database-00000-test8-37296-37498.out",
    ]
    return data_files


@pytest.fixture
def awr_miner_path(data_dir) -> Path:
    """
    A Path to the awr_miner_path dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_path dir

    """
    return Path(data_dir).resolve()


@pytest.fixture
def awr_miner_parsed(data_dir) -> Path:
    """
    A Path to the awr_miner_parsed dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_parsed dir

    """
    return Path(os.path.join(data_dir, "awr_miner_parsed")).resolve()


@pytest.fixture
def awr_miner_parsed_db(awr_miner_parsed) -> Path:
    """
    A Path to the directory created for a given database under awr_miner_parsed directory

    Parameters
    ----------
        awr_miner_parsed : Path
            The awr_miner_parsed fixture

    Returns
    -------
        Path
            A Path to the directory created for a given database under awr_miner_parsed directory

    """
    database_dir = "db_oracle-database-00000_609708250"
    return Path(os.path.join(awr_miner_parsed, database_dir)).resolve()


@pytest.fixture
def awr_miner_out(data_dir) -> Path:
    """
    A Path to the awr_miner_out dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_out dir

    """
    return Path(os.path.join(data_dir, "awr_miner_out")).resolve()


@pytest.fixture()
def memory_block_data():
    """
    A subset of the data present in any MEMORY block extracted with the Miner

    Returns
    -------
        string
           A simulated MEMORY block with telemetry information
    """

    data = [
        "~~BEGIN-MEMORY~~",
        "  SNAP_ID INSTANCE_NUMBER        SGA        PGA      TOTAL",
        "---------- --------------- ---------- ---------- ----------",
        "    220162               1        3.7         .8        4.5",
        "    220162               2        3.7         .8        4.5",
    ]

    return data


@pytest.fixture()
def main_metrics_block_data():
    """
    A subset of the data present in any MAIN-METRICS block extracted with the Miner

    Returns
    -------
        string
           A simulated MAIN-METRICS block with telemetry information
    """
    data = [
        "~~BEGIN-MAIN-METRICS~~",
        "snap      dur_m end                  inst     os_cpu os_cpu_max  os_cpu_sd db_wait_ratio db_cpu_ratio  cpu_per_s cpu_per_s_sd"
        " h_cpu_per_s h_cpu_per_s_sd        aas     aas_sd    aas_max    db_time db_time_sd sql_res_t_cs bkgd_t_per_s   logons_s "
        "logons_total     exec_s   hard_p_s  l_reads_s  commits_s  read_mb_s read_mb_s_max  read_iops read_iops_max   "
        "read_bks read_bks_direct write_mb_s write_mb_s_max write_iops write_iops_max  write_bks write_bks_direct  "
        "redo_mb_s db_block_gets_s db_block_changes_s gc_cr_rec_s gc_cu_rec_s gc_cr_get_cs gc_cu_get_cs gc_bk_corrupted gc_bk_lost    "
        "px_sess    se_sess s_blk_r_lat cell_io_int_mb cell_io_int_mb_max",
        "---------- ---------- -------------- ---------- ---------- ---------- ---------- ------------- ------------ ---------- "
        "------------ ----------- -------------- ---------- ---------- ---------- ---------- ---------- ------------ ------------ "
        "---------- ------------ ---------- ---------- ---------- ---------- ---------- ------------- ---------- ------------- ---------- "
        "--------------- ---------- -------------- ---------- -------------- ---------- ---------------- ---------- --------------- "
        "------------------ ----------- ----------- ------------ ------------ --------------- ---------- ---------- ---------- -----------"
        " -------------- ------------------",
        "37297         60 22/09/21 23:59          1       18.5       41.9        8.9          21.5         78.5       .806         .629    "
        "   2.813          1.353          1         .8        3.1      100.3       79.5            0           .2         .7        303.3  "
        "   2462.9        1.5    14324.9       13.5       17.2         252.3      305.1        3436.6     2124.8          1290.2        2.1"
        "           47.9       65.8         1635.6        223            207.1         .1           708.1              570.8        23.5"
        "        39.2            0            0               0          0          0        2.3          .1         1202.4            "
        "14558.3",
        "37298         60 22/09/21 23:59          1       18.5       41.9        8.9          21.5         78.5       .806         .629    "
        "   2.813          1.353          1         .8        3.1      100.3       79.5            0           .2         .7        303.3  "
        "   2462.9        1.5    14324.9       13.5       17.2         252.3      305.1        3436.6     2124.8          1290.2        2.1"
        "           47.9       65.8         1635.6        223            207.1         .1           708.1              570.8        23.5"
        "        39.2            0            0               0          0          0        2.3          .1         1202.4            ",
    ]

    return data


@pytest.fixture()
def artifact_url() -> str:
    """
    The full URL where the AWR Miner is located in the artifactory

    Returns
    -------
        string
           the full URL to the AWR-MINER.zip artifact
    """
    return "https://artifacthub-phx.oci.oraclecorp.com/artifactory/maa-plat-st-generic/occa/AWR-Miner.zip"


@pytest.fixture()
def bar_deprecation_message(artifact_url) -> str:
    """
    The BAR deprecation message as it appears in awr_miner_parse.py

    arameters
    ----------
        artifact_url : str
            The artifact_url fixture

    Returns
    -------
        string
           the BAR deprecation message
    """
    div_line = "=" * 136
    return (
        f"{div_line}\n"
        "WARNING: There are files in this collection extracted with BAR Miner.\n\n"
        "ONLY files obtained with OCCA AWR Miner 21.6.1 and later will be supported in future releases of OCCA.\n"
        f"Download the latest OCCA AWR Miner from : {artifact_url}\n"
        f"{div_line}\n"
    )


@pytest.fixture()
def awr_miner_deprecation_message(artifact_url) -> str:
    """
    The AWR Miner deprecation message as it appears in awr_miner_parse.py

    arameters
    ----------
        artifact_url : str
            The artifact_url fixture

    Returns
    -------
        string
           the AWR Miner deprecation message
    """
    div_line = "=" * 136
    return (
        f"{div_line}\n"
        "ERROR: There are files in this collection extracted with old version of OCCA AWR Miner.\n\n"
        "ONLY files obtained with OCCA AWR Miner 21.6.1 and later are supported by OCCA.\n"
        f"Download the latest OCCA AWR Miner from : {artifact_url}\n"
        f"{div_line}\n"
    )


@pytest.fixture()
def database_parameters_df() -> pd.DataFrame:
    """
    Create Database Parameters DataFrame.

    Returns
    -------
    pd.DataFrame
        A Database Parameters DataFrame
    """

    data = {
        "INSTANCE_NUMBER": [1, 1, 1, 1],
        "PARAMETER_NAME": ["p1", "p2", "p3", "p4"],
        "VALUE": ["p1val", "p2val", "p3val", "p4val"],
    }

    return pd.DataFrame(data)


@pytest.fixture()
def main_metrics_df() -> pd.DataFrame:
    """
    Create a Main Metrics DataFrame.

    Returns
    -------
    pd.DataFrame
        A Main Metrics DataFrame
    """

    data = {
        "snap": [169824, 169825, 169826],
        "dur_m": [15, 16, 15],
        "end": ["23/04/12", "23/04/12", "23/04/12"],
        "inst": [1, 1, 1],
        "os_cpu": [26.5, 25.3, 23.8],
        "os_cpu_max": [29.7, 28.1, 26.0],
        "os_cpu_sd": [1.5, 1.3, 1.4],
        "db_wait_ratio": [30.3, 30.9, 32.1],
        "db_cpu_ratio": [69.7, 69.1, 67.9],
        "cpu_per_s": [37.917, 34.426, 33.122],
        "cpu_per_s_sd": [1.996, 2.879, 2.537],
        "h_cpu_per_s": [50.242, 47.987, 45.116],
        "h_cpu_per_s_sd": [2.86, 2.53, 2.696],
        "aas": [54.5, 49.8, 48.8],
        "aas_sd": [4.0, 3.1, 2.2],
        "aas_max": [65.1, 56.1, 53.2],
        "db_time": [5448.7, 4977.2, 4877.7],
        "db_time_sd": [398.9, 313.3, 223.2],
        "sql_res_t_cs": [0.1, 0.1, 0.1],
        "bkgd_t_per_s": [2.2, 3.2, 2.3],
        "logons_s": [0.1, 0.1, 0.1],
        "logons_total": [3131.8, 3131.3, 3131.4],
        "exec_s": [83803.3, 69522.9, 63788.4],
        "hard_p_s": [0.4, 0.5, 1.1],
        "l_reads_s": [2681768.1, 2493819.5, 2368451.4],
        "commits_s": [173.1, 195.4, 170.8],
        "read_mb_s": [513.4, 665.2, 954.1],
        "read_mb_s_max": [888.9, 1486.0, 2036.2],
        "read_iops": [35483.0, 30002.0, 29702.5],
        "read_iops_max": [53416.7, 41398.1, 41512.5],
        "read_bks": [61714.7, 77493.4, 100368.2],
        "read_bks_direct": [21865.6, 40582.2, 48534.0],
        "write_mb_s": [36.3, 29.2, 25.2],
        "write_mb_s_max": [111.2, 82.7, 68.1],
        "write_iops": [1388.2, 1701.4, 1599.6],
        "write_iops_max": [2170.5, 2505.8, 2122.5],
        "write_bks": [2020.6, 1898.8, 1589.6],
        "write_bks_direct": [954.4, 794.9, 497.9],
        "redo_mb_s": [5.9, 4.6, 3.8],
        "db_block_gets_s": [21826.8, 20883.2, 16823.7],
        "db_block_changes_s": [13912.2, 15046.9, 12965.3],
        "gc_cr_rec_s": [0, 0, 0],
        "gc_cu_rec_s": [0, 0, 0],
        "gc_cr_get_cs": [0, 0, 0],
        "gc_cu_get_cs": [0, 0, 0],
        "gc_bk_corrupted": [0, 0, 0],
        "gc_bk_lost": [0, 0, 0],
        "px_sess": [0, 0, 0],
        "se_sess": [50.1, 50.0, 46.5],
        "s_blk_r_lat": [0.1, 0.1, 0.1],
        "cell_io_int_mb": [32944.0, 41648.0, 58704.1],
        "cell_io_int_mb_max": [56083.2, 91013.9, 124506.5],
    }

    return pd.DataFrame(data)


@pytest.fixture()
def sqlnet_metrics_df() -> pd.DataFrame:
    """
    Create SQL Net Metrics DataFrame.

    Returns
    -------
    pd.DataFrame
        A SQL Net Metrics DataFrame
    """

    data = {
        "snap": [169824, 169825, 169826],
        "inst": [1, 1, 1],
        "rqsts_to_from_client": [860700000000.0, 860770000000.0, 860830000000.0],
        "sqlnet_to_from_client": [860700000000.0, 860770000000.0, 860830000000.0],
        "sqlnet_bytes_received": [
            256830000000000.0,
            256850000000000.0,
            256860000000000.0,
        ],
        "sqlnet_bytes_sent": [828370000000000.0, 828440000000000.0, 828510000000000.0],
        "sqlnet_bytes_vector_from": [
            12718000000000.0,
            12719000000000.0,
            12720000000000.0,
        ],
        "sqlnet_bytes_vector_to": [
            16548000000000.0,
            16549000000000.0,
            16549000000000.0,
        ],
    }

    return pd.DataFrame(data)


@pytest.fixture()
def iostat_by_function_df() -> pd.DataFrame:
    """
    Create IOSTAT-BY-FUNCTION DataFrame.

    Returns
    -------
    pd.DataFrame
        A IOSTAT-BY-FUNCTION  DataFrame
    """

    data = {
        "SNAP_ID": [169825, 169825, 169825],
        "FUNCTION_NAME": ["Smart Scan", "Streams AQ", "Others"],
        "SM_R_REQS": [0, 13, 297548],
        "SM_W_REQS": [0, 0, 44126],
        "LG_R_REQS": [0.0, 0.0, 1547191602.0],
        "LG_W_REQS": [0, 0, 3128],
    }

    return pd.DataFrame(data)

@pytest.fixture
def io_object_type() -> pd.DataFrame:
    """
    Create sample data for io_object_type.

    Returns
    -------
    pd.DataFrame
        io_object_type DataFrame
    """
    data = {'OBJ_TYPE': ["never","gonna" ,"give","you","up" ]}
    return pd.DataFrame(data)

@pytest.fixture
def snap_history_df() -> pd.DataFrame:
    """
    Create sample data for io_object_type.

    Returns
    -------
    pd.DataFrame
        io_object_type DataFrame
    """
    data = {'SNAP_ID': ["OCCA","alosorio","test","cat1" ]}
    return pd.DataFrame(data)

def get_parse_ouput(thedir):
    """
    Part of the standard output coming from the parse() routine.

    Parameters
    ----------
        thedir : str
            A directory to be added to the message when is sent to stdoout

    Returns
    -------
      string
          with a subset of the standard output of parse()
    """
    sep = os.path.sep
    return (
        f"        wrote section: OS-INFORMATION to {thedir}{sep}OS-INFORMATION.csv\n"
        f"        wrote section: OS-INFORMATION2 to {thedir}{sep}OS-INFORMATION2.csv\n"
        f"        wrote section: PATCH-HISTORY to {thedir}{sep}PATCH-HISTORY.csv\n"
        f"        wrote section: MODULE to {thedir}{sep}MODULE.csv\n"
        f"        wrote section: SNAP-HISTORY to {thedir}{sep}SNAP-HISTORY.csv\n"
        f"        wrote section: MEMORY to {thedir}{sep}MEMORY.csv\n"
        f"        wrote section: MEMORY-SGA-ADVICE to {thedir}{sep}MEMORY-SGA-ADVICE.csv\n"
        f"        wrote section: MEMORY-PGA-ADVICE to {thedir}{sep}MEMORY-PGA-ADVICE.csv\n"
        f"        wrote section: SIZE-ON-DISK to {thedir}{sep}SIZE-ON-DISK.csv\n"
        f"        wrote section: OSSTAT to {thedir}{sep}OSSTAT.csv\n"
        f"        wrote section: MAIN-METRICS to {thedir}{sep}MAIN-METRICS.csv\n"
        f"        wrote section: SQLNET-METRICS to {thedir}{sep}SQLNET-METRICS.csv\n"
        f"        wrote section: DATABASE-PARAMETERS to {thedir}{sep}DATABASE-PARAMETERS.csv\n"
        f"        wrote section: DATABASE-PARAMETERS2 to {thedir}{sep}DATABASE-PARAMETERS2.csv\n"
        f"        wrote section: SNAP-HISTORY-TZ to {thedir}{sep}SNAP-HISTORY-TZ.csv\n"
        f"        wrote section: AVERAGE-ACTIVE-SESSIONS to {thedir}{sep}AVERAGE-ACTIVE-SESSIONS.csv\n"
        f"        wrote section: IO-WAIT-HISTOGRAM to {thedir}{sep}IO-WAIT-HISTOGRAM.csv\n"
        f"        wrote section: IO-OBJECT-TYPE to {thedir}{sep}IO-OBJECT-TYPE.csv\n"
        f"        wrote section: IOSTAT-BY-FUNCTION to {thedir}{sep}IOSTAT-BY-FUNCTION.csv\n"
        f"        wrote section: TOP-N-TIMED-EVENTS to {thedir}{sep}TOP-N-TIMED-EVENTS.csv\n"
        f"        wrote section: SYSSTAT to {thedir}{sep}SYSSTAT.csv\n"
        f"        wrote section: SEGMENT-IO to {thedir}{sep}SEGMENT-IO.csv\n"
        f"        wrote section: TOP-SQL-SUMMARY to {thedir}{sep}TOP-SQL-SUMMARY.csv\n"
        f"        wrote section: TOP-SQL-BY-SNAPID to {thedir}{sep}TOP-SQL-BY-SNAPID.csv\n"
    )


def test_clean_numeric_delimiters_number_with_numeric_delimiters():
    """
    Test normal operation of the clean_numeric_delimiters.

    Given: a number containing numeric separators

    When: clean_numeric_delimiters() is invoked

    Then: the number is returned with the thousends separator as ','
          and decimal  separator as '.'
    """

    # Text Value , conversion needed
    test_str = "123,123.123"
    expected = "123.123,123"
    assert parse.clean_numeric_delimiters(test_str) == expected



def test_clean_numeric_delimiters_number_without_numeric_delimiters():
    """
    Test normal operation of the clean_numeric_delimiters.

    Given: a number not containing numeric separators

    When: clean_numeric_delimiters() is invoked

    Then: the number is returned untouched
    """

    # Numeric Value , return value without modification
    test_str = 123123
    expected = 123123
    assert parse.clean_numeric_delimiters(test_str) == expected


def test_determine_numeric_delimiters_in_memory_metrics(memory_block_data, capsys):
    """
    Test normal operation of the determine_numeric_delimiters in Memory block data.

    Given: a list of lines from BEGIN-MEMORY block containing metric data

    When: determine_numeric_delimiters() is invoked

    Then: the message "Found comma as numeric separator in Memory Value {column} {value}"
          is shown on stdout and the function returns True

    Parameters
    ----------
        memory_block_data : list[]
            The memory_block_data fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """

    # Test for the presence of comma as decimal separator in SGA column value
    list_replaced = [s.replace("3.7", "3,7") for s in memory_block_data]
    expected = "        Info : Found comma as numeric separator in Memory Value 2 '3,7'. Enabling adjustment of numeric separators...\n"
    assert parse.determine_numeric_delimiters(list_replaced)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Test for the presence of comma as decimal separator in PGA column value
    list_replaced = [s.replace(".8", ",8") for s in memory_block_data]
    expected = "        Info : Found comma as numeric separator in Memory Value 3 ',8'. Enabling adjustment of numeric separators...\n"
    assert parse.determine_numeric_delimiters(list_replaced)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Test for the presence of comma as decimal separator in TOTAL column value
    list_replaced = [s.replace("4.5", "4,5") for s in memory_block_data]
    expected = "        Info : Found comma as numeric separator in Memory Value 4 '4,5'. Enabling adjustment of numeric separators...\n"
    assert parse.determine_numeric_delimiters(list_replaced)
    captured = capsys.readouterr()
    assert expected in captured.out


def test_determine_numeric_delimiters_in_cpu_metrics(main_metrics_block_data, capsys):
    """
    Test normal operation of the determine_numeric_delimiters in Main Metrics block data.

    Given: a list of lines from BEGIN-MAIN-METRICS block containing metric data

    When: determine_numeric_delimiters() is invoked

    Then: the message "Found comma as numeric separator in Main Metrics Value {column} {value}"
          is shown on stdout and the function returns True

    Parameters
    ----------
        main_metrics_block_data : list[]
            The main_metrics_block_data fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """

    # Test for the presence of comma as decimal separator in cpu_per_s column value
    list_replaced = [s.replace("78.5", "78,5") for s in main_metrics_block_data]
    expected = "        Info : Found comma as numeric separator in Main Metrics 9 '78,5'. Enabling adjustment of numeric separators...\n"
    assert parse.determine_numeric_delimiters(list_replaced)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Test for the presence of comma as decimal separator in cpu_per_s_sd column value
    list_replaced = [s.replace(".806", ",806") for s in main_metrics_block_data]
    expected = "        Info : Found comma as numeric separator in Main Metrics 10 ',806'. Enabling adjustment of numeric separators...\n"
    assert parse.determine_numeric_delimiters(list_replaced)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Test for the presence of comma as decimal separator in h_cpu_per_s column value
    list_replaced = [s.replace(".629", ",629") for s in main_metrics_block_data]
    expected = "        Info : Found comma as numeric separator in Main Metrics 11 ',629'. Enabling adjustment of numeric separators...\n"
    assert parse.determine_numeric_delimiters(list_replaced)
    captured = capsys.readouterr()
    assert expected in captured.out


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_get_versions_from_os_information_block(awr_miner_out, file):
    """
    Test the obtention of database version and AWR miner version from the OS-INFORMATION block.

    Given: an AWR miner file containing a standard OS-INFORMATION block

    When: get_versions_from_os_information_block() is invoked

    Then: the list of  full database version , major database version and AWR miner version is returned

    Parameters
    ----------
        file : file name string
            The builtin pytest.mark.parametrize decorator
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    expected = ["19.0.0.0.0", "19", "21.6.1"]
    assert parse.get_versions_from_os_information_block(awr_miner_out, file) == expected


def test_get_versions_from_os_information_block_bad_lines(tmp_path):
    """
    Test that version parsing doesn't throw exceptions, even if string
    is malformed.

    Given: an AWR miner file containing a standard OS-INFORMATION
    block, generated in the test

    When: get_versions_from_os_information_block() is invoked

    Then: Empty set should be returned due to parsing issues
    """

    filename = "awr_test_file.out"
    test_file = tmp_path / filename
    test_file.write_text('''
------------------------- BEGIN-OS-INFORMATION -----------------------------------------
Enter value for awr_miner_ver: 
~~BEGIN-OS-INFORMATION~~
STAT_NAME                                                    STAT_VALUE
------------------------------------------------------------ ------------------------------------------------------------
NUM_CPUS                                                     128
NUM_CPU_CORES                                                64
NUM_CPU_SOCKETS                                              2
~~END-OS-INFORMATION~~
Elapsed: 00:00:00.24
''')
    result = parse.get_versions_from_os_information_block(tmp_path, filename)
    assert len(result) == 0


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-11111-11111.out"])
def test_get_versions_from_os_information_block_missing_version_lines(awr_miner_out, file):
    """
    Test the operation of get_versions_from_os_information_block when data is missing in the file is going to
    look if OS-INFORMATION2 block has the version.

    Given: an AWR miner file which does not have database version and AWR miner lines in OS-INFORMATION block

    When: get_versions_from_os_information_block() is invoked

    Then: a version from OS-INFORMATION2 block is returned.

    Parameters
    ----------
        file : file name string
            The builtin pytest.mark.parametrize decorator
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    expected = ['19.0.0.0.0', '19', '0']
    assert parse.get_versions_from_os_information_block(awr_miner_out, file) == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test10-37296-37498.out"])
def test_are_ora_errors_in_file_is_true(awr_miner_out, file):
    """
    Test the presence of 'ORA-' errors in an AWR miner file in a mandatory section

    Given: a faulty AWR miner file with 'ORA-' errors in section OS-INFORMATION

    When: are_ora_errors_in_file() is invoked

    Then: True is returned indicating there are 'ORA-' errors in a mandatory section in the file

    Parameters
    ----------
        file : file name string
            The builtin pytest.mark.parametrize decorator
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    expected = True
    assert parse.are_ora_errors_in_file(awr_miner_out, file) == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test1-37296-37498.out"])
def test_are_ora_errors_in_file_in_not_mandatory_section_is_false(awr_miner_out, file):
    """
    Test the presence of 'ORA-' errors in an AWR miner file in a not mandatory section

    Given: a faulty AWR miner file with 'ORA-' errors in section SEGMENT-IO-AWR

    When: are_ora_errors_in_file() is invoked

    Then: False is returned

    Parameters
    ----------
        file : file name string
            The builtin pytest.mark.parametrize decorator
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    expected = False
    assert parse.are_ora_errors_in_file(awr_miner_out, file) == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_are_ora_errors_in_file_is_false(awr_miner_out, file):
    """
    Test the lack  of 'ORA-' errors in an AWR miner file

    Given: an AWR miner file without 'ORA-' errors

    When: are_ora_errors_in_file() is invoked

    Then: False is returned indicating there are no 'ORA-' errors in the file

    Parameters
    ----------
        file : file name string
            The builtin pytest.mark.parametrize decorator
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    expected = False
    assert parse.are_ora_errors_in_file(awr_miner_out, file) == expected


def test_awr_miner_out_dir_does_not_exists(data_dir, capsys):
    """
    Test missing awr_miner_out directory.

    Given: an unexistant directory.

    When: check_awr_miner_path_exists() is invoked

    Then: the message 'ERROR : Directory {directory} does not exist; cannot continue' is displayed on stdout
        and the function should return False

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """

    # Define fake paths for AWR_MINER_PATH and awr_miner_out directory
    awr_fake_miner_path = os.path.join(str(data_dir), "fakedir")
    awr_fake_miner_out_path = os.path.join(awr_fake_miner_path, "awr_miner_out")

    expected = False
    dir_exists = parse.check_awr_miner_path_exists(awr_fake_miner_path)
    captured = capsys.readouterr()

    # Test if the directory exists
    assert expected == dir_exists

    # Test the message written on stdout
    expected = f"ERROR : Directory {awr_fake_miner_out_path} does not exist; cannot continue\n"
    assert expected in captured.out


def test_awr_miner_out_does_not_have_files(data_dir, capsys):
    """
    Test awr_miner_out directory does not contain AWR collection files.

    Given: an existant directory without files on it

    When: check_awr_miner_path_exists() is invoked

    Then: the message 'ERROR : No files found in  {directory}.
          Expecting awr-hist*.out files; cannot continue' is displayed on stdout

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    # Set the Working directories
    awr_fake_miner_path = os.path.join(str(data_dir), "fakedir")
    awr_fake_miner_out_path = os.path.join(awr_fake_miner_path, "awr_miner_out")

    # Delete them if they exist from previous executions
    if Path.is_dir(Path(awr_fake_miner_out_path)):
        os.rmdir(awr_fake_miner_out_path)
    if Path.is_dir(Path(awr_fake_miner_path)):
        os.rmdir(awr_fake_miner_path)

    # Create awr_miner_out directory
    os.mkdir(awr_fake_miner_path)
    os.mkdir(awr_fake_miner_out_path)

    parse.check_awr_miner_files_exist(awr_fake_miner_path)
    captured = capsys.readouterr()
    expected = f"\n\nERROR : No files found in {awr_fake_miner_out_path}. Expecting awr-hist*.out files; cannot continue\n"
    assert expected in captured.out

    # Remove the empty awr_miner_out directory created
    os.rmdir(awr_fake_miner_out_path)
    os.rmdir(awr_fake_miner_path)


def test_deprecation_message(awr_miner_out, awr_miner_deprecation_message, capsys):
    """
    Test the AWR Miner Warning deprecation message

    Given: AWR_MINER_VERSION_DEPRECATED var as True

    When: print_bar_deprecation_message() is invoked

    Then: the Warning message is displayed on stdout indicating that either
          the collection has been obtained using an OCCA AWR Miner lower
          than the AWR_MINER_MIN_SUPPORTED_VERSION or the collection has
          been obtained using BAR Miner.

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture
        awr_miner_deprecation_message: String
            The awr_miner_deprecation_message fixture
        awr_miner_out : Path
            The awr_miner_out fixture

    """
    parse.AWR_MINER_VERSION_DEPRECATED = True

    parse.print_deprecation_message(awr_miner_out,deletefiles=False)
    captured = capsys.readouterr()

    expected = awr_miner_deprecation_message
    assert expected == captured.out


def test_bar_deprecation_message_warning(awr_miner_out, bar_deprecation_message, capsys):
    """
    Test the BAR Miner Warning deprecation message

    Given: AWR_MINER_VERSION_DEPRECATED var as True

    When: print_bar_deprecation_message() is invoked

    Then: the Warning message is displayed on stdout indicating that either
          the collection has been obtained using an OCCA AWR Miner lower
          than the AWR_MINER_MIN_SUPPORTED_VERSION or the collection has
          been obtained using BAR Miner.

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture
        bar_deprecation_message: String
            The bar_deprecation_message fixture
        awr_miner_out : Path
            The awr_miner_out fixture

    """
    parse.BAR_COLLECTION_DETECTED = True
    parse.BAR_MINER_WARNING_MODE = True

    parse.print_bar_deprecation_message(awr_miner_out)
    captured = capsys.readouterr()

    expected = bar_deprecation_message
    assert expected == captured.out


def test_bar_deprecation_message_error(awr_miner_out, bar_deprecation_message, capsys):
    """
    Test the BAR Miner Error deprecation message

    Given: AWR_MINER_VERSION_DEPRECATED var as True and BAR_MINER_ERROR_MODE as True

    When: print_bar_deprecation_message() is invoked

    Then: the Error message is displayed on stdout indicating that either the collection
          has been obtained using an OCCA AWR Miner lower than the AWR_MINER_MIN_SUPPORTED_VERSION
          or the collection has been obtained using BAR Miner. The parsing is stopped.

    Parameters
    ----------
        capsys : CaptureFixture[str]
            The pytest capsys fixture
        bar_deprecation_message: String
            The bar_deprecation_message fixture
        awr_miner_out : Path
            The awr_miner_out fixture

    """
    parse.BAR_COLLECTION_DETECTED = True
    parse.BAR_MINER_WARNING_MODE = True
    parse.BAR_MINER_WARNING_MODE = False
    parse.BAR_MINER_ERROR_MODE = True

    expected = bar_deprecation_message.replace("WARNING", "ERROR")
    expected = expected.replace("will be supported in future releases of", "are supported by")

    parse.print_bar_deprecation_message(awr_miner_out)
    captured = capsys.readouterr()
    assert expected == captured.out


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test3-37296-37498.out"])
def test_is_valid_db_version(file):
    """
    Test the normal operation of is_valid_db_version() routine.

    Given: A database version higher than 11g

    When: is_valid_db_version() is invoked

    Then: True is returned

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator

    """
    assert parse.is_valid_db_version(file, "19") is True


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test3-37296-37498.out"])
def test_is_valid_db_version_bad_version(file):
    """
    Test the normal operation of is_valid_db_version() routine.

    Given: A database version lower than 11g

    When: is_valid_db_version() is invoked

    Then: False is returned and the file is added to badFiles list

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator

    """
    # Clean up badFiles list
    parse.badFiles = []

    # Assert returns false
    db_version = "10"
    assert parse.is_valid_db_version(file, db_version) is False

    # Check the contents of badFiles List
    expected = [
        {
            "minerFile": file,
            "error": "Not supported database version, should be 11g or higher.",
            "reason": f"The collection is for database version: {db_version}",
        }
    ]
    assert parse.badFiles == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test3-37296-37498.out"])
def test_parse_with_invalid_database_version_in_file(awr_miner_out, awr_miner_parsed, awr_miner_parsed_db, file, capsys):
    """
    Test collection files extracted from database versions lower than 11g.

    Given: A file containing a VERSION parameter lower then 11g

    When: parse() is invoked

    Then: the Warning message is displayed on stdout indicating that the collection
          file is excluded from the analysis and won't be parsed.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        awr_miner_parsed_db : Path
            The awr_miner_parsed_db fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    awr_miner_parsed_csv_dir = os.path.join(awr_miner_parsed_db, file)

    expected = "        Warning : Collection should be for 11g or higher databases, Skipping file...\n"
    parse.parse(awr_miner_out, awr_miner_parsed, file)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Cleanup created directories and env
    shutil.rmtree(awr_miner_parsed_csv_dir, ignore_errors=True)


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test10-37296-37498.out"])
def test_parse_with_ora_errors_in_file(awr_miner_out, awr_miner_parsed, file, capsys):
    """
    Test collection file contains 'ORA-' errors

    Given: A file containing 'ORA-' errors

    When: parse() is invoked

    Then: the Warning message is displayed on stdout indicating that the collection
          file is excluded from the analysis and won't be parsed.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    # Test the expected message is on stdout
    expected = "        Warning : Collection contains ERRORs, Skipping file...\n"
    parse.parse(awr_miner_out, awr_miner_parsed, file)
    captured = capsys.readouterr()
    assert expected in captured.out


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test2-37296-37498.out"])
def test_parse_with_awr_miner_deprecated_version(awr_miner_out, awr_miner_parsed, file, capsys):
    """
    Test the detection of older AWR_MINER_VERSION during the normal operation of parse()

    Given: A file with AWR_MINER_VERSION less than AWR_MINER_MIN_SUPPORTED_VERSION

    When: parse() is invoked

    Then: the var AWR_MINER_VERSION_DEPRECATED should get True.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture , only used here to hide the parse output

    """
    expected = True
    parse.parse(awr_miner_out, awr_miner_parsed, file)
    captured = capsys.readouterr()

    # Assert the dectection flag gets true
    assert parse.AWR_MINER_VERSION_DEPRECATED == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_parse(awr_miner_out, awr_miner_parsed, awr_miner_parsed_db, file, capsys):
    """
    Test the normal behaviour of the parse routine.

    Given: A file with a valid AWR Miner collection

    When: parse() is invoked

    Then: the file is parsed and the csv files are created withouth errors
          and with content. The messages displayed on the stdout for the
          parsing of the file are correct.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        awr_miner_parsed_db : Path
            The awr_miner_parsed_db fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """

    parse.badParses = []

    awr_miner_parsed_csv_dir = os.path.join(awr_miner_parsed_db, file).replace(".out", "")

    # Get the standard parse output for each of the csv files
    parse_output = get_parse_ouput(awr_miner_parsed_csv_dir)
    expected = (
        "\nParsing file awr-hist-609708250-oracle-database-00000-37296-37498.out\n"
        "     DBID: 609708250, DB: oracle-database-00000, VERSION: 19.0.0.0.0, "
        "snap_ids: 37296 thru 37498, AWR_MINER_VERSION: 21.6.1\n" + parse_output
    )
    parse.parse(awr_miner_out, awr_miner_parsed, file)
    captured = capsys.readouterr()
    assert expected == captured.out

    # Check created files
    parsed_files = [
        "OS-INFORMATION",
        "OS-INFORMATION2",
        "PATCH-HISTORY",
        "MODULE",
        "SNAP-HISTORY",
        "MEMORY",
        "MEMORY-SGA-ADVICE",
        "MEMORY-PGA-ADVICE",
        "SIZE-ON-DISK",
        "OSSTAT",
        "MAIN-METRICS",
        "SQLNET-METRICS",
        "DATABASE-PARAMETERS",
        "DATABASE-PARAMETERS2",
        "SNAP-HISTORY-TZ",
        "AVERAGE-ACTIVE-SESSIONS",
        "IO-WAIT-HISTOGRAM",
        "IO-OBJECT-TYPE",
        "IOSTAT-BY-FUNCTION",
        "TOP-N-TIMED-EVENTS",
        "SYSSTAT",
        "SEGMENT-IO",
        "TOP-SQL-SUMMARY",
        "TOP-SQL-BY-SNAPID",
    ]
    for f in parsed_files:
        fname = f + ".csv"
        fpath = os.path.join(awr_miner_parsed_csv_dir, fname)

        # File exists
        assert os.path.isfile(fpath)

        # File is not empty
        assert os.path.getsize(fpath) > 0

    # Assert badParses is empty
    assert not parse.badParses

    # Cleanup created directories and env
    shutil.rmtree(awr_miner_parsed, ignore_errors=True)


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test4-37296-37498.out"])
def test_parse_with_unnamed_columns(awr_miner_out, awr_miner_parsed, awr_miner_parsed_db, file, capsys):
    """
    Test the behaviour of parse failures

    Given: A file with a valid AWR Miner collection

    When: parse() is invoked

    Then: the file is checked for 'Unnamed' columns and added to the badParse list.
      An informational message is written to stdout indicating the fact that the
      file can't be processed and the reason of failure.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        awr_miner_parsed_db : Path
            The awr_miner_parsed_db fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    awr_miner_db_new = str(awr_miner_parsed_db).replace("db_oracle-database-00000", "db_oracle-database-00000-test4")
    awr_miner_parsed_csv_dir = os.path.join(awr_miner_db_new, file).replace(".out", "")

    expected = [
        {
            "minerFile": "awr-hist-609708250-oracle-database-00000-test4-37296-37498.out",
            "section": "PATCH-HISTORY",
            "error": "Unnamed: 4",
            "reason": "Unparseable content",
            "file": awr_miner_parsed_csv_dir + os.path.sep + "PATCH-HISTORY.csv",
        }
    ]

    parse.parse(awr_miner_out, awr_miner_parsed, file)

    # Not used , just to hide the stdout on execution
    captured = capsys.readouterr()

    assert parse.badParses == expected

    # Cleanup created directories and env
    shutil.rmtree(awr_miner_parsed, ignore_errors=True)


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test5-37296-37498.out"])
def test_parse_and_rename_columns(awr_miner_out, awr_miner_parsed, awr_miner_parsed_db, file, capsys):
    """
    Test the rename of columns in the DataFrame to normalize them

    Given: A file with a valid AWR Miner collection

    When: parse() is invoked

    Then: the DataFrame columns are renamed to the expected column names

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        awr_miner_parsed_db : Path
            The awr_miner_parsed_db fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture

    """
    awr_miner_db_new = str(awr_miner_parsed_db).replace("db_oracle-database-00000", "db_oracle-database-00000-test5")
    awr_miner_parsed_csv_dir = os.path.join(awr_miner_db_new, file).replace(".out", "")

    parse.parse(awr_miner_out, awr_miner_parsed, file)

    # Not used , just to hide the stdout on execution
    captured = capsys.readouterr()

    # Check global column rename from Snap Id to SNAP_ID (MEMORY,csv)
    csv_file = os.path.join(awr_miner_parsed_csv_dir, "MEMORY.csv")
    assert os.path.isfile(csv_file)

    with open(csv_file) as f:
        first_line = f.readline().strip("\n")

    assert "SNAP_ID," in first_line  # Snap ID to SNAP_ID

    # Check column rename from cpu_p_sec to cpu_per_s in MAIN-METRICS.csv file
    csv_file = os.path.join(awr_miner_parsed_csv_dir, "MAIN-METRICS.csv")
    assert os.path.isfile(csv_file)

    with open(csv_file) as f:
        first_line = f.readline().strip("\n")

    assert ",cpu_per_s," in first_line  # cpu_p_sec to cpu_per_s

    # Check column renames in SQLNET-METRICS.csv:
    #  -> sqlnet_bytes_received to sqlnet_bytes_received_from_client
    #  -> sqlnet_bytes_sent to sqlnet_bytes_sent_to_client
    #  -> sqlnet_bytes_vector_from to sqlnet_bytes_vector_from_client
    #  -> sqlnet_bytes_vector_to to sqlnet_bytes_vector_to_client
    csv_file = os.path.join(awr_miner_parsed_csv_dir, "SQLNET-METRICS.csv")
    assert os.path.isfile(csv_file)

    with open(csv_file) as f:
        first_line = f.readline().strip("\n")

    assert ",sqlnet_bytes_received_from_client," in first_line
    assert ",sqlnet_bytes_sent_to_client," in first_line
    assert ",sqlnet_bytes_vector_from_client," in first_line
    assert ",sqlnet_bytes_vector_to_client," in first_line

    # Check column rename from FUNCTION NAME to FUNCTION_NAME in IOSTAT-BY-FUNCTION.csv
    csv_file = os.path.join(awr_miner_parsed_csv_dir, "IOSTAT-BY-FUNCTION.csv")
    assert os.path.isfile(csv_file)

    with open(csv_file) as f:
        first_line = f.readline().strip("\n")
    assert ",FUNCTION_NAME," in first_line

    # Cleanup created directories and env
    shutil.rmtree(awr_miner_parsed, ignore_errors=True)


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test6-37296-37498.out"])
def test_parse_with_missing_sections(awr_miner_out, awr_miner_parsed, file, capsys):
    """
    Test the existance of missing sections in the AWR Miner file.

    Given: A file with missing sections

    When: parse() is invoked

    Then: the warning message indicating which sections are missing in the
        collection file is displayed on stdout.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    expected = "        Warning : Collection does not contain  sections ['MODULE', 'PATCH-HISTORY']\n"
    parse.parse(awr_miner_out, awr_miner_parsed, file)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Cleanup created directories and env
    shutil.rmtree(awr_miner_parsed, ignore_errors=True)


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test7-37296-37498.out"])
def test_parse_with_missing_mandatory_sections(awr_miner_out, awr_miner_parsed, file, capsys):
    """
    Test the existance of missing mandatory sections in the AWR Miner file.

    Given: A file with missing sections

    When: parse() is invoked

    Then: the Error message indicating which mandatory sections are missing in the
        collection file is displayed on stdout, the parsed files obtained from the
        collection are deleted as  the collection file is invalid and can't be processed

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    expected = "        Warning : Collection does not contain mandatory sections ['SIZE-ON-DISK'], Skipping file...\n"
    parse.parse(awr_miner_out, awr_miner_parsed, file)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Cleanup created directories and env
    shutil.rmtree(awr_miner_parsed, ignore_errors=True)


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test8-37296-37498.out"])
def test_parse_with_malformed_rows(awr_miner_out, awr_miner_parsed, file, capsys):
    """
    Test the presence corrupted data (unable to decode) in MODULE column of TOP-SQL-BY-SNAPID block.

    Intentionally added 4 whitespaces in the ACTION column before the character '/'  to force the
    detection of those lines as corrupted. This modification has been performed on the following
    line numbers: 21962, 22014, 22056 and 22080. The other 4 rows containing unicode chars but
    which its length is coherent with the separator line are : 22133, 22198, 22263 and 22911

    Given: A file containing corrupted data for MODULE column in the expected block

    When: parse() is invoked

    Then: the lines are discarded when building the csv fie and a message indicating this fact
        is displayed on stdout.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        file : file
            The builtin pytest.mark.parametrize decorator
        capsys : CaptureFixture[str]
            The pytest capsys fixture
    """
    expected = "          Warning : 4 rows ignored from source due and assumed corrupt.\n"

    parse.parse(awr_miner_out, awr_miner_parsed, file)
    captured = capsys.readouterr()
    assert expected in captured.out

    # Cleanup created directories and env
    shutil.rmtree(awr_miner_parsed, ignore_errors=True)


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_get_min_snapshot_id_from_snap_history_tz_block(awr_miner_out, file):
    """
    Test the extraction of min_snap_id from SNAP-HISTORY-TZ block

    Given: A file containing SNAP-HISTORY-TZ block

    When: get_min_snapshot_id_from_snap_history_tz_block() is invoked

    Then: the min_snap_id is returned from the first rows in the block

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = 37296

    actual = parse.get_min_snapshot_id_from_snap_history_tz_block(awr_miner_out, file)
    assert expected == actual


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_get_snaphosts_from_snap_memory_block(awr_miner_out, file):
    """
    Test the extraction of min_snap_id and max_snap_id from SNAP-HISTORY block

    Given: A file containing SNAP-HISTORY block

    When: get_snapshots_from_snap_history_block() is invoked

    Then: the min_snap_id and max_snap_id should returned within a list

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = [37297, 37498]

    actual = parse.get_snap_id_range_from_memory_section(awr_miner_out/file)
    assert expected == actual


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_is_valid_file_name(file):
    """
    Test if the file name matches the expected naming convention.

    Given: A file name matching the standard naming convention

    When: is_valid_file_name() is invoked

    Then: True is returned

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = True
    actual = parse.is_valid_file_name(file)
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498-badfilename.out"])
def test_is_valid_file_name_with_bad_filename(file):
    """
    Test if the file name matches the expected naming convention.

    Given: A file name NOT matching the standard naming convention

    When: is_valid_file_name() is invoked

    Then: False is returned

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    # Clean out badFiles list
    parse.badFiles = []

    expected = False
    actual = parse.is_valid_file_name(file)

    # Test returns true
    assert expected == actual

    # Test the contents of badFiles List
    expected = [
        {
            "minerFile": file,
            "error": "file name does not match the naming convention, no match on pattern",
            "expected": "awr-hist-<DBID>-<DBNAME>-<MIN_SNAP_ID>-<MAX_SNAP_ID>.out",
        }
    ]
    assert parse.badFiles == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_get_miner_file_name_pieces(file):
    """
    Test the obtention of dbid,dbname,snap_id_start and snap_id_end from the file name

    Given: A file name matching the standard naming convention

    When: get_miner_file_name_pieces() is invoked

    Then: A dict containing each of the pieces extracted from the file name

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = {
        "dbid": "609708250",
        "dbname": "oracle-database-00000",
        "snap_id_start": "37296",
        "snap_id_end": "37498",
    }
    actual = parse.get_miner_file_name_pieces(file)
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-609708250-oracle-database-00000-37296-37498.out"])
def test_get_miner_file_name_pieces_with_bad_filename(file):
    """
    Test the behaviour of get_miner_file_name_pieces() when the
    file name does not match the standard naming convention

    Given: A file name NOT matching the standard naming convention

    When: get_miner_file_name_pieces() is invoked

    Then: An Empty dict is returned

    Parameters
    ----------
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    expected = {}
    actual = parse.get_miner_file_name_pieces(file)
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_validate_snapshot_id_start(awr_miner_out, file):
    """
    Test the normal behaviour of validate_snapshot_id_start() routine

    Given: A file name matching the standard naming convention with valid snapshot ids

    When: validate_snapshot_id_start() is invoked

    Then: True is returned

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    # Set min and max snapshot ids. NOTE : are integers
    min_snap_id = 37297

    expected = True
    actual = parse.validate_snapshot_id_start(awr_miner_out, file, min_snap_id)
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498-20030525.out"])
def test_validate_snapshot_ids_with_bad_filename(awr_miner_out, file):
    """
    Test the behaviour of validate_snapshot_id_start() routine when the
    file passed is matching the regex applied on is_valid_file_name()
    but the file name is still not valid. In this test we suffix the
    file name with a date '-20030525' we check the start_snap_id matches
    the contents of the collection file.

    Given: A file matching the regex applied by is_valid_file_name() routine

    When: validate_snapshot_id_start() is invoked

    Then: False is returned and an error message is printed on stdout.

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    # The routine get_miner_file_name_pieces() will return:
    #  { 'dbid': '609708250',
    #   'dbname': 'oracle-database-00000-37297',
    #   'snap_id_start': '37498'
    #   'snap_id_end': '20030525',
    #
    #  }
    min_snap_id_from_file_name = 37498
    min_snap_id_from_collection = 37297
    min_snap_id_from_range = 37198
    max_snap_id_from_range = 37396

    # Clean out badFiles list
    parse.warning_files = []

    # Test the snapshots are not in the file
    expected = True
    actual = parse.validate_snapshot_id_start(awr_miner_out, file, min_snap_id_from_file_name)
    assert actual == expected

    expected = [
        {
            "minerFile": file,
            "warning": "file name does not match the naming convention, invalid snapshot start",
            "expected": "awr-hist-<DBID>-<DBNAME>-<MIN_SNAP_ID>-<MAX_SNAP_ID>.out",
            "reason": "MIN_SNAP_ID from filename: "
            + str(min_snap_id_from_file_name)
            + ", MIN_SNAP_ID from collection: "
            + str(min_snap_id_from_collection)
            + " Expected to be between "
            + str(min_snap_id_from_range)
            + " and "
            + str(max_snap_id_from_range),
        }
    ]
    assert parse.warning_files == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_is_valid_snapshot_range(awr_miner_out, file):
    """
    Test the normal behaviour of is_valid_snapshot_range() routine

    Given: A file name matching the standard naming convention with valid snapshot ids

    When: is_valid_snapshot_range() is invoked

    Then: True is returned

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    # Set min and max snapshot ids. NOTE : are integers
    min_snap_id = 37296
    max_snap_id = 37498

    expected = True
    actual = parse.is_valid_snapshot_range(awr_miner_out, file, min_snap_id, max_snap_id)
    assert actual == expected


@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498-20030525.out"])
def test_is_valid_snapshot_range_with_bad_filename(awr_miner_out, file):
    """
    Test the behaviour of is_valid_snapshot_range() routine when the
    file passed is matching the regex applied on is_valid_file_name()
    but the file name is still not valid. In this test we suffix the
    file name with a date '-20030525' we check the difference between
    min and max is less than the value set for snap_diff variable (1000)

    Given: A file name matching the standard naming convention with valid snapshot ids

    When: is_valid_snapshot_range() is invoked

    Then: False is returned and the file is added to badFiles List

    Parameters
    ----------
        awr_miner_out : Path
            The awr_miner_out fixture
        file : file
            The builtin pytest.mark.parametrize decorator
    """
    # Cleanup up badFiles list
    parse.warning_files = []

    # Set min and max snapshot ids. NOTE : are integers
    min_snap_id = 37498
    max_snap_id = 20030525
    snap_diff = 5760

    expected = True
    actual = parse.is_valid_snapshot_range(awr_miner_out, file, min_snap_id, max_snap_id)
    assert actual == expected

    # Check the record is created in  badFiles
    expected = [
        {
            "minerFile": file,
            "warning": "file name does not match the naming convention, snap range mistmatch",
            "expected": "awr-hist-<DBID>-<DBNAME>-<MIN_SNAP_ID>-<MAX_SNAP_ID>.out",
            "reason": "The expected difference between min " + str(min_snap_id) + " and"
            " max " + str(max_snap_id) + " snapshots must be less than " + str(snap_diff),
        }
    ]
    assert parse.warning_files == expected


def test_get_awr_miner_path_read_from_dir(awr_miner_path):
    """
    Test the normal operation of get_awr_miner_path() routine

    Given: AWR_MINER_PATH is not present on the environment

    When: get_awr_miner_path() is invoked

    Then: The value of the current directory is returned

    Parameters
    ----------
        awr_miner_path : Path
            The awr_miner_path fixture
    """
    os.chdir(awr_miner_path)
    assert parse.get_awr_miner_path() == awr_miner_path


def test_get_awr_miner_path_read_from_env():
    """
    Test the normal operation of get_awr_miner_path() routine

    Given: AWR_MINER_PATH variable present on the execution environment.

    When: get_awr_miner_path() is invoked

    Then: The value of the variable is returned
    """
    # Instantiate Monkepatch
    mp = pytest.MonkeyPatch()

    expected = Path("/tmp").resolve()

    # Set AWR_MINER_PATH on the environment
    mp.setenv("AWR_MINER_PATH", str(expected))
    assert parse.get_awr_miner_path() == expected


def test_get_awr_miner_parsed_path(data_dir, awr_miner_parsed):
    """
    Test the normal operation of get_awr_miner_parsed_path() routine

    Given: An existant directory

    When: get_awr_miner_parsed_path() is invoked

    Then: The path to awr_miner_parsed is returned under the directory

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
    """
    expected = awr_miner_parsed
    assert parse.get_awr_miner_parsed_path(data_dir) == expected


def test_get_awr_miner_parsed_bad_dir(data_dir):
    """
    Test the normal operation of get_awr_miner_parsed_path() routine

    Given: A not existant directory

    When: get_awr_miner_parsed_path() is invoked

    Then: None is returned

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
    """
    d = Path(os.path.join(data_dir, "fakedir"))
    assert parse.get_awr_miner_parsed_path(d) is None


def test_get_awr_miner_out_path(data_dir, awr_miner_out):
    """
    Test the normal operation of get_awr_miner_out_path() routine

    Given: An existant directory

    When: get_awr_miner_out_path() is invoked

    Then: The path to awr_miner_out is returned under the directory

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
        awr_miner_out : Path
            The awr_miner_out fixture
    """
    expected = awr_miner_out
    assert parse.get_awr_miner_out_path(data_dir) == expected


def test_get_awr_miner_out_bad_dir(data_dir):
    """
    Test the normal operation of get_awr_miner_parsed_path() routine

    Given: A not existant directory

    When: get_awr_miner_out_path() is invoked

    Then: None is returned

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture
    """
    d = Path(os.path.join(data_dir, "fakedir"))
    assert parse.get_awr_miner_out_path(d) is None


def test_convert_db_version_to_int():
    """
    Test the normal operation of convert_version_to_int() routine

    Given: A string representation of a version , such 19.0.0.0.0

    When: convert_version_to_int() is invoked

    Then: The string is returned converted to int

    """
    expected = 19
    assert parse.convert_db_version_to_int("19") == expected


def test_convert_db_version_to_int_version_has_periods():
    """
    Test the normal operation of convert_version_to_int() routine

    Given: A string representation of a version , such 19.0.0.0.0

    When: convert_version_to_int() is invoked

    Then: The string is returned converted to int after removing the separators

    """
    expected = 190000
    assert parse.convert_db_version_to_int("19.0.0.0.0") == expected


def test_convert_db_version_to_int_version_is_empty():
    """
    Test the normal operation of convert_version_to_int() routine

    Given: An Empty string

    When: convert_version_to_int() is invoked

    Then: None is returned

    """
    expected = None
    assert parse.convert_db_version_to_int("") is None


def test_convert_db_version_to_int_valueerror_exception():
    """
    Test the normal operation of convert_version_to_int() routine

    Given: A string that cannot be converted to int

    When: convert_version_to_int() is invoked

    Then: None is returned and ValueError exception is signalled

    """
    expected = None
    assert parse.convert_db_version_to_int("abc") is None


def test_convert_awr_version_to_int():
    """
    Test the normal operation of convert_awr_version_to_int() routine

    Given: A string which its length is less than the length of AWR_MINER_MIN_SUPPORTED_VERSION

    When: convert_awr_version_to_int() is invoked

    Then: The string is returned converted to int right padded with zeros

    """
    expected = 2200
    assert parse.convert_awr_version_to_int("22") == expected


def test_rename_cols_in_database_parameters_df(database_parameters_df):
    """
    Test the normal operation of rename_cols_in_database_parameters_df() routine.

    Given: A Database Parameters Dataframe using different column names from the expected

    When: rename_cols_in_database_parameters_df() is invoked

    Then: The columns are renamed in the DataFrame

    Parameters
    ----------
        database_parameters_df : Path
            The database_parameters_df fixture
    """
    df = pd.DataFrame(database_parameters_df)

    # Rename column VALUE to Value
    df = df.rename(columns={"VALUE": "Value"})

    if "Value" in df:
        actual_df = parse.rename_cols_in_database_parameters_df(df)
        assert "VALUE" in actual_df
    else:
        # The rename has failed or the shape is different
        assert False


def test_rename_cols_in_main_metrics_df(main_metrics_df):
    """
    Test the normal operation of rename_cols_in_main_metrics_df() routine.

    Given: A Main Metrics Dataframe using different column names from the expected

    When: rename_cols_in_main_metrics_df() is invoked

    Then: The columns are renamed in the DataFrame

    Parameters
    ----------
        main_metrics_df : pd.Dataframe
            The main_metrics_df fixture
    """
    df = pd.DataFrame(main_metrics_df)

    # Rename column cpu_per_s to cpu_p_sec
    df = df.rename(columns={"cpu_per_s": "cpu_p_sec"})

    if "cpu_p_sec" in df:
        actual_df = parse.rename_cols_in_main_metrics_df(df)
        assert "cpu_per_s" in actual_df
    else:
        # The rename has failed or the shape is different
        assert False

    # Check lastSuccess var
    expected = "In rename_cols_in_main_metrics_df()"
    assert parse.lastSuccess == expected


def test_rename_cols_in_sqlnet_metrics_df(sqlnet_metrics_df):
    """
    Test the normal operation of rename_cols_in_sqlnet_metrics_df() routine.

    Given: A SQL Net Metrics Dataframe using different column names from the expected

    When: rename_cols_in_sqlnet_metrics_df() is invoked

    Then: The columns are renamed in the DataFrame

    Parameters
    ----------
        sqlnet_metrics_df : pd.Dataframe
            The sqlnet_metrics_df fixture
    """
    df = pd.DataFrame(sqlnet_metrics_df)

    if "sqlnet_bytes_received" in df and "sqlnet_bytes_sent" in df and "sqlnet_bytes_vector_from" in df and "sqlnet_bytes_vector_to" in df:
        actual_df = parse.rename_cols_in_sqlnet_metrics_df(df)
        assert "sqlnet_bytes_received_from_client" in actual_df
        assert "sqlnet_bytes_sent_to_client" in actual_df
        assert "sqlnet_bytes_vector_from_client" in actual_df
        assert "sqlnet_bytes_vector_to_client" in actual_df
    else:
        # The rename has failed or the shape is different
        assert False


def test_rename_cols_in_iostat_by_function_df(iostat_by_function_df):
    """
    Test the normal operation of rename_cols_in_iostat_by_function_df() routine.

    Given: A IOSTAT-BY-FUNCTION Dataframe using different column names from the expected

    When: rename_cols_in_iostat_by_function_df() is invoked

    Then: The columns are renamed in the DataFrame

    Parameters
    ----------
        iostat_by_function_df : pd.Dataframe
            The iostat_by_function_df fixture
    """
    df = pd.DataFrame(iostat_by_function_df)

    # Rename column cpu_per_s to cpu_p_sec
    df = df.rename(columns={"FUNCTION_NAME": "FUNCTION NAME"})

    if "FUNCTION NAME" in df:
        actual_df = parse.rename_cols_in_iostat_by_function_df(df)
        assert "FUNCTION_NAME" in actual_df
    else:
        # The rename has failed or the shape is different
        assert False
def test_rename_cols_in_io_object_type(io_object_type):
    """
    Testing the renaming column from pandas.

    Parameters
    ----------
        io_object_type : pd.Dataframe
            The io_object_type fixture
    """

    df = parse.rename_cols_in_io_object_type_df(io_object_type)
    assert "OBJ_TYPE" not in df
    assert "OBJECT_TYPE" in df

def test_rename_cols_in_snap_history_tz_df(snap_history_df):
    """
    Testing the renaming column from pandas.

    Parameters
    ----------
        io_object_type : pd.Dataframe
            The io_object_type fixture
    """

    df = parse.rename_cols_in_snap_history_tz_df(snap_history_df)
    assert "snap" not in df
    assert "SNAP ID" not in df
    assert "SNAP_ID" not in df
    assert "SNAP" in df


@pytest.mark.parametrize("file", ["SQL-METRICS-rollover-SNAP_ID.txt"])
def test_get_rollover_snaps_from_snap_id(awr_miner_out, file):
    """
    Test the normal operation of get_rollover_snaps_from_snap_id() routine.

    Given: A Dataframe created using pd.read_fwf(routine) which contains rollover snaps

    When: get_rollover_snaps_from_snap_id() is invoked

    Then: A new DataFrame is returned containing the SNAP_IDs corrected, the rolloverSnaps
        list contains the item signalling the fact

    Parameters
    ----------
        awr_miner_out : pd.Dataframe
            The awr_miner_out fixture
         file : file
            The builtin pytest.mark.parametrize decorator
    """

    # Create a DataFrame using read_fwf() which is going to contain rollover on SNAP_ID column
    txt_file = os.path.join(awr_miner_out, file)
    df_from_file = pd.read_fwf(txt_file)

    # Create a DataFrame containing only the corrupted SNAP_ID records
    filtered_df_from_file = df_from_file[df_from_file["SNAP_ID"].between(0, 168)].reset_index(drop=True)

    # SNAP_ID 9999 is the latest good one
    max_good_snap_id = 9999

    # SNAP_ID 10168 is the latest present on the file
    max_snap_id = 10168

    # Update the corrupted SNAP_IDs on the Dataframe
    new_snap_ids = [i for i in range(max_good_snap_id + 1, max_snap_id + 1)]
    for idx, rec in enumerate(new_snap_ids):
        filtered_df_from_file.at[filtered_df_from_file.index[idx], "SNAP_ID"] = rec

    # Set the rollover file
    rollover_file = os.path.join(awr_miner_out, "SQL-METRICS_rollover_snap.csv")

    # Get the resulting DataFrame from get_rollover_snaps_from_snap_id() routine
    actual_df = parse.get_rollover_snaps_from_snap_id(df_from_file, file, "SQL-METRICS", rollover_file)

    # Create the subset of corrected ones
    filtered_actual_df = actual_df[actual_df["SNAP_ID"].between(10000, 10168)].reset_index(drop=True)

    # Assert both DataFrames are equal
    assert_frame_equal(filtered_actual_df, filtered_df_from_file)

    # Assert the content of rolloverSnaps list matches
    expected = [
        {
            "minerFile": file,
            "section": "SQL-METRICS",
            "file": rollover_file,
        }
    ]
    assert parse.rolloverSnaps == expected

    # Assert the rollover snap file is created
    assert os.path.isfile(rollover_file)

    # Cleanup created files
    os.remove(rollover_file)


@pytest.mark.parametrize("file", ["SQL-METRICS-rollover-snap.txt"])
def test_get_rollover_snaps_from_snap(awr_miner_out, file):
    """
    Test the normal operation of get_rollover_snaps_from_snap_id() routine.

    Given: A Dataframe created using pd.read_fwf(routine) which contains rollover snaps

    When: get_rollover_snaps_from_snap_id() is invoked

    Then: A new DataFrame is returned containing the SNAP_IDs corrected, the rolloverSnaps
        list contains the item signalling the fact

    Parameters
    ----------
        awr_miner_out : pd.Dataframe
            The awr_miner_out fixture
         file : file
            The builtin pytest.mark.parametrize decorator
    """

    # Create a DataFrame using read_fwf() which is going to contain rollover on snap column
    txt_file = os.path.join(awr_miner_out, file)
    df_from_file = pd.read_fwf(txt_file)

    # Create a DataFrame containing only the corrupted snap records
    filtered_df_from_file = df_from_file[df_from_file["snap"].between(0, 168)].reset_index(drop=True)

    # SNAP_ID 9999 is the latest good one
    max_good_snap_id = 9999

    # SNAP_ID 10168 is the latest present on the file
    max_snap_id = 10168

    # Update the corrupted snap on the Dataframe
    new_snap_ids = [i for i in range(max_good_snap_id + 1, max_snap_id + 1)]
    for idx, rec in enumerate(new_snap_ids):
        filtered_df_from_file.at[filtered_df_from_file.index[idx], "snap"] = rec

    # Set the rollover file
    rollover_file = os.path.join(awr_miner_out, "SQL-METRICS_rollover_snap.csv")

    # Get the resulting DataFrame from get_rollover_snaps_from_snap_id() routine
    actual_df = parse.get_rollover_snaps_from_snap(df_from_file, file, "SQL-METRICS", rollover_file)

    # Create the subset of corrected ones
    filtered_actual_df = actual_df[actual_df["snap"].between(10000, 10168)].reset_index(drop=True)

    # Assert both DataFrames are equal
    assert_frame_equal(filtered_actual_df, filtered_df_from_file)

    # When the tests are executed as whole ,we get two records on the list
    if len(parse.rolloverSnaps) > 1:
        # Assert the content of rolloverSnaps list matches
        expected = [
            {
                "minerFile": file,
                "section": "SQL-METRICS",
                "file": rollover_file,
            },
            {
                "minerFile": file.replace("snap", "SNAP_ID"),
                "section": "SQL-METRICS",
                "file": rollover_file,
            },
        ]
    else:
        # Assert the content of rolloverSnaps list matches
        expected = [
            {
                "minerFile": file,
                "section": "SQL-METRICS",
                "file": rollover_file,
            }
        ]

        assert parse.rolloverSnaps == expected

    # Assert the rollover snap file is created
    assert os.path.isfile(rollover_file)

    # Cleanup created files
    os.remove(rollover_file)


@pytest.mark.parametrize("file", ["TOP-SQL-BY-SNAPID.txt"])
def test_check_malformed_rows(awr_miner_out, file):
    """
    Test the normal operation of check_malformed_rows() routine.

    Given: A file containing TOP-SQL-BY-SNAPID block(s) with corrupted rows

    When: check_malformed_rows() is invoked

    Then: The lines containing the corrupted rows are removed

    Parameters
    ----------
        awr_miner_out : pd.Dataframe
            The awr_miner_out fixture
         file : file
            The builtin pytest.mark.parametrize decorator
    """

    # Cleanup rowsCorrupt list
    parse.rowsCorrupt = []

    # Create a copy of the original file
    txt_orig_file = os.path.join(awr_miner_out, file)
    txt_new_file = os.path.join(awr_miner_out, file.replace(".txt", ".txt.temp"))
    shutil.copyfile(txt_orig_file, txt_new_file)

    # Call the routine
    parse.check_malformed_rows(Path(txt_new_file))

    # Read the original file
    with open(txt_orig_file) as f:
        orig_lines = f.readlines()
    orig_lines_lgt = len(orig_lines)

    # Read the file created by the routine
    with open(txt_new_file) as f:
        new_lines = f.readlines()
    new_lines_lgt = len(new_lines)

    # Substract the items from drop_parameter list
    expected_lines_lgt = orig_lines_lgt - 3

    # Assert the lines have been removed
    assert new_lines_lgt == expected_lines_lgt

    # Assert rowsCorrupt has 3 elements
    assert len(parse.rowsCorrupt) == 3

    # Clean temporary file
    os.remove(txt_new_file)


@pytest.mark.parametrize("file", ["DATABASE-PARAMETERS.txt"])
def test_remove_separator_line(awr_miner_out, file):
    """
    Test the normal operation of remove_separator_line() routine.

    Given: A file containing DATABASE-PARAMETERS block(s) with separator between column headers and data

    When: remove_separator_line() is invoked

    Then: The line containing the separator line is removed

    Parameters
    ----------
        awr_miner_out : pd.Dataframe
            The awr_miner_out fixture
         file : file
            The builtin pytest.mark.parametrize decorator
    """

    # Create a copy of the original file
    txt_orig_file = os.path.join(awr_miner_out, file)
    txt_new_file = os.path.join(awr_miner_out, file.replace(".txt", ".txt.temp"))
    shutil.copyfile(txt_orig_file, txt_new_file)

    # Call the routine
    parse.remove_separator_line(Path(txt_new_file))

    # Read the original file
    with open(txt_orig_file) as f:
        orig_lines = f.readlines()
    orig_lines_lgt = len(orig_lines)

    # Read the file created by the routine
    with open(txt_new_file) as f:
        new_lines = f.readlines()
    new_lines_lgt = len(new_lines)

    # Substract the items from drop_parameter list
    expected_lines_lgt = orig_lines_lgt - 1

    # Assert the lines have been removed
    assert new_lines_lgt == expected_lines_lgt

    # Clean temporary file
    os.remove(txt_new_file)

@pytest.mark.parametrize("file", ["DATABASE-PARAMETERS.txt"])
def test_colspecs_for_fixed_width_parsing(awr_miner_out, file):
    """
    Test the normal operation of get_colspecs_for_fixed_width_parsing() routine.

    Given: A file with separator line between header and data

    When: fix_lines_in_raw_txt_file() is invoked

    Then: A list if tuples is returned with the start and end position for each of the chunks

    Parameters
    ----------
         awr_miner_out : Path
            The awr_miner_out fixture
         file : file
            The builtin pytest.mark.parametrize decorator
    """
    col_widths_expected = [(0, 64), (65, 577)]
    f = os.path.join(awr_miner_out, file)
    col_widths = parse.get_colspecs_for_fixed_width_parsing(f)

    assert col_widths == col_widths_expected

@pytest.mark.parametrize("file", ["TOP-SQL-BY-SNAPID.txt"])
def test_colspecs_for_fixed_width_parsing_no_separator(awr_miner_out, file):
    """
    Test the normal operation of get_colspecs_for_fixed_width_parsing() routine.

    Given: A file without separator line between header and data

    When: fix_lines_in_raw_txt_file() is invoked

    Then: An Empty list is returned

    Parameters
    ----------
         awr_miner_out : Path
            The awr_miner_out fixture
         file : file
            The builtin pytest.mark.parametrize decorator
    """
    col_widths_expected = []
    f = os.path.join(awr_miner_out, file)
    col_widths = parse.get_colspecs_for_fixed_width_parsing(f)

    assert col_widths == col_widths_expected


# NOTE : pip3 install pytest-datafiles to use the following tests
@pytest.mark.datafiles(os.path.join(Path(__file__).parent.parent.parent, "testdata", "awr", "test_awr_parse"), on_duplicate="overwrite")
@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-37296-37498.out"])
def test_main(testdata_files, file, datafiles, monkeypatch, capsys):
    """
    Test the normal operation of the main() routine

    Given: An AWR Miner collection file

    When: main() is invoked

    Then: The file should be parsed without errors

    Parameters
    ----------
        testdata_files
            The testdata_files fixture
        file
            The file fixture
        datafiles
            The datafiles pytest fixture
        monkeypatch
            The monkeypatch pytest fixture
        capsys
            The capsys pytest fixture
    """

    # Drop from temp are the files that we are not interested on
    for f in testdata_files:
        if f != file:
            Path.unlink(Path(os.path.join(datafiles, "awr_miner_out", f)))

    # Set AWR_MINER_PATH in the environment using Monkey Patch
    monkeypatch.setenv("AWR_MINER_PATH", str(datafiles))

    sys.argv = ["awr_miner_parse.py"]
    parse.main()
    captured = capsys.readouterr()
    assert "Begin @" in captured.out
    assert "End @" in captured.out


@pytest.mark.datafiles(os.path.join(Path(__file__).parent.parent.parent, "testdata", "awr", "test_awr_parse"), on_duplicate="overwrite")
@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test2-37296-37498.out"])
def test_main_with_old_awr_miner_collection(testdata_files, file, datafiles, monkeypatch, capsys):
    """
    Test the normal operation of the main() routine

    Given: An AWR Miner collection file extracted with and Old AWR Miner Version

    When: main() is invoked

    Then: The file should be rejected and an error message is written to stdout

    Parameters
    ----------
        testdata_files
            The testdata_files fixture
        file
            The file fixture
        datafiles
            The datafiles pytest fixture
        monkeypatch
            The monkeypatch pytest fixture
        capsys
            The capsys pytest fixture
    """

    # Drop from temp area the files that we are not interested on
    for f in testdata_files:
        if f != file:
            Path.unlink(Path(os.path.join(datafiles, "awr_miner_out", f)))

    # Set AWR_MINER_PATH in the environment using Monkey Patch
    monkeypatch.setenv("AWR_MINER_PATH", str(datafiles))

    expected = "ERROR: There are files in this collection extracted with old version of OCCA AWR Miner.\n\n"
    sys.argv = ["awr_miner_parse.py"]
    parse.main()
    captured = capsys.readouterr()
    assert expected in captured.out


@pytest.mark.datafiles(os.path.join(Path(__file__).parent.parent.parent, "testdata", "awr", "test_awr_parse"), on_duplicate="overwrite")
@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test9-37296-37498.out"])
def test_main_with_bar_miner_collection(testdata_files, file, datafiles, monkeypatch, capsys):
    """
    Test the normal operation of the main() routine

    Given: A collection file simulating a BAR Collection

    When: main() is invoked

    Then: The file should be rejected and an message is written to stdout

    Parameters
    ----------
        testdata_files
            The testdata_files fixture
        file
            The file fixture
        datafiles
            The datafiles pytest fixture
        monkeypatch
            The monkeypatch pytest fixture
        capsys
            The capsys pytest fixture
    """

    # Drop from temp are the files that we are not interested on
    for f in testdata_files:
        if f != file:
            Path.unlink(Path(os.path.join(datafiles, "awr_miner_out", f)))

    # Set AWR_MINER_PATH in the environment using Monkey Patch
    monkeypatch.setenv("AWR_MINER_PATH", str(datafiles))

    expected = "There are files in this collection extracted with BAR Miner.\n\n"
    sys.argv = ["awr_miner_parse.py"]
    parse.main()
    captured = capsys.readouterr()
    assert expected in captured.out


@pytest.mark.datafiles(os.path.join(Path(__file__).parent.parent.parent, "testdata", "awr", "test_awr_parse"), on_duplicate="overwrite")
@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test2-37296-37498.out"])
def test_main_with_allowoldminer_arg(testdata_files, file, datafiles, monkeypatch, capsys):
    """
    Test the normal operation of the main() routine

    Given: An AWR Miner collection file extracted with and Old AWR Miner Version

    When: main() is invoked with arg allowoldminer

    Then: The file is parsed and the deprecation message is not written to stdout

    Parameters
    ----------
        testdata_files
            The testdata_files fixture
        file
            The file fixture
        datafiles
            The datafiles pytest fixture
        monkeypatch
            The monkeypatch pytest fixture
        capsys
            The capsys pytest fixture
    """

    # Drop from temp are the files that we are not interested on
    for f in testdata_files:
        if f != file:
            Path.unlink(Path(os.path.join(datafiles, "awr_miner_out", f)))

    # Set AWR_MINER_PATH in the environment using Monkey Patch
    monkeypatch.setenv("AWR_MINER_PATH", str(datafiles))

    # Set Args
    sys.argv = ["awr_miner_parse.py"]
    sys.argv.append("--allowoldminer")

    parse.main()
    captured = capsys.readouterr()

    # Assert the message is on stdout
    expected = "ERROR: There are files in this collection extracted with old version of OCCA AWR Miner.\n\n"
    assert expected not in captured.out
    assert "Begin @" in captured.out
    assert "End @" in captured.out


@pytest.mark.datafiles(os.path.join(Path(__file__).parent.parent.parent, "testdata", "awr", "test_awr_parse"), on_duplicate="overwrite")
@pytest.mark.parametrize("file", ["awr-hist-609708250-oracle-database-00000-test9-37296-37498.out"])
def test_main_with_allowobar_arg(testdata_files, file, datafiles, monkeypatch, capsys):
    """
    Test the normal operation of the main() routine

    Given: A collection file simulating a BAR Collection

    When: main() is invoked with arg allowbar

    Then: The file is parsed and the deprecation message is not written to stdout

    Parameters
    ----------
        testdata_files
            The testdata_files fixture
        file
            The file fixture
        datafiles
            The datafiles pytest fixture
        monkeypatch
            The monkeypatch pytest fixture
        capsys
            The capsys pytest fixture
    """

    # Drop from temp are the files that we are not interested on
    for f in testdata_files:
        if f != file:
            Path.unlink(Path(os.path.join(datafiles, "awr_miner_out", f)))

    # Set AWR_MINER_PATH in the environment using Monkey Patch
    monkeypatch.setenv("AWR_MINER_PATH", str(datafiles))

    # Set Args
    sys.argv = ["awr_miner_parse.py"]
    sys.argv.append("--allowbar")

    parse.main()
    captured = capsys.readouterr()

    # Assert the message is on stdout
    expected = "There are files in this collection extracted with BAR Miner.\n\n"
    assert expected not in captured.out
    assert "Begin @" in captured.out
    assert "End @" in captured.out


@pytest.fixture
def setup_cohort_structure(testdata_dir, tmp_path) -> Path:
    """
    Copy .out files from the data directory into the right
    cohort folders (CohortA, CohortB, CohortC) in a tmp dir.

    Parameters
    ----------
    data_dir : Path
    tmp_path : Path

    Returns
    -------
    Path
        The path to the directory where the cohort structure was created.
    """
    if os.environ.get('AWR_MINER_PATH') : del os.environ['AWR_MINER_PATH']
    awr_miner_out = tmp_path / "awr_miner_out"
    awr_miner_out.mkdir(parents=True, exist_ok=True)

    cohort_A = awr_miner_out / "CohortA"
    cohort_B = awr_miner_out / "CohortB"
    cohort_C = awr_miner_out / "CohortC"

    cohort_A.mkdir()
    cohort_B.mkdir()
    cohort_C.mkdir()


    out_files = list((testdata_dir / 'awr' / 'test_awr_end_to_end').rglob('*.out'))


    shutil.copy(out_files[0], cohort_A)
    shutil.copy(out_files[1], cohort_B)
    shutil.copy(out_files[2], cohort_C)

    return awr_miner_out.resolve()

    # shutil.rmtree(tmp_path, ignore_errors=True)
class Args:
    params = ""
from occa.constants.Paths import  FilePaths as fp

def test_parse_and_cleanup(setup_cohort_structure):
    """
    Test that runs the parser on the cohort structure, checks that the
    cohort_whichdb_mapping.csv exists , and ensures cleanup of all files and directories afterward.
    """
    awr_extract_root_folder = setup_cohort_structure.parent

    args = Args()
    #Changing to working area
    os.chdir(awr_extract_root_folder)

    #If parse ran fine it would generate the following file 'cohort_whichdb_mapping.csv'
    occa.awr_parse(args)
    occa.awr_plot(args, reload=True)
    expected_output_file = fp.WHICH_DB_MAPPING_FILE

    assert expected_output_file.exists()
    assert fp.AWR_PROPERTIES_ORIGINAL.exists()
    assert fp.AWR_PROPERTIES.exists()

    df_mapping = pd.read_csv(fp.WHICH_DB_MAPPING_FILE)
    df_properties = pd.read_csv(fp.AWR_PROPERTIES)

    assert not df_mapping.empty, "Maping is empty"
    assert not df_properties.empty, "Properties is empty."

    merged_df = pd.merge(df_mapping, df_properties, left_on='WHICH_DB', right_on='WHICH_DB', how='inner')
    for cohort in df_mapping['Cohort'].unique():
        mapping_db = df_mapping[df_mapping['Cohort'] == cohort]['WHICH_DB'].tolist()
        properties_db = df_properties[df_properties['WHICH_DB'].isin(mapping_db)]
        assert not properties_db.empty, f"No whichDB match found for cohort: {cohort}"
    # assert 1==""
