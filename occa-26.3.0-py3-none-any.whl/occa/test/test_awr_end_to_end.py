import logging
import os
from pathlib import Path

import pytest

from occa import occa
from utils import utils as u

LOGGER = logging.getLogger(__name__)


class Args:
    params = ""


# Relative from the test code
testdata_path = (Path(__file__).parent.parent.parent / "testdata" / "awr").resolve()


@pytest.mark.parametrize("folder", ["test_awr_end_to_end"])
def test_awr_parse(folder, capsys):
    testdata = testdata_path / folder
    u.clean_testdata(testdata)
    os.chdir(testdata)
    args = Args()
    occa.awr_parse(args)
    captured = capsys.readouterr()
    assert "End @" in captured.out
    assert "following errors occurred" not in captured.out


@pytest.mark.parametrize("folder", ["test_awr_end_to_end"])
def test_awr_plot(folder, capsys):
    testdata = testdata_path / folder
    os.chdir(testdata)
    args = Args()
    occa.awr_plot(args, reload=True)
    captured = capsys.readouterr()
    assert "Total running time" in captured.out
    assert "following fatal were encountered" not in captured.out

    # Modify properties files
    u.modify_properties_file(testdata / u.AWR_MINER_OCCA / "properties")


@pytest.mark.parametrize("folder", ["test_awr_end_to_end"])
def test_awr_run(folder, capsys):
    testdata = testdata_path / folder
    os.chdir(testdata)
    args = Args()
    occa.awr_run(args)
    captured = capsys.readouterr()
    assert "End @" in captured.out
    assert "following fatal were encountered" not in captured.out


@pytest.mark.parametrize("folder", ["test_awr_end_to_end"])
def test_awr_import(folder, capsys, caplog):
    testdata = testdata_path / folder
    os.chdir(testdata)
    args = Args()

    # Check messages coming in stdout
    captured = capsys.readouterr()
    assert "following fatal were encountered" not in captured.out

    with caplog.at_level(logging.INFO):
        occa.awr_import(args)

    # Check messages coming from the logger
    assert "Created AWR Collection Import file:" in caplog.text
    assert "End @" in caplog.text

    # Check the import file has been created
    fpath = os.path.join(testdata, u.AWR_MINER_OCCA, u.AWR_OCCA_UPLOAD_JSON)
    assert os.path.isfile(fpath)
    assert os.path.getsize(fpath) > 0

    u.clean_testdata(testdata)
