import pandas as pd
from datetime import datetime

from occa.awr_miner_Run_Metric_Analysis import date_overlaps_and_overlaps_days_within_cohort,\
    check_overlaps_within_group, check_all_cohorts,has_needed_data_days


def test_has_needed_data_days():
    df_valid = pd.DataFrame({
        'min': [datetime(2024, 1, 1), datetime(2024, 1, 5)], #1-8 and 5-12
        'max': [datetime(2024, 1, 8), datetime(2024, 1, 12)],
    })
    assert has_needed_data_days(df_valid) == True

    df_invalid = pd.DataFrame({
        'min': [datetime(2024, 1, 1), datetime(2024, 1, 5)], # 1- 8 and 5-10
        'max': [datetime(2024, 1, 8), datetime(2024, 1, 10)],
        'Cohort':['CohortA','CohortB'],
        'cdb':['cdbA','cdbB']
    })
    assert has_needed_data_days(df_invalid) == False

    df_exact = pd.DataFrame({
        'min': [datetime(2024, 1, 5), datetime(2024, 1, 10)], #1-8 and 5-12
        'max': [datetime(2024, 1, 15), datetime(2024, 1, 18)],
    })
    assert has_needed_data_days(df_exact) == True

    df_zero_days = pd.DataFrame({
        'min': [datetime(2024, 1, 1)],
        'max': [datetime(2024, 1, 1)],
        'Cohort':['CohortA'],
        'cdb':['cdbA']# No overlap
    })
    assert has_needed_data_days(df_zero_days) == False

    df_more_than_7 = pd.DataFrame({
        'min': [datetime(2024, 1, 1), datetime(2024, 1, 5)], #1-9 and 5-13 -> good
        'max': [datetime(2024, 1, 9), datetime(2024, 1, 13)],
    })
    assert has_needed_data_days(df_more_than_7) == True

    df_valid_4_days = pd.DataFrame({
        'min':[datetime(2025, 1, 1), datetime(2025, 1, 1)],  #
        'max':[datetime(2025, 1, 5), datetime(2025, 1, 6)],
        'Cohort':['CohortCatA','CohortCatB'],
        'cdb':['cdbA','cdbB']
    })
    assert has_needed_data_days(df_valid_4_days,4) == True
    assert has_needed_data_days(df_valid_4_days,4) == True

    df_valid_7_days = pd.DataFrame({
        'min':[datetime(2025, 1, 1), datetime(2025, 1, 1)],  #
        'max':[datetime(2025, 1, 8), datetime(2025, 1, 9)],
        'Cohort':['CohortMewA','CohortMewB'],
        'cdb':['cdbA','cdbB']
    })
    assert has_needed_data_days(df_valid_7_days,4) == True
    assert has_needed_data_days(df_valid_7_days,7) == True
    assert has_needed_data_days(df_valid_7_days,9) == False
def test_date_overlaps_and_overlaps_days_within_cohort():
    # start1, end1 -- start2,end2

    assert date_overlaps_and_overlaps_days_within_cohort(datetime(2024, 1, 1), datetime(2024, 1, 10),
                                                         datetime(2024, 1, 5), datetime(2024, 1,
                                                                                        15)) == (False, 5, 0)  # Overlaps for  5 days but not >= 7
    assert date_overlaps_and_overlaps_days_within_cohort(datetime(2024, 1, 1), datetime(2024, 1, 10),
                                                         datetime(2024, 1, 11),
                                                         datetime(2024, 1, 20)) == (False, -1, -1)  # No overlaps
    assert date_overlaps_and_overlaps_days_within_cohort(datetime(2024, 1, 1), datetime(2024, 1, 10),
                                                         datetime(2024, 1, 10),
                                                         datetime(2024, 1, 20)) == (False, -1, -1)  # No overlaps
    assert date_overlaps_and_overlaps_days_within_cohort(datetime(2024, 1, 1), datetime(2024, 1, 10),
                                                         datetime(2024, 1, 3),
                                                         datetime(2024, 1, 10)) == (True, 0, 0)  # overlaps and 7 days


def test_check_overlaps_within_group():
    data = {
        'Cohort':['A', 'A', 'A'],
        'cdb':['CDB1', 'CDB2', 'CDB3'],
        # 1-10, 5-15,10-20
        # O,1 overlap but no  7 days
        # 0 2 does not overlap
        # 1,2 overlaps but no >= 7 days
        'min':[datetime(2024, 1, 1), datetime(2024, 1, 5), datetime(2024, 1, 10)],
        'max':[datetime(2024, 1, 10), datetime(2024, 1, 15), datetime(2024, 1, 20)]
    }
    df = pd.DataFrame(data)
    result = check_overlaps_within_group(df)
    expected = [('A', 'CDB1', 'CDB2', (0, 1),5, 0),
                ('A', 'CDB1', 'CDB3', (0, 2),-1,-1),
                ('A', 'CDB2', 'CDB3', (1, 2),5,0)
                ]

    assert result == expected


def test_check_all_cohorts():
    data = {
        'Cohort':['A', 'A', 'B', 'B'],
        'cdb':['CDB1', 'CDB2', 'CDB3', 'CDB4'],
        'min':[datetime(2024, 1, 1), datetime(2024, 1, 3), datetime(2024, 2, 1), datetime(2024, 2, 10)],
        'max':[datetime(2024, 1, 10), datetime(2024, 1, 15), datetime(2024, 2, 5), datetime(2024, 2, 15)]
    }
    df = pd.DataFrame(data)
    result = check_all_cohorts(df)
    expected = [
        ('B', 'CDB3', 'CDB4', (2, 3),-1,-1)  # 1-5 ,10-15 , no overlap
    ]
    assert result == expected


def test_check_all_cohorts_all_overlapping():
    data = {
        'Cohort':['A', 'A', 'B', 'B'],
        'cdb':['CDB1', 'CDB2', 'CDB3', 'CDB4'],
        'min':[datetime(2024, 1, 1), datetime(2024, 1, 3), datetime(2024, 2, 1), datetime(2024, 2, 2)],
        'max':[datetime(2024, 1, 10), datetime(2024, 1, 15), datetime(2024, 2, 9), datetime(2024, 2, 9)]
    }
    df = pd.DataFrame(data)
    result = check_all_cohorts(df)
    expected = []
    assert result == expected
