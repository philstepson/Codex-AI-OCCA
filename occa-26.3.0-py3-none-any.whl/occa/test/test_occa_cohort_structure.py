import os
import shutil
import tempfile
import uuid
from pathlib import Path

import pandas as pd
import pytest

from awr_miner_parse import get_miner_file_name_pieces
from occa import occa

# Path where .out files are located
testdata_awr_path = Path(__file__).parent.parent.parent / "testdata" / "awr"
test_awr_end_to_end_dir = os.path.join(testdata_awr_path, 'test_awr_end_to_end', 'awr_miner_out')


@pytest.fixture
def args():
    class Args:
        params = ""
        checkmetrics = None

    yield Args()


@pytest.fixture
def setup_and_teardown():
    """
    This one creates random folder and put 1 .out within
    """
    temp_dir = tempfile.mkdtemp()

    awr_miner_out_dir = os.path.join(temp_dir, 'awr_miner_out')
    os.makedirs(awr_miner_out_dir, exist_ok=True)

    files_to_copy = [
        'awr-hist-1208226996-oracle-database-00002-7182-7383.out',
        'awr-hist-2210461847-oracle-database-00000-7102-7307.out',
        'awr-hist-2273923123-oracle-database-00001-6064-6267.out'
    ]

    cohort_folders = []

    for file_name in files_to_copy:
        # A folder name with cat name on it:)
        folder_name = f"cat{uuid.uuid4().hex[:5].upper()}"
        folder_path = os.path.join(awr_miner_out_dir, folder_name)
        os.makedirs(folder_path, exist_ok=True)

        src_file = os.path.join(test_awr_end_to_end_dir, file_name)
        dest_file = os.path.join(folder_path, file_name)
        shutil.copy(src_file, dest_file)

        cohort_folders.append((folder_name, dest_file))

    original_dir = os.getcwd()

    os.chdir(temp_dir)

    yield temp_dir, cohort_folders

    # teardown
    os.chdir(original_dir)
    shutil.rmtree(temp_dir)


def test_cohort_structure(setup_and_teardown, args):
    temp_dir, cohort_folders = setup_and_teardown

    occa.awr_parse(args)
    occa.awr_plot(args, reload=True)

    # Path to propertis
    csv_path = os.path.join(temp_dir, 'awr_miner_occa', 'properties', 'awr_properties_database.csv')

    assert os.path.exists(csv_path), "Somethint went wrong, csv file doesn't exists"
    assert os.path.exists(os.path.join(temp_dir,
                                       'cohort_whichdb_mapping.csv')), "Something went wrong, cohort_whichdb_mapping file doesn't exists"

    df = pd.read_csv(csv_path)

    # CHecking that the WHICH_DB Key it's in the properties.csv
    # and matches the random folder name generated it should be 1 match for each one
    # since we have .out in 1 folder
    for folder_name, out_file in cohort_folders:
        pieces = get_miner_file_name_pieces(str(out_file))
        expected_which_db = f"db_{pieces['dbname']}_{pieces['dbid']}-{pieces['snap_id_start']}-{pieces['snap_id_end']}"

        matching_row = df[(df['Cohort'] == folder_name)&(df['WHICH_DB'] == expected_which_db)]

        assert not matching_row.empty, f"No matching row found in CSV for folder {folder_name} and WHICH_DB {expected_which_db}"
