
from occa_Shared import getCPUType



def test_getCPUType_INTEL():
    assert getCPUType("GenuineIntel", "") == "INTEL"
    assert getCPUType("X86", "") == "INTEL"
    assert getCPUType("GeNuInEiNTeL<", "") == "INTEL"
    assert getCPUType("_GeNuInEiNTeL__", "") == "INTEL"

def test_getCPUType_IBM():
    assert getCPUType("POWER", "") == "IBM"
    assert getCPUType("aaaPoWERbbb", "") == "IBM"
    assert getCPUType("zSeries", "") == "IBM"
    assert getCPUType("ZZSerIeS", "") == "IBM"
    assert getCPUType("aix", "") == "IBM"
    assert getCPUType("alalalalaaix", "") == "IBM"

def test_getCPUType_AMD():
    assert getCPUType("AMD", "") == "AMD"
    assert getCPUType("amD", "") == "AMD"

def test_getCPUType_SPARC():
    assert getCPUType("SPARC", "") == "SPARC"
    assert getCPUType("solaris", "") == "SPARC"
    assert getCPUType("", "SoLaRis") == "SPARC"
    assert getCPUType("", "sparc") == "SPARC"
    assert getCPUType("", "sun4v") == "SPARC"
    assert getCPUType("sun4v", "") == "SPARC"

def test_getCPUType_OTHER():
    assert getCPUType("Unknown", "") == "OTHER: Unknown"
    assert getCPUType("-_-", "") == "OTHER: -_-"
    assert getCPUType(123, "") == "OTHER: 123"
    assert getCPUType("I love cats", "") == "OTHER: I love cats"
    assert getCPUType("", "") == ""
    assert getCPUType("x", "Hello you") == "OTHER: x"
    assert getCPUType("InTeL", "") == "OTHER: InTeL"
    assert getCPUType("ammmd", "") == "OTHER: ammmd"


