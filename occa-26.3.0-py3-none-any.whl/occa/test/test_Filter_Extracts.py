import os
import time
from collections import OrderedDict
from pathlib import Path
import extracts.Filter_Extracts as FE

import pytest

# Relative from the test code
testdata_path = (
    Path(__file__).parent.parent.parent / "testdata" / "em" / "sourceSideFiltering"
).resolve()


def test_sorted_list_should_be_returned_when_list_is_provided():
    expected = "server2,server1"
    themap = OrderedDict()
    themap["targetguid"] = ["server1", "server2"]
    theval = "targetguid"
    assert FE.create_string_from_list(themap, theval) == expected


def test_string_should_be_returned_when_string_is_provided():
    expected = "server1"
    themap = OrderedDict()
    themap["targetguid"] = ["server1"]
    theval = "targetguid"
    assert FE.create_string_from_list(themap, theval) == expected


@pytest.mark.parametrize(
    "file",
    [
        "test.csv",
    ],
)
def test_list_should_be_returned_when_file_is_provided(file):
    testdata = testdata_path / file
    expected = [
        '"H1","H2","H3","H4","H5","H6","H7"',
        '"COL1","COL2","COL3","COL4","COL5","COL6","COL7"',
    ]
    assert FE.create_list_of_lines_from_file(str(testdata)) == expected


@pytest.mark.parametrize(
    "file",
    [
        "test.csv",
    ],
)
def test_first_line_of_file_should_be_returned_when_file_is_provided(file):
    testdata = testdata_path / file
    expected = '"H1","H2","H3","H4","H5","H6","H7"\n'
    assert FE.get_first_line_from_file(str(testdata)) == expected


@pytest.mark.parametrize(
    "file",
    [
        "properties_database_filter_test.csv",
    ],
)
def test_map_of_filtered_targets_should_be_returned_when_file_is_provided(file, capsys):
    testdata = testdata_path / file
    expected = OrderedDict()
    expected["db_targets"] = [
        "1DD151397191979949C989FEF8E997AB",
        "7B0C53D1632D6E4C2B14E0CE0A1268A6",
    ]
    expected["host_targets"] = [
        "57BAB896E2E06A994CD72A1C0A2B6EB",
        "9344E75DFAE9ACCF05FBDF28645D3042",
    ]
    expected["dbmachine_targets"] = [
        "2FF04D5FEE1B254DCED50C4857C762B8",
        "6171276FFD3FCCE452FB04A2FECBE661",
    ]
    assert FE.create_map_of_ids_per_target_type(str(testdata)) == expected

    captured = capsys.readouterr()
    assert captured.out == " Targets : Filtered[10] Total[12]\n"


@pytest.mark.parametrize(
    "file",
    [
        "properties_database_filter_test_without_exclusions.csv",
    ],
)
def test_map_of_all_targets_should_be_returned_when_file_is_provided(file, capsys):
    testdata = testdata_path / file
    expected = OrderedDict()
    expected["db_targets"] = [
        "1DD151397191979949C989FEF8E997AB",
        "7B0C53D1632D6E4C2B14E0CE0A1268A6",
    ]
    expected["host_targets"] = [
        "57BAB896E2E06A994CD72A1C0A2B6EB",
        "9344E75DFAE9ACCF05FBDF28645D3042",
    ]
    expected["dbmachine_targets"] = [
        "2FF04D5FEE1B254DCED50C4857C762B8",
        "6171276FFD3FCCE452FB04A2FECBE661",
    ]
    assert FE.create_map_of_ids_per_target_type(str(testdata)) == expected

    captured = capsys.readouterr()
    assert captured.out == " Targets : Filtered[0] Total[2]\n"


@pytest.mark.parametrize(
    "file",
    [
        "emcc_sizing_structure_db_props_test.csv",
    ],
)
def test_map_of_db_parameters_should_be_returned_when_file_is_provided(file):
    testdata = testdata_path / file
    expected = OrderedDict()
    expected["1DD151397191979949C989FEF8E997AB"] = {
        "cdb_cost_center": "",
        "cdb_department": "",
        "cdb_lifecycle_status": "Development",
        "cdb_line_of_bus": "",
        "cdb_location": "DCEAST",
        "cdb_version": "12.1.0.2.210119",
        "target_guid": "1DD151397191979949C989FEF8E997AB",
    }
    assert FE.process_db_properties(str(testdata)) == expected


@pytest.mark.parametrize(
    "file",
    [
        "emcc_sizing_structure_db_single_node_test.csv",
    ],
)
def test_map_of_sizing_structure_values_for_single_node_should_be_returned_when_file_is_provided(
    file,
):
    testdata = testdata_path / file
    expected = OrderedDict()
    expected["1DD151397191979949C989FEF8E997AB"] = {
        "dbmachine": "",
        "dbmachine_owner": "",
        "cdb_owner": "SYSMAN",
        "cdb_standby_type": "",
        "cdb_status": "Target Up",
        "cdb_last_load_time_utc": "2022-03-29 21:19:59",
        "ma": "GenuineIntel x86_64",
        "dbmachine_target_guid": "",
        "cluster": "none",
        "Database Name": "DB2",
        "target_guid": "1DD151397191979949C989FEF8E997AB",
        "Server List": "server2.oracle.com",
        "Database List": "1DD151397191979949C989FEF8E997AB",
        "Host List": "9344E75DFAE9ACCF05FBDF28645D3042",
    }
    assert FE.process_db_infrastructure(str(testdata)) == expected


@pytest.mark.parametrize(
    "file",
    [
        "emcc_sizing_structure_db_cluster_test.csv",
    ],
)
def test_map_of_sizing_structure_values_for_cluster_should_be_returned_when_file_is_provided(
    file,
):
    testdata = testdata_path / file
    expected = OrderedDict()

    # Clustered Targets
    expected["6839593D87C77765869FC35C0C32EA42"] = {
        "dbmachine": "dbmachine1.oracle.com",
        "dbmachine_owner": "OMSADMIN",
        "cdb_owner": "OMSADMIN",
        "cdb_standby_type": "",
        "cdb_status": "Target Up",
        "cdb_last_load_time_utc": "2022-04-12 06:54:02",
        "ma": "GenuineIntel x86_64",
        "dbmachine_target_guid": "988E2BD1504EE7C618B6D8F9FE7337EF",
        "cluster": "cluster1",
        "Database List": "A65B7E014D89A826790D5C01D3E3EE6E,5C50D6802996AA485143013D534C56E8",
        "Host List": "C2624BB9C261F2434561D03A95ABA69F,5715D4CC4E603450C4F42C1F046CECC2",
        "Database Name": "cdb1",
        "target_guid": "6839593D87C77765869FC35C0C32EA42",
        "Server List": "host2.oracle.com,host1.oracle.com",
    }

    assert FE.process_db_infrastructure(str(testdata)) == expected


def test_merge_infra_and_properties_dicts_for_target_should_be_returned():
    properties_dict = OrderedDict()
    properties_dict["1DD151397191979949C989FEF8E997AB"] = {
        "cdb_cost_center": "",
        "cdb_department": "",
        "cdb_lifecycle_status": "Development",
        "cdb_line_of_bus": "",
        "cdb_location": "DCEAST",
        "cdb_version": "12.1.0.2.210119",
        "target_guid": "1DD151397191979949C989FEF8E997AB",
    }

    infra_dict = OrderedDict()
    infra_dict["1DD151397191979949C989FEF8E997AB"] = {
        "dbmachine": "",
        "dbmachine_owner": "",
        "cdb_owner": "SYSMAN",
        "cdb_standby_type": "",
        "cdb_status": "Target Up",
        "cdb_last_load_time_utc": "2022-03-29 21:19:59",
        "cluster": "none",
        "Database Name": "DB2",
        "target_guid": "1DD151397191979949C989FEF8E997AB",
        "Server List": "server2.oracle.com",
        "Database List": "1DD151397191979949C989FEF8E997AB",
        "Host List": "9344E75DFAE9ACCF05FBDF28645D3042",
    }

    # Merge both dicts
    prop_and_infra_dict = OrderedDict()
    for k, v in properties_dict["1DD151397191979949C989FEF8E997AB"].items():
        prop_and_infra_dict[k] = v

    for k, v in infra_dict["1DD151397191979949C989FEF8E997AB"].items():
        prop_and_infra_dict[k] = v

    merged_dict = [prop_and_infra_dict]

    assert FE.merge_infra_and_prop_dicts(properties_dict, infra_dict) == merged_dict


def test_merge_infra_and_properties_dicts_for_inexistant_target_should_be_reported(
    capsys,
):
    expected = " TARGET GUID : 123456789123456789123456789AAAAA not found in emcc_sizing_structure_db_props.csv\n"

    properties_dict = OrderedDict()
    properties_dict["123456789123456789123456789AAAAA"] = {
        "cdb_cost_center": "",
        "cdb_department": "",
        "cdb_lifecycle_status": "Development",
        "cdb_line_of_bus": "",
        "cdb_location": "DCEAST",
        "cdb_version": "12.1.0.2.210119",
        "target_guid": "1DD151397191979949C989FEF8E997AB",
    }

    infra_dict = OrderedDict()
    infra_dict["1DD151397191979949C989FEF8E997AB"] = {
        "dbmachine": "",
        "dbmachine_owner": "",
        "cdb_owner": "SYSMAN",
        "cdb_standby_type": "",
        "cdb_status": "Target Up",
        "cdb_last_load_time_utc": "2022-03-29 21:19:59",
        "cluster": "none",
        "Database Name": "DB2",
        "target_guid": "1DD151397191979949C989FEF8E997AB",
        "Server List": "server2.oracle.com",
        "Database List": "1DD151397191979949C989FEF8E997AB",
        "Host List": "9344E75DFAE9ACCF05FBDF28645D3042",
    }

    FE.merge_infra_and_prop_dicts(properties_dict, infra_dict)

    captured = capsys.readouterr()
    assert captured.out == expected


@pytest.mark.parametrize(
    "file",
    [
        "emcc_sizing_metrics_db_hourly_03_months_test.csv",
    ],
)
def test_lines_from_telemetry_matching_target_guid_should_be_returned_when_file_is_provided(
    file, capsys
):
    testdata = testdata_path / file

    expected = [
        '"1DD151397191979949C989FEF8E997AB","DB2","oracle_database","Throughput","Average Active Sessions","instance_throughput",'
        '"avg_active_sessions","2022-03-28 08:00:00",.437,1.42,.796833333,.364901859,6\n',
        '"1DD151397191979949C989FEF8E997AB","DB2","oracle_database","Throughput","Physical Writes (per second)",'
        '"instance_throughput","physwrites_ps","2022-03-28 09:00:00",2.91,4.808,3.37783333,.715807912,6\n',
        '"1DD151397191979949C989FEF8E997AB","DB2","oracle_database","Throughput","I/O Megabytes (per second)",'
        '"instance_throughput","iombs_ps","2022-03-28 08:00:00",116.044,195.541,158.631833,33.2997738,6\n',
        '"1DD151397191979949C989FEF8E997AB","DB2","oracle_database","Throughput","Physical Reads (per second)",'
        '"instance_throughput","physreads_ps","2022-03-28 09:00:00",2146.342,18653.354,5860.95917,6386.39151,6\n',
    ]

    # Seed the other parameters
    uidlist = ["1DD151397191979949C989FEF8E997AB"]
    file_start_time = time.time()
    with open(testdata, "r") as f:
        filelines = f.readlines()

    matched_lines = FE.get_lines_per_uid(
        str(testdata), filelines, uidlist, file_start_time
    )
    assert matched_lines.sort() == expected.sort()

    expected_stdout = "emcc_sizing_metrics_db_hourly_03_months_test.csv [####################] 100% [4]"
    captured = capsys.readouterr()
    assert expected_stdout in captured.out
