import pytest

from pathlib import Path
from pandas import pandas as pd

from pandas_helpers.pandas_data_utils import remove_duplicate_dates_from_EM_df, prepare_em_df

test_cases = {
    # All different 
    "case_1": {  
        "data": {
            "TARGET_GUID": ["ID1", "ID2", "ID3", "ID4"],
            "metric": ["db_inst_cpu_usage.avg_tot_cpu_usage_ps", "instance_throughput.iorequests_ps", "instance_throughput.iombs_ps", "instance_throughput.physreads_ps"],
            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",
                "2024-03-12 11:00:00",
                "2024-03-13 12:00:00",
                "2024-03-14 23:00:00",
            ],
        },
        "expected": {
            "TARGET_GUID": ["ID1", "ID2", "ID3", "ID4"],
            "metric": ["db_inst_cpu_usage.avg_tot_cpu_usage_ps", "instance_throughput.iorequests_ps", "instance_throughput.iombs_ps", "instance_throughput.physreads_ps"],
            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",
                "2024-03-12 11:00:00",
                "2024-03-13 12:00:00",
                "2024-03-14 23:00:00",
            ],
        },
    },
    
    # Multiple duplicates for same TARGET_GUID and metric
    "case_2": {  
        "data": {
            "TARGET_GUID": ["ID1", "ID1", "ID1", "ID2", "ID2"],
            "metric": ["db_inst_cpu_usage.avg_tot_cpu_usage_ps", "db_inst_cpu_usage.avg_tot_cpu_usage_ps", "db_inst_cpu_usage.avg_tot_cpu_usage_ps", "instance_throughput.iorequests_ps", "instance_throughput.iorequests_ps"],
            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",#1 keep
                "2024-03-11 11:00:00",#1 this should be removed
                "2024-03-11 23:00:00",#1 thistoo
                "2024-04-11 00:00:00",#2 keep 
                "2024-04-11 11:00:00",#2 delete
            ],
        },
        "expected": {
            "TARGET_GUID": ["ID1", "ID2"],
            "metric": ["db_inst_cpu_usage.avg_tot_cpu_usage_ps", "instance_throughput.iorequests_ps"],
            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",
                "2024-04-11 00:00:00",
            ]
        },
    },
    
    # all  entries share the same TARGET_GUID but different Types
    "case_3": {  
        "data": {
            "TARGET_GUID": ["ID1", "ID1", "ID1", "ID1"],
            "metric": ["db_inst_cpu_usage.avg_tot_cpu_usage_ps", "instance_throughput.iorequests_ps", "instance_throughput.iombs_ps", "instance_throughput.physreads_ps"],
            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",#kee
                "2024-03-11 11:00:00",#keep
                "2024-03-11 12:00:00",#keep
                "2024-03-11 23:00:00",#keep
            ],
        },
        "expected": {
            "TARGET_GUID": ["ID1", "ID1", "ID1", "ID1"],
            "metric": ["db_inst_cpu_usage.avg_tot_cpu_usage_ps",
                       "instance_throughput.iombs_ps",
                       "instance_throughput.iorequests_ps",
                       "instance_throughput.physreads_ps"
                       ],
            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",
                "2024-03-11 12:00:00",
                "2024-03-11 11:00:00",
                "2024-03-11 23:00:00",
            ]
        },
    },

"case_4": {
        "data": {
            "TARGET_GUID": ["ID1", "ID1", "ID1", "ID2","ID2", "ID3", "ID3"],
            "metric": [
                       "db_inst_cpu_usage.avg_tot_cpu_usage_ps", "db_inst_cpu_usage.avg_tot_cpu_usage_ps", "db_inst_cpu_usage.avg_tot_cpu_usage_ps",
                       "instance_throughput.physreads_ps",'instance_throughput.physreads_ps',
                       "db_inst_cpu_usage.avg_tot_cpu_usage_ps","instance_throughput.physreads_ps"
                       ],

            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",#kee
                "2024-03-11 12:21:12",#d
                "2024-03-11 19:02:09",#d
                "2024-03-11 23:00:00",#keep
                "2024-03-12 11:00:00",#keep
                "2024-03-11 12:00:00",#keep
                "2024-03-12 12:00:00"#keep
            ]
        },
        "expected": {
            "TARGET_GUID": ["ID1", "ID2","ID2", "ID3", "ID3"],
            "metric": [
                       "db_inst_cpu_usage.avg_tot_cpu_usage_ps",
                       "instance_throughput.physreads_ps",'instance_throughput.physreads_ps',
                       "db_inst_cpu_usage.avg_tot_cpu_usage_ps","instance_throughput.physreads_ps"
                       ],
            "ROLLUP_TIMESTAMP_UTC": [
                "2024-03-11 00:00:00",
                "2024-03-11 23:00:00",
                "2024-03-12 11:00:00",
                "2024-03-11 12:00:00",
                "2024-03-12 12:00:00"
            ]
        }
    }

}


# CPU_METRIC                 = 'db_inst_cpu_usage.avg_tot_cpu_usage_ps'
# IOPS_METRIC                = 'instance_throughput.iorequests_ps'
# IOMBS_METRIC               = 'instance_throughput.iombs_ps'
# PHYSREADS_METRIC           = 'instance_throughput.physreads_ps'
# PHYSWRITES_METRIC          = 'instance_throughput.physwrites_ps'
# LOGONS_METRIC              = 'Database_Resource_Usage.logons'
# PGA_METRIC                 = 'memory_usage_sga_pga.pga_total'
# SGA_METRIC                 = 'memory_usage_sga_pga.sga_total'

def test_filter_duplicates():
    results = {}
    for name, case in test_cases.items():
        df = pd.DataFrame(case["data"])
        expected_df = pd.DataFrame(case["expected"])

        if not df.empty:
            df["ROLLUP_TIMESTAMP_UTC"] = pd.to_datetime(df["ROLLUP_TIMESTAMP_UTC"]) # same as in run metric analysis
        if not expected_df.empty:
            expected_df["ROLLUP_TIMESTAMP_UTC"] = pd.to_datetime(expected_df["ROLLUP_TIMESTAMP_UTC"])

        assert expected_df.equals(remove_duplicate_dates_from_EM_df(df))

TESTDATA_PATH = (Path(__file__).parent.parent.parent / "testdata" / "em").resolve()


# 🐱 The target file (manually duplicated added line  8,9,43 duplicated with diff timestamp)️🐱
# emcc_sizing_metrics_host_daily_09_months.csv
@pytest.mark.parametrize("em_folder", ["test_emcc_data"])
def test_filter_duplicated_with_em_data(em_folder):
    target_file = TESTDATA_PATH / em_folder / "emcc_sizing_extracts" / "emcc_sizing_metrics_host_daily_09_months.csv"

    #Reading and converting column to time
    original_df = pd.read_csv(target_file,
                            parse_dates=["ROLLUP_TIMESTAMP_UTC"])

    original_df = prepare_em_df(original_df)
    #Manually added 3 lines, so I'm expecting the same length - 3
    expected_length_df = len(original_df) - 3

    processed_df = remove_duplicate_dates_from_EM_df(original_df)
    assert len(processed_df) == expected_length_df
