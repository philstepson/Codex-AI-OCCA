import pandas as pd

from pandas_helpers.pandas_data_utils import contains


def test_df_column_contains_special_characters():
    food_pdf = pd.DataFrame({"Mac":["s_and_wich", "cheeseburger^", "pasta", "pizza<><<", "salad~"],
                             "Cheese":["a/", "b(", "c()", "d))", "e&"]})
    cats_pdf = pd.DataFrame({"Cats":["kitten", "puppy$", "meow)", "whiskers("]})

    # SPECIAL_CHARACTERS -> utils.py
    column_1 = food_pdf.Mac
    column_2 = food_pdf.Cheese
    column_3 = cats_pdf.Cats

    assert not contains(column_1, "/")
    assert not contains(column_1, "(")
    assert not contains(column_1, "$$")
    assert not contains(column_1, "&")
    assert not contains(column_1, "&()/")

    assert contains(column_2, "/")
    assert contains(column_2, "(")
    assert contains(column_2, "&")
    assert contains(column_2, "&()/")

    assert contains(column_3, "(")
    assert contains(column_3, "()")
    assert contains(column_3, "$")
    assert not contains(column_3, "/")
    assert not contains(column_3, "&")
