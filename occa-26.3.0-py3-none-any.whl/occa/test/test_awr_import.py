"""
Unit tests for awr_miner_import.py
"""
import sys

#
# Version History
#
# 2023-06-20    1.0 pro     Initial version


import pytest

import hashlib
import json
import logging
import os
import simplejson

import numpy as np
import pandas as pd

from pathlib import Path
from pandas.testing import assert_frame_equal

# Import awr_miner_import
import occa.awr_miner_import as imp


@pytest.fixture
def testdata_dir() -> Path:
    """
    A Path to the root directory for tests

    Returns
    -------
    Path
        A Path to the root directory for tests

    """
    return Path(os.path.join(Path(__file__).parent.parent.parent, "testdata")).resolve()


@pytest.fixture
def data_dir(testdata_dir) -> Path:
    """
    A Path to the directory containing the needed files for this Unit Test.
    This path will be also used for the generated files as part of the execution
    of this unit test

    Parameters
    ----------
        testdata_dir : Path
            The testdata_dir fixture

    Returns
    -------
    Path
        A Path to the directory for this tests

    """
    return Path(os.path.join(testdata_dir, "awr", "test_awr_import")).resolve()


@pytest.fixture
def awr_miner_path(data_dir) -> Path:
    """
    A Path to the awr_miner_path dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_path dir

    """
    return Path(data_dir).resolve()


@pytest.fixture
def awr_miner_occa(data_dir) -> Path:
    """
    A Path to the awr_miner_occa dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_occa dir

    """
    return Path(os.path.join(data_dir, "awr_miner_occa")).resolve()


@pytest.fixture
def awr_miner_occa_properties(awr_miner_occa) -> Path:
    """
    A Path to the awr_miner_occa dir

    Parameters
    ----------
        awr_miner_occa : Path
            The awr_miner_occa fixture

    Returns
    -------
        Path
            A Path to the awr_miner_occa/properties dir

    """
    return Path(os.path.join(awr_miner_occa, "properties")).resolve()


@pytest.fixture
def awr_miner_sizing(awr_miner_occa) -> Path:
    """
    A Path to the awr_miner_occa/sizing dir

    Parameters
    ----------
        awr_miner_occa : Path
            The awr_miner_occa fixture

    Returns
    -------
        Path
            A Path to the awr_miner_occa/sizing dir

    """
    return Path(os.path.join(awr_miner_occa, "sizing")).resolve()


@pytest.fixture
def awr_miner_plot(awr_miner_occa) -> Path:
    """
    A Path to the awr_miner_occa/plot dir

    Parameters
    ----------
        awr_miner_occa : Path
            The awr_miner_occa fixture

    Returns
    -------
        Path
            A Path to the awr_miner_occa/plot dir

    """
    return Path(os.path.join(awr_miner_occa, "plot")).resolve()


@pytest.fixture
def awr_miner_plot_unadjusted(awr_miner_plot) -> Path:
    """
    A Path to the awr_miner_occa/plot dir

    Parameters
    ----------
        awr_miner_plot : Path
            The awr_miner_plot fixture

    Returns
    -------
        Path
            A Path to the awr_miner_occa/plot/unadjusted dir

    """
    return Path(os.path.join(awr_miner_plot, "unadjusted")).resolve()


@pytest.fixture
def awr_miner_parsed(data_dir) -> Path:
    """
    A Path to the awr_miner_parsed dir

    Parameters
    ----------
        data_dir : Path
            The data_dir fixture

    Returns
    -------
        Path
            A Path to the awr_miner_parsed dir

    """
    return Path(os.path.join(data_dir, "awr_miner_parsed")).resolve()


@pytest.fixture
def awr_miner_parsed_db(awr_miner_parsed) -> Path:
    """
    A Path to the directory created for a given database under awr_miner_parsed directory

    Parameters
    ----------
        awr_miner_parsed : Path
            The awr_miner_parsed fixture

    Returns
    -------
        Path
            A Path to the directory created for a given database under awr_miner_parsed directory

    """
    database_dir = "db_oracle-database-00000_2210461847"
    return Path(os.path.join(awr_miner_parsed, database_dir)).resolve()


@pytest.fixture
def awr_miner_parsed_file(awr_miner_parsed_db) -> Path:
    """
    A Path to the directory created for a given collection under awr_miner_parsed directory

    Parameters
    ----------
        awr_miner_parsed_db : Path
            The awr_miner_parsed_db fixture

    Returns
    -------
        Path
            A Path to the directory created for a collection under awr_miner_parsed directory

    """
    collection_dir = "awr-hist-2210461847-oracle-database-00000-7102-7307"
    return Path(os.path.join(awr_miner_parsed_db, collection_dir)).resolve()


@pytest.fixture
def databases_csv(awr_miner_sizing) -> Path:
    """
    A Path to the databases.csv file

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture

    Returns
    -------
        Path
            A Path to the awr_miner_out dir

    """
    f = "databases.csv"
    return Path(os.path.join(awr_miner_sizing, f)).resolve()


@pytest.fixture
def top_sql_summary_csv() -> str:
    """
    The filename for the TOP-SQL-SUMMARY.csv parsed file

    Returns
    -------
        str
            The filename for the TOP-SQL-SUMMARY.csv parsed file

    """
    return "TOP-SQL-SUMMARY.csv"


@pytest.fixture
def top_sql_by_snapid_csv() -> str:
    """
    The filename for the TOP-SQL-BY-SNAPID.csv parsed file

    Returns
    -------
        str
            The filename for the TOP-SQL-BY-SNAPID.csv parsed file

    """
    return "TOP-SQL-BY-SNAPID.csv"


@pytest.fixture
def segment_io_csv() -> str:
    """
    The filename for the SEGMENT-IO.csv parsed file

    Returns
    -------
        str
            The filename for the SEGMENT-IO.csv parsed file

    """
    return "SEGMENT-IO.csv"


@pytest.fixture()
def json_import_data() -> str:
    """
    A Simulated json payload of the content collected on import.

    The keys adjustments and metric_presence_by_stage are empty because lack
    of datasets containing those keys.

    The key plot_html is intentinally empty because the ammount data dumped

    Returns
    -------
        string
           A simulated json import
    """

    json_data = """
        {
            "databases": [
                {
                  "excluded": "NaN",
                  "excluded_reason": "Nan",
                  "cdb_cohort": "testprod",
                  "cdb": "db_oracle-database-00000_2210461847-7102-7307",
                  "cdb_instance_count": 1,
                  "clustered": "NON-CLUSTERED",
                  "Server List": "host-00000",
                  "cdb_target_guid": "db_oracle-database-00000_2210461847-7102-7307",
                  "cwd": "test_awr_end_to_end",
                  "platform": "Darwin",
                  "extract_dttm_utc": "2022-12-01 11:00:00",
                  "create_dttm_utc": "2023-05-16 10:07:44",
                  "source": "AWR_miner",
                  "version": 1.33,
                  "cdb_version": "19.0.0.0.0"
                }
            ],
            "hosts": [
                {
                    "host": "host-00000",
                    "total_cpu_cores": 48,
                    "logical_cpu_count": 96,
                    "mem_gb": 1510.11,
                    "dist_version": "Linux_x86_64-bit",
                    "cpu_type": "INTEL",
                    "host_target_guid": "host-00000",
                    "cwd": "test_awr_end_to_end",
                    "platform": "Darwin",
                    "extract_dttm_utc": "2022-12-01 11:00:00",
                    "create_dttm_utc": "2023-05-16 10:07:44",
                    "source": "AWR_miner",
                    "version": 1.33
                }
            ],
            "instances": [
                {
                    "excluded": "Nan",
                    "excluded_reason": "Nan",
                    "cdb_cohort": "testprod",
                    "WHICH_DB": "db_oracle-database-00000_2210461847-7102-7307",
                    "cdb": "db_oracle-database-00000_2210461847-7102-7307",
                    "db": "db_oracle-database-00000_2210461847-7102-7307$host-00000$001",
                    "host": "host-00000",
                    "total_cpu_cores": 48,
                    "logical_cpu_count": 96,
                    "mem_gb": 1510.11,
                    "dist_version": "Linux_x86_64-bit",
                    "cpu_type": "INTEL",
                    "db_cohort": "testprod",
                    "sga_size_gb": 5.3,
                    "pga_size_gb": 3.0,
                    "init_cpu_count": 96,
                    "cdb_target_guid": "db_oracle-database-00000_2210461847-7102-7307",
                    "db_target_guid": "db_oracle-database-00000_2210461847-7102-7307$host-00000$001",
                    "host_target_guid": "host-00000",
                    "cwd": "test_awr_end_to_end",
                    "platform": "Darwin",
                    "extract_dttm_utc": "2022-12-01 11:00:00",
                    "create_dttm_utc": "2023-05-16 10:07:44",
                    "source": "AWR_miner",
                    "version": 1.33
                }
            ],
            "cohort_rollups": [
                {
                    "Name": "testprod",
                    "Rollup Type": "AVERAGE",
                    "Time Unit": "HOURLY",
                    "Time Period": 3,
                    "Adjusted Values": "N",
                    "Databases Included": 3,
                    "Databases Excluded": 0,
                    "Instances Included": 3,
                    "Instances Excluded": 0,
                    "Hours": 205.0,
                    "Allocated Storage (GB)": 28803.3,
                    "Used Storage (GB)": 28803.3,
                    "DB vCPU": 1.628,
                    "DB vCPU for Standby": 1.628,
                    "DB PGA (MB)": 9420.8,
                    "DB SGA (MB)": 29798.4,
                    "DB Memory (MB)": 39116.8,
                    "DB IOPS": 564.7,
                    "DB IOPS for Standby": 564.7,
                    "DB Logons": 508.0,
                    "cwd": "test_awr_end_to_end",
                    "platform": "Darwin",
                    "extract_dttm_utc": "2022-12-01 11:00:00",
                    "create_dttm_utc": "2023-05-16 10:07:44",
                    "source": "AWR_miner",
                    "version": 1.33
                }
            ],
            "database_rollups": [
                {
                    "Cohort": "testprod",
                    "Name": "db_oracle-database-00000_2210461847-7102-7307",
                    "Rollup Type": "AVERAGE",
                    "Time Unit": "HOURLY",
                    "Time Period": 3,
                    "Adjusted Values": "N",
                    "Instances Included": 1,
                    "Instances Excluded": 0,
                    "Hours": 205.0,
                    "Allocated Storage (GB)": 9729.07,
                    "Used Storage (GB)": 9729.07,
                    "DB vCPU": 0.027,
                    "DB vCPU for Standby": 0.027,
                    "DB PGA (MB)": 3072.0,
                    "DB SGA (MB)": 5427.2,
                    "DB Memory (MB)": 8499.2,
                    "DB IOPS": 35.9,
                    "DB IOPS for Standby": 35.9,
                    "DB Logons": 166.3,
                    "cwd": "test_awr_end_to_end",
                    "platform": "Darwin",
                    "extract_dttm_utc": "2022-12-01 11:00:00",
                    "create_dttm_utc": "2023-05-16 10:07:44",
                    "source": "AWR_miner",
                    "version": 1.33
                }
            ],
            "sizing": [
                {
                    "cdb_cohort": "testprod",
                    "cdb": "All",
                    "cdb_type": "All",
                    "instance_count": 3,
                    "metric": "Allocated Storage (GB)",
                    "adjusted": 0,
                    "summary_of": "cdb_cohort",
                    "peak": 28803.3,
                    "average": 28463.585,
                    "sum_peak_x_hrs": 5904676.5,
                    "sum_metric_x_hrs": 5835034.925,
                    "sum_peak_x_hrs_m_sum_metric_x_hrs": 69641.575,
                    "sum_metric_x_hrs_o_sum_peak_x_hrs": 0.988,
                    "hrs": 205.0,
                    "cdb_target_guid": "All",
                    "cwd": "test_awr_end_to_end",
                    "platform": "Darwin",
                    "extract_dttm_utc": "2022-12-01 11:00:00",
                    "create_dttm_utc": "2023-05-16 10:07:44",
                    "source": "AWR_miner",
                    "version": 1.33
                }
            ],
            "database_statistics": [
                {
                    "cdb_cohort": "testprod",
                    "cdb": "db_oracle-database-00000_2210461847-7102-7307",
                    "metric": "Allocated Storage (GB)",
                    "adjusted": 0,
                    "summary_of": "cdb",
                    "cdb_target_guid": "db_oracle-database-00000_2210461847-7102-7307",
                    "count": 205.0,
                    "mean": 9729.07,
                    "std": 0.0,
                    "min": 9729.07,
                    "p10": 9729.07,
                    "p20": 9729.07,
                    "p30": 9729.07,
                    "p40": 9729.07,
                    "p50": 9729.07,
                    "p60": 9729.07,
                    "p70": 9729.07,
                    "p80": 9729.07,
                    "p90": 9729.07,
                    "p95": 9729.07,
                    "p99": 9729.07,
                    "max": 9729.07,
                    "total": 1994459.35,
                    "max_rank": 2.0,
                    "total_rank": 2.0,
                    "Rollup Type": "AVERAGE",
                    "Time Unit": "HOURLY",
                    "Time Period": 3,
                    "cwd": "test_awr_end_to_end",
                    "platform": "Darwin",
                    "extract_dttm_utc": "2022-12-01 11:00:00",
                    "create_dttm_utc": "2023-05-16 10:07:44",
                    "source": "AWR_miner",
                    "version": 1.33
                }
            ],
            "adjustments": [],
            "metric_presence_by_stage": [],
            "database_vcpu_hours": [
                {
                  "Name": "db_oracle-database-00000_2210461847-7102-7307",
                  "Rollup Type": "AVERAGE",
                  "Time Unit": "HOURLY",
                  "Time Period": 3,
                  "Adjusted Values": "N",
                  "GT vCPU Count": 0.0,
                  "Hrs": 205,
                  "cwd": "test_awr_end_to_end",
                  "platform": "Darwin",
                  "extract_dttm_utc": "2022-12-01 11:00:00",
                  "create_dttm_utc": "2023-05-16 10:07:44",
                  "source": "AWR_miner",
                  "version": 1.33
                }
            ],
            "database_parameters": [
                {
                    "PARAMETER_NAME": "DBFIPS_140",
                    "VALUE": "FALSE",
                    "snap_id_start": 7102,
                    "snap_id_end": 7307,
                    "cdb": "db_oracle-database-00000_2210461847-7102-7307",
                    "INSTANCE_NUMBER": 1
                }
            ],
            "top_sql": [
                {
                    "MODULE": "Nan",
                    "ACTION": "Nan",
                    "SQL_ID": "54wkgprhc32fh",
                    "COMMAND_NAME": "SELECT",
                    "PARSING_SCHEMA_NAME": "XXXXXX",
                    "EXEC_RANK": 3,
                    "ELAP_RANK": 1,
                    "LOG_READS_RANK": 1,
                    "PHYS_READS_RANK": 3,
                    "EXECS": 1,
                    "ELAP": 1371438,
                    "LOG_READS": 11017,
                    "PHY_READ_GB": 0,
                    "PLAN_COUNT": 1,
                    "PX_SERVERS_EXECS": 0,
                    "snap_id_start": 7102,
                    "snap_id_end": 7307,
                    "cdb": "db_oracle-database-00000_2210461847-7102-7307"
                }
            ],
            "top_sql_by_snapshot": [
                {
                    "SNAP_ID": 7130,
                    "PARSING_SCHEMA_NAME": "XXXXXXXXXX",
                    "PLAN_HASH": 0,
                    "MODULE": "DBMS_SCHEDULER",
                    "ACTION": "MGMT_CONFIG_JOB",
                    "SQL_ID": "44c8h21v4x42s",
                    "COMMAND_NAME": "CALLMETHOD",
                    "EXECS": 1,
                    "BUFFER_GETS": 624,
                    "ROWS_PROC": 0,
                    "CPU_T_S": 0.1,
                    "ELAP_S": 0.4,
                    "READ_MB": 0.2,
                    "IO_WAIT": 0.2,
                    "ELAP_RANK": 1,
                    "PLAN_CHANGE": 0,
                    "PLANS": 1,
                    "PHY_READ_GB": 0,
                    "PX_SERVERS_EXECS": 0,
                    "DIRECT_W_GB": 0,
                    "IOWAIT_TIME": 213621,
                    "PIO": 21,
                    "snap_id_start": 7102,
                    "snap_id_end": 7307,
                    "cdb": "db_oracle-database-00000_2210461847-7102-7307"
                }
            ],
            "segment_io": [
                {
                    "OWNER": "XXXXXX",
                    "OBJECT_NAME": "SYS_IL0000018683C00031$$",
                    "OBJECT_TYPE": "INDEX PARTITION",
                    "SUBOBJECT_NAME": "SYS_IL_P3730",
                    "TABLESPACE_NAME": "SYSAUX",
                    "PARTITION_SIZE_GB_RUNNING": 0.0001,
                    "PARTITION_SIZE_GB": 0.0001,
                    "SEG_SIZE_GB": 0.0,
                    "DB_SIZE_GB": 2.111,
                    "DB_DISK_SPACE_ALLOC_GB": 2.612,
                    "DB_TEMP_SPACE_ALLOC_GB": 0.063,
                    "SEG_PHYSICAL_READS": 110,
                    "SEG_PHYSICAL_WRITES": 0,
                    "SEG_PHYSICAL_IO": 110,
                    "SEG_PHYSICAL_IO_RUNNING": 110,
                    "SEG_PHYSICAL_IO_TOT": 640,
                    "PHYSICAL_READS": 110,
                    "PHYSICAL_WRITES": 0,
                    "PHYSICAL_IO": 110,
                    "PHYSICAL_IO_RUNNING": 110,
                    "PHYSICAL_IO_TOT": 640,
                    "PHYSICAL_READS_DIRECT": 0,
                    "PHYSICAL_WRITES_DIRECT": 0,
                    "SEG_PHYSICAL_READS_DIRECT": 0,
                    "SEG_PHYSICAL_WRITES_DIRECT": 0,
                    "INST_CNT": 1,
                    "STARTUP_TIME": "2022-09-16T01:14:32",
                    "REPORT_TIME_UTC": "2022-12-01T10:01:51",
                    "UPTIME_SEC": 6605239,
                    "SEGMENT_PRESENT_FLG": 1,
                    "RUN_SEG_PHYS_IO_PCT_OF_TOT": 17.1875,
                    "RUN_PHYSCIAL_IO_PCT_OF_TOT": 17.1875,
                    "ROWS_TOT": 14,
                    "snap_id_start": 6064,
                    "snap_id_end": 6267,
                    "cdb": "db_oracle-database-00001_2273923123-6064-6267"
                }
            ],
            "properties_database": [
                {
                    "Unnamed: 0": 0,
                    "Cohort": "testprod",
                    "WHICH_DB": "db_oracle-database-00000_2210461847-7102-7307",
                    "cdb": "Nan",
                    "STOP": "STOP",
                    "DB_NAME": "oracle-database-00000",
                    "Allocated Storage (GB).max": 9729.07,
                    "DB vCPU.max": 0.027,
                    "DB PGA (MB).max": 3072.0,
                    "DB SGA (MB).max": 5427.2,
                    "DB Memory (MB).max": 8499.2,
                    "DB IOPS.max": 35.9,
                    "DB Logons.max": 166.3,
                    "Allocated Storage (GB).99%": 9729.07,
                    "DB vCPU.99%": 0.026,
                    "DB PGA (MB).99%": 3072.0,
                    "DB SGA (MB).99%": 5427.2,
                    "DB Memory (MB).99%": 8499.2,
                    "DB IOPS.99%": 35.584,
                    "DB Logons.99%": 165.776,
                    "Allocated Storage (GB).95%": 9729.07,
                    "DB vCPU.95%": 0.007,
                    "DB PGA (MB).95%": 3072.0,
                    "DB SGA (MB).95%": 5427.2,
                    "DB Memory (MB).95%": 8499.2,
                    "DB IOPS.95%": 26.78,
                    "DB Logons.95%": 159.78,
                    "Allocated Storage (GB).90%": 9729.07,
                    "DB vCPU.90%": 0.003,
                    "DB PGA (MB).90%": 3072.0,
                    "DB SGA (MB).90%": 5427.2,
                    "DB Memory (MB).90%": 8499.2,
                    "DB IOPS.90%": 15.38,
                    "DB Logons.90%": 153.1,
                    "Allocated Storage (GB).80%": 9729.07,
                    "DB vCPU.80%": 0.002,
                    "DB PGA (MB).80%": 3072.0,
                    "DB SGA (MB).80%": 5427.2,
                    "DB Memory (MB).80%": 8499.2,
                    "DB IOPS.80%": 10.02,
                    "DB Logons.80%": 146.36,
                    "Allocated Storage (GB).mean": 9729.07,
                    "DB vCPU.mean": 0.003,
                    "DB PGA (MB).mean": 3034.037,
                    "DB SGA (MB).mean": 5427.2,
                    "DB Memory (MB).mean": 8461.237,
                    "DB IOPS.mean": 11.051,
                    "DB Logons.mean": 134.832,
                    "Allocated Storage (GB).min": 9729.07,
                    "DB vCPU.min": 0.002,
                    "DB PGA (MB).min": 2969.6,
                    "DB SGA (MB).min": 5427.2,
                    "DB Memory (MB).min": 8396.8,
                    "DB IOPS.min": 6.7,
                    "DB Logons.min": 126.4,
                    "cwd": "test_awr_end_to_end",
                    "platform": "Darwin",
                    "create_dttm_utc": "2023-05-16 10:29:54",
                    "version": 22.1
                }
           ],
            "plots_html": [],
            "occa_version": "1.19.1",
            "date_generated": "2023-05-16T10:30:02.854649",
            "user": "user1",
            "script_dir": "/dir/occa",
            "data_dir": "/dir/awr_miner_occa/sizing",
            "database_names_hash": "6b593a5061fbc1c00cf99908aa03bc61"
    }
        """
    return json_data


@pytest.fixture()
def databases_output_dict() -> dict:
    """
    A Simulated output dict for the databases key

    Returns
    -------
        dict
           A simulated dict
    """
    output_dict = {
        "databases": [
            {
                "excluded": np.nan,
                "excluded_reason": np.nan,
                "cdb_cohort": "DEV",
                "cdb": "db1_609708251-37296-37498",
                "cdb_instance_count": 2,
                "clustered": "CLUSTERED",
                "Server List": "host05vm02,host06vm02",
                "cdb_target_guid": "db1_609708251-37296-37498",
                "cwd": "dir1",
                "platform": "Darwin",
                "extract_dttm_utc": "2022-09-30 15:00:00",
                "create_dttm_utc": "2023-06-14 11:21:49",
                "source": "AWR_miner",
                "version": 1.34,
                "cdb_version": "19.0.0.0.0",
            },
            {
                "excluded": np.nan,
                "excluded_reason": np.nan,
                "cdb_cohort": "TEST",
                "cdb": "db2_609708252-37296-37498",
                "cdb_instance_count": 2,
                "clustered": "CLUSTERED",
                "Server List": "host05vm03,host06vm03",
                "cdb_target_guid": "db2_609708252-37296-37498",
                "cwd": "dir1",
                "platform": "Darwin",
                "extract_dttm_utc": "2022-09-30 15:00:00",
                "create_dttm_utc": "2023-06-14 11:21:49",
                "source": "AWR_miner",
                "version": 1.34,
                "cdb_version": "19.0.0.0.0",
            },
            {
                "excluded": np.nan,
                "excluded_reason": np.nan,
                "cdb_cohort": "PROD",
                "cdb": "db3_609708250-37296-37498",
                "cdb_instance_count": 2,
                "clustered": "CLUSTERED",
                "Server List": "host05vm01,host06vm01",
                "cdb_target_guid": "db3_609708250-37296-37498",
                "cwd": "dir1",
                "platform": "Darwin",
                "extract_dttm_utc": "2022-09-30 15:00:00",
                "create_dttm_utc": "2023-06-14 11:21:49",
                "source": "AWR_miner",
                "version": 1.34,
                "cdb_version": "19.0.0.0.0",
            },
        ],
    }

    return output_dict


@pytest.mark.parametrize("file", ["awr_occa_upload_data.json"])
def test_write_to_file_from_json_content(awr_miner_occa, file, json_import_data, caplog):
    """
    Test the normal operation of write_to_file() routine.

    Given: a json string containing a valid import payload

    When: write_to_file() is invoked

    Then: A json file is written to the file system , a message
          is sent to the logger indicating the write was successful

    Parameters
    ----------
        awr_miner_occa : Path
            The awr_mine_occa fixture
        json_import_data : str
            The json_import_data fixture
        file : str
            The builtin pytest.mark.parametrize decorator
        caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """
    f = os.path.join(awr_miner_occa, file)

    # Load the json tet data
    try:
        data = simplejson.dumps(json.loads(json_import_data), ignore_nan=True)
    except ValueError as err:
        assert False, "Invalid JSON data"

    with caplog.at_level(logging.INFO):
        imp.write_to_file(f, data)

    # Assert the right message comes from the logger
    captured = caplog.text
    assert "Created AWR Collection Import file:" in captured

    # Assert file is created with content
    assert os.path.isfile(f)
    assert os.path.getsize(f) > 0

    # Clean up the file created
    os.remove(f)


def test_check_dirs(awr_miner_path, awr_miner_occa_properties):
    """
    Test the normal operation of check_dirs() routine.

    Given: The awr_miner_path directory

    When: check_dirs() is invoked

    Then: True

    Parameters
    ----------
        awr_miner_path : Path
            The awr_miner_path fixture
        awr_miner_occa_properties : Path
            The awr_miner_occa_properties fixture
    """

    # Create properties directories , the rest are there
    os.mkdir(awr_miner_occa_properties)

    # Assert all the directories exist
    assert imp.check_dirs(awr_miner_path) is True

    # Delete properties directories
    os.rmdir(awr_miner_occa_properties)


def test_check_dirs_dir_does_not_exist(awr_miner_path, awr_miner_occa_properties, caplog):
    """
    Test the normal operation of check_dirs() routine.

    Given: The awr_miner_path directory

    When: check_dirs() is invoked

    Then: False as awr_miner_occa_properties directory does not exist and
          a message is written to the logger indicating the directory is missing

    Parameters
    ----------
        awr_miner_path : Path
            The awr_miner_path fixture
        awr_miner_occa_properties : Path
            The awr_miner_occa_properties fixture
        caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """

    # Assert one of the directories does not exist
    assert imp.check_dirs(awr_miner_path) is False

    # Assert the message written to the logger
    with caplog.at_level(logging.CRITICAL):
        imp.check_dirs(awr_miner_path)
        captured = caplog.text

    expected = f"\nERROR: Directory {awr_miner_occa_properties} doesn't exist\n"
    assert expected in captured


@pytest.mark.parametrize("file", ["OS-INFORMATION.csv"])
def test_read_csv_if_exists_file_exists(awr_miner_parsed_file, file):
    """
    Test the normal operation of read_csv_if_exists() routine.

    Given: A Path to an existing parsed csv file

    When: read_csv_if_exists() is invoked

    Then: pd.DataFrame is returned with the content of the csv file

    Parameters
    ----------
        awr_miner_parsed_file : Path
            The awr_miner_parsed_file fixture
        file : str
            The builtin pytest.mark.parametrize decorator
    """
    f = os.path.join(awr_miner_parsed_file, file)
    df = imp.read_csv_if_exists(f)

    # Assert dataframe contains data
    assert not df.empty


@pytest.mark.parametrize("file", ["fake.csv"])
def test_read_csv_if_exists_file_does_not_exists(awr_miner_parsed_file, file):
    """
    Test the normal operation of read_csv_if_exists() routine.

    Given: A Path to an unexistant file

    When: read_csv_if_exists() is invoked

    Then: An empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_parsed_file : Path
            The awr_miner_parsed_file fixture
        file : str
            The builtin pytest.mark.parametrize decorator
    """
    f = os.path.join(awr_miner_parsed_file, file)
    df = imp.read_csv_if_exists(f)

    # Assert dataframe is empty
    assert df.empty


def test_get_path_to_db_files_dbname_follows_convention(awr_miner_sizing, awr_miner_parsed, awr_miner_parsed_file, databases_csv):
    """
    Test the normal operation of get_path_to_db_files() routine.
    If the 'cdb' column contains a standard database name that name is used
    to locate the path to the parsed files.

    Given: A databases.csv file with cdb column following standard naming convention

    When: get_path_to_db_files() is invoked

    Then: A dict with the database name and the path to its files

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        awr_miner_parsed_file : Path
            The awr_miner_parsed_file fixture
        databases_csv : Path
            The databases_csv fixture
    """
    databases_df = imp.read_csv_if_exists(databases_csv)

    # Path should be composed using the cdb column value on the dataframe
    expected = {"db_oracle-database-00000_2210461847-7102-7307": f"{awr_miner_parsed_file}"}

    # Assert dict contains identifier and path
    if not databases_df.empty:
        assert imp.get_path_to_db_files(awr_miner_parsed, databases_df) == expected


@pytest.mark.parametrize("file", ["databases_modified_cdb.csv"])
def test_get_path_to_db_files_dbname_does_not_follow_convention(awr_miner_sizing, awr_miner_parsed, awr_miner_parsed_file, file):
    """
    Test the normal operation of get_path_to_db_files() routine.
    If the 'cdb' column contains a database name not following the standard naming convention
    the path to its parsed files should be extracted from the OS.

    Given: A databases.csv file with cdb column NOT following standard naming convention

    When: get_path_to_db_files() is invoked

    Then: A dict with the database name and the path to its files

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        awr_miner_parsed_file : Path
            The awr_miner_parsed_file fixture
        file : str
            The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(awr_miner_sizing, file))

    # Path should be read from the OS location because cdb column dataframe does not follow naming convention
    expected = {"db_oracle-database-00000": f"{awr_miner_parsed_file}"}

    # Assert dict contains identifier and path
    if not databases_df.empty:
        assert imp.get_path_to_db_files(awr_miner_parsed, databases_df) == expected


@pytest.mark.parametrize("file", ["databases_not_exists.csv"])
def test_get_path_to_db_files_databases_csv_does_not_exist(awr_miner_sizing, awr_miner_parsed, file):
    """
    Test the normal operation of get_path_to_db_files() routine.

    Given: A inexistant database.csv file

    When: get_path_to_db_files() is invoked

    Then: Empty dict is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        file : str
            The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(awr_miner_sizing, file))

    expected = {}

    # Assert dict is empty
    if not databases_df.empty:
        assert imp.get_path_to_db_files(awr_miner_parsed, databases_df) == expected


def test_get_db_parameters_block_extraction_flag_is_set_to_false(awr_miner_sizing, awr_miner_parsed, databases_csv):
    """
    Test the normal operation of get_db_parameters_block() routine.

    Given: Extraction flag is set to False

    When: get_db_parameters_block() is invoked

    Then: Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
       databases_csv : Path
           The databases_csv fixture
    """
    databases_df = imp.read_csv_if_exists(databases_csv)
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    # Set the files
    if1 = "DATABASE-PARAMETERS.csv"
    if2 = "DATABASE-PARAMETERS2.csv"

    imp.dump_db_parameters = False
    df = imp.get_db_parameters_block(databases_df_to_path_dict, if1, if2)

    # Assert dataframe is empty
    assert df.empty


def test_get_db_parameters_block_extraction_flag_is_set_to_true(awr_miner_sizing, awr_miner_parsed, databases_csv):
    """
    Test the normal operation of get_db_parameters_block() routine.

    Given: Extraction flag is set to True

    When: get_db_parameters_block() is invoked

    Then: Not Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
    """
    databases_df = imp.read_csv_if_exists(databases_csv)
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    # Set the files
    if1 = "DATABASE-PARAMETERS.csv"
    if2 = "DATABASE-PARAMETERS2.csv"

    imp.dump_db_parameters = True
    df = imp.get_db_parameters_block(databases_df_to_path_dict, if1, if2)

    # Assert dataframe is not empty
    assert not df.empty


def test_get_db_parameters_block_dataframes_are_same(awr_miner_sizing, awr_miner_parsed, databases_csv):
    """
    Test the normal operation of get_db_parameters_block() routine.

    Given: Extraction flag is set to True and database parameters csv files

    When: get_db_parameters_block() is invoked

    Then: pd.DataFrame is returned with the content of the csv files

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)
    if1 = "DATABASE-PARAMETERS.csv"
    if2 = "DATABASE-PARAMETERS2.csv"

    imp.dump_db_parameters = True
    df = imp.get_db_parameters_block(databases_df_to_path_dict, if1, if2)

    # Filter the returned dataframe to test only some of the values
    returned_df = df[
        (df.PARAMETER_NAME == "audit_file_dest")
        | (df.PARAMETER_NAME == "background_dump_dest")
        | (df.PARAMETER_NAME == "sga_max_size")
        | (df.PARAMETER_NAME == "compatible")
        | (df.PARAMETER_NAME == "db_block_size")
    ]

    # Sort the filtered dataframe by parameter_name and reindex
    returned_df = returned_df.sort_values("PARAMETER_NAME").reset_index(drop=True)

    # Set the Expected results
    expected_series = [
        ["audit_file_dest", "XXXXXXXXXXXX", 7102, 7307, "db_oracle-database-00000_2210461847-7102-7307", 1],
        ["background_dump_dest", "XXXXXXXXXXXX", 7102, 7307, "db_oracle-database-00000_2210461847-7102-7307", 1],
        ["sga_max_size", "6442450944", 7102, 7307, "db_oracle-database-00000_2210461847-7102-7307", 1],
        ["compatible", "19.0.0", 7102, 7307, "db_oracle-database-00000_2210461847-7102-7307", 1],
        ["db_block_size", "8192", 7102, 7307, "db_oracle-database-00000_2210461847-7102-7307", 1],
    ]

    expected_columns = ["PARAMETER_NAME", "VALUE", "snap_id_start", "snap_id_end", "cdb", "INSTANCE_NUMBER"]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Sort the expected  dataframe by parameter_name and reindex
    expected_df = expected_df.sort_values("PARAMETER_NAME").reset_index(drop=True)

    # Assert dataframes are the same
    assert_frame_equal(returned_df, expected_df)


def test_get_top_sql_statements_block_extraction_flag_is_set_to_false(
    awr_miner_sizing, awr_miner_parsed, databases_csv, top_sql_summary_csv
):
    """
    Test the normal operation of get_top_sql_statements_block() routine.

    Given: Extraction flag is set to False

    When: get_top_sql_statements_block() is invoked

    Then: Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
       databases_csv : Path
           The databases_csv fixture
       top_sql_summary_csv : str
           The top_sql_summary_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_top_sql = False
    df = imp.get_top_sql_statements_block(databases_df_to_path_dict, top_sql_summary_csv)

    # Assert dataframe is empty
    assert df.empty


def test_get_top_sql_statements_block_extraction_flag_is_set_to_true(
    awr_miner_sizing, awr_miner_parsed, databases_csv, top_sql_summary_csv
):
    """
    Test the normal operation of get_top_sql_statements_block() routine.

    Given: Extraction flag is set to True

    When: get_top_sql_statements_block() is invoked

    Then: Not Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
       databases_csv : Path
           The databases_csv fixture
       top_sql_summary_csv : str
            The top_sql_summary_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_top_sql = True
    df = imp.get_top_sql_statements_block(databases_df_to_path_dict, top_sql_summary_csv)

    # Assert dataframe is not empty
    assert not df.empty


def test_get_top_sql_statements_block_dataframes_are_same(awr_miner_sizing, awr_miner_parsed, databases_csv, top_sql_summary_csv):
    """
    Test the normal operation of get_top_sql_statements_block() routine.

    Given: Extraction flag is set to True and top sql csv file

    When: get_top_sql_statements_block() is invoked

    Then: pd.DataFrame is returned with the content of the csv files

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
             The databases_csv fixture
        top_sql_summary_csv : str
             The top_sql_summary_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_top_sql = True
    df = imp.get_top_sql_statements_block(databases_df_to_path_dict, top_sql_summary_csv)

    # Sort the returned dataframe by sql_id and reindex
    returned_df = df.sort_values("SQL_ID").reset_index(drop=True)

    # Set the Expected results
    expected_series = [
        [
            np.nan,
            np.nan,
            "54wkgprhc32fh",
            "SELECT",
            "XXXXXX",
            3,
            1,
            1,
            3,
            1,
            1371438,
            11017,
            0,
            1,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB",
            "bkryyh4vf4p55",
            "SELECT",
            "XXXXXXXXXX",
            1,
            2,
            4,
            5,
            8,
            787652,
            876,
            0,
            1,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            np.nan,
            np.nan,
            "bgaf73qzarpgb",
            "SELECT",
            "XXXXXX",
            3,
            3,
            2,
            5,
            1,
            747511,
            10940,
            0,
            1,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB",
            "44c8h21v4x42s",
            "CALLMETHOD",
            "XXXXXXXXXX",
            2,
            4,
            3,
            1,
            3,
            680637,
            1973,
            0,
            1,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB_1",
            "1qk1m8muarmha",
            "PL/SQLEXECUTE",
            "XXXXXXXXXX",
            3,
            5,
            5,
            2,
            1,
            348793,
            428,
            0,
            1,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            "TOAD 15.1.113.1379",
            "262165056,768937216,560973504",
            "04vfkrajpkrnj",
            "SELECT",
            "XXXXXX",
            3,
            6,
            6,
            4,
            1,
            204163,
            25,
            0,
            1,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
    ]

    expected_columns = [
        "MODULE",
        "ACTION",
        "SQL_ID",
        "COMMAND_NAME",
        "PARSING_SCHEMA_NAME",
        "EXEC_RANK",
        "ELAP_RANK",
        "LOG_READS_RANK",
        "PHYS_READS_RANK",
        "EXECS",
        "ELAP",
        "LOG_READS",
        "PHY_READ_GB",
        "PLAN_COUNT",
        "PX_SERVERS_EXECS",
        "snap_id_start",
        "snap_id_end",
        "cdb",
    ]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Sort the expected dataframe by module and reindex
    expected_df = expected_df.sort_values("SQL_ID").reset_index(drop=True)

    # Assert dataframes are the same
    assert_frame_equal(returned_df, expected_df, check_dtype=False)


def test_get_top_sql_statements_by_snap_id_block_extraction_flag_is_set_to_false(awr_miner_sizing, awr_miner_parsed, databases_csv):
    """
    Test the normal operation of get_top_sql_statements_by_snap_id_block() routine.

    Given: Extraction flag is set to False

    When: get_top_sql_statements_by_snap_id_block() is invoked

    Then: Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
       databases_csv : Path
            The databases_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)
    ifile = "TOP-SQL-BY-SNAPID.csv"

    imp.dump_top_sql_by_snapshot = False
    df = imp.get_top_sql_statements_by_snap_id_block(databases_df_to_path_dict, ifile)

    # Assert dataframe is empty
    assert df.empty


def test_get_top_sql_statements_by_snap_id_block_extraction_flag_is_set_to_true(
    awr_miner_sizing, awr_miner_parsed, databases_csv, top_sql_by_snapid_csv
):
    """
    Test the normal operation of get_top_sql_statements_by_snap_id_block() routine.

    Given: Extraction flag is set to True

    When: get_top_sql_statements_by_snap_id_block() is invoked

    Then: Not Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
             The databases_csv fixture
        top_sql_by_snapid_csv : Path
             The top_sql_by_snapid_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_top_sql_by_snapshot = True
    df = imp.get_top_sql_statements_by_snap_id_block(databases_df_to_path_dict, top_sql_by_snapid_csv)

    # Assert dataframe is not empty
    assert not df.empty


def test_get_top_sql_statements_by_snap_id_block_dataframes_are_same(
    awr_miner_sizing, awr_miner_parsed, databases_csv, top_sql_by_snapid_csv
):
    """
    Test the normal operation of get_top_sql_statements_by_snap_id_block() routine.

    Given: Extraction flag is set to True and top sql buy snap id csv file

    When: get_top_sql_statements_by_snap_id_block() is invoked

    Then: pd.DataFrame is returned with the content of the csv files

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
        top_sql_by_snapid_csv : Path
            The top_sql_by_snapid_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_top_sql_by_snapshot = True
    df = imp.get_top_sql_statements_by_snap_id_block(databases_df_to_path_dict, top_sql_by_snapid_csv)

    # Sort the returned dataframe by sql_id and reindex
    returned_df = df.sort_values("SQL_ID").reset_index(drop=True)

    # Set the Expected results
    expected_series = [
        [
            7130,
            "XXXXXXXXXX",
            0,
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB",
            "44c8h21v4x42s",
            "CALLMETHOD",
            1,
            624,
            0,
            0.1,
            0.4,
            0.2,
            0.2,
            1,
            0,
            1,
            0,
            0,
            0,
            213621,
            21,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            7130,
            "XXXXXXXXXX",
            0,
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB_1",
            "1qk1m8muarmha",
            "PL/SQLEXECUTE",
            1,
            428,
            1,
            0.0,
            0.3,
            0.2,
            0.3,
            2,
            0,
            1,
            0,
            0,
            0,
            295926,
            30,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            7144,
            "XXXXXX",
            1388734953,
            "TOAD 15.1.113.1379",
            "262165056,768937216,560973504",
            "04vfkrajpkrnj",
            "SELECT",
            1,
            25,
            1,
            0.0,
            0.2,
            0.0,
            0.2,
            1,
            0,
            1,
            0,
            0,
            0,
            201524,
            1,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            7184,
            "XXXXXX",
            923899977,
            np.nan,
            np.nan,
            "54wkgprhc32fh",
            "SELECT",
            1,
            11017,
            0,
            1.3,
            1.4,
            0.1,
            0.0,
            1,
            0,
            1,
            0,
            0,
            0,
            6709,
            8,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            7184,
            "XXXXXX",
            2371407611,
            np.nan,
            np.nan,
            "bgaf73qzarpgb",
            "SELECT",
            1,
            10940,
            1,
            0.7,
            0.7,
            0.0,
            0.0,
            2,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            7226,
            "XXXXXXXXXX",
            0,
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB",
            "44c8h21v4x42s",
            "CALLMETHOD",
            1,
            589,
            0,
            0.2,
            0.2,
            0.0,
            0.0,
            1,
            0,
            1,
            0,
            0,
            0,
            13,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            7298,
            "XXXXXXXXXX",
            2872975115,
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB",
            "bkryyh4vf4p55",
            "SELECT",
            8,
            876,
            8,
            0.4,
            0.8,
            0.0,
            0.0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            7298,
            "XXXXXXXXXX",
            0,
            "DBMS_SCHEDULER",
            "MGMT_CONFIG_JOB",
            "44c8h21v4x42s",
            "CALLMETHOD",
            1,
            760,
            0,
            0.1,
            0.2,
            0.1,
            0.0,
            2,
            0,
            1,
            0,
            0,
            0,
            19214,
            19,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
    ]

    expected_columns = [
        "SNAP_ID",
        "PARSING_SCHEMA_NAME",
        "PLAN_HASH",
        "MODULE",
        "ACTION",
        "SQL_ID",
        "COMMAND_NAME",
        "EXECS",
        "BUFFER_GETS",
        "ROWS_PROC",
        "CPU_T_S",
        "ELAP_S",
        "READ_MB",
        "IO_WAIT",
        "ELAP_RANK",
        "PLAN_CHANGE",
        "PLANS",
        "PHY_READ_GB",
        "PX_SERVERS_EXECS",
        "DIRECT_W_GB",
        "IOWAIT_TIME",
        "PIO",
        "snap_id_start",
        "snap_id_end",
        "cdb",
    ]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Sort the expected dataframe by module and reindex
    expected_df = expected_df.sort_values("SQL_ID").reset_index(drop=True)

    # Assert dataframes are the same
    assert_frame_equal(returned_df, expected_df)


def test_get_segment_io_block_block_extraction_flag_is_set_to_false(awr_miner_sizing, awr_miner_parsed, databases_csv, segment_io_csv):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: Extraction flag is set to False

    When: get_segment_io_block() is invoked

    Then: Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
        segment_io_csv : str
            The segment_io_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_segment_io = False
    df = imp.get_segment_io_block(databases_df_to_path_dict, segment_io_csv)

    # Assert dataframe is empty
    assert df.empty


def test_get_segment_io_block_extraction_flag_is_set_to_true(awr_miner_sizing, awr_miner_parsed, databases_csv, segment_io_csv):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: Extraction flag is set to True

    When: get_segment_io_block() is invoked

    Then: Not Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
           The databases_csv fixture
        segment_io_csv : str
           The segment_io_csv fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_segment_io = True
    df = imp.get_segment_io_block(databases_df_to_path_dict, segment_io_csv)

    # Assert dataframe is not empty
    assert not df.empty


@pytest.mark.parametrize("file", ["SEGMENT-IO-RENAME-PCT-COLS.csv"])
def test_get_segment_io_block_dataframe_pct_columns_renamed(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: A file with telemetry data and columns RUNNING_SEG_PHYSCIAL_IO_PCT_OF_TOT
           and RUNNING_PHYSCIAL_IO_PCT_OF_TOT present in the DataFrame created

    When: get_segment_io_block() is invoked

    Then: The columns should be renamed to RUN_SEG_PHYS_IO_PCT_OF_TOT and  RUN_PHYSCIAL_IO_PCT_OF_TOT

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
        file : str
            The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_segment_io = True
    df = imp.get_segment_io_block(databases_df_to_path_dict, file)

    # Assert the expected columns are in the dataframe after renamed them
    assert "RUN_SEG_PHYS_IO_PCT_OF_TOT" in df.columns.values.tolist()
    assert "RUN_PHYSCIAL_IO_PCT_OF_TOT" in df.columns.values.tolist()


@pytest.mark.parametrize("file", ["SEGMENT-IO-PCT-GT-99.csv"])
def test_get_segment_io_block_no_rows_under_limit_by_pct(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: A file with telemetry data not matching the selection criteria ,
           the columns RUN_PHYSCIAL_IO_PCT_OF_TOT of the csv file are beyond
           the 99% limit.

    When: get_segment_io_block() is invoked

    Then:Empty pd.DataFrame is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
         file : str
             The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    # The file passed does not contain rows below the limit_by_pct_set , should return empty df
    imp.dump_segment_io = True
    df = imp.get_segment_io_block(databases_df_to_path_dict, file)

    # Assert dataframe is empty
    assert df.empty


@pytest.mark.parametrize("file", ["SEGMENT-IO-1500-ROWS.csv"])
def test_get_segment_io_block_dataframe_limit_by_pct_lower_than_thousend(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: A file with telemetry data where there are less than 1000 of rows where
           the columns RUN_PHYSCIAL_IO_PCT_OF_TOT of the csv file are under
           the 99% limit.

    When: get_segment_io_block() is invoked

    Then: The 500 rows of the file are returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
             The databases_csv fixture
        file : str
             The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    # The file passed contain 500 rows below the limit_by_pct_set
    imp.dump_segment_io = True
    df = imp.get_segment_io_block(databases_df_to_path_dict, file)

    # Assert the df has only the 500 rows
    assert len(df.index) == 500


@pytest.mark.parametrize("file", ["SEGMENT-IO-2000-ROWS.csv"])
def test_get_segment_io_block_dataframe_limit_by_pct_higher_than_thousend(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: A file with telemetry data where there are more than 1000 of rows where
           the columns RUN_PHYSCIAL_IO_PCT_OF_TOT of the csv file are under
           the 99% limit.

    When: get_segment_io_block() is invoked

    Then: The first 1000 rows of the file are returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
        file : str
             The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    # The file passed contain more than 1000 rows below the limit_by_pct_set
    imp.dump_segment_io = True
    df = imp.get_segment_io_block(databases_df_to_path_dict, file)

    # Assert the df has only the first 1000 rows
    assert len(df.index) == 1000


@pytest.mark.parametrize("file", ["SEGMENT-IO-WRONG-DATE-TIME-FORMAT.csv"])
def test_get_segment_io_block_wrong_startup_and_report_time_format(awr_miner_sizing, awr_miner_parsed, databases_csv, file, caplog):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: A file with telemetry data where the STARTUP_TIME and REPORT_TIME_UTC
           columns do not accomplish with ISO 8601 date format

    When: get_segment_io_block() is invoked

    Then: Those rows which can't be converted are reported in a logger message

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
       databases_csv : Path
            The databases_csv fixture
       file : str
            The builtin pytest.mark.parametrize decorator
        caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_segment_io = True
    with caplog.at_level(logging.INFO):
        df = imp.get_segment_io_block(databases_df_to_path_dict, file)

    # Assert the right message comes from the logger
    captured = caplog.text
    assert "contains rows with unparseable date format" in captured
    assert "Column REPORT_TIME_UTC :  1 rows [2]" in captured
    assert "Column STARTUP_TIME :  1  rows [2]" in captured
    assert "These rows have been skipped from the import" in captured


def test_get_segment_io_block_dataframes_are_same(awr_miner_sizing, awr_miner_parsed, databases_csv, segment_io_csv, caplog):
    """
    Test the normal operation of get_segment_io_block() routine.

    Given: A file with telemetry data for the SEGMENT-IO block

    When: get_segment_io_block() is invoked

    Then: pd.DataFrame is returned with the expected content.

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
        segment_io_csv : str
            The segment_io_csv fixture
        caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    imp.dump_segment_io = True
    df = imp.get_segment_io_block(databases_df_to_path_dict, segment_io_csv)

    # Sort the returned dataframe by sql_id and reindex
    returned_df = df.sort_values("OBJECT_NAME").reset_index(drop=True)

    # Set the Expected results
    expected_series = [
        [
            "XXXXXX",
            "SYS_IL0000018570C00097$$",
            "INDEX PARTITION",
            "SYS_IL_P6412",
            "SYSAUX",
            0.0001,
            0.0001,
            0.0,
            2.719,
            3.716,
            0.099,
            0,
            10,
            10,
            10,
            10,
            0,
            10,
            10,
            10,
            10,
            0,
            0,
            0,
            0,
            1,
            "22-09-16T01:06:21",
            "22-12-01T10:11:48",
            6606327,
            1,
            100,
            95,
            2,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
        [
            "XXXXXXXXXXXXXXXXX",
            "CLOUD",
            "TABLE",
            np.nan,
            "SYSAUX",
            0.0001,
            np.nan,
            np.nan,
            2.719,
            3.716,
            0.099,
            0,
            0,
            0,
            10,
            10,
            0,
            0,
            0,
            10,
            10,
            0,
            0,
            0,
            0,
            1,
            "22-09-16T01:06:21",
            "22-12-01T10:11:48",
            6606327,
            0,
            100,
            95,
            2,
            7102,
            7307,
            "db_oracle-database-00000_2210461847-7102-7307",
        ],
    ]

    expected_columns = [
        "OWNER",
        "OBJECT_NAME",
        "OBJECT_TYPE",
        "SUBOBJECT_NAME",
        "TABLESPACE_NAME",
        "PARTITION_SIZE_GB_RUNNING",
        "PARTITION_SIZE_GB",
        "SEG_SIZE_GB",
        "DB_SIZE_GB",
        "DB_DISK_SPACE_ALLOC_GB",
        "DB_TEMP_SPACE_ALLOC_GB",
        "SEG_PHYSICAL_READS",
        "SEG_PHYSICAL_WRITES",
        "SEG_PHYSICAL_IO",
        "SEG_PHYSICAL_IO_RUNNING",
        "SEG_PHYSICAL_IO_TOT",
        "PHYSICAL_READS",
        "PHYSICAL_WRITES",
        "PHYSICAL_IO",
        "PHYSICAL_IO_RUNNING",
        "PHYSICAL_IO_TOT",
        "PHYSICAL_READS_DIRECT",
        "PHYSICAL_WRITES_DIRECT",
        "SEG_PHYSICAL_READS_DIRECT",
        "SEG_PHYSICAL_WRITES_DIRECT",
        "INST_CNT",
        "STARTUP_TIME",
        "REPORT_TIME_UTC",
        "UPTIME_SEC",
        "SEGMENT_PRESENT_FLG",
        "RUN_SEG_PHYS_IO_PCT_OF_TOT",
        "RUN_PHYSCIAL_IO_PCT_OF_TOT",
        "ROWS_TOT",
        "snap_id_start",
        "snap_id_end",
        "cdb",
    ]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Sort the expected dataframe by module and reindex
    expected_df = expected_df.sort_values("OBJECT_NAME").reset_index(drop=True)

    # Assert dataframes are the same
    assert_frame_equal(returned_df, expected_df)


@pytest.mark.parametrize("file", ["OS-INFORMATION-VERSION-MISSING.csv"])
def test_get_db_version_from_os_info_block_version_is_missing(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_db_version_from_os_info_block() routine.

    Given: A file with missing database version from OS-INFORMATION block

    When: get_db_version_from_os_info_block() is invoked

    Then: pd.DataFrame with nan value for the cdb_version column

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
        file : str
            The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    df = imp.get_db_version_from_os_info_block(databases_df_to_path_dict, file)

    # Set the Expected results
    expected_series = [
        ["db_oracle-database-00000_2210461847-7102-7307", np.nan],
    ]

    expected_columns = ["cdb", "cdb_version"]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert dataframes are the same
    assert_frame_equal(df, expected_df)


@pytest.mark.parametrize("file", ["OS-INFORMATION.csv"])
def test_get_db_version_from_os_info_block_dataframes_are_same(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_db_version_from_os_info_block() routine.

    Given: A file with database version 19.0.0.0.0 in OS-INFORMATION block

    When: get_db_version_from_os_info_block() is invoked

    Then: pd.DataFrame with value 19.0.0.0.0 in the cdb_version column

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
       databases_csv : Path
           The databases_csv fixture
       file : str
           The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    df = imp.get_db_version_from_os_info_block(databases_df_to_path_dict, file)

    # Set the Expected results
    expected_series = [
        ["db_oracle-database-00000_2210461847-7102-7307", "19.0.0.0.0"],
    ]

    expected_columns = ["cdb", "cdb_version"]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert dataframes are the same
    assert_frame_equal(df, expected_df)


def test_read_all_html_plots_extraction_flag_is_set_to_false(awr_miner_plot):
    """
    Test the normal operation of read_all_html_plots() routine.

    Given: Extraction flag is set to False

    When: read_all_html_plots() is invoked

    Then: None is returned

    Parameters
    ----------
        awr_miner_plot : Path
            The awr_miner_plot fixture
    """
    imp.PLOT_UPLOAD_HTML = False
    assert imp.read_all_html_plots(awr_miner_plot) is None


def test_read_all_html_plots_extraction_flag_is_set_to_true(awr_miner_plot):
    """
    Test the normal operation of read_all_html_plots() routine.

    Given: Extraction flag is set to True (default)

    When: read_all_html_plots() is invoked

    Then: A not empty list is returned

    Parameters
    ----------
        awr_miner_plot : Path
            The awr_miner_plot fixture
    """
    imp.PLOT_UPLOAD_HTML = True
    actual = imp.read_all_html_plots(awr_miner_plot)
    assert len(actual) > 0


def test_read_all_html_plots_dir_does_not_exists(awr_miner_plot, caplog):
    """
    Test the normal operation of read_all_html_plots() routine.

    Given: A non existan directory

    When: read_all_html_plots() is invoked

    Then: An empty list is returned and a message is written to the logger

    Parameters
    ----------
        awr_miner_plot : Path
            The awr_miner_plot fixture
        caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """

    fake_dir = os.path.join(awr_miner_plot, "fakedir")
    expected_list = []
    expected_msg = f"Plot path {fake_dir} doesn't exist"

    with caplog.at_level(logging.ERROR):
        # Assert empty list is returned
        imp.PLOT_UPLOAD_HTML = True
        assert imp.read_all_html_plots(fake_dir) == expected_list

        # Assert the logger contains the expected message
        captured = caplog.text
        assert expected_msg in captured


def test_read_all_html_plots_files_do_not_exist(awr_miner_plot):
    """
    Test the normal operation of read_all_html_plots() routine.

    Given: An existant directory not containing files for the pattern search

    When: read_all_html_plots() is invoked

    Then: An empty list is returned.

    Parameters
    ----------
        awr_miner_plot : Path
            The awr_miner_plot fixture
    """

    fake_dir = os.path.join(awr_miner_plot, "fakedir")
    os.makedirs(fake_dir)

    expected_list = []

    assert imp.read_all_html_plots(fake_dir) == expected_list

    # Clean created directory
    os.rmdir(fake_dir)


def test_read_all_html_plots(awr_miner_plot, caplog):
    """
    Test the normal operation of read_all_html_plots() routine.

    Given: A directory containing html plot files

    When: read_all_html_plots() is invoked

    Then: A list of dicts with the contents of the files is created

    Parameters
    ----------
        awr_miner_plot : Path
            The awr_miner_plot fixture
        caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """

    imp.PLOT_UPLOAD_HTML = True

    with caplog.at_level(logging.DEBUG):
        actual = imp.read_all_html_plots(awr_miner_plot)

    # Hash the value for file_content key to perform comparison against it
    for dict_item in actual:
        if "file_content" in dict_item:
            file_content_bytes = hashlib.md5(dict_item["file_content"].encode())
            file_content_hash = file_content_bytes.hexdigest()
            dict_item["file_content"] = file_content_hash

    expected = [
        {
            "cohort": "testprod",
            "file_name": "testprod_DB_vCPU_unadjusted.html",
            "file_content": "7b2cc2aa8f9941e423cb065b81c50b36",
            "import_source": "AWR_EXTRACT",
            "individual_plots": 0
        },
        {
            "cohort": "testprod",
            "file_name": "testprod_awr_snap_coverage.html",
            "file_content": "76cacd27594a7fd853c7bf5a7f0a7d1f",
            "import_source": "AWR_EXTRACT",
            "individual_plots": 0
        },
    ]

    # Assert the lists are the same
    assert actual == expected

    # Capture logger output
    captured = caplog.text

    # Assert directory message is written to the logger
    expected_dir_message = f"Reading html plots from {awr_miner_plot}"
    assert expected_dir_message in captured

    # Assert Message for first file is written to the logger
    f1 = os.path.join(awr_miner_plot, "unadjusted", "testprod", "html", "testprod_DB_vCPU_unadjusted.html")
    assert f"Reading {f1}" in captured

    # Assert Message for second file is written to the logger
    f2 = os.path.join(awr_miner_plot, "unadjusted", "testprod", "html", "testprod_awr_snap_coverage.html")
    assert f"Reading {f2}" in captured


@pytest.mark.parametrize("file", ["cohort_rollups.csv"])
def test_filter_cohort_rollups(awr_miner_sizing, file, caplog):
    """
    Test the normal operation of filter_cohort_rollups() routine.

    Given: A file with cohorts set

    When: filter_cohort_rollups() is invoked

    Then: A Summary message is written to the logger

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
        caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """

    # Build the DataFrame from the file contents
    read_df = imp.read_csv_if_exists(os.path.join(awr_miner_sizing, file))

    expected_series = [
        [
            "DEV",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            1,
            0,
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "PROD",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            1,
            0,
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "TEST",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            1,
            0,
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
    ]

    expected_columns = [
        "Name",
        "Rollup Type",
        "Time Unit",
        "Time Period",
        "Adjusted Values",
        "Databases Included",
        "Databases Excluded",
        "Instances Included",
        "Instances Excluded",
        "Hours",
        "Allocated Storage (GB)",
        "Used Storage (GB)",
        "DB vCPU",
        "DB vCPU for Standby",
        "DB PGA (MB)",
        "DB SGA (MB)",
        "DB Memory (MB)",
        "DB IOPS",
        "DB IOPS for Standby",
        "DB Logons",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert the dataframes are the same, as come from read_csv_if_exists() routine
    assert_frame_equal(read_df, expected_df)

    with caplog.at_level(logging.INFO):
        actual_df = imp.filter_cohort_rollups(read_df)
        captured = caplog.text

        expected = "Cohort   Rollups Summary : Total[3] included[3] unassigned[0] excluded[0] processed[3]"

        # Assert the expected output is written to the logger
        assert expected in captured

    # Assert the DataFrame are the same, as its returned from filter_cohort_rollups() routine
    assert_frame_equal(read_df, actual_df)


@pytest.mark.parametrize("file", ["cohort_rollups_no_databases_included.csv"])
def test_filter_cohort_rollups_no_databases_included(awr_miner_sizing, file, caplog):
    """
    Test the normal operation of filter_cohort_rollups() routine.

    Given: A file with cohorts set without database included after analysis

    When: filter_cohort_rollups() is invoked

    Then: An error is thown to the logger, an empty dataframe is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
       caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """

    # Build the DataFrame from the file contents
    read_df = imp.read_csv_if_exists(os.path.join(awr_miner_sizing, file))

    expected_series = [
        [
            "DEV",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            0,
            1,
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "PROD",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            0,
            1,
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "TEST",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            0,
            1,
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
    ]

    expected_columns = [
        "Name",
        "Rollup Type",
        "Time Unit",
        "Time Period",
        "Adjusted Values",
        "Databases Included",
        "Databases Excluded",
        "Instances Included",
        "Instances Excluded",
        "Hours",
        "Allocated Storage (GB)",
        "Used Storage (GB)",
        "DB vCPU",
        "DB vCPU for Standby",
        "DB PGA (MB)",
        "DB SGA (MB)",
        "DB Memory (MB)",
        "DB IOPS",
        "DB IOPS for Standby",
        "DB Logons",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert the dataframes are the same
    assert_frame_equal(read_df, expected_df)

    with caplog.at_level(logging.INFO):
        actual_df = imp.filter_cohort_rollups(read_df)
        captured = caplog.text

        # Assert the error is coming in the logger message
        expected = "ERROR : Cohort Rollups not found in the collection!"
        assert expected in captured

        # Assert the numbers printed in the summary message
        expected = "Total[3] included[0] unassigned[0] excluded[0] processed[0]\n"
        assert expected in captured

    # Assert the DataFrame are the same
    assert actual_df.empty


@pytest.mark.parametrize("file", ["database_rollups.csv"])
def test_filter_databases_rollups(awr_miner_sizing, file, caplog):
    """
    Test the normal operation of filter_database_rollups() routine.

    Given: A file with cohorts set

    When: filter_database_rollups() is invoked

    Then: A Summary message is written to the logger

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
       caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """

    # Build the DataFrame from the file contents
    read_df = imp.read_csv_if_exists(os.path.join(awr_miner_sizing, file))

    expected_series = [
        [
            "DEV",
            "db1_609708251-37296-37498",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "PROD",
            "db2_609708250-37296-37498",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "TEST",
            "db3_609708252-37296-37498",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            2,
            0,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
    ]

    expected_columns = [
        "Cohort",
        "Name",
        "Rollup Type",
        "Time Unit",
        "Time Period",
        "Adjusted Values",
        "Instances Included",
        "Instances Excluded",
        "Hours",
        "Allocated Storage (GB)",
        "Used Storage (GB)",
        "DB vCPU",
        "DB vCPU for Standby",
        "DB PGA (MB)",
        "DB SGA (MB)",
        "DB Memory (MB)",
        "DB IOPS",
        "DB IOPS for Standby",
        "DB Logons",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert the dataframes are the same, as come from read_csv_if_exists() routine
    assert_frame_equal(read_df, expected_df)

    with caplog.at_level(logging.INFO):
        actual_df = imp.filter_database_rollups(read_df)
        captured = caplog.text

        expected = "Database Rollups Summary : Total[3] included[3] unassigned[0] excluded[0] processed[3]"

        # Assert the expected output is written to the logger
        assert expected in captured

    # Assert the DataFrame are the same, as its returned from filter_cohort_rollups() routine
    assert_frame_equal(read_df, actual_df)


@pytest.mark.parametrize("file", ["database_rollups_no_instances_included.csv"])
def test_filter_database_rollups_no_instances_included(awr_miner_sizing, file, caplog):
    """
    Test the normal operation of filter_cohort_rollups() routine.

    Given: A file with cohorts set without database included after analysis

    When: filter_cohort_rollups() is invoked

    Then: An error is thown to the logger, an empty dataframe is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
       caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """

    # Build the DataFrame from the file contents
    read_df = imp.read_csv_if_exists(os.path.join(awr_miner_sizing, file))

    expected_series = [
        [
            "DEV",
            "db1_609708251-37296-37498",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            0,
            2,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "PROD",
            "db2_609708250-37296-37498",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            0,
            2,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
        [
            "TEST",
            "db3_609708252-37296-37498",
            "AVERAGE",
            "HOURLY",
            3,
            "N",
            0,
            2,
            202,
            270.96,
            270.96,
            1.527,
            1.527,
            9625.6,
            9523.2,
            19046.4,
            1732.3,
            1732.3,
            619.4,
            "dir1",
            "Darwin",
            "2022-09-30 15:00:00",
            "2023-06-14 11:21:49",
            "AWR_miner",
            1.34,
        ],
    ]

    expected_columns = [
        "Cohort",
        "Name",
        "Rollup Type",
        "Time Unit",
        "Time Period",
        "Adjusted Values",
        "Instances Included",
        "Instances Excluded",
        "Hours",
        "Allocated Storage (GB)",
        "Used Storage (GB)",
        "DB vCPU",
        "DB vCPU for Standby",
        "DB PGA (MB)",
        "DB SGA (MB)",
        "DB Memory (MB)",
        "DB IOPS",
        "DB IOPS for Standby",
        "DB Logons",
        "cwd",
        "platform",
        "extract_dttm_utc",
        "create_dttm_utc",
        "source",
        "version",
    ]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert the dataframes are the same
    assert_frame_equal(read_df, expected_df)

    with caplog.at_level(logging.INFO):
        actual_df = imp.filter_database_rollups(read_df)
        captured = caplog.text

        # Assert the error is coming in the logger message
        expected = "ERROR : Database Rollups not found in the collection!"
        assert expected in captured

        # Assert the numbers printed in the summary message
        expected = "Total[3] included[0] unassigned[0] excluded[0] processed[0]\n"
        assert expected in captured

    # Assert the DataFrame are the same
    assert actual_df.empty


def test_create_database_names_hash(databases_output_dict):
    """
    Test the normal operation of create_database_names_hash() routine.

    Given: A dict with databases key and several databases

    When: create_database_names_hash() is invoked

    Then: A MD5 hash key is returned joining the database names

    Parameters
    ----------
        databases_output_dict : dict
            The databases_output_dict fixture
    """
    database_names_hash = imp.create_database_names_hash(databases_output_dict)
    expected = "5e0ad92c97fb7af7079360c155ea7c2c"
    assert database_names_hash == expected


def test_create_database_names_hash_no_databases_key():
    """
    Test the normal operation of create_database_names_hash() routine.

    Given: An empty dict or a dict without databases key on it

    When: create_database_names_hash() is invoked

    Then: An empty string is returned

    """
    database_names_hash = imp.create_database_names_hash({})
    expected = ""
    assert database_names_hash == expected


def test_create_input_json_exit_code():
    """
    Test the normal operation of create_input_json() when an error is detected.

    Given: Invoke create_input_json() with non-existant mandatory directory

    When: create_input_json() is invoked

    Then: Exit Code 1 should be returned

    """
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        imp.create_input_json()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1


@pytest.mark.parametrize("file", ["databases_excluded.csv"])
def test_check_excluded_databases(awr_miner_sizing, file, caplog):
    """
    Test the normal operation of check_excluded_databases() routine.

    Given: A file with some databases excluded with excluded reason

    When: check_excluded_databases() is invoked

    Then: True is returned and an error is thown to the logger

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
       caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """
    df = imp.read_csv_if_exists(Path(os.path.join(awr_miner_sizing, file)))

    with caplog.at_level(logging.CRITICAL):
        result = imp.check_excluded_databases(df)

    # Assert returns True
    assert result

    # Assert the right message comes from the logger
    captured = caplog.text
    expected = (
        "ERROR : The databases.csv file contains 2 excluded databases!\n\n"
        " These must be fixed before upload the file into OCCA Web.\n"
        " Review the OCCA User Guide to figure out the exclusion reason and how to resolve it.\n"
    )

    assert expected in captured


@pytest.mark.parametrize("file", ["databases.csv"])
def test_check_excluded_databases_is_false(awr_miner_sizing, file):
    """
    Test the normal operation of check_excluded_databases() routine.

    Given: A file without databases excluded by analysis

    When: check_excluded_databases() is invoked

    Then: False is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
    """
    df = imp.read_csv_if_exists(Path(os.path.join(awr_miner_sizing, file)))
    result = imp.check_excluded_databases(df)

    # Assert returns False
    assert not result


@pytest.mark.parametrize("file", ["instances_excluded.csv"])
def test_check_excluded_instances(awr_miner_sizing, file, caplog):
    """
    Test the normal operation of check_excluded_instances() routine.

    Given: A file with some instances excluded with excluded reason

    When: check_excluded_instances() is invoked

    Then: True is returned and an error is thown to the logger

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
       caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """
    df = imp.read_csv_if_exists(Path(os.path.join(awr_miner_sizing, file)))

    with caplog.at_level(logging.CRITICAL):
        result = imp.check_excluded_instances(df)

    # Assert returns True
    assert result

    # Assert the right message comes from the logger
    captured = caplog.text
    expected = (
        "ERROR : The instances.csv file contains 2 excluded instances!\n\n"
        " These must be fixed before upload the file into OCCA Web.\n"
        " Review the OCCA User Guide to figure out the exclusion reason and how to resolve it.\n"
    )

    assert expected in captured


@pytest.mark.parametrize("file", ["instances.csv"])
def test_check_excluded_instances_is_false(awr_miner_sizing, file, caplog):
    """
    Test the normal operation of check_excluded_instances() routine.

    Given: A file without instances excluded by analysis

    When: check_excluded_instances() is invoked

    Then: False is returned

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
       file : str
            The builtin pytest.mark.parametrize decorator
       caplog : LogCaptureFixture[str]
            The pytest caplog fixture
    """
    df = imp.read_csv_if_exists(Path(os.path.join(awr_miner_sizing, file)))
    result = imp.check_excluded_instances(df)

    # Assert returns False
    assert not result


def test_main_with_allow_excluded_arg():
    """
    Test the normal operation of args in main() routine

    Given: --allow-excluded arg

    When: main() is invoked

    Then: ALLOW_EXCLUDED var is set to True
    """
    sys.argv = ["awr_miner_import.py"]
    sys.argv.append("--allow-excluded")

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        imp.main()

    assert imp.ALLOW_EXCLUDED


def test_main_with_not_upload_plots_arg():
    """
    Test the normal operation of args in main() routine

    Given: --not-upload-plots arg

    When: main() is invoked

    Then: PLOT_UPLOAD_HTML var is set to True
    """
    sys.argv = ["awr_miner_import.py"]
    sys.argv.append("--not-upload-plots")

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        imp.main()

    assert not imp.PLOT_UPLOAD_HTML


@pytest.mark.parametrize("file", ["OS-INFORMATION-AWR_MINER_VERSION-MISSING.csv"])
def test_get_awr_miner_version_from_os_info_block(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_awr_miner_version_from_os_info_block() routine.

    Given: A file with missing AWR Miner version from OS-INFORMATION block

    When: get_awr_miner_version_from_os_info_block() is invoked

    Then: pd.DataFrame with nan value for the awr_miner_version column

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
        databases_csv : Path
            The databases_csv fixture
        file : str
            The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    df = imp.get_awr_miner_version_from_os_info_block(databases_df_to_path_dict, file)

    # Set the Expected results
    expected_series = [
        ["db_oracle-database-00000_2210461847-7102-7307", np.nan],
    ]

    expected_columns = ["cdb", "awr_miner_version"]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert dataframes are the same
    assert_frame_equal(df, expected_df)


@pytest.mark.parametrize("file", ["OS-INFORMATION.csv"])
def test_get_awr_miner_version_from_os_info_block_dataframes_are_same(awr_miner_sizing, awr_miner_parsed, databases_csv, file):
    """
    Test the normal operation of get_awr_miner_version_from_os_info_block() routine.

    Given: A file with AWR_MINER_VER 21.6.1 in OS-INFORMATION block

    When: get_awr_miner_version_from_os_info_block() is invoked

    Then: pd.DataFrame with value 21.6.1 in the awr_miner_version column

    Parameters
    ----------
        awr_miner_sizing : Path
            The awr_miner_sizing fixture
        awr_miner_parsed : Path
            The awr_miner_parsed fixture
       databases_csv : Path
           The databases_csv fixture
       file : str
           The builtin pytest.mark.parametrize decorator
    """
    databases_df = imp.read_csv_if_exists(os.path.join(databases_csv))
    databases_df_to_path_dict = imp.get_path_to_db_files(awr_miner_parsed, databases_df)

    df = imp.get_awr_miner_version_from_os_info_block(databases_df_to_path_dict, file)

    # Set the Expected results
    expected_series = [
        ["db_oracle-database-00000_2210461847-7102-7307", "21.6.1"],
    ]

    expected_columns = ["cdb", "awr_miner_version"]

    expected_df = pd.DataFrame(expected_series, columns=expected_columns)

    # Assert dataframes are the same
    assert_frame_equal(df, expected_df)