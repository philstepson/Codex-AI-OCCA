import os
import re
import shutil
import sys
from pathlib import Path

import pytest
import requests
from rich import print

import occa.occa as occa

# Relative from the test code
testdata_path = (Path(__file__).parent.parent.parent / "testdata" / "awr" / "test_occa_version").resolve()


@pytest.mark.skip("Check VPN")
def is_on_vpn():
    """Ping a site only on Oracle VPN"""
    artifactory_url = "https://artifacthub-phx.oci.oraclecorp.com/"
    try:
        r = requests.get(artifactory_url, timeout=2)
    except requests.exceptions.ConnectionError:
        print("ConnectionError since not on VPN")
        return False
    print("Connection to Oracle found")
    return True


@pytest.mark.filterwarnings("ignore:Unverified HTTPS")
def test_artifactory_version(capsys):
    if is_on_vpn():
        # If I can ping artifacthub, keep testing, else quit
        data = occa.get_artifactory_version()
        captured = capsys.readouterr()

        if data is not None:
            assert data["occa-version"]
            assert data["occa-install-filename"]
            assert "Connection to Oracle found" in captured.out


def test_check_if_current_version(capsys):
    version_str = "1.5.5"
    occa.version.version = "1.5.5"
    assert occa.version.version

    # Set version and force to be latest
    server_version_data = {
        "occa-version": "1.0",
        "occa-install-filename": "dummyfile.tar.gz",
    }
    assert occa.check_if_current_version(server_version_data) == True
    captured = capsys.readouterr()

    expected = "You are at the latest version of the OCCA Desktop scripts\n"
    assert expected in captured.out

    # Set version and force new version on the server
    server_version_str = "2.0"
    server_version_data["occa-version"] = "2.0"
    assert occa.check_if_current_version(server_version_data) == False
    captured = capsys.readouterr()

    expected = "A newer OCCA Desktop"
    assert expected in captured.out

    assert occa.check_if_current_version(None) == True
    captured = capsys.readouterr()


@pytest.mark.filterwarnings("ignore:Unverified HTTPS")
def test_main_version(capsys):

    # Create supporting directory and change to it
    if not testdata_path.exists():
        os.mkdir(testdata_path)
    os.chdir(testdata_path)

    sys.argv = ["occa", "--version"]
    occa.main()
    captured = capsys.readouterr()

    files = [
        "occa_Pre_Flight.py",
        "occa_Create_Property_Files.py",
        "occa_Copy_Primary_DB_Name_To_DB_Properties.py",
        "occa_Copy_Primary_DB_Size_To_Properties.py",
        "occa_Copy_EMCC_Sizing_Parameters_To_DB_Properties.py",
        "occa_Add_Properties.py",
        "occa_Run_Metric_Analysis.py",
        "occa_Create_Import.py",
        "awr_miner_parse.py",
        "awr_miner_plot.py",
        "awr_miner_Run_Metric_Analysis.py",
        "awr_miner_import.py",
        "occa_Shared.py",
    ]

    assert "Getting version numbers of all scripts" in captured.out
    assert "OCCA Path is" in captured.out

    for f in files:
        fp = re.compile(rf"{f} version: (\d+)\.(\d+)(\.\d+)?")
        assert re.search(fp, captured.out)

    # Clean directories
    shutil.rmtree(testdata_path, ignore_errors=True)
