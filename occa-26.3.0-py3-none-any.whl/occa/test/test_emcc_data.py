import os
import pandas as pd

import pytest

from pathlib import Path

from utils import utils as u
from occa import occa

from pandas.testing import assert_frame_equal


class Args:
    params = ""
    checkmetrics = None


TESTDATA_PATH = (Path(__file__).parent.parent.parent / "testdata" / "em").resolve()


@pytest.mark.parametrize("folder", ["test_emcc_data"])
def test_emcc_data(folder):
    testdata = TESTDATA_PATH / folder
    u.clean_testdata(testdata, analysis="emcc")
    os.chdir(testdata)
    args = Args()
    # Create properties
    occa.create_properties(args)
    # Modify properties
    u.modify_properties_file(testdata / u.EMCC_OCCA_SIZING_PROPERTIES)
    # Add properties
    occa.add_properties(args)
    # Run data analysis
    occa.run_metric_analysis(args)
    # Generate JSON
    occa.emcc_import(args)
    #
    # Check the content of the CSV files generated during EMCC analysis
    actual_files = []
    expected_files = []
    # Files in 'occa_sizing_output/sizing'
    for filename in u.SIZING_FILES_LIST + u.SIZING_ADDITIONAL_FILES_LIST:
        actual_files.append(os.path.join(testdata, u.EMCC_OCCA_SIZING_OUTPUT, "sizing", filename))
        expected_files.append(os.path.join(testdata, "expected", "sizing", filename))

    for actual_file_path, expected_file_path in zip(actual_files, expected_files):
        actual_data = pd.read_csv(actual_file_path)
        expected_data = pd.read_csv(expected_file_path)

        # Compare DataFrame shapes
        assert actual_data.shape == expected_data.shape

        # Drop columns if the information varies according to runtime and execution time
        actual_data = actual_data.drop(columns=["platform", "create_dttm_utc", "cwd", "version"])
        expected_data = expected_data.drop(columns=["platform", "create_dttm_utc", "cwd", "version"])
        if 'shared_version' in actual_data.columns:
            actual_data = actual_data.drop(columns=["shared_version"])
            expected_data = expected_data.drop(columns=["shared_version"])

        # The 'Server List' column of 'databases.csv' and 'metric_presence_by_stage.csv' varies between executions
        if actual_file_path.endswith((u.SIZING_DBS, u.SIZING_METRICS_STAGE)):
            actual_data = actual_data.drop(columns=["Server List"])
            expected_data = expected_data.drop(columns=["Server List"])

        # Compare the content of the files
        assert_frame_equal(actual_data, expected_data)

    u.clean_testdata(testdata, analysis="emcc")
