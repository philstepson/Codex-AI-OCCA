import os
import shutil
import tempfile
from pathlib import Path
from unittest.mock import patch

import pandas as pd
import pytest

from occa import occa

testdata_awr_path = Path(__file__).parent.parent.parent / "testdata" / "awr"


expected_structure_for_parse = {
    '': {
        'dirs': ['awr_miner_out', 'awr_miner_parsed'],
        'files': []
    },
    'awr_miner_out': {
        'dirs': [],
        'files': [
            'awr-hist-1208226996-oracle-database-00002-7182-7383.out',
            'awr-hist-2210461847-oracle-database-00000-7102-7307.out',
            'awr-hist-2273923123-oracle-database-00001-6064-6267.out'
        ]
    },
    'awr_miner_parsed': {
        'dirs': [
            'db_oracle-database-00000_2210461847',
            'db_oracle-database-00001_2273923123',
            'db_oracle-database-00002_1208226996'
        ],
        'files': []
    },
    'expected_parsed_files': {
        'files': [
            'AVERAGE-ACTIVE-SESSIONS.csv',
            'AVERAGE-ACTIVE-SESSIONS.txt',
            'DATABASE-PARAMETERS2.csv',
            'DATABASE-PARAMETERS2.txt',
            'DATABASE-PARAMETERS.csv',
            'DATABASE-PARAMETERS.txt',
            'IO-OBJECT-TYPE.csv',
            'IO-OBJECT-TYPE.txt',
            'IOSTAT-BY-FUNCTION.csv',
            'IOSTAT-BY-FUNCTION.txt',
            'IO-WAIT-HISTOGRAM.csv',
            'IO-WAIT-HISTOGRAM.txt',
            'MAIN-METRICS.csv',
            'MAIN-METRICS.txt',
            'MEMORY.csv',
            'MEMORY-PGA-ADVICE.csv',
            'MEMORY-PGA-ADVICE.txt',
            'MEMORY-SGA-ADVICE.csv',
            'MEMORY-SGA-ADVICE.txt',
            'MEMORY.txt',
            'MODULE.csv',
            'MODULE.txt',
            'OS-INFORMATION2.csv',
            'OS-INFORMATION2.txt',
            'OS-INFORMATION.csv',
            'OS-INFORMATION.txt',
            'OSSTAT.csv',
            'OSSTAT.txt',
            'PATCH-HISTORY.csv',
            'PATCH-HISTORY.txt',
            'SEGMENT-IO.csv',
            'SEGMENT-IO.txt',
            'SIZE-ON-DISK.csv',
            'SIZE-ON-DISK.txt',
            'SNAP-HISTORY.csv',
            'SNAP-HISTORY.txt',
            'SNAP-HISTORY-TZ.csv',
            'SNAP-HISTORY-TZ.txt',
            'SQLNET-METRICS.csv',
            'SQLNET-METRICS.txt',
            'SYSSTAT.csv',
            'SYSSTAT.txt',
            'TOP-N-TIMED-EVENTS.csv',
            'TOP-N-TIMED-EVENTS.txt',
            'TOP-SQL-BY-SNAPID.csv',
            'TOP-SQL-BY-SNAPID.txt',
            'TOP-SQL-SUMMARY.csv',
            'TOP-SQL-SUMMARY.txt'
        ]
    },
}

expected_structure_for_plot = {
    '': {
        'dirs': ['awr_miner_occa', 'awr_miner_plots'],
        'files': []
    },
    'awr_miner_occa': {
        'dirs': ['properties'],
        'files': [
            'awr_miner_tz_choices.csv',
            'occa_composite.csv'
        ]
    },
    'awr_miner_occa/properties': {
        'dirs': [],
        'files': [
            'awr_properties_database_original.csv',
            'awr_tz_database_original.csv'
        ]
    },
    'awr_miner_plots': {
        'dirs': ['csv', 'html'],
        'files': [
            'awr_miner_plot.log'
        ]
    },
    'awr_miner_plots/csv': {
        'dirs': [],
        'files': [
            '00_instances.csv',
            '00_source_row_counts.csv',
            'AVERAGE-ACTIVE-SESSIONS.csv',
            'DATABASE-PARAMETERS2.csv',
            'DATABASE-PARAMETERS.csv',
            'IO-OBJECT-TYPE.csv',
            'IOSTAT-BY-FUNCTION.csv',
            'IO-WAIT-HISTOGRAM.csv',
            'MAIN-METRICS.csv',
            'MEMORY.csv',
            'MEMORY-PGA-ADVICE.csv',
            'MEMORY-SGA-ADVICE.csv',
            'MODULE.csv',
            'OS-INFORMATION2.csv',
            'OS-INFORMATION.csv',
            'OSSTAT.csv',
            'PATCH-HISTORY.csv',
            'SIZE-ON-DISK.csv',
            'SNAP-HISTORY.csv',
            'SNAP-HISTORY-TZ.csv',
            'SQLNET-METRICS.csv',
            'SYSSTAT.csv',
            'TOP-N-TIMED-EVENTS.csv',
            'TOP-SQL-BY-SNAPID.csv',
            'TOP-SQL-SUMMARY.csv'
        ]
    },
    'awr_miner_plots/html': {
        'dirs': [],
        'files': [
            'db_oracle-database-00000_2210461847-7102-7307.html',
            'db_oracle-database-00001_2273923123-6064-6267.html',
            'db_oracle-database-00002_1208226996-7182-7383.html'
        ]
    }
}




expected_columns_for_awr_miner_occa_dir = {
    'awr_miner_tz_choices.csv': ['MINUTES_DIFF_FROM_UTC', 'TZ'],
    'occa_composite.csv': ['WHICH_DB', 'DB_NAME', 'INSTANCE', 'end', 'SNAP_ID', 'dur_m', 'DB vCPU', 'DB Logons', 'os_cpu', 'DB SGA (MB)', 'DB PGA (MB)', 'DB Memory (MB)', 'read_iops', 'write_iops', 'DB IOPS', 'Allocated Storage (GB)', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'awr_properties_database_original.csv': ['Cohort', 'WHICH_DB', 'cdb', 'STOP', 'DB_NAME', 'Allocated Storage (GB).max', 'DB vCPU.max', 'DB PGA (MB).max', 'DB SGA (MB).max', 'DB Memory (MB).max', 'DB IOPS.max', 'DB Logons.max', 'Allocated Storage (GB).99%', 'DB vCPU.99%', 'DB PGA (MB).99%', 'DB SGA (MB).99%', 'DB Memory (MB).99%', 'DB IOPS.99%', 'DB Logons.99%', 'Allocated Storage (GB).95%', 'DB vCPU.95%', 'DB PGA (MB).95%', 'DB SGA (MB).95%', 'DB Memory (MB).95%', 'DB IOPS.95%', 'DB Logons.95%', 'Allocated Storage (GB).90%', 'DB vCPU.90%', 'DB PGA (MB).90%', 'DB SGA (MB).90%', 'DB Memory (MB).90%', 'DB IOPS.90%', 'DB Logons.90%', 'Allocated Storage (GB).80%', 'DB vCPU.80%', 'DB PGA (MB).80%', 'DB SGA (MB).80%', 'DB Memory (MB).80%', 'DB IOPS.80%', 'DB Logons.80%', 'Allocated Storage (GB).mean', 'DB vCPU.mean', 'DB PGA (MB).mean', 'DB SGA (MB).mean', 'DB Memory (MB).mean', 'DB IOPS.mean', 'DB Logons.mean', 'Allocated Storage (GB).min', 'DB vCPU.min', 'DB PGA (MB).min', 'DB SGA (MB).min', 'DB Memory (MB).min', 'DB IOPS.min', 'DB Logons.min', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'awr_tz_database_original.csv': ['WHICH_DB', 'TZ', 'MINUTES_DIFF_FROM_UTC_list', 'snaps_with_tz_offset_count', 'snaps_missing_tz_offset_count'],
}

expected_columns_for_awr_miner_plots  =  {
    #'00_host_effective_cpu.csv' : ['host', 'cpu_type', 'total_cpu_cores', 'logical_cpu_count', 'logical_cpu_count_effective', 'PLATFORM_NAME', 'WHICH_DB', 'cwd', 'platform', 'extract_dttm_utc', 'create_dttm_utc', 'source', 'shared_version', 'version'],
    #'00_host_effective_cpu_metrics.csv' : ['host_target_guid', 'host', 'cpu_type', 'total_cpu_cores', 'logical_cpu_count', 'ROLLUP_TIMESTAMP_UTC', 'AVERAGE', 'AVERAGE_logical_cpu_count', 'logical_cpu_count_effective', 'AVERAGE_logical_cpu_count_floor', 'effective_o_AVERAGE_pct', 'cwd', 'platform', 'extract_dttm_utc', 'create_dttm_utc', 'source', 'shared_version', 'version'],
    '00_instances.csv' : ['WHICH_DB', 'DB_NAME', 'INSTANCE', 'HOST', 'snap_id_start', 'snap_id_end', 'NUM_CPUS', 'NUM_CPU_CORES', 'NUM_CPU_SOCKETS', 'PGA', 'PHYSICAL_MEMORY_GB', 'PLATFORM_NAME', 'SGA', 'SGA + PGA', 'VERSION', 'cpu_count', 'cpu_min_count', 'cpu_type', 'rqsts_to_from_client', 'rqsts_to_from_client (daily avg)', 'sqlnet_GB_received_from_client', 'sqlnet_GB_received_from_client (daily avg)', 'sqlnet_GB_sent_to_client', 'sqlnet_GB_sent_to_client (daily avg)', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    '00_source_row_counts.csv' : ['WHICH_DB', 'DB_NAME', 'snap_id_start', 'snap_id_end', 'SOURCE', 'rows', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'AVERAGE-ACTIVE-SESSIONS.csv' : ['SNAP_ID', 'WAIT_CLASS', 'AVG_SESS', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    #'bad_db_vcpu.csv' : ['WHICH_DB', 'snap', 'dur_m', 'end', 'inst', 'cpu_type', 'cpu_per_s', 'cpu_count', 'cpu_per_s_o_cpu_count', 'os_cpu', 'os_cpu_max', 'h_cpu_per_s', 'cwd', 'platform', 'create_dttm_utc', 'source', 'version'],
    'DATABASE-PARAMETERS.csv' : ['PARAMETER_NAME', 'VALUE', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'IO-OBJECT-TYPE.csv' : ['SNAP_ID', 'OBJECT_TYPE', 'LOGICAL_READ_GB', 'PHYSICAL_READ_GB', 'PHYSICAL_WRITE_GB', 'GB_ADDED', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'IO-WAIT-HISTOGRAM.csv' : ['SNAP_ID', 'WAIT_CLASS', 'EVENT_NAME', 'WAIT_TIME_MILLI', 'WAIT_COUNT', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'IOSTAT-BY-FUNCTION.csv' : ['SNAP_ID', 'FUNCTION_NAME', 'SM_R_REQS', 'SM_W_REQS', 'LG_R_REQS', 'LG_W_REQS', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'MAIN-METRICS.csv' : ['snap', 'dur_m', 'end', 'inst', 'os_cpu', 'os_cpu_max', 'os_cpu_sd', 'db_wait_ratio', 'db_cpu_ratio', 'cpu_per_s', 'cpu_per_s_sd', 'h_cpu_per_s', 'h_cpu_per_s_sd', 'aas', 'aas_sd', 'aas_max', 'db_time', 'db_time_sd', 'sql_res_t_cs', 'bkgd_t_per_s', 'logons_s', 'logons_total', 'exec_s', 'hard_p_s', 'l_reads_s', 'commits_s', 'read_mb_s', 'read_mb_s_max', 'read_iops', 'read_iops_max', 'read_bks', 'read_bks_direct', 'write_mb_s', 'write_mb_s_max', 'write_iops', 'write_iops_max', 'write_bks', 'write_bks_direct', 'redo_mb_s', 'db_block_gets_s', 'db_block_changes_s', 'gc_cr_rec_s', 'gc_cu_rec_s', 'gc_cr_get_cs', 'gc_cu_get_cs', 'gc_bk_corrupted', 'gc_bk_lost', 'px_sess', 'se_sess', 's_blk_r_lat', 'cell_io_int_mb', 'cell_io_int_mb_max', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'MEMORY-PGA-ADVICE.csv' : ['SNAP_ID', 'INSTANCE_NUMBER', 'PGA_TARGET_GB', 'SIZE_FACTOR', 'ESTD_EXTRA_MB_RW', 'LEAD_SIZE_DIFF_MB', 'ESTD_PGA_CACHE_HIT_PERCENTAGE', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'MEMORY.csv' : ['SNAP_ID', 'INSTANCE_NUMBER', 'SGA', 'PGA', 'TOTAL', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'MODULE.csv' : ['MODULE', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'OS-INFORMATION.csv' : ['STAT_NAME', 'STAT_VALUE', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'OS-INFORMATION2.csv' : ['STAT_NAME', 'INSTANCE', 'STAT_VALUE', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'OSSTAT.csv' : ['SNAP_ID', 'INSTANCE_NUMBER', 'load', 'cpus', 'cores', 'sockets', 'mem_gb', 'mem_free_gb', 'idle', 'busy', 'user', 'sys', 'iowait', 'nice', 'cpu_wait', 'rsrc_mgr_wait', 'vm_in', 'vm_out', 'cpu_count', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'PATCH-HISTORY.csv' : ['RNUM', 'ACTION_TIME', 'ACTION', 'NAMESPACE', 'VERSION', 'ID', 'COMMENTS', 'BUNDLE_SERIES', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'SIZE-ON-DISK.csv' : ['SNAP_ID', 'SIZE_GB', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'SNAP-HISTORY-TZ.csv' : ['SNAP', 'END_TIME', 'INST', 'MINUTES_DIFF_FROM_UTC', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'SNAP-HISTORY.csv' : ['SNAP_MIN', 'SNAP_MAX', 'CNT', 'INST_COUNT', 'ERROR_COUNT', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'SQLNET-METRICS.csv' : ['snap', 'inst', 'rqsts_to_from_client', 'sqlnet_to_from_client', 'sqlnet_bytes_received_from_client', 'sqlnet_bytes_sent_to_client', 'sqlnet_bytes_vector_from_client', 'sqlnet_bytes_vector_to_client', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'SYSSTAT.csv' : ['SNAP_ID', 'cell_flash_hits', 'read_iops', 'read_mb', 'read_mb_opt', 'cell_int_mb', 'cell_int_ss_mb', 'ehcc_con_dmls', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'TOP-N-TIMED-EVENTS.csv' : ['SNAP_ID', 'WAIT_CLASS', 'EVENT_NAME', 'PCTDBT', 'TOTAL_TIME_S', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'TOP-SQL-BY-SNAPID.csv' : ['SNAP_ID', 'PARSING_SCHEMA_NAME', 'PLAN_HASH', 'MODULE', 'ACTION', 'SQL_ID', 'COMMAND_NAME', 'EXECS', 'BUFFER_GETS', 'ROWS_PROC', 'CPU_T_S', 'ELAP_S', 'READ_MB', 'IO_WAIT', 'ELAP_RANK', 'PLAN_CHANGE', 'PLANS', 'PHY_READ_GB', 'PX_SERVERS_EXECS', 'DIRECT_W_GB', 'IOWAIT_TIME', 'PIO', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version'],
    'TOP-SQL-SUMMARY.csv' : ['MODULE', 'ACTION', 'SQL_ID', 'COMMAND_NAME', 'PARSING_SCHEMA_NAME', 'EXEC_RANK', 'ELAP_RANK', 'LOG_READS_RANK', 'PHYS_READS_RANK', 'EXECS', 'ELAP', 'LOG_READS', 'PHY_READ_GB', 'PLAN_COUNT', 'PX_SERVERS_EXECS', 'snap_id_start', 'snap_id_end', 'WHICH_DB', 'cwd', 'platform', 'create_dttm_utc', 'version']
}




@pytest.fixture
def setup_and_teardown():
    temp_dir = tempfile.mkdtemp()

    awr_miner_out_dir = os.path.join(temp_dir,'awr_miner_out')
    os.makedirs(awr_miner_out_dir, exist_ok=True)

    # 🥷 steal some .out files to test the parse & plot
    files_to_copy = [
        'awr-hist-1208226996-oracle-database-00002-7182-7383.out',
        'awr-hist-2210461847-oracle-database-00000-7102-7307.out',
        'awr-hist-2273923123-oracle-database-00001-6064-6267.out'
    ]

    test_awr_end_to_end_dir = os.path.join(testdata_awr_path, 'test_awr_end_to_end','awr_miner_out')
    for file_name in files_to_copy:
        src_file = os.path.join(test_awr_end_to_end_dir, file_name)
        dest_file = os.path.join(awr_miner_out_dir,file_name)
        shutil.copy(src_file, dest_file)

    original_dir = os.getcwd()
    os.chdir(temp_dir)

    yield temp_dir

    os.chdir(original_dir)
    shutil.rmtree(temp_dir)


@pytest.fixture
def args():
    class Args:
        params = ""
        checkmetrics = None
    yield Args()


def verify_csv_columns(file_path, expected_columns):
    df = pd.read_csv(file_path)
    actual_columns = set(df.columns)
    expected_columns_set = set(expected_columns)
    assert actual_columns == expected_columns_set, f"Expected columns: {expected_columns_set}, insetad found {actual_columns} in {file_path}"


def verify_directory_structure(base_path, expected_structure, relative_path=""):
    current_path = os.path.join(base_path, relative_path)

    if relative_path in expected_structure:
        expected_dirs = expected_structure[relative_path].get('dirs', [])
        expected_files = expected_structure[relative_path].get('files', [])
        for expected_dir in expected_dirs:
            assert os.path.isdir(os.path.join(current_path, expected_dir)), f"Missing directory: {expected_dir} in {relative_path}"

        for expected_file in expected_files:
            assert os.path.isfile(os.path.join(current_path, expected_file)), f"Missing file: {expected_file} in {relative_path}"

        for expected_dir in expected_dirs:
            new_relative_path = os.path.join(relative_path, expected_dir)
            verify_directory_structure(base_path, expected_structure, new_relative_path)
    else:
        if 'expected_parsed_files' in expected_structure and Path(current_path).parent.name == 'awr_miner_parsed':
            #Expected parsed files for all subdirs in awr_miner_parsed subdirs -> files
            subdirs = [d for d in os.listdir(current_path) if os.path.isdir(os.path.join(current_path, d))]
            for subdir in subdirs:
                subdir_path = os.path.join(current_path, subdir)
                expected_files = expected_structure['expected_parsed_files'].get('files', [])
                for expected_file in expected_files:
                    assert os.path.isfile(os.path.join(subdir_path, expected_file)), f"Missing file: {expected_file} in {os.path.relpath(subdir_path, base_path)}"


def check_columns_for_awr_miner_plots_files(temp_dir):

    csv_columnns_to_check = [
       # ('awr_miner_plots/csv/00_host_effective_cpu.csv',expected_columns_for_awr_miner_plots['00_host_effective_cpu.csv']),
       # ('awr_miner_plots/csv/00_host_effective_cpu_metrics.csv',expected_columns_for_awr_miner_plots['00_host_effective_cpu_metrics.csv']),
        ('awr_miner_plots/csv/00_instances.csv',expected_columns_for_awr_miner_plots['00_instances.csv']),
        ('awr_miner_plots/csv/00_source_row_counts.csv',expected_columns_for_awr_miner_plots['00_source_row_counts.csv']),
        ('awr_miner_plots/csv/AVERAGE-ACTIVE-SESSIONS.csv',expected_columns_for_awr_miner_plots['AVERAGE-ACTIVE-SESSIONS.csv']),
        #('awr_miner_plots/csv/bad_db_vcpu.csv',expected_columns_for_awr_miner_plots['bad_db_vcpu.csv']),
        ('awr_miner_plots/csv/IO-OBJECT-TYPE.csv',expected_columns_for_awr_miner_plots['IO-OBJECT-TYPE.csv']),
        ('awr_miner_plots/csv/IO-WAIT-HISTOGRAM.csv',expected_columns_for_awr_miner_plots['IO-WAIT-HISTOGRAM.csv']),
        ('awr_miner_plots/csv/IOSTAT-BY-FUNCTION.csv',expected_columns_for_awr_miner_plots['IOSTAT-BY-FUNCTION.csv']),
        ('awr_miner_plots/csv/MAIN-METRICS.csv',expected_columns_for_awr_miner_plots['MAIN-METRICS.csv']),
        ('awr_miner_plots/csv/MEMORY-PGA-ADVICE.csv',expected_columns_for_awr_miner_plots['MEMORY-PGA-ADVICE.csv']),
        ('awr_miner_plots/csv/MEMORY.csv',expected_columns_for_awr_miner_plots['MEMORY.csv']),
        ('awr_miner_plots/csv/MODULE.csv',expected_columns_for_awr_miner_plots['MODULE.csv']),
        ('awr_miner_plots/csv/OS-INFORMATION.csv',expected_columns_for_awr_miner_plots['OS-INFORMATION.csv']),
        ('awr_miner_plots/csv/OS-INFORMATION2.csv',expected_columns_for_awr_miner_plots['OS-INFORMATION2.csv']),
        ('awr_miner_plots/csv/OSSTAT.csv',expected_columns_for_awr_miner_plots['OSSTAT.csv']),
        ('awr_miner_plots/csv/PATCH-HISTORY.csv',expected_columns_for_awr_miner_plots['PATCH-HISTORY.csv']),
        ('awr_miner_plots/csv/SIZE-ON-DISK.csv',expected_columns_for_awr_miner_plots['SIZE-ON-DISK.csv']),
        ('awr_miner_plots/csv/SNAP-HISTORY-TZ.csv',expected_columns_for_awr_miner_plots['SNAP-HISTORY-TZ.csv']),
        ('awr_miner_plots/csv/SNAP-HISTORY.csv',expected_columns_for_awr_miner_plots['SNAP-HISTORY.csv']),
        ('awr_miner_plots/csv/SQLNET-METRICS.csv',expected_columns_for_awr_miner_plots['SQLNET-METRICS.csv']),
        ('awr_miner_plots/csv/SYSSTAT.csv',expected_columns_for_awr_miner_plots['SYSSTAT.csv']),
        ('awr_miner_plots/csv/TOP-N-TIMED-EVENTS.csv',expected_columns_for_awr_miner_plots['TOP-N-TIMED-EVENTS.csv']),
        ('awr_miner_plots/csv/TOP-SQL-BY-SNAPID.csv',expected_columns_for_awr_miner_plots['TOP-SQL-BY-SNAPID.csv']),
        ('awr_miner_plots/csv/TOP-SQL-SUMMARY.csv',expected_columns_for_awr_miner_plots['TOP-SQL-SUMMARY.csv'])
    ]

    for file_path, columns in csv_columnns_to_check:
        verify_csv_columns(os.path.join(temp_dir, file_path), columns)
def check_columns_for_awr_miner_occa_files(temp_dir):

    csv_columnns_to_check = [
        ('awr_miner_occa/awr_miner_tz_choices.csv', expected_columns_for_awr_miner_occa_dir['awr_miner_tz_choices.csv']),
        ('awr_miner_occa/occa_composite.csv', expected_columns_for_awr_miner_occa_dir['occa_composite.csv']),
        ('awr_miner_occa/properties/awr_properties_database_original.csv', expected_columns_for_awr_miner_occa_dir['awr_properties_database_original.csv']),
        ('awr_miner_occa/properties/awr_tz_database_original.csv', expected_columns_for_awr_miner_occa_dir['awr_tz_database_original.csv']),
    ]

    for file_path, columns in csv_columnns_to_check:
        verify_csv_columns(os.path.join(temp_dir, file_path), columns)

def test_file_generation(setup_and_teardown,args):
    temp_dir = setup_and_teardown
    awr_miner_out_dir = os.path.join(temp_dir, 'awr_miner_out')

    #Parse and check content structure
    with patch.dict(os.environ, {"AWR_MINER_PATH":temp_dir}):

        occa.awr_parse(args)

        verify_directory_structure(temp_dir, expected_structure_for_parse)


        #Plot and check plot structure
        occa.awr_plot(args,reload=True)
        verify_directory_structure(temp_dir, expected_structure_for_plot)

        #Content of column of the files for occa and plots folders.
        check_columns_for_awr_miner_occa_files(temp_dir)
        check_columns_for_awr_miner_plots_files(temp_dir)

