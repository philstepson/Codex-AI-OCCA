import os
import tempfile
import pytest
from pathlib import Path

import pandas as pd

import occa.occa as occa
import occa.occa_storage as occa_storage

# oracledb docs:  https://python-oracledb.readthedocs.io/en/latest/index.html

# Relative from the test code
testdata_path = (
    Path(__file__).parent.parent.parent / "testdata" / "em" / "Sample1c-NEW"
).resolve()


class Args:
    params = ""
    checkmetrics = ""


def test_mkdir():
    with tempfile.TemporaryDirectory() as tempdir:
        testfolder = Path(tempdir) / "testfolder"
        occa_storage.mkdir(str(testfolder))
        assert testfolder.exists()


@pytest.mark.skip("Not ready for prod")
def test_load_save():
    with tempfile.TemporaryDirectory() as tempdir:
        testfolder = Path(tempdir) / "testfolder"
        testdata = testfolder / "testdata.csv"
        occa_storage.mkdir(str(testfolder))

        # Grab some test data
        df = pd.read_csv(
            testdata_path / "emcc_sizing_extracts" / "emcc_sizing_structure_db.csv"
        )

        occa_storage.to_csv(df, str(testdata))
        assert testdata.exists()

        loaded_df = occa_storage.read_csv(str(testdata))
        assert loaded_df.equals(df)


@pytest.mark.skip("Not ready for prod")
def test_convert_path():
    occa_storage.init_new_storage()
    # This is what a path in the original scripts tend to look like
    example_path = Path("./emcc_sizing_extracts/emcc_sizing_structure_db.csv")
    assert "storage" not in str(example_path)
    new_path = occa_storage.convert_to_new_storage(example_path)
    assert "storage" in str(new_path)


@pytest.mark.skip("Not ready for prod")
def test_occa_create_property_files():
    """
    Create_Property_Files is the first script to use new storage class
    Call Create_Property_Files from occa wrapper
    """

    os.chdir(testdata_path)
    occa.create_properties(Args())

    assert Path(
        testdata_path / "occa_sizing_properties" / "properties_database_original.csv"
    ).exists()


@pytest.mark.skip("Not ready for prod")
def test_occa_add_property_files():
    os.chdir(testdata_path)
    occa.create_properties(Args())

    # Rename files from original, as required by add_properties
    properties_dir = Path(testdata_path / "occa_sizing_properties")
    rename_list = {
        "properties_database_original.csv": "properties_database.csv",
        "properties_instance_original.csv": "properties_instance.csv",
        "properties_server_original.csv": "properties_server.csv",
    }
    for from_file in rename_list:
        (properties_dir / from_file).rename(properties_dir / rename_list[from_file])

    occa.add_properties(Args())


@pytest.mark.skip("Long test")
def test_occa_run_analysis():
    os.chdir(testdata_path)
    occa.create_properties(Args())

    assert Path(
        testdata_path / "occa_sizing_properties" / "properties_database.csv"
    ).exists()
    occa.run_metric_analysis(Args())


@pytest.mark.skip("Not ready for prod")
def test_init_db_connection():
    occa_storage.init_database_connection()

    # Connect to database and do something
    cursor = occa_storage.connection.cursor()
    cursor.execute("select count(*) from opportunities")
    row = cursor.fetchone()
    assert row[0] > 100


@pytest.mark.skip("Not ready for prod")
def test_write_csv_to_db():
    occa_storage.init_database_connection()

    # Grab some test data
    filepath = testdata_path / "emcc_sizing_extracts" / "emcc_sizing_structure_db.csv"
    df = pd.read_csv(filepath)

    occa_storage.to_csv(df, str(filepath))


@pytest.mark.skip("Not ready for prod")
def test_read_csv_from_db():
    occa_storage.init_database_connection()

    # Grab some test data
    filepath = testdata_path / "emcc_sizing_extracts" / "emcc_sizing_structure_db.csv"
    df = pd.read_csv(filepath)

    new_df = occa_storage.read_csv(str(filepath))

    assert new_df.equals(df)


@pytest.mark.skip("Long test")
def test_upload_extracts():
    occa_storage.init_database_connection()
    extracts_dir = testdata_path / "emcc_sizing_extracts"
    occa_storage.upload_extracts(str(extracts_dir))



@pytest.mark.skip("Table does not exist")
def test_upload_properties():
    occa_storage.init_database_connection()
    occa_storage.upload_properties(testdata_path)
