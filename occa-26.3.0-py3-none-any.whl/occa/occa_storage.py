import getpass
import os
from io import StringIO
from pathlib import Path

import oracledb
import pandas as pd

USE_COMMON_STORAGE = True

# returns strings or bytes instead of a locator
oracledb.defaults.fetch_lobs = False

# Setup paths to use, defaults to unchanged
original_working_dir = Path.cwd().resolve()
storage_working_dir = original_working_dir
connect_string = ""
if "CONNECT_OCCAPROD" in os.environ:
    connect_string = os.environ["CONNECT_OCCAPROD"]
connection: oracledb.Connection = None

user = getpass.getuser()


def init_database_connection():
    global connection
    if not connection:
        try:
            connection = oracledb.connect(connect_string)
        except oracledb.OperationalError as e:
            # Cannot connect
            print(f"Oracle exception: {e}")
            raise


def init_new_storage(storage_dir=Path("/tmp/occastorage")):
    """
    Update the storage directory if needed.  Will be called by web service.
    """
    global storage_working_dir

    # TODO: What should the location be?
    # storage_working_dir = Path(__file__).parent.resolve() / "storage"
    storage_working_dir = storage_dir.resolve()
    storage_working_dir.mkdir(exist_ok=True)


def convert_to_new_storage(filename: Path) -> Path:
    filepath = filename.resolve()
    filepath_str = str(filepath)
    new_filepath = filepath_str.replace(
        str(original_working_dir), str(storage_working_dir)
    )
    return Path(new_filepath)


def mkdir(filename: str, exist_ok=True) -> None:
    """
    Replaces os.makedirs
    """
    return os.makedirs(filename, exist_ok=exist_ok)


def read_csv(filename: str) -> pd.DataFrame:
    """
    Replaces to pd.read_csv(filename)
    """

    if not connection:
        df = pd.read_csv(filename)
    else:
        local_filename = str(Path(filename).resolve())
        cursor = connection.cursor()
        cursor.execute(
            """
            select CSV_DATA from ANALYSIS_FILES
            where USERNAME = :1 and LOCAL_PATH = :2
            order by CREATED_ON desc
            """,
            [user, local_filename],
        )
        row = cursor.fetchone()
        csv_data = StringIO(row[0])
        df = pd.read_csv(csv_data)

    return df


def to_csv(df: pd.DataFrame, filename: str, index=False):
    """
    Replaces DataFrame.to_csv(filename)
    """
    if not connection:
        df.to_csv(filename, index=index)
    else:
        csv_data = df.to_csv(index=index)
        cursor = connection.cursor()
        # Normalize the filenames to make sure they are consistent across runs
        local_filename = str(Path(filename).resolve())
        local_parent = str(Path(local_filename).resolve().parent)
        cursor.execute(
            """
            insert into ANALYSIS_FILES (USERNAME, LOCAL_PATH, LOCAL_PARENT, CSV_DATA)
            values (:1, :2, :3, :4)
            """,
            [user, local_filename, local_parent, csv_data],
        )
        connection.commit()


def upload_extracts(extracts_directory: str, file_limit=0, hourly=True):
    extracts_path = Path(extracts_directory).resolve()
    init_database_connection()

    files_uploaded = 0
    for csv_filename in extracts_path.glob("*.csv"):
        # Skip hourly files if requested
        if not hourly and "hourly" in csv_filename:
            continue
        df = pd.read_csv(csv_filename)
        print(f"Uploading {str(csv_filename)}")
        to_csv(df, str(csv_filename))
        files_uploaded += 1
        if file_limit > 0 and files_uploaded >= file_limit:
            break

    print(f"Files uploaded: {files_uploaded}")


def upload_properties(base_directory: Path):
    properties_path = base_directory / "occa_sizing_properties"
    init_database_connection()

    database_properties = pd.read_csv(str(properties_path / "properties_database.csv"))
    database_properties = database_properties.fillna("")

    cursor = connection.cursor()
    # Normalize the filenames to make sure they are consistent across runs

    for index, row in database_properties.iterrows():
        data_values = [
            row["Cohort"],
            user,
            row["Database Name"],
            row["cdb_status"],
            row["cdb_standby_type"],
            row["target_guid"],
            str(properties_path),
        ]
        print(data_values)
        cursor.execute(
            """insert into PROPERTIES_DATABASE (COHORT, USERNAME, DATABASE_NAME, CDB_STATUS, CDB_STANDBY, TARGET_GUID, BASE_DIRECTORY)
        values (:1, :2, :3, :4, :5, :6, :7)""",
            data_values,
        )
    connection.commit()
