#!/usr/bin/local/python3

# Zip up all data files into a single artifact.  This makes it easier for the user
# to send debug information to the developers.

import os
import zipfile
import shutil
import logging
from pathlib import Path
from datetime import date

logger = logging.getLogger(__name__)


def main():
    folders_to_add = [
        "./emcc_sizing_extracts",
        "./occa_sizing_extracts",
        "./occa_sizing_properties",
        "./occa_sizing_output",
        "./awr_miner_out",
        "./awr_miner_parsed",
        "./awr_miner_plots",
        "./awr_miner_occa",
        "./occa",
    ]
    # Copy occa files from net-topo repo to main repo
    parent_name = str(Path(".").resolve().name)
    print(Path("."))
    print(parent_name)
    date_code = date.today().isoformat()
    zip_filename = Path(".") / f"occa-sizing-artifacts-{parent_name}-{date_code}.zip"

    Path(zip_filename).unlink(missing_ok=True)
    print(f"Writing archives to {zip_filename}")
    with zipfile.ZipFile(
        Path(".") / zip_filename, "w", compression=zipfile.ZIP_DEFLATED
    ) as archive:
        for folder in folders_to_add:
            print(f"  Zipping {folder}...")
            for dirname, subdirs, files in os.walk(folder):
                archive.write(dirname)
                for filename in files:
                    archive.write(os.path.join(dirname, filename))

    print(f"Archive file {zip_filename} written")


if __name__ == "__main__":
    main()
