import re

import pandas as pd
from pathlib import Path
from constants.Paths import FilePaths as fp
def has_no_em_output_excluded_dbs(base_path : Path):
    db_output_df = pd.read_csv(base_path/fp.EMCC_OUTPUT_DATABASE)
    instance_output_df = pd.read_csv(base_path/fp.EMCC_OUTPUT_INSTANCE)

    has_db_excluded = db_output_df.index[db_output_df.excluded == 'excluded'].tolist()
    has_ins_excluded = instance_output_df.index[instance_output_df.excluded == 'excluded'].tolist()
    return has_db_excluded or has_ins_excluded

def contains(column: pd.Series, characters: str) -> bool:
    """
    Check if text_to_search exists in a DataFrame column.

    Args:
        column: Pandas Series [column of a dataframe]
        characters: str

    Returns:
        bool: True if the text_to_search exists, False otherwise.
    """
    pattern = '[' + re.escape(characters) + ']'
    found = column.str.contains(pattern, regex=True, na=False).any()
    return found



# * * * * * * * * * * *  EM SECTION  * * * * * * * * * * *

def remove_duplicate_dates_from_EM_df(df):
    """
    Removes duplicate dates from a DataFrame based on the 'ROLLUP_TIMESTAMP_UTC' column,
    grabbing only the date and grabbing the first ocurrence

    ----------
    Parameters:
    df: pandas.DataFrame
    Returns:
    -------
    pandas.DataFrame
        A DataFrame with duplicate dates removed, keeping only the first occurrence.
    """

    temp_column = 'ROLLUP_DATE'
    df = df.sort_values(by=['TARGET_GUID','metric','ROLLUP_TIMESTAMP_UTC'])
    df[temp_column] = df["ROLLUP_TIMESTAMP_UTC"].dt.date #create a new column  avoid - unhashable type series
    # Get the boolean serie for first ocurrence by substed - target - metric - date
    serie_first_ocurrence = df.duplicated(subset=['TARGET_GUID','metric',temp_column],keep='first')
    df = df.drop(columns=[temp_column])
    #invert the serie to get the rows that points to True
    return df.loc[~serie_first_ocurrence].reset_index(drop=True)


def prepare_em_df(df):
    """
    Prepares EM DataFrame by stripping and creating 'metric' column
    this action is repeated twice on run metric analysis and needed for testing
    -> 'test_filter_duplicated_with_em_data'


    ----------
    Parameters:
        df: pandas.DataFrame
    Returns:
    -------
    pandas.DataFrame
        Same DF with extra column and stripped columns
    """
    df.columns = [c.strip() for c in df.columns]
    df['metric'] = df['METRIC_NAME'] + '.' + df['METRIC_COLUMN']
    return df


def has_incorrect_values(df : pd.DataFrame , columns : list) -> pd.DataFrame:

    """

    Parameters
    ----------
    df : pd.DataFrame object to identify if there's any 0s values on the given columns
    columns :columns to search

    Returns
    -------
    returns a pandas DataFrame Object.
    """

    #First any is to look in columns values and second any is for return
    return (df[columns].apply(pd.to_numeric, errors='coerce') < 0).any().any()


