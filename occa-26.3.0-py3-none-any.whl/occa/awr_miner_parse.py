import argparse
import datetime
import fnmatch
import os
import platform
import re
import shutil
import sys
from pathlib import Path
from typing import List
from typing import Optional
from version import version, __version__

import numpy as np
import pandas as pd

import occa_storage
from cohort_folder_mapper import execute_cohort_folder_workflow
from file_manager.FileSystemHandler import DirectoryHandler as DH
from occa_Shared import raise_error_when_run_from_api

awr_sections = [
    "AVERAGE-ACTIVE-SESSIONS",
    "DATABASE-PARAMETERS",
    "IO-OBJECT-TYPE",
    "IO-WAIT-HISTOGRAM",
    "IOSTAT-BY-FUNCTION",
    "MAIN-METRICS",
    "PDB-METRICS",
    "MEMORY-PGA-ADVICE",
    "MEMORY-SGA-ADVICE",
    "MEMORY",
    "MODULE",
    "OS-INFORMATION",
    "OS-INFORMATION2",
    "OSSTAT",
    "PATCH-HISTORY",
    "SEGMENT-IO",
    "SIZE-ON-DISK",
    "SNAP-HISTORY-TZ",
    "SNAP-HISTORY",
    "SQLNET-METRICS",
    "SYSSTAT",
    "TOP-N-TIMED-EVENTS",
    "TOP-SQL-BY-SNAPID",
    "TOP-SQL-SUMMARY",
]

awr_mandatory_sections = [
    "MAIN-METRICS",
    "MEMORY",
    "OS-INFORMATION",
    "OS-INFORMATION2",
    "SIZE-ON-DISK",
    "DATABASE-PARAMETERS",
]

# Flag to indicate the removal of the parsed txt files created during the parsing process
DELETE_PARSED_TXT_FILES = False

# Set AWR Miner MIN supported version
AWR_MINER_MIN_SUPPORTED_VERSION = "21.6.1"

# Set mode for BAR collections (Error or Warning)
BAR_MINER_WARNING_MODE = True
BAR_MINER_ERROR_MODE = False

# Set AWR Miner file name pattern
AWR_MINER_FILE_NAME_PATTERN = re.compile(r"awr-hist-(\d+)-(.*)-(\d+)-(\d+).out")

badFiles, badParses, rolloverSnaps, rowsCorrupt = [], [], [], []
warning_files = []
warning_lg = []
AWR_MINER_PATH, AWR_MINER_PARSED, AWR_MINER_OUT = "", "", ""
filenameTxt, filenameCsv, filenameRollover, lastSuccess = "", "", "", ""
(
    AWR_MINER_VERSION_DEPRECATED,
    ALLOW_OLD_MINER,
    BAR_COLLECTION_DETECTED,
    BAR_REMOVE_FROM_MANDATORY_SECTIONS,
) = (False, False, False, False)
AWR_MINER_URL = "https://artifacthub-phx.oci.oraclecorp.com/artifactory/maa-plat-st-generic/occa/AWR-Miner.zip"


def lg(t):
    """Print text to stdout"""
    print(t)


def get_awr_miner_path():
    """
    Return the execution path either from environment or current working directory.

    Returns
    ----------
         Path : Path
            The contents of AWR_MINER_PATH if is set on the environment or
            the path to the current working directory
    """
    if "AWR_MINER_PATH" in os.environ:
        awr_miner_path = os.environ["AWR_MINER_PATH"]
    else:
        awr_miner_path = os.getcwd()

    return Path(awr_miner_path).resolve()


def get_awr_miner_parsed_path(awr_miner_path: Path) -> Path:
    """
    Return the path to the awr_miner_parsed directory.

    Parameters
    ----------
          awr_miner_path : str
              The path to awr_miner_path

    Returns
    ----------
         Path : Path
            The path to the awr_miner_parsed directory

    """
    if Path.is_dir(awr_miner_path):
        return Path(os.path.join(awr_miner_path, "awr_miner_parsed")).resolve()


def get_awr_miner_out_path(awr_miner_out: Path) -> Path:
    """
    Return the path to the awr_miner_out directory.

    Parameters
    ----------
          awr_miner_out : str
              The path to awr_miner_out

    Returns
    ----------
         Path : Path
            The path to the awr_miner_out directory

    """
    if Path.is_dir(awr_miner_out):
        return Path(os.path.join(awr_miner_out, "awr_miner_out")).resolve()


def clean_numeric_delimiters(x):
    """If the value is a string, then remove currency symbol and delimiters
    otherwise, the value is numeric and can be converted
    """
    if isinstance(x, str):
        return x.replace(",", "@@").replace(".", ",").replace("@@", ".")
    else:
        return x


def determine_numeric_delimiters(lines) -> bool:
    """
    Check values in files to determine the numeric delimiter.

    Parameters
    ----------
          lines : list[str]
              The lines of the AWR Miner file

    Returns
    ----------
         bool : bool
            True if some of the columns in BEGIN-MEMORY or MAIN-METRICS blocks
            contains comma as decimal separator , False otherwise.
    """

    # Find a couple of sections which are most likely to have decimal separators, and check what they use
    # Find this block:
    # ~~BEGIN-MEMORY~~
    #    SNAP_ID INSTANCE_NUMBER        SGA        PGA      TOTAL
    # ---------- --------------- ---------- ---------- ----------
    #     220162               1        3,7         ,8        4,5
    #     220163               1        3,7         ,8        4,5

    columns_to_check = (2, 3, 4)
    block_line = 0
    for line in lines:
        if "~~BEGIN-MEMORY~~" in line:
            block_line = 1
        elif block_line > 0:
            block_line = block_line + 1

        # Stop reading when we have finished the block
        if "~~END-MEMORY~~" in line:
            break

        if block_line >= 5:
            # Get the third column
            for column in columns_to_check:
                try:
                    sga_value = line.split()[column]
                    if "," in sga_value:
                        lg(
                            f"        Info : Found comma as numeric separator in Memory Value {column} '{sga_value}'."
                            + " Enabling adjustment of numeric separators..."
                        )
                        return True
                except IndexError as e:
                    # There must be blank columns to get not all parsed columns
                    # This happens also if the data block doesn't exist
                    pass

    # Backup, check BEGIN-MAIN-METRICS, CPU metrics
    columns_to_check = (9, 10, 11)
    block_line = 0
    for line in lines:
        if "~~BEGIN-MAIN-METRICS~~" in line:
            block_line = 1
        elif block_line > 0:
            block_line = block_line + 1

        # Stop reading when we have finished the block
        if "~~END-MAIN-METRICS~~" in line:
            break

        if block_line >= 5:
            for column in columns_to_check:
                try:
                    column_value = line.split()[column]
                    if "," in column_value:
                        lg(
                            f"        Info : Found comma as numeric separator in Main Metrics {column} '{column_value}'."
                            + " Enabling adjustment of numeric separators..."
                        )
                        return True
                except IndexError as e:
                    # There must be blank columns to get not all parsed columns
                    # This happens also if the data block doesn't exist
                    pass

    # If we haven't detected don't change anything
    return False


def is_valid_file_name(fname) -> bool:
    """
    Check the file name passed matches the expected pattern.

    Parameters
    ----------
          fname : str
              The file name to check the pattern against

    Returns
    ----------
         bool : bool
            True if the filename matches the pattern, False otherwise
    """
    if re.match(AWR_MINER_FILE_NAME_PATTERN, fname):
        return True
    else:
        badFiles.append(
            {
                "minerFile": fname,
                "error": "file name does not match the naming convention, no match on pattern",
                "expected": "awr-hist-<DBID>-<DBNAME>-<MIN_SNAP_ID>-<MAX_SNAP_ID>.out",
            }
        )
        return False


def get_miner_file_name_pieces(fname) -> dict:
    """
    Get the values from the file name.

    Parameters
    ----------
          fname : str
              The file name to extract the values from

    Returns
    ----------
         dict : dict
              Dict containing the match groups of the regex applied
    """
    filepieces = {}
    match_groups = re.search(AWR_MINER_FILE_NAME_PATTERN, fname)

    # Get the pieces
    if match_groups:
        filepieces["dbid"] = match_groups.group(1)
        filepieces["dbname"] = match_groups.group(2)
        filepieces["snap_id_start"] = match_groups.group(3)
        filepieces["snap_id_end"] = match_groups.group(4)

    return filepieces


def get_versions_from_os_information_block(awr_miner_out, minerFilename) -> List[str]:
    """
    Extract Database Version and AWR version from OS-INFORMATION block.

    Parameters
    ----------
        awr_miner_out : Path
            The path to awr_miner_out directory
        minerFilename : str
            The name of the AWR Miner file

    Returns
    ----------
         version_list : list[str]
              List of strings in the following format  ["19.0.0.0.0", "19", "21.6.1"] where
              db_version = "19.0.0.0.0" , db_major_version = "19" , awr_miner_version = "21.6.1"
    """
    version_list = []

    minerFilenamePath = os.path.join(awr_miner_out, minerFilename)
    try:
        f = open(minerFilenamePath)
        lines = f.readlines()
    except:
        f = open(minerFilenamePath, encoding="ISO-8859-1")
        lines = f.readlines()

    # Get the lines containing VERSION information from BEGIN-OS-INFORMATION block
    version_line = ""
    awr_miner_version_line = ""
    for line in lines:
        if "VERSION" in line:
            version_line = line
        elif "AWR_MINER_VER" in line:
            awr_miner_version_line = line
        elif (
            len(version_line) > 0
            and len(awr_miner_version_line) > 0
            or "~~END-OS-INFORMATION2~~" in line
        ):
            break

    # Get the Database version from VERSION line
    if len(version_line) > 0:
        try:
            version_line = " ".join(version_line.split())
            full_db_version = version_line.split(" ")[-1]
            major_db_version = full_db_version.split(".")[0]
            version_list.append(full_db_version)
            version_list.append(major_db_version)
        except IndexError:
            # If there's an odd parsing issue, move on
            pass

    # Ger AWR Miner version from AWR_MINER_VER line
    if len(awr_miner_version_line) > 0:
        try:
            awr_miner_version_line = " ".join(awr_miner_version_line.split())
            awr_miner_version = awr_miner_version_line.split(" ")[1]
            version_list.append(awr_miner_version)
        except IndexError:
            # If there's an odd parsing issue, move on
            pass

    return version_list


def are_ora_errors_in_file(awr_miner_out, minerFilename) -> bool:
    """
    Check for 'ORA-' error in the collection file.

    Parameters
    ----------
        awr_miner_out : Path
            The path to awr_miner_out directory
        minerFilename : str
            The name of the AWR Miner file

    Returns
    ----------
         bool : bool
            True if there are errors in a mandatory section, False otherwise

    """
    ora_error_pattern = re.compile(r"ORA-(\d+):")
    are_ora_errors = False
    are_ora_errors_in_mandatory_section = False

    minerFilenamePath = os.path.join(awr_miner_out, minerFilename)
    try:
        f = open(minerFilenamePath)
        lines = f.readlines()
    except:
        f = open(minerFilenamePath, encoding="ISO-8859-1")
        lines = f.readlines()

    # Check for ORA- string in the lines
    section_name = ""
    for line in lines:

        # Detect the section
        if line.startswith("------------------------- BEGIN"):
            section_line_lst = line.split()
            if len(section_line_lst) >= 2:
                section_name = section_line_lst[1][6:]
                continue

        match_groups = re.search(ora_error_pattern, line)
        if match_groups:
            if section_name in awr_mandatory_sections:
                badFiles.append(
                    {
                        "minerFile": minerFilename,
                        "error": "ORA- errors detected in the collection",
                        "reason": f"The collection has the following errors: "
                        + match_groups[0].replace(":", ""),
                    }
                )
                are_ora_errors_in_mandatory_section = True
            else:
                badParses.append(
                    {
                        "minerFile": minerFilename,
                        "section": section_name,
                        "error": "ORA- errors detected in the collection",
                        "reason": f"The collection has the following errors: "
                        + match_groups[0].replace(":", ""),
                    }
                )

        # Only return true if the error is present in a mandatory section
        if are_ora_errors_in_mandatory_section:
            are_ora_errors = True

    return are_ora_errors


def check_awr_miner_path_exists(d) -> bool:
    """
    Check for the existance of the directory passed.

    Parameters
    ----------
        d : Path
            The path to check if is a directory

    Returns
    ----------
         bool : bool
            True if the Path is a directory, False otherwise

    """
    d = Path(os.path.join(d, "awr_miner_out"))
    if Path.is_dir(d):
        return True
    else:
        lg(f"\n\nERROR : Directory {str(d)} does not exist; cannot continue")
        return False


def check_awr_miner_files_exist(d) -> List[str]:
    """
    Check if files named "awr-hist*.out" exist in the directory.
    Parameters
    ----------
        d : Path
            The path to search for the expected files

    Returns
    ----------
         files : list[str]
            The list of files matching the criteria

    """
    filelist = []
    d = Path(os.path.join(d, "awr_miner_out"))
    error_msg = f"No files found in {str(d)}. Expecting awr-hist*.out files; cannot continue"

    try:
        # Changed to work with cohort structure and normal behaviour
        # I'm grabbing all of them as a Path validations are made by
        # parent+filename
        filelist = np.sort([f for f in d.rglob("awr-hist*.out")])
    except FileNotFoundError as e:
        lg(
            f"\n\nERROR : {error_msg}"
        )
        filelist = []

    if len(filelist) == 0:
        lg(
            f"\n\nERROR : {error_msg}"
        )
        raise_error_when_run_from_api('AWR: ', f"{error_msg}")

        filelist = []

    return filelist


def print_bar_deprecation_message(awr_miner_parsed, deletefiles=False):
    """
    Print to stdout the BAR deprecation message.

    Parameters
    ----------
         awr_miner_parsed :
            The path to the directory with parsed files
         deletefiles : bool
            Flag to indicate the deletion of files
    """
    if BAR_COLLECTION_DETECTED:
        if BAR_MINER_WARNING_MODE:
            lg("=" * 136)
            lg(
                "WARNING: There are files in this collection extracted with BAR Miner.\n\n"
                f"ONLY files obtained with OCCA AWR Miner {AWR_MINER_MIN_SUPPORTED_VERSION} "
                f"and later will be supported in future releases of OCCA.\n"
                f"Download the latest OCCA AWR Miner from : {AWR_MINER_URL}"
            )
            lg("=" * 136)
        elif BAR_MINER_ERROR_MODE:
            lg("=" * 136)
            message_error = (
                "There are files in this collection extracted with BAR Miner."
            )
            lg(
                f"ERROR: {message_error}\n\n"
                f"ONLY files obtained with OCCA AWR Miner {AWR_MINER_MIN_SUPPORTED_VERSION} "
                f"and later are supported by OCCA.\n"
                f"Download the latest OCCA AWR Miner from : {AWR_MINER_URL}"
            )
            if deletefiles:
                shutil.rmtree(awr_miner_parsed, ignore_errors=True)
            lg("=" * 136)
            raise_error_when_run_from_api('AWR: ', message_error)


def print_deprecation_message(awr_miner_parsed, deletefiles=True):
    """
    Print to stdout the AWR Miner deprecation message.

    Parameters
    ----------
         awr_miner_parsed :
            The path to the directory with parsed files
         deletefiles : bool
            Flag to indicate the deletion of files
    """
    if not ALLOW_OLD_MINER and AWR_MINER_VERSION_DEPRECATED:
        lg("=" * 136)
        message_error = "There are files in this collection extracted with old version of OCCA AWR Miner."
        lg(
            f"ERROR: {message_error}\n\n"
            f"ONLY files obtained with OCCA AWR Miner {AWR_MINER_MIN_SUPPORTED_VERSION} "
            f"and later are supported by OCCA.\n"
            f"Download the latest OCCA AWR Miner from : {AWR_MINER_URL}"
        )
        lg("=" * 136)
        raise_error_when_run_from_api('AWR: ', message_error)
        if deletefiles:
            shutil.rmtree(awr_miner_parsed, ignore_errors=True)


def get_min_snapshot_id_from_snap_history_tz_block(
    awr_miner_out: Path, minerFilename: str, snap_id_start=0
) -> int:
    """
    Extract the value from SNAP column for the first row seen in SNAP-HISTORY-TZ block.

    Parameters
    ----------
        awr_miner_out : Path
            The path to awr_miner_out directory
        minerFilename : str
            The name of the AWR Miner file
        snap_id_start : int
            The value of snap_id_start to make it valid if "COLUMNNOTINTHISVERSION" occurs.

    Returns
    ----------
         int : int
              The first SNAP ID value from the block
    """
    min_snap = ""
    snap_info_line = ""

    minerFilenamePath = os.path.join(awr_miner_out, minerFilename)
    try:
        f = open(minerFilenamePath)
        lines = f.readlines()
    except:
        f = open(minerFilenamePath, encoding="ISO-8859-1")
        lines = f.readlines()

    # Get the lines containing snapshot information from  SNAP-HISTORY block
    start = False
    for line in lines:
        line = line.upper().strip(
            "\n"
        )  # Error found for "Snap" ans "snap" line fix-> upper
        if len(line) == 0:
            continue
        if "~~BEGIN-SNAP-HISTORY-TZ~~" in line:
            start = True
            continue
        elif start and ("SNAP" in line.upper()):
            continue
        elif start and ("----------" in line):
            continue
        elif start and "~~END-SNAP-HISTORY~~" in line:
            break
        elif not start:
            continue
        else:
            if "COLUMNNOTINTHISVERSION" in line:
                badParses.append(
                    {
                        "minerFile": minerFilename,
                        "section": "SNAP-HISTORY-TZ",
                        "error": "ORA- errors detected in the collection",
                        "reason": f"COLUMNNOTINTHISVERSION Error found in the section, assigned the snap_id_start to skip it",
                    }
                )

                return snap_id_start

            # We just want the first line
            snap_info_line = line
            break

    # Get the min_snap from snap_info_line
    if len(snap_info_line) > 0:
        snap_info_line = " ".join(snap_info_line.split())
        min_snap = snap_info_line.split(" ")[0]

    # Convert the value to int
    if len(min_snap) > 0:
        min_snap = int(min_snap)

    return min_snap


def is_valid_snapshot_range(awr_miner_out, minerFilename, snap_id_start, snap_id_end):
    """
    Check if  snap_id_end is greater than snap_id_start and if the
    difference between them is greater than the snap_diff variable

    Parameters
    ----------
         awr_miner_out : Path
            The path to the awr_miner_out directory
        minerFilename : str
            The name of the AWR Miner file
        snap_id_start : int
            The snap_id_start value
        snap_id_end : int
            The snap_id_end value

    Returns
    ----------
         bool : bool
              True if the condition is met , False otherwise
    """

    # Set the max difference between start and end snapshot
    # Twice of the value of snapshots of 15 minutes for 30 days (2 * 2880)
    snap_diff = 5760

    # Match against SNAP-HISTORY block snap ids range
    if (snap_id_end > snap_id_start) and (snap_id_end - snap_id_start) > snap_diff:
        # Match against SNAP-HISTORY-TZ block snap id
        min_snap_id = get_min_snapshot_id_from_snap_history_tz_block(
            awr_miner_out, minerFilename
        )
        if snap_id_start != min_snap_id:
            warning_files.append(
                {
                    "minerFile": minerFilename,
                    "warning": "file name does not match the naming convention, snap range mistmatch",
                    "expected": "awr-hist-<DBID>-<DBNAME>-<MIN_SNAP_ID>-<MAX_SNAP_ID>.out",
                    "reason": f"The expected difference between min {str(snap_id_start)} and"
                    f" max {str(snap_id_end)} snapshots must be less than {str(snap_diff)}",
                }
            )
            return True

    return True


def get_snap_id_range_from_memory_section(file_path):
    first_snap = None
    last_snap = None

    with open(file_path, "r") as f:
        in_memory_section = False
        for line in f:
            line = line.strip()
            if "~~BEGIN-MEMORY~~" in line:
                in_memory_section = True
                continue

            if "~~END-MEMORY~~" in line:
                break

            if in_memory_section:
                # Skip header line and --- separatorr line
                if (
                    line.upper().startswith("SNAP")
                    or line.startswith("----")
                    or not line
                ):
                    continue
                parts = line.split()
                if len(parts) != 5:
                    error_msg = "Some values (SGA,PGA) are missing in MEMORY section."
                    file_name=file_path.name
                    badFiles.append({
                        "minerFile":file_name,
                        "error":error_msg,
                        "reason":"missing SGA or PGA values.",
                    })

                    warning_lg.append({
                        "minerFile":file_name,
                        "lg": "        Warning : Collection does not contain mandatory sections values in ['MEMORY'] Section, Skipping file..."
                    })

                    break

                snap_id = int(parts[0])

                # First snap if not set
                if first_snap is None:
                    first_snap = snap_id

                # Updating the last snap id <- last line
                last_snap = snap_id

    return [first_snap, last_snap]


def validate_snapshot_id_start(
    awr_miner_out: Path, minerFilename: str, snap_id_start: int
) -> bool:
    """
    Validate the snap_id_start value matches with a valid range
    around the SNAP_MIN value extracted from the SNAP-HISTORY
    block present in the collection file. The MIN_SNAP_ID field
    read from the filename must be between the previous 100
    snapshots and the next 100 snapshots from the SNAP_MIN value.

    Parameters
    ----------
       awr_miner_out : Path
            The path to awr_miner_out directory
        minerFilename : str
            The name of the AWR Miner file
        snap_id_start : int
            The snap_id_start value from the filename

    Returns
    ----------
         bool : bool
              True if the condition is met , False otherwise
    """

    valid_snapshot_ids = []
    valid_snap_id_start = 0
    snap_minus = 0
    snap_plus = 0
    snap_range = 100

    # Get min and max snap_id from MEMORY block
    # Previously snaps were  obtained from snap-history but sometimes these values were wrong
    # looks like MEMORY section or any other section can have this snaps ids and be more accurated
    min_and_max_snap_list = get_snap_id_range_from_memory_section(
        awr_miner_out / minerFilename
    )
    # min_and_max_snap_list = get_snapshots_from_snap_history_block(awr_miner_out, minerFilename)
    if min_and_max_snap_list:
        valid_snap_id_start = min_and_max_snap_list[0]
        if valid_snap_id_start and valid_snap_id_start > 0:
            valid_snapshot_ids.append(valid_snap_id_start)

            # Expand the snapshot range
            for i in range(1, snap_range):
                snap_plus = valid_snap_id_start + i
                snap_minus = valid_snap_id_start - i
                valid_snapshot_ids.append(snap_plus)
                valid_snapshot_ids.append(snap_minus)

            # Sort the list
            valid_snapshot_ids.sort()

    # Get min snap_id from SNAP-HISTORY-TZ block
    valid_snap_id_start_from_snap_history_tz = (
        get_min_snapshot_id_from_snap_history_tz_block(
            awr_miner_out, minerFilename, snap_id_start
        )
    )

    # Check the snap_id received is present in the list
    if snap_id_start in valid_snapshot_ids:
        return True
    elif snap_id_start == valid_snap_id_start_from_snap_history_tz:
        return True
    elif min_and_max_snap_list and snap_minus > 0 and snap_plus > 0:
        warning_files.append(
            {
                "minerFile": minerFilename,
                "warning": "file name does not match the naming convention, invalid snapshot start",
                "expected": "awr-hist-<DBID>-<DBNAME>-<MIN_SNAP_ID>-<MAX_SNAP_ID>.out",
                "reason": f"MIN_SNAP_ID from filename: {str(snap_id_start)}"
                f", MIN_SNAP_ID from collection: {str(valid_snap_id_start)}"
                f" Expected to be between {str(snap_minus)} and {str(snap_plus)}",
            }
        )
        return True
    else:
        return True


def convert_awr_version_to_int(version_as_string) -> Optional[int]:
    """
    Convert the version passed as string to int to allow mathematical operations.

    Input : 21.6.1
    Output : 2161

    Parameters
    ----------
         version_as_string : str
            The string containing the version information

    Returns
    ----------
          int : int
            An int value after removing the '.' chars from the version string,
            right padded with zeroes when the length of the replaced string is
            less than the one set by AWR_MINER_MIN_SUPPORTED_VERSION var

    """

    version_as_int = None
    version_as_string_lgt = len(version_as_string)

    if version_as_string_lgt > 0:
        replaced_version_as_string = version_as_string.replace(".", "")

        # Replace the periods in AWR_MINER_MIN_SUPPORTED_VERSION
        replaced_awr_miner_min_supported_version = (
            AWR_MINER_MIN_SUPPORTED_VERSION.replace(".", "")
        )

        # Add zeros to the right in case the length is different
        if len(replaced_awr_miner_min_supported_version) > len(
            replaced_version_as_string
        ):
            how_many = len(replaced_awr_miner_min_supported_version) - len(
                replaced_version_as_string
            )
            replaced_version_as_string += how_many * "0"

        # Convert the value to int
        try:
            version_as_int = int(replaced_version_as_string)
        except ValueError:
            pass

    return version_as_int


def convert_db_version_to_int(version_as_string) -> Optional[int]:
    """
    Convert the version passed as string to int to allow mathematical operations.

    Input : 19.0.0.0.0
    Output : 19000

    Parameters
    ----------
         version_as_string : str
            The string containing the version information

    Returns
    ----------
          int : int
            An int value after removing the '.' chars from the version string,
            right padded with zeroes when the length of the replaced string is
            less than the one set by AWR_MINER_MIN_SUPPORTED_VERSION var

    """

    version_as_int = None
    version_as_string_lgt = len(version_as_string)

    if version_as_string_lgt > 0:
        replaced_version_as_string = version_as_string.replace(".", "")

        # Convert the value to int
        try:
            version_as_int = int(replaced_version_as_string)
        except ValueError:
            pass

    return version_as_int


def rename_cols_in_database_parameters_df(df: pd.DataFrame) -> pd.DataFrame():
    """
    Rename columns in the input Data Frame.

    Parameters
    ----------
        df : pd.DataFrame()
            The input Data Frame

    Returns
    ----------
         df : pd.DataFrame()
            The Data Frame with the columns renamed

    """
    # Debugging info
    global lastSuccess
    lastSuccess = "In rename_cols_in_database_parameters_df()"

    # Rename Value to VALUE if present on the df
    if "Value" in df:
        df = df.rename(columns={"Value": "VALUE"})

    return df


def rename_cols_in_main_metrics_df(df: pd.DataFrame) -> pd.DataFrame():
    """
    Rename columns in the input Data Frame.

    Parameters
    ----------
        df : pd.DataFrame()
            The input Data Frame

    Returns
    ----------
         df : pd.DataFrame()
            The Data Frame with the columns renamed

    """

    # Debug Info
    global lastSuccess
    lastSuccess = "In rename_cols_in_main_metrics_df()"

    # Rename cpu_p_sec to cpu_per_s
    if "cpu_p_sec" in df and "cpu_per_s" not in df:
        df = df.rename(columns={"cpu_p_sec": "cpu_per_s"})

    df = df.rename(columns={"SNAP_ID": "snap"})

    return df


def rename_cols_in_sqlnet_metrics_df(df: pd.DataFrame) -> pd.DataFrame():
    """
    Rename columns in the input Data Frame.

    Parameters
    ----------
        df : pd.DataFrame()
            The input Data Frame

    Returns
    ----------
         df : pd.DataFrame()
            The Data Frame with the columns renamed

    """

    # Debug Info
    global lastSuccess
    lastSuccess = "In rename_cols_in_sqlnet_metrics_df()"

    # Rename columns
    if "sqlnet_bytes_received" in df:
        df = df.rename(
            columns={"sqlnet_bytes_received": "sqlnet_bytes_received_from_client"}
        )

    if "sqlnet_bytes_sent" in df:
        df = df.rename(columns={"sqlnet_bytes_sent": "sqlnet_bytes_sent_to_client"})

    if "sqlnet_bytes_vector_from" in df:
        df = df.rename(
            columns={"sqlnet_bytes_vector_from": "sqlnet_bytes_vector_from_client"}
        )

    if "sqlnet_bytes_vector_to" in df:
        df = df.rename(
            columns={"sqlnet_bytes_vector_to": "sqlnet_bytes_vector_to_client"}
        )

    df = df.rename(columns={"SNAP_ID": "snap"})

    return df


def rename_cols_in_iostat_by_function_df(df: pd.DataFrame) -> pd.DataFrame():
    """
    Rename columns in the input Data Frame.

    Parameters
    ----------
        df : pd.DataFrame()
            The input Data Frame

    Returns
    ----------
         df : pd.DataFrame()
            The Data Frame with the columns renamed

    """

    # Debug Info
    global lastSuccess
    lastSuccess = "In rename_cols_in_iostat_by_function_df()"

    if "FUNCTION NAME" in df:
        df = df.rename(columns={"FUNCTION NAME": "FUNCTION_NAME"})

    return df


def rename_cols_in_io_object_type_df(df: pd.DataFrame) -> pd.DataFrame():
    """
    Rename columns in the input Data Frame.

    Parameters
    ----------
        df : pd.DataFrame()
            The input Data Frame

    Returns
    ----------
         df : pd.DataFrame()
            The Data Frame with the columns renamed

    """

    # Debug Info
    global lastSuccess
    lastSuccess = "In rename_cols_in_io_object_type_df()"

    df = df.rename(columns={"OBJ_TYPE": "OBJECT_TYPE"})
    return df


def rename_cols_in_snap_history_tz_df(df: pd.DataFrame) -> pd.DataFrame():
    """
    Rename columns in the input Data Frame.

    Parameters
    ----------
        df : pd.DataFrame()
            The input Data Frame

    Returns
    ----------
         df : pd.DataFrame()
            The Data Frame with the columns renamed

    """

    # Debug Info
    global lastSuccess
    lastSuccess = "In rename_cols_in_snap_history_tz_df()"

    df = df.rename(columns={"SNAP_ID": "SNAP"})
    return df


def get_rollover_snaps_from_snap_id(
    df: pd.DataFrame, minerFilename, section, rollover_filename
) -> pd.DataFrame():
    snapIds = pd.to_numeric(df["SNAP_ID"]).tolist()

    if snapIds[0] > snapIds[-1]:
        newSnapIds = [
            i + df["SNAP_ID"].astype(int).tolist()[0]
            for i in range(len(df["SNAP_ID"].unique()))
        ]

        _ = []
        for idx, old in enumerate(df["SNAP_ID"].unique().tolist()):
            _.append([old, newSnapIds[idx]])

        newSnapDf = pd.DataFrame(_)
        newSnapDf.columns = ["SNAP_ID", "SNAP_ID_new"]

        occa_storage.to_csv(newSnapDf, rollover_filename)
        rolloverSnaps.append(
            {"minerFile": minerFilename, "section": section, "file": rollover_filename}
        )

        df = pd.merge(
            left=df,
            right=newSnapDf,
            how="left",
            left_on=["SNAP_ID"],
            right_on=["SNAP_ID"],
        )
        df["SNAP_ID"] = df["SNAP_ID_new"]
        df.drop(columns=["SNAP_ID_new"], inplace=True)

    return df


def get_rollover_snaps_from_snap(
    df: pd.DataFrame, minerFilename, section, rollover_filename
) -> pd.DataFrame():
    snapIds = df["snap"].astype(int).tolist()

    if snapIds[0] > snapIds[-1]:
        newSnapIds = [
            i + df["snap"].tolist()[0] for i in range(len(df["snap"].unique()))
        ]

        _ = []
        for idx, old in enumerate(df["snap"].unique().tolist()):
            # print(old, newSnapIds[idx])
            _.append([old, newSnapIds[idx]])

        newSnapDf = pd.DataFrame(_)
        newSnapDf.columns = ["snap", "snap_new"]

        occa_storage.to_csv(newSnapDf, rollover_filename)
        rolloverSnaps.append(
            {"minerFile": minerFilename, "section": section, "file": rollover_filename}
        )

        df = pd.merge(
            left=df, right=newSnapDf, how="left", left_on=["snap"], right_on=["snap"]
        )
        df["snap"] = df["snap_new"]
        df.drop(columns=["snap_new"], inplace=True)

    return df


def check_malformed_rows(txt_file):
    """
    Check each of the rows in the txt file attempting to detect mismatch between the row
    length and the separator length. The content of the row must match in length the
    length of the separator if that is not the case either the row contains chars encoded
    in a format that we can't decode or the content has been manipulated post extraction.

    Matches the length of the row against the length of the separator line in the block,
    if the length of the row is longer than the length of the separator line the row is
    added to rowsCorrupt list.

    Parameters
    ----------
        txt_file : Path
            The Path of the temporary txt file containing the section data.
    """
    global rowsCorrupt, lastSuccess

    rowsCorrupt = []

    # Debug Info
    lastSuccess = "In check_malformed_rows()"

    with txt_file.open("r", encoding="UTF-8") as f:
        txt_data = f.readlines()

    if len(txt_data) < 3:
        # Nothing to do
        return

    # Calc the max header length, from the first several lines
    header_length = max(
        len(txt_data[0].strip()), len(txt_data[1].strip()), len(txt_data[2].strip())
    )
    clean_data = []
    for line in txt_data:
        if line.startswith("---"):
            # Skip separators
            pass
        elif len(line.strip()) > header_length:
            # If a data row is longer than the header, something is off
            rowsCorrupt.append(line)
        else:
            # Add to clean list
            clean_data.append(line)

    with txt_file.open("w", encoding="UTF-8") as f:
        f.writelines(clean_data)


def remove_separator_line(txt_file):
    """
    Remove the separator line on the file passed.

    Example:

         SNAP_ID WAIT_CLASS           EVENT_NAME                              PCTDBT TOTAL_TIME_S
      ---------- -------------------- ----------------------------------- ---------- ------------
          155659 DB CPU               DB CPU                                   76.26    111664772
          155659 System I/O           control file sequential read             62.64     91719692

    The separator is a sequence of dash characters separated by a single whitespace.
    The separator should be dropped from the temporary txt file before build the csv file.

    Parameters
    ----------
        txt_file : Path
            The Path of the temporary txt file containing the section data.
    """
    global lastSuccess
    new_lines = []

    # Debug Info
    lastSuccess = "In remove_separator_line()"

    # Remove separator line
    with open(txt_file, "r", encoding="UTF-8") as f:
        f_lines = f.readlines()
        for line in f_lines:
            if "---" in line:
                continue
            new_lines.append(line)

    # Write the list to the file
    with open(txt_file, "w", encoding="UTF-8") as o:
        o.writelines(new_lines)


def print_banner():
    """
    Print to stdout the tool banner.
    """
    lg(
        "======================================================================================================="
    )
    lg(sys.argv[0] + ", version " + __version__ + "\n")
    lg("sys.version_info  : " + str(sys.version_info))
    lg("platform.system() : " + str(platform.system()))
    lg("numpy.__version__ : " + np.__version__)
    lg("pandas.__version__: " + pd.__version__)
    lg(
        "======================================================================================================="
    )


def check_bad_parses():
    """
    Print to stdout the contents of the badParses list.
    """
    if len(badParses) > 0:
        lg(
            "\n======================================================================================================="
        )
        lg("WARNING: The following sections will NOT be included for analysis")
        for i in badParses:
            lg("\nfile        : " + i["minerFile"])
            if "section" in i:
                lg("section     : " + i["section"])
            lg("error       : " + i["error"])
            if "reason" in i:
                lg("reason      : " + i["reason"])
            if "lastSuccess" in i:
                lg("lastSuccess : " + i["lastSuccess"])
            if "file" in i:
                lg("file        : " + i["file"])
        lg(
            "\n======================================================================================================="
        )


def check_bad_file_name_parses():
    """
    Print to stdout the contents of the badParses list.
    """
    error_separated = ""
    # Don't use the same error_separated for logging
    # I only care about the error, not the files
    if len(badFiles) > 0:
        lg(
            "\n======================================================================================================="
        )
        lg("ERROR: The following files will NOT be included for analysis")
        for i in badFiles:
            lg("\nfile     : " + i["minerFile"])
            lg("error    : " + i["error"])
            error_separated += i["error"]
            if "expected" in i:
                lg("expected : " + i["expected"])
                error_separated += i["expected"]
            if "reason" in i:
                error_separated += i["reason"]
                lg("reason   : " + i["reason"])
            error_separated += ";"
        lg(
            "\n======================================================================================================="
        )

        if os.environ.get("RUN_FROM_API") == "True":
            raise Exception("Easy Miner ", error_separated.strip())

        file_pieces = get_miner_file_name_pieces(i["minerFile"])
        db_name = file_pieces["dbname"]
        dbid = file_pieces["dbid"]
        path = os.path.join(
            AWR_MINER_PARSED, ("db_" + db_name + "_" + str(dbid))
        )
        shutil.rmtree(path, ignore_errors=True)


def check_warning_files_name_parses():
    """
    Print to stdout the contents of the warning_filess list.
    """
    if len(warning_files) > 0:
        lg(
            "\n======================================================================================================="
        )
        print("WARNING: potential issues in the following files")
        for i in warning_files:
            lg("\nfile     : " + i["minerFile"])
            lg("warning    : " + i["warning"])
            if "expected" in i:
                lg("expected : " + i["expected"])
            if "reason" in i:
                lg("reason   : " + i["reason"])
        lg(
            "\n======================================================================================================="
        )


def check_rollover_snaps():
    """
    Print to stdout the contents of the rolloverSnaps list.
    """
    if len(rolloverSnaps) > 0:
        lg(
            "\n==========================================================================================="
        )
        lg(
            "\nThe following sections had files that required applying rollover snap logic."
        )
        lg(
            "\nThese sections will be included by the AWR miner plotting & occa upload scripts."
        )
        lg("\nThe rollover values are contained in the files shown.")
        for i in rolloverSnaps:
            lg("\nfile: " + i["minerFile"])
            lg("section     : " + i["section"])
            lg("file        : " + i["file"])

        lg(
            "\n==========================================================================================="
        )


def check_unnamed_columns_in_df(df, section, minerFilename, filenameCsv):
    """
    Add Unnamed columns in Data Frame to badParses List. Unnamed columns means bad parsing.

    Parameters
    ----------
        df : pd.DataFrame()
            The input DataFrame
        section : str
            The section from the AWR Miner out that need to be fixed
        minerFilename : str
            The name of the AWR Miner file
        filenameCsv : str
            The name of the csv file
    """
    df_column_names = list(df.columns.values)
    for col in df_column_names:
        if "Unnamed" in col:
            badParses.append(
                {
                    "minerFile": minerFilename,
                    "section": section,
                    "error": col,
                    "reason": "Unparseable content",
                    "file": filenameCsv,
                }
            )


def is_valid_db_version(minerFilename: str, db_version: str) -> bool:
    """
    Verify that the Database Version passed is higher than 11g

    Parameters
    ----------
        minerFilename : str
            The name of the AWR Miner file
        db_version : str
            The Database version to check.

    Returns
    ----------
        bool : bool
            True if the db_version is higher than 11 , False otherwise
    """

    major_db_version_as_int = convert_db_version_to_int(db_version)

    if major_db_version_as_int is not None and major_db_version_as_int < 11:
        badFiles.append(
            {
                "minerFile": minerFilename,
                "error": "Not supported database version, should be 11g or higher.",
                "reason": f"The collection is for database version: {str(major_db_version_as_int)}",
            }
        )
        return False

    return True


def get_colspecs_for_fixed_width_parsing(file_txt: str):
    """
    Get colspecs parameter to prevent Unnamed columns from panda.read_fwf() routine.

    Each file for each section contains the column names for the data, a separator and the data.

    Example:

         SNAP_ID WAIT_CLASS           EVENT_NAME                              PCTDBT TOTAL_TIME_S
      ---------- -------------------- ----------------------------------- ---------- ------------
          155659 DB CPU               DB CPU                                   76.26    111664772
          155659 System I/O           control file sequential read             62.64     91719692

    The separator is a sequence of dash characters separated by a single whitespace.
    Each of these chunks represent the width of the data belonging to the column.

    This routine parses the content of the seprator line and gets the start and end index of each
    chunk.

    Parameters:
        file_txt : str
            Txt file containing the block

    Return:
        list[(int,int)] : list[(int,int)]
            start and end position in the string for each of the pieces
    """
    global lastSuccess

    col_widths = []
    sep_line = ""
    blank_line = ""

    # Debug Info
    lastSuccess = "In get_colspecs_for_fixed_width_parsing()"

    # Open the file and read the separator line
    with open(file_txt, "r") as fp:
        blank_line = fp.readline().strip()
        if len(blank_line) > 0:
            # Sometimes the first line of the file is not empty
            sep_line = fp.readline().strip("\n")
        else:
            header_line = fp.readline().strip("\n")
            sep_line = fp.readline().strip("\n")

    # Apply the regex to the separator line
    col_pattern = re.compile(r"(-+)")
    if len(sep_line) > 0:
        match_groups = re.finditer(col_pattern, sep_line)

        # Get the start and end index for each match group
        for col in match_groups:
            col_widths.append(col.span())

    return col_widths


def parse(awr_miner_out, awr_miner_parsed, minerFilename: str):
    """
    Parse the AWR Miner file to create csv files per each of the sections.

    Parameters
    ----------
        awr_miner_out : Path
            The path to awr_miner_out directory
        awr_miner_parsed : Path
             The path to awr_miner_parsed directory
        minerFilename : str
            The name of the file
    """

    global badParses, rolloverSnaps
    global filenameTxt, filenameCsv, filenameRollover
    global section, lastSuccess, DELETE_PARSED_TXT_FILES
    global AWR_MINER_VERSION_DEPRECATED, BAR_COLLECTION_DETECTED

    lg("\nParsing file " + minerFilename)

    # Check the miner file name accomplish with the name convention
    if not (is_valid_file_name(minerFilename)):
        lg(
            "     Warning : Collection file name does not match the naming convention, Skipping file..."
        )
        return
    # Get the values from the file name
    file_pieces = get_miner_file_name_pieces(minerFilename)
    DBID = file_pieces["dbid"]
    DB = file_pieces["dbname"]
    SNAP_ID_START = int(file_pieces["snap_id_start"])
    SNAP_ID_END = int(file_pieces["snap_id_end"])

    # Check 'ORA-' errors in the collection
    if are_ora_errors_in_file(awr_miner_out, minerFilename):
        lg("        Warning : Collection contains ERRORs, Skipping file...")
        return

    # Check the difference between max and min snap id to detect manipulations on the file name
    if not (
        is_valid_snapshot_range(
            awr_miner_out, minerFilename, SNAP_ID_START, SNAP_ID_END
        )
    ):
        lg(
            "     Warning : Collection file name does not match the naming convention, Skipping file..."
        )
        return

    # Check the SNAP_ID_START from the file name matches the one in the collection
    if not (validate_snapshot_id_start(awr_miner_out, minerFilename, SNAP_ID_START)):
        lg(
            "     Warning : Collection file name does not match the naming convention, Skipping file..."
        )
        return

    # Get the Database and AWR Miner versions
    version_list = get_versions_from_os_information_block(awr_miner_out, minerFilename)
    full_db_version = "Unknown"
    awr_miner_full_version = "Unknown"
    major_db_version = ""
    if version_list and len(version_list) == 3:
        full_db_version = version_list[0]
        major_db_version = version_list[1]
        awr_miner_full_version = version_list[2]

    # Print the progress message on stdout
    lg(
        f"     DBID: {str(DBID)}, DB: {DB}, VERSION: {full_db_version}, snap_ids: {str(SNAP_ID_START)} "
        f"thru {str(SNAP_ID_END)}, AWR_MINER_VERSION: {awr_miner_full_version}"
    )

    # Check the Database version from the collection
    if not (is_valid_db_version(minerFilename, major_db_version)):
        lg(
            "        Warning : Collection should be for 11g or higher databases, Skipping file..."
        )
        return

    # Check if is a BAR collection
    awr_miner_full_version_as_int = convert_awr_version_to_int(awr_miner_full_version)
    if awr_miner_full_version_as_int is not None:
        if "5" in str(awr_miner_full_version_as_int)[:1]:
            BAR_COLLECTION_DETECTED = True
            if BAR_REMOVE_FROM_MANDATORY_SECTIONS:
                awr_mandatory_sections.remove("OS-INFORMATION2")

    # Check the AWR Miner Version from the collection
    if not BAR_COLLECTION_DETECTED and not ALLOW_OLD_MINER:
        awr_miner_full_version_as_int = convert_awr_version_to_int(
            awr_miner_full_version
        )
        awr_min_supported_version_as_int = convert_db_version_to_int(
            AWR_MINER_MIN_SUPPORTED_VERSION
        )
        if awr_miner_full_version_as_int is not None:
            if awr_miner_full_version_as_int < awr_min_supported_version_as_int:
                AWR_MINER_VERSION_DEPRECATED = True

    # Read the contents of the file
    minerFilenamePath = os.path.join(awr_miner_out, minerFilename)
    try:
        f = open(minerFilenamePath)
        lines = f.readlines()
    except:
        f = open(minerFilenamePath, encoding="ISO-8859-1")
        lines = f.readlines()

    # Determine if the numeric separator needs to be adjusted for the whole file
    adjust_numeric_sep = determine_numeric_delimiters(lines)

    parsedPath = os.path.join(
        awr_miner_parsed, ("db_" + DB + "_" + str(DBID)), minerFilename.strip(".out")
    )
    os.makedirs(parsedPath, exist_ok=True)

    # Process the file
    inFrame = False
    sections_found = []
    for i, l in enumerate(lines):
        if l.startswith("~~BEGIN"):
            inFrame = True
            section = l[8:-3]
            sections_found.append(section)

            filenameTxt = os.path.join(parsedPath, (section + ".txt"))
            filenameCsv = os.path.join(parsedPath, (section + ".csv"))
            filenameRollover = os.path.join(
                parsedPath, (section + "_rollover_snap.csv")
            )

            lg("        wrote section: " + section + " to " + filenameCsv)
            o = open(filenameTxt, "w", encoding="UTF-8")

        elif l.startswith("~~END") or l.startswith("~END"):
            inFrame = False
            o.close()

            # Get colspecs for fixed-width parsing
            col_widths = get_colspecs_for_fixed_width_parsing(filenameTxt)

            # Check for malforned rows
            check_malformed_rows(Path(filenameTxt))

            # Remove the separator line in the txt file
            remove_separator_line(Path(filenameTxt))

            try:
                lastSuccess = "before pd.read_fwf(filenameTxt)"
                if col_widths:
                    try:
                        df = pd.read_fwf(filenameTxt, colspecs=col_widths)
                    except:
                        df = pd.read_fwf(
                            filenameTxt, colspecs=col_widths, encoding="ISO-8859-1"
                        )
                else:
                    try:
                        df = pd.read_fwf(filenameTxt)
                    except:
                        df = pd.read_fwf(filenameTxt, encoding="ISO-8859-1")

                # Handle the SQL*Plus pagesize limit (50000 lines)
                lastSuccess = "Removing possible duplicate headers"
                df = df[df.ne(df.columns).any(axis=1)]

                if "SNAP_ID" in df:
                    df = df[df["SNAP_ID"] != "SNAP_ID"]
                if "snap" in df:
                    df = df[df["snap"] != "snap"]
                if "SNAP" in df:
                    df = df[df["SNAP"] != "SNAP"]

                # Instead for searching 'Snap Id' in the columns, normalize and find with normalization
                for col in df.columns:
                    # we aim for any combination like Snap Id, Snap ID, snap id  snap ID and so on...
                    # if we found any case, we rename it and get out of the loop
                    if col.strip().replace("_", " ").lower() == "snap id":
                        df.rename(columns={col: "SNAP_ID"}, inplace=True)
                        break

                # Detect and fix rollover snaps
                if "SNAP_ID" in df:
                    lastSuccess = "if 'SNAP_ID' in df"
                    df = get_rollover_snaps_from_snap_id(
                        df, minerFilename, section, filenameRollover
                    )

                if "snap" in df:
                    lastSuccess = "if 'snap' in df"
                    df = get_rollover_snaps_from_snap(
                        df, minerFilename, section, filenameRollover
                    )

                # Rename and Fix Unnamed cols in sections
                if section == "OS-INFORMATION":
                    lastSuccess = "if section in ['OS-INFORMATION']"

                    # if DB_NAME is missing, copy from CDB_NAME and modify it
                    db_name = df[df["STAT_NAME"] == "DB_NAME"]["STAT_VALUE"].values[0]
                    if not isinstance(db_name, str):
                        db_name = (
                            df[df["STAT_NAME"] == "CDB_NAME"]["STAT_VALUE"].values[0]
                            + "_FROMCDBNAME"
                        )
                        df.loc[df["STAT_NAME"].isin(["DB_NAME"]), "STAT_VALUE"] = (
                            db_name
                        )

                    # Tweak these values as they are strings
                    if adjust_numeric_sep:
                        df.loc[df["STAT_NAME"].isin(["HOSTS"]), "STAT_VALUE"] = df[
                            "STAT_VALUE"
                        ].str.replace(",", ".", regex=False)

                        df.loc[
                            df["STAT_NAME"].isin(["AWR_MINER_VER", "VERSION"]),
                            "STAT_VALUE",
                        ] = df["STAT_VALUE"].str.replace(".", ",", regex=False)

                elif section in ["DATABASE-PARAMETERS", "DATABASE-PARAMETERS2"]:
                    df = rename_cols_in_database_parameters_df(df)
                elif section in ["MAIN-METRICS", "PDB-METRICS"]:
                    df = rename_cols_in_main_metrics_df(df)
                elif section == "SQLNET-METRICS":
                    df = rename_cols_in_sqlnet_metrics_df(df)
                elif section == "IOSTAT-BY-FUNCTION":
                    df = rename_cols_in_iostat_by_function_df(df)
                elif section == "IO-OBJECT-TYPE":
                    df = rename_cols_in_io_object_type_df(df)
                elif section == "SNAP-HISTORY-TZ":
                    df = rename_cols_in_snap_history_tz_df(df)

                if adjust_numeric_sep:
                    lastSuccess = "before if adjust_numeric_sep"
                    df = df.applymap(clean_numeric_delimiters)

                df["snap_id_start"] = SNAP_ID_START
                df["snap_id_end"] = SNAP_ID_END

                # Check for corrupted rows
                if len(rowsCorrupt) > 0:
                    lg(
                        f"          Warning : {len(rowsCorrupt)} rows ignored from source due and assumed corrupt."
                    )

                # Check for Unnamed columns on the dataframe (Means bad parsing)
                check_unnamed_columns_in_df(df, section, minerFilename, filenameCsv)

                # Write the csv file
                lastSuccess = "occa_storage.to_csv(df, filenameCsv, index=False)"
                occa_storage.to_csv(df, filenameCsv, index=False)

                # Clean up temporary txt files created
                if DELETE_PARSED_TXT_FILES:
                    if section != "MAIN-METRICS":
                        os.remove(filenameTxt)

            except Exception as fc:
                badParses.append(
                    {
                        "minerFile": minerFilename,
                        "section": section,
                        "error": str(fc),
                        "reason": "Error reading/writing frame for section",
                        "file": filenameTxt,
                        "lastSuccess": lastSuccess,
                    }
                )

        elif inFrame:
            if l.strip() != "":
                o.write(l)
                f.close()

    # Check for missing sections
    sections_missing = []
    for expected_section in awr_sections:
        if (expected_section == "MAIN-METRICS" and "PDB-METRICS" in sections_found) or (
            expected_section == "PDB-METRICS" and "MAIN-METRICS" in sections_found
        ):
            continue
        if (
            expected_section not in sections_found
            and expected_section not in awr_mandatory_sections
        ):
            sections_missing.append(expected_section)

    if len(sections_missing) > 0:
        badParses.append(
            {
                "minerFile": minerFilename,
                "section": ",".join(sections_missing),
                "error": "Missing sections",
                "reason": f"Sections {sections_missing} are missing in the collection file",
            }
        )
        lg(
            f"        Warning : Collection does not contain  sections {sections_missing}"
        )

    # Check for missing mandatory sections
    mandatory_sections_missing = []
    for mandatory_expected_section in awr_mandatory_sections:
        if mandatory_expected_section not in sections_found:
            mandatory_sections_missing.append(mandatory_expected_section)

    for i in warning_lg:
        if 'lg' in i and minerFilename == i['minerFile']:
            lg(i['lg'])

    if len(mandatory_sections_missing) > 0:
        badFiles.append(
            {
                "minerFile": minerFilename,
                "error": "Missing mandatory sections",
                "reason": f"Section {mandatory_sections_missing} is missing in the collection file",
            }
        )
        lg(
            f"        Warning : Collection does not contain mandatory sections {mandatory_sections_missing}, Skipping file..."
        )

        sections = " ".join(mandatory_sections_missing)
        raise_error_when_run_from_api('AWR: ',f"Missing mandatory sections {sections}")
        # Delete awr_miner_parsed dir to prevent the files will be processed by run-metrics
        parent_parsed_path = Path(parsedPath).parent.absolute()
        shutil.rmtree(parent_parsed_path, ignore_errors=True)

        return


# ----------------------------------------------------------------------------------------------------------------------
def main():
    global BAR_MINER_WARNING_MODE, BAR_MINER_ERROR_MODE, BAR_REMOVE_FROM_MANDATORY_SECTIONS, ALLOW_OLD_MINER
    global AWR_MINER_PATH, AWR_MINER_PARSED, AWR_MINER_OUT

    argparser = argparse.ArgumentParser(
        prog="awr_miner_parse.py",
        description="Print the results of script awr_miner_parse.py",
    )
    argparser.add_argument(
        "-v",
        "--version",
        type=str,
        action="store",
        nargs="*",
        help="Print the version of the script",
    )
    argparser.add_argument(
        "--allowbar",
        type=str,
        action="store",
        nargs="*",
        help="Allow BAR collections to be processed",
    )
    argparser.add_argument(
        "--allowoldminer",
        type=str,
        action="store",
        nargs="*",
        help="Allow AWR deperecated collections to be processed",
    )

    args = argparser.parse_args()

    if args.version is not None:
        print(sys.argv[0] + ", version " + __version__)
        quit()

    # Optional flag to enable the processing of BAR collections
    if args.allowbar is not None:
        BAR_MINER_WARNING_MODE = False
        BAR_MINER_ERROR_MODE = False
        BAR_REMOVE_FROM_MANDATORY_SECTIONS = True

    # Optional flag to enable the processing of Old AWR Miner collections
    if args.allowoldminer is not None:
        ALLOW_OLD_MINER = True

    # Print the tool banner
    print_banner()

    # Get paths
    AWR_MINER_PATH = get_awr_miner_path()
    AWR_MINER_PARSED = get_awr_miner_parsed_path(AWR_MINER_PATH)
    AWR_MINER_OUT = get_awr_miner_out_path(AWR_MINER_PATH)

    # Verify AWR_MINER_PATH exists
    if not check_awr_miner_path_exists(AWR_MINER_PATH):
        quit()

    # if there's defined a folder-structure execute this
    execute_cohort_folder_workflow(AWR_MINER_OUT)

    # Verify there are out files in awr_miner_out directory
    filelist = check_awr_miner_files_exist(AWR_MINER_PATH)

    lg(
        "Begin @ "
        + datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        + " UTC"
    )

    # Parse files
    if len(filelist) > 0:
        for file in filelist:
            parse(file.parent, AWR_MINER_PARSED, file.name)

    # Check bad file name parses
    check_bad_file_name_parses()

    # Check warning file name parses
    check_warning_files_name_parses()

    # Check bad parses
    check_bad_parses()

    # Check rollover snaps
    check_rollover_snaps()

    # Error if is old AWR Miner collection
    print_deprecation_message(AWR_MINER_PARSED)

    # Check if is a Bar Collection
    print_bar_deprecation_message(AWR_MINER_PARSED)

    lg("\nEnd @ " + datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S") + " UTC\n")


if __name__ == "__main__":
    main()
