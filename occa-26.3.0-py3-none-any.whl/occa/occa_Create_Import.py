import argparse
import base64
import datetime
import getpass
import hashlib
import json
import logging
import os
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import simplejson
from version import version, __version__

# Print everything to stdout
logging.basicConfig(stream=sys.stdout, format="%(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# Create a flag to enable pretty printing of json output for troubleshooting purposes
JSON_OUTPUT_PRETTY_PRINT = False

# Flags to enable the dump of blocks
EM_METRICS = True
PLOT_UPLOAD_HTML = True
PLOT_UPLOAD_PNG = True

# Flag to allow bypass of detected excluded databases an instances
ALLOW_EXCLUDED = False

# Define constants
current_path = Path().resolve()
output_file_name = os.path.join("occa_sizing_output", "occa_upload_data.json")
application_endpoint = f"https://occa.us.oracle.com/ords/f?p=500"


def generate_cohort_rollup(
    database_df: pd.DataFrame, sizing_df: pd.DataFrame
) -> pd.DataFrame:
    # Need a pandas pivot table to put the per cohort and metric in as columns

    # select value
    # group by cdb_cohort, metric, adjusted
    # where summary_of = 'cdb_cohort'
    cohort_df = sizing_df[sizing_df["summary_of"] == "cdb_cohort"]
    cohort_pivot = cohort_df.pivot(
        index=["cdb_cohort", "adjusted"], columns="metric", values="peak"
    )
    cohort_pivot = cohort_pivot.reset_index()
    cohort_pivot["included_count"] = 0
    cohort_pivot["excluded_count"] = 0
    excluded_count = (
        database_df[database_df["excluded"] == "excluded"].groupby("cdb_cohort").size()
    )
    cohort_df.set_index("cdb_cohort")
    # new_df = cohort_df.merge(excluded_count, on="cdb_cohort")
    return cohort_pivot


def pivot_database_metrics(
    database_df: pd.DataFrame, sizing_df: pd.DataFrame
) -> pd.DataFrame:
    sizing_metrics_df = sizing_df[sizing_df["summary_of"] == "cdb"]
    sizing_metrics_df = sizing_metrics_df.pivot(
        index=["cdb_cohort", "cdb", "adjusted"], columns="metric", values="peak"
    )
    sizing_metrics_df = sizing_metrics_df.reset_index()
    return sizing_metrics_df


def write_to_file(filename, data):
    with open(filename, "w", encoding="UTF-8") as data_file:
        data_file.write(data)
        logger.info(f"\nCreated EM Collection Import file:  {filename}")


def read_csv_if_exists(csv_filename) -> pd.DataFrame:
    """Check to see file exists before loading it"""
    if os.path.exists(csv_filename):
        return pd.read_csv(csv_filename)
    else:
        return pd.DataFrame()


def read_all_html_plots():
    """Read the html plots based on the file_pattern defined from disk into a structure"""

    file_patterns = (
        "**/*_DB_vCPU_adjusted.html",
        "**/*_Adjustments.html",
        "**/*_Allocated_Storage_(GB)_Unadjusted.html",
    )
    plot_paths = [
        (current_path / "occa_sizing_output/plots/adjusted/").resolve(),
        (current_path / "occa_sizing_output/plots/DailyUnadjusted"),
    ]

    file_list = []
    for plot_path in plot_paths:
        logger.debug(f"Reading html plots from {plot_path}")
        if not plot_path.exists():
            logger.error(f"Plot path {plot_path} doesn't exist")
            continue

        # Create the list of files
        for f in file_patterns:
            file_list.extend(plot_path.glob(f))

    output = []
    for html_file in file_list:
        logger.debug(f"Reading {html_file}")
        cohort_name = html_file.name.split("_")[0]

        # Drop excluded cohort
        if cohort_name == "excluded":
            continue

        file_data = {
            "cohort": cohort_name,
            "file_name": html_file.name,
            "file_content": html_file.read_text(encoding="UTF-8"),
            "import_source": "EMCC_EXTRACT",
        }

        file_data["individual_plots"] = (
            1 if "individual_plots" in html_file.parts else 0
        )

        output.append(file_data)

    return output


def read_all_png_plots():
    """Read all PNG plots from disk into a structure"""

    plot_path = (current_path / "occa_sizing_output/plots/adjusted/").resolve()

    logger.debug(f"Reading png plots from {plot_path}")
    if not plot_path.exists():
        logger.error(f"Plot path {plot_path} doesn't exist")
        return

    output = {}
    for png_file in plot_path.glob("**/*CPU*.png"):
        logger.debug(f"Reading {png_file}")
        output[png_file.name] = base64.b64encode(png_file.read_bytes())

    return output


def get_em_metrics(fil):

    em_metrics_filtered_df = pd.DataFrame()

    em_metrics_file = fil
    em_metrics_collections = ["db_inst_cpu_usage", "oracle_storage"]

    if EM_METRICS:

        em_metrics_df = read_csv_if_exists(em_metrics_file)
        if "COLL_NAME" in em_metrics_df.columns:
            em_metrics_filtered_df = em_metrics_df[
                em_metrics_df["COLL_NAME"].isin(em_metrics_collections)
            ]

    return em_metrics_filtered_df


def filter_cohort_rollups(df) -> pd.DataFrame:
    """Filter data in cohort_rollups_df dataframe"""

    output_df = pd.DataFrame()
    from_file_cohorts_count = len(df)

    # Grab the rows where Database Included is greater than 0
    output_df = df[df["Databases Included"] > 0]
    database_included_count = len(output_df)

    # Grab the rows where the cohort is not set to unassigned
    output_df = output_df[output_df["Name"] != "unassigned"]
    df_unassigned = df[df["Name"] == "unassigned"]
    unsassigned_cohorts_count = len(df_unassigned)

    # Grab the rows where the cohort is not set to exclude
    output_df = output_df[output_df["Name"] != "exclude"]
    df_excluded = df[df["Name"] == "exclude"]
    excluded_cohorts_count = len(df_excluded)

    if output_df.empty:
        logger.critical(f"ERROR : Cohort Rollups not found in the collection!")
        logger.critical(
            f"        Total[{from_file_cohorts_count}] "
            f"included[{database_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{database_included_count - unsassigned_cohorts_count - excluded_cohorts_count }]"
        )
        sys.exit(1)
    else:
        logger.info(
            f"Cohort   Rollups Summary : "
            f"Total[{from_file_cohorts_count}] "
            f"included[{database_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{database_included_count - unsassigned_cohorts_count - excluded_cohorts_count }]"
        )
    return output_df


def filter_database_rollups(df) -> pd.DataFrame:
    """Filter data in database_rollups_df dataframe"""

    output_df = pd.DataFrame()
    from_file_cohorts_count = len(df)

    output_df = df[df["Instances Included"] > 0]
    instances_included_count = len(output_df)

    output_df = output_df[output_df["Cohort"] != "unassigned"]
    df_unassigned = df[df["Cohort"] == "unassigned"]
    unsassigned_cohorts_count = len(df_unassigned)

    output_df = output_df[output_df["Cohort"] != "exclude"]
    df_excluded = df[df["Cohort"] == "exclude"]
    excluded_cohorts_count = len(df_excluded)

    if output_df.empty:
        logger.critical(f"ERROR : Database Rollups not found in the collection!")
        logger.critical(
            f"        Total[{from_file_cohorts_count}] "
            f"included[{instances_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{instances_included_count - unsassigned_cohorts_count - excluded_cohorts_count}]"
        )
        sys.exit(1)
    else:
        logger.info(
            f"Database Rollups Summary : "
            f"Total[{from_file_cohorts_count}] "
            f"included[{instances_included_count}] "
            f"unassigned[{unsassigned_cohorts_count}] "
            f"excluded[{excluded_cohorts_count}] "
            f"processed[{instances_included_count - unsassigned_cohorts_count - excluded_cohorts_count}]"
        )
    return output_df


def create_database_names_hash(output_dict) -> str:
    """Create MD5 Hash over the list of database names present in the collection"""
    database_names_list = []

    if "databases" in output_dict:
        for rec in output_dict["databases"]:
            database_name = rec["cdb"]
            database_names_list.append(database_name)
        database_names_str = " ".join(database_names_list)
        database_names_bytes = hashlib.md5(database_names_str.encode())
        database_names_hash = database_names_bytes.hexdigest()
    else:
        database_names_hash = ""

    return database_names_hash


def print_banner():
    """
    Print to stdout the tool banner.
    """
    logger.info(
        "======================================================================================================="
    )
    logger.info(sys.argv[0] + ", version " + __version__)
    logger.info("sys.version_info  : " + str(sys.version_info))
    logger.info("platform.system() : " + str(platform.system()))
    logger.info("numpy.__version__ : " + np.__version__)
    logger.info("pandas.__version__: " + pd.__version__)
    logger.info(
        "======================================================================================================="
    )
    logger.info(" ")


def check_dirs(working_path) -> bool:
    """
    Verify the needed directories exists to run this program

    Parameters:
        working_path : Path
            The absolute path of the current working directoru
    Returns:
        bool : bool
            True if all the needed directories are present , False otherwsie

    """
    sizing_pathname = os.path.join(current_path, "occa_sizing_output", "sizing")
    if not os.path.exists(sizing_pathname):
        logger.critical(f"\nERROR : Directory {sizing_pathname} doesn't exist\n")
        return False

    return True


def check_excluded_databases(db_df: pd.DataFrame) -> bool:
    """
    Check the contents of the file databases.csv to verify that there are no excluded databases
    in the file generated by the awr-run command.

    Parameters:
        db_df : pandas.DataFrame
            The databases dataframe
    Return:
        bool : bool
            True if there are databases excluded

    """

    if not ALLOW_EXCLUDED:
        # Filter excluded and unassigned cohorts
        filtered_db_df = db_df[
            (db_df["cdb_cohort"] != "unassigned") & (db_df["cdb_cohort"] != "excluded")
        ]

        # Filter the rows without excluded reason
        filtered_db_df = filtered_db_df[filtered_db_df.excluded_reason.notnull()]

        if len(filtered_db_df) > 0:
            logger.critical(
                f"ERROR : The databases.csv file contains {len(filtered_db_df)} excluded databases!\n\n"
                f" These must be fixed before upload the file into OCCA Web.\n"
                f" Review the OCCA User Guide to figure out the exclusion reason and how to resolve it.\n"
            )
            return True

    return False


def check_excluded_instances(inst_df: pd.DataFrame) -> bool:
    """
    Check the contents of the file instances.csv to verify that there are no excluded databases
    in the file generated by the awr-run command.

    Parameters:
        inst_df : pandas.DataFrame
            The databases dataframe
    Return:
        bool : bool
            True if there are databases excluded

    """

    if not ALLOW_EXCLUDED:
        # Filter excluded and unassigned cohorts
        filtered_inst_df = inst_df[
            (inst_df["cdb_cohort"] != "unassigned")
            & (inst_df["cdb_cohort"] != "excluded")
        ]

        # Filter the rows without excluded reason
        filtered_inst_df = filtered_inst_df[filtered_inst_df.excluded_reason.notnull()]

        if len(filtered_inst_df) > 0:
            logger.critical(
                f"ERROR : The instances.csv file contains {len(filtered_inst_df)} excluded instances!\n\n"
                f" These must be fixed before upload the file into OCCA Web.\n"
                f" Review the OCCA User Guide to figure out the exclusion reason and how to resolve it.\n"
            )
            return True

    return False


def create_input_json(write_file=True):
    """"""
    global current_path
    current_path = Path().resolve()
    logger.info(
        "Begin @ " + datetime.datetime.now(datetime.timezone.utc).isoformat() + " UTC"
    )

    # Print the tool banner
    print_banner()

    # Check needed directories
    if not (check_dirs(current_path)):
        exit(1)

    # Set the directories
    sizing_pathname = current_path / "occa_sizing_output" / "sizing"
    properties_pathname = current_path / "occa_sizing_properties"

    # Get databases information
    databases_df = read_csv_if_exists(os.path.join(sizing_pathname, "databases.csv"))

    # Check for excluded databases
    if check_excluded_databases(databases_df):
        exit(1)

    # Process Cohort Rollups
    cohort_rollups_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "cohort_rollups.csv")
    )
    if cohort_rollups_df.empty:
        logger.critical(f"ERROR : Cohort Rollups not found in the collection!")
        exit(1)

    # Filter out unused entries in cohort rollups
    cohort_rollups_df = filter_cohort_rollups(cohort_rollups_df)
    if cohort_rollups_df.empty:
        exit(1)

    # Process Database Rollups
    database_rollups_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "database_rollups.csv")
    )
    if database_rollups_df.empty:
        logger.critical(f"ERROR : Database Rollups not found in the collection!")
        exit(1)

    # Filter out unused entries in database rollups
    database_rollups_df = filter_database_rollups(database_rollups_df)
    if database_rollups_df.empty:
        exit(1)

    # Check for excluded instances
    instances_df = read_csv_if_exists(os.path.join(sizing_pathname, "instances.csv"))
    if check_excluded_instances(instances_df):
        exit(1)

    hosts_df = read_csv_if_exists(os.path.join(sizing_pathname, "servers.csv"))
    sizing_df = read_csv_if_exists(os.path.join(sizing_pathname, "sizing.csv"))
    adjustments_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "adjustments.csv")
    )
    database_statistics_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "database_statistics.csv")
    )
    cohort_statistics_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "cohort_statistics.csv")
    )
    metric_presence_by_stage_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "metric_presence_by_stage.csv")
    )
    database_vcpu_hours_df = read_csv_if_exists(
        os.path.join(sizing_pathname, "database_vcpu_hours.csv")
    )
    em_metrics_df = get_em_metrics(
        os.path.join(sizing_pathname, "emcc_sizing_em_metrics.csv")
    )
    properties_database_df = read_csv_if_exists(
        properties_pathname / "properties_database.csv"
    )
    properties_instance_df = read_csv_if_exists(
        properties_pathname / "properties_instance.csv"
    )
    properties_server_df = read_csv_if_exists(
        properties_pathname / "properties_server.csv"
    )

    output_structure = {}
    output_structure["databases"] = databases_df.to_dict(orient="records")
    output_structure["hosts"] = hosts_df.to_dict(orient="records")
    output_structure["instances"] = instances_df.to_dict(orient="records")
    output_structure["cohort_rollups"] = cohort_rollups_df.to_dict(orient="records")
    output_structure["database_rollups"] = database_rollups_df.to_dict(orient="records")
    output_structure["sizing"] = sizing_df.to_dict(orient="records")
    # output_structure["adjustments"] = adjustments_df.to_dict(orient="records")
    # output_structure["database_statistics"] = database_statistics_df.to_dict( orient="records")
    # output_structure["sizing_rollups"] = generate_cohort_rollup(databases_df, sizing_df).to_dict(orient="records")
    # output_structure["database_metrics"] = pivot_database_metrics( databases_df, sizing_df).to_dict(orient="records")
    # output_structure["metric_presence_by_stage"] = metric_presence_by_stage_df.to_dict(orient="records")
    output_structure["database_vcpu_hours"] = database_vcpu_hours_df.to_dict(
        orient="records"
    )
    output_structure["em_metrics"] = em_metrics_df.to_dict(orient="records")
    output_structure["em_properties_database"] = properties_database_df.to_dict(
        orient="records"
    )
    output_structure["em_properties_instance"] = properties_instance_df.to_dict(
        orient="records"
    )
    output_structure["em_properties_server"] = properties_server_df.to_dict(
        orient="records"
    )

    # Add plots to json.  Can be turned off
    if PLOT_UPLOAD_HTML:
        output_structure["plots_html"] = read_all_html_plots()
    if PLOT_UPLOAD_PNG:
        output_structure["plots_png"] = read_all_png_plots()

    # Generation data
    output_structure["occa_version"] = version
    output_structure["input_source"] = "EMCC_EXTRACT"
    output_structure["date_generated"] = datetime.datetime.now(
        datetime.timezone.utc
    ).isoformat()
    output_structure["user"] = getpass.getuser()
    output_structure["script_dir"] = str(Path(__file__).parent.resolve())
    output_structure["data_dir"] = str(Path(sizing_pathname).resolve())
    output_structure["database_names_hash"] = create_database_names_hash(
        output_structure
    )

    if JSON_OUTPUT_PRETTY_PRINT:
        output_json = json.dumps(output_structure, indent=2)
        # Python writes "NaN', Oracle expects "null".  Just replace it all
        output_json = output_json.replace("NaN", "null")
    else:
        output_json = simplejson.dumps(output_structure, ignore_nan=True)

    if write_file:
        write_to_file(os.path.join(current_path, output_file_name), output_json)

    logger.info(f"\nUpload file to: " + application_endpoint)

    logger.info(
        "\nEnd @ " + datetime.datetime.now(datetime.timezone.utc).isoformat() + " UTC\n"
    )

    return output_json


def main():
    global ALLOW_EXCLUDED, PLOT_UPLOAD_HTML, PLOT_UPLOAD_PNG

    argparser = argparse.ArgumentParser(
        prog="occa_Create_Import.py",
        description="Create json file to upload to OCCA Web",
    )
    argparser.add_argument(
        "--allow-excluded",
        type=str,
        action="store",
        nargs="*",
        help="Allow excluded databases and instances if those are detected",
    )
    argparser.add_argument(
        "--not-upload-plots",
        type=str,
        action="store",
        nargs="*",
        help="Disable uploading of PLOT files",
    )

    args = argparser.parse_args()

    if args.allow_excluded is not None:
        ALLOW_EXCLUDED = True
    if args.not_upload_plots is not None:
        PLOT_UPLOAD_HTML = False
        PLOT_UPLOAD_PNG = False

    create_input_json()


if __name__ == "__main__":
    main()
