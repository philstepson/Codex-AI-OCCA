"""
#
# Sample first cell
#
import os

os.environ['AWR_MINER_PATH']='/Users/tfrazier/Pycharm_NetworkTopology/results/cust-working-dir'
os.environ['AWR_MINER_PATH']='/Users/tfrazier/Pycharm_NetworkTopology/sizing/AWR_Miner_Examples/craft.01'

SHOW=True

TEMPLATE='ggplot2'
TEMPLATE='seaborn'
"""

import os
import cohort_folder_mapper
from version import version, __version__
from occa_Shared import  raise_error_when_run_from_api
from occa_build_analysis_snap_range import build_analysis_snaps_time


if "AWR_MINER_PATH" in os.environ:
    AWR_MINER_PATH = os.environ["AWR_MINER_PATH"]
else:
    AWR_MINER_PATH = os.getcwd()

# ---

try:
    if SHOW != "":
        pass

except:
    try:
        shell = get_ipython().__class__.__name__
        if shell == "ZMQInteractiveShell":
            SHOW = True  # Jupyter notebook or qtconsole
        elif shell == "TerminalInteractiveShell":
            SHOW = False  # Terminal running IPython
        else:
            SHOW = False  # Other type (?)
    except NameError:
        SHOW = False  # Probably standard Python interpreter

# ---

try:
    if TEMPLATE != "":
        pass
except:
    TEMPLATE = "seaborn"

# ---

if "SHOW_SOURCE_DATA" in os.environ:
    SHOW_SOURCE_DATA = (os.environ["SHOW_SOURCE_DATA"].upper()) == "Y"
else:
    SHOW_SOURCE_DATA = False

PERCENTILES = [0.80, 0.90, 0.95, 0.99]

# ---

import argparse
import datetime
import numpy as np
import pandas as pd
import platform
import plotly as plt
import plotly.graph_objects as go
import plotly.express as px
import pytz
import sys
import time

from occa_Shared import *
from collections import defaultdict
import occa_storage

"""

Type the following into cell before exporting as .html
po.init_notebook_mode() 

"""

# ----------------------------------------------------------------------------------------------------------------------

argparser = argparse.ArgumentParser(
    prog="awr_miner_plot.py",
    description="Print the results of script awr_miner_plot.py",
)

argparser.add_argument(
    "-v",
    "--version",
    type=str,
    action="store",
    nargs="*",
    help="Print the version of the script",
)
argparser.add_argument(
    "-p",
    "--parameters",
    type=str,
    action="store",
    nargs="*",
    help="Print the parameters used by the script",
)
argparser.add_argument(
    "-s",
    "--showsource",
    type=str,
    action="store",
    nargs="*",
    help="Show a summary of source data in chart captions",
)
argparser.add_argument(
    "-t",
    "--tz",
    type=str,
    action="store",
    nargs="*",
    help="Generate timezone files then stop",
)
argparser.add_argument(
    "-np",
    "--noplots",
    type=str,
    action="store",
    nargs="*",
    help="Skip the production of plots",
)
argparser.add_argument(
    "-d",
    "--data",
    type=str,
    action="store",
    nargs="*",
    help="Write the data for each figure to a file",
)

args = argparser.parse_args()

if args.version is not None:
    print(sys.argv[0] + " version: " + __version__)
    quit()

DATA = args.data is not None
PLOTTING = args.noplots is None
SHOW_SOURCE_DATA = args.showsource is not None

# ----------------------------------------------------------------------------------------------------------------------

OCCA_PATH = "awr_miner_occa"
SOURCE = "AWR_miner"

ADJUST_IBM_CORES = True
# ADJUST_IBM_CORES = False

COMPUTE_EFFECTIVE_VCPU = True
# COMPUTE_EFFECTIVE_VCPU = False

HEIGHT = 2200
WIDTH = 1920

DATA_TYPES = [
    "AVERAGE-ACTIVE-SESSIONS",
    "DATABASE-PARAMETERS",
    "DATABASE-PARAMETERS2",
    "IO-OBJECT-TYPE",
    "IO-WAIT-HISTOGRAM",
    "IOSTAT-BY-FUNCTION",
    "MAIN-METRICS",
    "MEMORY",
    "MEMORY-PGA-ADVICE",
    "MEMORY-SGA-ADVICE",
    "MODULE",
    "OS-INFORMATION",
    "OS-INFORMATION2",
    "OSSTAT",
    "PATCH-HISTORY",
    "SIZE-ON-DISK",
    "SNAP-HISTORY",
    "SNAP-HISTORY-TZ",
    "SQLNET-METRICS",
    "SYSSTAT",
    "TOP-N-TIMED-EVENTS",
    "TOP-SQL-BY-SNAPID",
    "TOP-SQL-SUMMARY",
]

OBJECT_TYPE_COLORS = {
    "INDEX": "navy",
    "LOB": "limegreen",
    "LOB PARTITION": "dodgerblue",
    "TABLE": "coral",
}

WAIT_CLASS_COLORS = {
    "Administrative": "rgb(251, 205,  74)",  # from OMC
    "Application": "rgb(237, 102,  71)",  # from OMC
    "Cluster": "gray",
    "Commit": "rgb(255, 181,  77)",  # from OMC
    "Concurrency": "rgb(185,  97, 203)",  # from OMC
    "Configuration": "rgb(247, 243, 123)",  # from OMC
    "CPU": "rgb(104, 193, 130)",  # from OMC
    "Network": "rgb( 71, 189, 239)",  # from OMC
    "Other": "rgb(227, 113, 178)",  # from OMC
    "Queueing": "rgb(162, 191,  57)",  # from OMC (Wait for CPU)
    "Scheduler": "rgb(209, 231, 204)",  # from OMC
    "System I/O": "rgb(109, 219, 219)",  # from OMC
    "User I/O": "rgb(  5, 112, 202)",  # from OMC
}

DATABASE_COLS = ["Allocated Storage (GB)"]
INSTANCE_COLS = [
    "DB vCPU",
    "DB PGA (MB)",
    "DB SGA (MB)",
    "DB Memory (MB)",
    "DB IOPS",
    "DB Logons",
]
PCT_COLS = ["max", "99%", "95%", "90%", "80%", "mean", "min"]

OCCA_ALIASES = {
    "SIZE_GB": "Allocated Storage (GB)",
    "USED_SIZE_GB": "Used Storage (GB)",
    "cpu_per_s": "DB vCPU",
    "PGA": "DB PGA (MB)",
    "SGA": "DB SGA (MB)",
    "SGAPGA": "DB Memory (MB)",
    "iops": "DB IOPS",
    "logons_total": "DB Logons",
}

PRECISION = 3
#
# For now
#
INCLUDE_OVERRIDES = False

# ---

dataDf, figs = {}, []
instancesDf, snapDf = [], []

cwd = os.getcwd().split(os.sep)[-1]
now = datetime.datetime.now(datetime.timezone.utc)
platformName = platform.system()
tb = time.time()
tsDisplay = now.strftime("%Y/%m/%d %H:%M:%S") + " UTC"

now = now.strftime("%Y-%m-%d %H:%M:%S")

# ----------------------------------------------------------------------------------------------------------------------


def lg(t):
    global logFile

    logFile.write(t + "\n")
    print(t)


# ---


def parseForFigure7(s):
    f = s["variable"].split(" ")

    event_name = ""
    for c in range(len(f) - 1):
        event_name += f[c] + " "
    event_name = event_name.strip()

    wait_time_milli = f[len(f) - 1]

    return event_name, wait_time_milli


# ----------------------------------------------------------------------------------------------------------------------


def printDf(lbl, dataFrameToPrint, rows=25, showTail=True):
    lg("\n" + lbl + " of len " + str(len(dataFrameToPrint)))
    lg("--------------------------------------------------")
    lg("index")
    lg("=====")

    for c in dataFrameToPrint.index.names:
        if c is None:
            lg("None")
        else:
            lg(str(c).ljust(45))

    lg("\ncolumns")
    lg("========")

    for c in sorted(dataFrameToPrint.columns):
        lg(str(c).ljust(45) + " : " + str(dataFrameToPrint[c].dtypes))

    lg("\nhead(" + str(rows) + ")")
    lg(str(dataFrameToPrint.head(rows)))

    if showTail:
        lg("\ntail(" + str(rows) + ")")
        lg(str(dataFrameToPrint.tail(rows)))

    lg("--------------------------------------------------")


# ----------------------------------------------------------------------------------------------------------------------

dataDf, ignoredFiles, whichDB, whichDBs = {}, [], "", []

os.makedirs(
    AWR_MINER_PATH + os.sep + "awr_miner_plots" + os.sep + "html", exist_ok=True
)
os.makedirs(AWR_MINER_PATH + os.sep + "awr_miner_plots" + os.sep + "csv", exist_ok=True)

logFile = open(
    AWR_MINER_PATH + os.sep + "awr_miner_plots" + os.sep + "awr_miner_plot.log", "a"
)

lg("awr_miner_plot.py, version: " + __version__)
lg("")
lg("sys.version_info          : " + str(sys.version_info))
lg("platform.system()         : " + str(platform.system()))
lg("pandas.__version__        : " + str(pd.__version__))
lg("plotly.__version__        : " + str(plt.__version__))
lg("pytz.__version__          : " + str(pytz.__version__))
lg("---------------------------------------------------")
lg("\n")

if args.parameters is not None:
    quit()

# ---

if not os.path.exists(AWR_MINER_PATH + os.sep + "awr_miner_parsed"):
    lg(
        "\n\nDirectory "
        + AWR_MINER_PATH
        + os.sep
        + "awr_miner_parsed does not exist; cannot continue"
    )

    assert False

# ---


def loadCSV(filePath, whichDB, whichType):
    global dataDf

    tb = time.time()

    try:
        if whichType == "MAIN-METRICS":
            # TODO: 'date_format' can be used once the compatibility with Pandas 1.5 is no longer required
            # 'date_parser' has been deprecated in Pandas 2.0
            df = pd.read_csv(filePath)
            # This casting has to be done to have compatibility on both Pandas 1.5 and 2.2
            df["end"] = pd.to_datetime(df["end"], format="%y/%m/%d %H:%M")
        elif whichType == "SNAP-HISTORY-TZ":
            df = pd.read_csv(filePath, parse_dates=["END_TIME"])
        else:
            df = pd.read_csv(filePath)
    except Exception as fc:
        lg("\n     Loading " + filePath + " resulted in exception " + str(fc) + "\n")
        return

    df.columns = [c.strip() for c in df.columns]
    df.drop_duplicates(inplace=True)

    df["WHICH_DB"] = whichDB

    if len(dataDf) == 0 or whichType not in dataDf:
        dataDf[whichType] = df

    else:
        dataDf[whichType] = pd.concat([dataDf[whichType], df], ignore_index=True)
        dataDf[whichType].drop_duplicates(inplace=True)

    # lg('     Loaded ' + str(len(df)) + ' rows in ' + str(round(time.time() - tb, 3)) + ' s from ' + filePath)


# ---

db = ""

# Check if awr_miner_parsed directory is empty
if not os.listdir(AWR_MINER_PATH + os.sep + "awr_miner_parsed"):
    lg(
        "\n====================================================================================================================="
    )
    lg("ERROR : awr_miner_parsed directory is empty.\n")
    lg("Either prereq command occa --awr-parse has not been executed yet")
    lg("or all the files in this collection have been rejected at awr-parse time.")
    lg(
        "====================================================================================================================="
    )
    sys.exit()

for subdir, dirs, files in os.walk(AWR_MINER_PATH + os.sep + "awr_miner_parsed"):

    pieces = subdir.split(os.sep)

    if pieces[len(pieces) - 1].startswith("db_"):
        db = pieces[len(pieces) - 1]
        lg("Found DB " + db + "...")

        continue

    if pieces[len(pieces) - 1].startswith("awr-hist-"):
        if db == "":
            lg(
                "Unexpected directory structure error; continuing until next DB directory"
            )
            continue

        snap_range = pieces[len(pieces) - 1].split("-")
        whichDB = (
            db
            + "-"
            + snap_range[len(snap_range) - 2]
            + "-"
            + snap_range[len(snap_range) - 1]
        )

        # print('snap_range: ' + str(snap_range))
        # print('whichDB   : ' + str(whichDB))

        lg("   Loading files for snap range" + whichDB + "...")

    if len(files) == 0:
        # lg('Ignoring non-file directory ' + subdir)
        continue

    elif whichDB == "":
        lg("whichDB not established; ignoring directory " + subdir)
        continue

    # lg('whichDB: ' + whichDB + ', files: ' + str(files))

    ctr = 0
    for file in files:
        whichType = file.replace(".csv", "")

        if whichType in DATA_TYPES:
            loadCSV(os.path.join(subdir, file), whichDB, whichType)
            ctr += 1
        else:
            ignoredFiles.append(file)

    if ctr > 0:
        whichDBs.append(whichDB)

# ---

dbDf = dataDf["OS-INFORMATION"][dataDf["OS-INFORMATION"]["STAT_NAME"] == "DB_NAME"][
    ["WHICH_DB", "STAT_VALUE", "snap_id_start", "snap_id_end"]
]
dbDf.rename(columns={"STAT_VALUE": "DB_NAME"}, inplace=True)

# ---

summaryDf = []
for k in dataDf:
    df = dataDf[k].copy()
    df["SOURCE"] = k
    df["rows"] = 1
    df = df.groupby(["WHICH_DB", "SOURCE"], as_index=False)[["rows"]].count()
    df = pd.merge(
        left=df, right=dbDf, how="left", left_on=["WHICH_DB"], right_on=["WHICH_DB"]
    )

    summaryDf = (
        df if len(summaryDf) == 0 else pd.concat([summaryDf, df], ignore_index=True)
    )

summaryDf = summaryDf[
    ["WHICH_DB", "DB_NAME", "snap_id_start", "snap_id_end", "SOURCE", "rows"]
]
summaryDf["cwd"] = cwd
summaryDf["platform"] = platformName
summaryDf["create_dttm_utc"] = now
summaryDf["version"] = __version__

filename = (
    AWR_MINER_PATH
    + os.sep
    + "awr_miner_plots"
    + os.sep
    + "csv"
    + os.sep
    + "00_source_row_counts.csv"
)
occa_storage.to_csv(
    summaryDf.sort_values(["DB_NAME", "snap_id_start", "SOURCE"]), filename, index=False
)

lg("\nWrote row counts to file " + filename)

# ----------------------------------------------------------------------------------------------------------------------

u = set(whichDBs)
whichDBs = list(u)
whichDBs = sorted(whichDBs)

instancesDf = []
occaDf = {}
sources = {}
fatalErrors = {}

# whichDB loop to assemble instances into a single dataframe.  Result is in instanceDf
for whichDB in whichDBs:
    abandonDB = False

    if DATA:
        DATA_PATH = (
            AWR_MINER_PATH
            + os.sep
            + "awr_miner_plots"
            + os.sep
            + "data"
            + os.sep
            + whichDB
        )
        os.makedirs(DATA_PATH, exist_ok=True)

    if len(dbDf[dbDf["WHICH_DB"] == whichDB]) == 0:
        if whichDB not in fatalErrors:
            fatalErrors[whichDB] = []

        fatalErrors[whichDB].append(
            "Unable to parse the data frame that starts ~~BEGIN-OS-INFORMATION~~ in the .out file for "
            + whichDB
        )

        abandonDB = True
        continue

    # ---

    DB_NAME = dbDf[dbDf["WHICH_DB"] == whichDB]["DB_NAME"].values[0]
    sources[whichDB] = []

    df = (
        []
        if "OS-INFORMATION2" not in dataDf
        else dataDf["OS-INFORMATION2"][dataDf["OS-INFORMATION2"]["WHICH_DB"] == whichDB]
    )

    if "OS-INFORMATION2" in dataDf:
        sources[whichDB].append("OS-INFORMATION2")
    else:
        sources[whichDB].append("OS-INFORMATION")

    if len(df) > 0:
        # Use OS-INFORMATION2 to extract instance data
        instDf = df[df["INSTANCE"] > 0].copy()

        platformDf = df[df["STAT_NAME"] == "PLATFORM_NAME"][["STAT_VALUE"]]
        versionDf = df[df["STAT_NAME"] == "VERSION"][["STAT_VALUE"]]

        try:
            # filename = AWR_MINER_PATH + os.sep + 'awr_miner_plots' + os.sep + 'before_pivot.csv'
            # occa_storage.to_csv(instDf, filename, index=False)
            instDf = pd.pivot(
                instDf, index="INSTANCE", columns=["STAT_NAME"], values="STAT_VALUE"
            ).reset_index()
        except Exception as fc:
            filename = (
                AWR_MINER_PATH
                + os.sep
                + "awr_miner_plots"
                + os.sep
                + "duplicates_"
                + whichDB
                + ".csv"
            )
            lg("\n\n" + str(fc) + " was raised; writing file to " + filename)
            occa_storage.to_csv(instDf, filename, index=False)

            assert False

        cols = ["INSTANCE"]

        try:
            cpuPlatform = platformDf[["STAT_VALUE"]].to_numpy()[0][0]
        except:
            cpuPlatform = ""

        try:

            if "NUM_CPUS" not in instDf:
                if "!CPU_COUNT" in instDf:
                    instDf["NUM_CPUS"] = instDf["!CPU_COUNT"]
                else:
                    if whichDB not in fatalErrors:
                        fatalErrors[whichDB] = []

                    fatalErrors[whichDB].append(
                        "A value for NUM_CPUS is missing, for an INSTANCE > 0, from the frame that starts ~~BEGIN-OS-INFORMATION2~~ in the .out file for "
                        + whichDB
                    )
                    abandonDB = True

            # Check for NANs per instance
            if instDf["NUM_CPUS"].isnull().values.any():
                if whichDB not in fatalErrors:
                    fatalErrors[whichDB] = []

                fatalErrors[whichDB].append(
                    "A value for NUM_CPUS is Nan, for an INSTANCE > 0, from the frame that starts ~~BEGIN-OS-INFORMATION2~~ in the .out file for "
                    + whichDB
                )
                abandonDB = True

            if "NUM_CPU_CORES" not in instDf:
                if "!CPU_CORE_COUNT" in instDf:
                    instDf["NUM_CPU_CORES"] = instDf["!CPU_CORE_COUNT"]
                elif "NUM_CPUS" in instDf and cpuPlatform.upper().find("ZSERIES") > -1:
                    instDf["NUM_CPU_CORES"] = instDf["NUM_CPUS"]
                else:
                    if whichDB not in fatalErrors:
                        fatalErrors[whichDB] = []

                    fatalErrors[whichDB].append(
                        "A value for NUM_CPU_CORES is missing, for an INSTANCE > 0, from the frame that starts ~~BEGIN-OS-INFORMATION2~~ in the .out file for "
                        + whichDB
                    )
                    abandonDB = True

            if "HOSTS" in instDf:
                cols.append("HOSTS")
            if "NUM_CPUS" in instDf:
                cols.append("NUM_CPUS")
            if "NUM_CPU_CORES" in instDf:
                cols.append("NUM_CPU_CORES")
            if "NUM_CPU_SOCKETS" in instDf:
                cols.append("NUM_CPU_SOCKETS")
            if "PHYSICAL_MEMORY_GB" in instDf:
                cols.append("PHYSICAL_MEMORY_GB")

            instDf = instDf[cols]

            # OS_INFORMATION2 calls it HOSTS, OS_INFORMATION calls it HOST
            # It's a singular here, so call it HOST for when the two dfs are appended
            if "HOSTS" in instDf:
                instDf.rename(columns={"HOSTS": "HOST"}, inplace=True)

            if not abandonDB:
                if "NUM_CPUS" in instDf:
                    instDf["NUM_CPUS"] = instDf["NUM_CPUS"].astype(int)
                if "NUM_CPU_CORES" in instDf:
                    instDf["NUM_CPU_CORES"] = instDf["NUM_CPU_CORES"].astype(int)
                    instDf["NUM_CPU_SOCKETS"] = instDf["NUM_CPU_CORES"].astype(int)

        except Exception as fc:
            filename = (
                AWR_MINER_PATH
                + os.sep
                + "awr_miner_plots"
                + os.sep
                + "bad_instances_"
                + whichDB
                + ".csv"
            )
            lg("\n\n" + str(fc) + " was raised; writing file to " + filename)
            occa_storage.to_csv(instDf, filename, index=False)

            assert False

        if abandonDB:
            continue

        # ---

        if len(platformDf) > 0:
            instDf = pd.merge(left=instDf, right=platformDf, how="cross")
            instDf.rename(columns={"STAT_VALUE": "PLATFORM_NAME"}, inplace=True)

        if len(versionDf) > 0:
            instDf = pd.merge(left=instDf, right=versionDf, how="cross")
            instDf.rename(columns={"STAT_VALUE": "VERSION"}, inplace=True)

    else:
        # else use OS-INFORMATION to get instance data
        df = dataDf["OS-INFORMATION"][dataDf["OS-INFORMATION"]["WHICH_DB"] == whichDB]

        platformDf = df[df["STAT_NAME"] == "PLATFORM_NAME"][["STAT_VALUE"]]
        versionDf = df[df["STAT_NAME"] == "VERSION"][["STAT_VALUE"]]

        try:
            instances = int(df[df["STAT_NAME"] == "INSTANCES"]["STAT_VALUE"].values[0])
        except Exception as fc:
            lg(str(fc) + " raised reading INSTANCES count; cannot continue")
            assert False

        # ---

        missingStats = {}

        try:
            numCPUs = int(df[df["STAT_NAME"] == "NUM_CPUS"]["STAT_VALUE"].values[0])
        except Exception as fc:
            missingStats["NUM_CPUS"] = True

        try:
            numCores = int(
                df[df["STAT_NAME"] == "NUM_CPU_CORES"]["STAT_VALUE"].values[0]
            )
        except Exception as fc:
            missingStats["NUM_CPU_CORES"] = True

        try:
            numSockets = int(
                df[df["STAT_NAME"] == "NUM_CPU_SOCKETS"]["STAT_VALUE"].values[0]
            )
        except:
            missingStats["NUM_CPU_SOCKETS"] = False
            numSockets = -1

        try:
            memoryGB = float(
                df[df["STAT_NAME"] == "PHYSICAL_MEMORY_GB"]["STAT_VALUE"].values[0]
            )
        except:
            missingStats["PHYSICAL_MEMORY_GB"] = False
            memoryGB = 0

        try:
            hosts = df[df["STAT_NAME"] == "HOSTS"]["STAT_VALUE"].values[0].split(",")
        except:
            missingStats["HOSTS"] = False
            hosts = []

        fail = False

        if len(missingStats) > 0:
            lg(
                f"\nThe following values are missing from OS-INFORMATION for db {whichDB}"
            )
            lg("----------------------------------------------------")
            error_separated = (
                f"The following values are missing from OS-INFORMATION for db {whichDB}"
            )
            for m in missingStats:
                # Don't want the 20X white space characters space
                # into the STATUS column table for each missing stat
                lg(m.ljust(20) + ", Catastrophic? " + str(missingStats[m]))
                error_separated += str(missingStats[m])
                if missingStats[m]:
                    fail = True

        if fail:
            raise_error_when_run_from_api("AWR: ",error_separated.strip())
            quit()

        if (
            "MAIN-METRICS" in dataDf
            and len(
                dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            )
            > 0
        ):
            instanceNumbers = sorted(
                dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB][
                    "inst"
                ].unique()
            )
        else:
            instanceNumbers = range(instances)

        instDf = []
        for i in range(instances):
            h = "" if i >= len(hosts) else hosts[i]

            df = pd.DataFrame(
                [[instanceNumbers[i], h, numCPUs, numCores, numSockets, memoryGB]],
                columns=[
                    "INSTANCE",
                    "HOST",
                    "NUM_CPUS",
                    "NUM_CPU_CORES",
                    "NUM_CPU_SOCKETS",
                    "PHYSICAL_MEMORY_GB",
                ],
            )
            instDf = df if len(instDf) == 0 else pd.concat([instDf, df])

        # ---

        if len(platformDf) > 0:
            instDf = pd.merge(left=instDf, right=platformDf, how="cross")
            instDf.rename(columns={"STAT_VALUE": "PLATFORM_NAME"}, inplace=True)

        if len(versionDf) > 0:
            instDf = pd.merge(left=instDf, right=versionDf, how="cross")
            instDf.rename(columns={"STAT_VALUE": "VERSION"}, inplace=True)

    # End of OS-INFORMATION|OS-INFORMATION2 block

    # ---
    df = (
        []
        if "DATABASE-PARAMETERS2" not in dataDf
        else dataDf["DATABASE-PARAMETERS2"][
            dataDf["DATABASE-PARAMETERS2"]["WHICH_DB"] == whichDB
        ]
    )

    if "DATABASE-PARAMETERS2" in dataDf:
        sources[whichDB].append("DATABASE-PARAMETERS2")
    else:
        sources[whichDB].append("DATABASE-PARAMETERS")

    if len(df) > 0:
        df = df[df["PARAMETER_NAME"].isin(["cpu_count", "cpu_min_count"])][
            ["INSTANCE_NUMBER", "PARAMETER_NAME", "VALUE"]
        ]

        if len(df) == 0:
            instDf["cpu_count"] = 0
            instDf["cpu_min_count"] = 0

        else:
            df = pd.pivot_table(
                df,
                index="INSTANCE_NUMBER",
                columns="PARAMETER_NAME",
                values="VALUE",
                aggfunc="min",
            ).reset_index()
            instDf = pd.merge(
                left=instDf,
                right=df,
                how="left",
                left_on=["INSTANCE"],
                right_on=["INSTANCE_NUMBER"],
            )

            if "cpu_count" in instDf:
                instDf["cpu_count"] = instDf["cpu_count"].fillna(0).astype(int)
            else:
                instDf["cpu_count"] = 0

            if "cpu_min_count" in instDf:
                instDf["cpu_min_count"] = instDf["cpu_min_count"].fillna(0).astype(int)
            else:
                instDf["cpu_min_count"] = 0

            instDf.drop(columns=["INSTANCE_NUMBER"], inplace=True)

    else:
        df = (
            []
            if "DATABASE-PARAMETERS" not in dataDf
            else dataDf["DATABASE-PARAMETERS"][
                dataDf["DATABASE-PARAMETERS"]["WHICH_DB"] == whichDB
            ]
        )

        if len(df) == 0:
            instDf["cpu_count"] = 0
            instDf["cpu_min_count"] = 0

        else:
            df = df[df["PARAMETER_NAME"].isin(["cpu_count", "cpu_min_count"])][
                ["PARAMETER_NAME", "VALUE"]
            ]
            df = pd.pivot_table(
                df, columns="PARAMETER_NAME", values="VALUE", aggfunc="min"
            )

            instDf["cpu_count"] = (
                int(df["cpu_count"].values[0]) if "cpu_count" in df else 0
            )
            instDf["cpu_min_count"] = (
                int(df["cpu_min_count"].astype(float).values[0])
                if "cpu_min_count" in df
                else 0
            )

    # ---

    df = (
        []
        if "MEMORY" not in dataDf
        else dataDf["MEMORY"][dataDf["MEMORY"]["WHICH_DB"] == whichDB]
    )

    if "MEMORY" in dataDf:
        sources[whichDB].append("MEMORY")

        occaCols = ["WHICH_DB", "SNAP_ID", "INSTANCE_NUMBER", "SGA", "PGA", "TOTAL"]
        _ = df[occaCols].copy()
        _["DB_NAME"] = DB_NAME
        _.rename(columns={"TOTAL": "SGAPGA"}, inplace=True)
        occaDf["MEMORY"] = (
            _
            if "MEMORY" not in occaDf
            else pd.concat([occaDf["MEMORY"], _], ignore_index=True)
        )

    if len(df) > 0:
        snapIdMax = df["SNAP_ID"].max()

        memoryDf = df[df["SNAP_ID"] == snapIdMax][
            ["INSTANCE_NUMBER", "SGA", "PGA", "TOTAL"]
        ].copy()
        memoryDf.rename(
            columns={"INSTANCE_NUMBER": "INSTANCE", "TOTAL": "SGA + PGA"}, inplace=True
        )

        instDf = pd.merge(
            left=instDf,
            right=memoryDf,
            how="left",
            left_on=["INSTANCE"],
            right_on=["INSTANCE"],
        )

    # ---

    df = (
        []
        if "MAIN-METRICS" not in dataDf
        else dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
    )

    if "MAIN-METRICS" in dataDf:
        sources[whichDB].append("MAIN-METRICS")

        occaCols = [
            "WHICH_DB",
            "dur_m",
            "snap",
            "end",
            "inst",
            "cpu_per_s",
            "logons_total",
            "os_cpu",
        ]
        _ = df[occaCols].copy()
        _["DB_NAME"] = DB_NAME
        _.rename(columns={"snap": "SNAP_ID", "inst": "INSTANCE_NUMBER"}, inplace=True)
        occaDf["CPU"] = (
            _
            if "CPU" not in occaDf
            else pd.concat([occaDf["CPU"], _], ignore_index=True)
        )

    # ---

    df = (
        []
        if "SQLNET-METRICS" not in dataDf
        else dataDf["SQLNET-METRICS"][dataDf["SQLNET-METRICS"]["WHICH_DB"] == whichDB]
    )

    if "SQLNET-METRICS" in dataDf:
        sources[whichDB].append("SQLNET-METRICS")

    if len(df) > 0:
        df = df.copy()
        df = df[
            [
                "inst",
                "snap",
                "rqsts_to_from_client",
                "sqlnet_bytes_received_from_client",
                "sqlnet_bytes_sent_to_client",
            ]
        ]
        df = pd.melt(df, id_vars=["inst", "snap"])
        df["value"] = df["value"].fillna(0).astype(int)
        #
        #       Protect against a counter reset mid-snap
        #
        df2 = df.copy()
        df2["snap"] = df2["snap"] - 1
        df.rename(columns={"value": "shifted"}, inplace=True)
        df = pd.merge(
            left=df2,
            right=df,
            how="left",
            left_on=["inst", "snap", "variable"],
            right_on=["inst", "snap", "variable"],
        )
        df["diff"] = df["value"] - df["shifted"]
        #
        #       Throw-out any resets
        #
        df = df[df["diff"] >= 0]
        df = df.groupby(["inst", "variable"], as_index=False)["diff"].sum()

        df.loc[df["variable"].str.find("bytes") > -1, "diff"] = df["diff"] / 1024**3
        df.loc[df["variable"].str.find("bytes") > -1, "variable"] = df[
            "variable"
        ].str.replace("bytes", "GB")

        df["diff"] = df["diff"].round(3)
        df.columns = ["INSTANCE", "variable", "value"]

        if (
            "MAIN-METRICS" in dataDf
            and len(
                dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            )
            > 0
        ):
            daysShown = (
                dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB][
                    "end"
                ].max()
                - dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB][
                    "end"
                ].min()
            ).total_seconds() / (24 * 60 * 60)

            sqlNetAvgDf = df.copy()
            sqlNetAvgDf["value"] = sqlNetAvgDf["value"] / daysShown
            sqlNetAvgDf["value"] = round(sqlNetAvgDf["value"], 3)
            sqlNetAvgDf["variable"] = sqlNetAvgDf["variable"] + " (daily avg)"

            sqlNetDf = pd.concat([df, sqlNetAvgDf], ignore_index=True)
            sqlNetDf = pd.pivot(
                sqlNetDf, index=["INSTANCE"], columns=["variable"], values="value"
            ).reset_index()

            instDf = pd.merge(
                left=instDf,
                right=sqlNetDf,
                how="left",
                left_on=["INSTANCE"],
                right_on=["INSTANCE"],
            )

    # End of WHICH_DB loop
    # ---

    instDf["WHICH_DB"] = whichDB
    instancesDf = (
        instDf
        if len(instancesDf) == 0
        else pd.concat([instancesDf, instDf], ignore_index=True)
    )

    if DATA:
        filename = DATA_PATH + os.sep + "instDf.csv"
        occa_storage.to_csv(instDf, filename, index=False)
        lg(("Wrote file " + filename))

    if 1 == 0:
        printDf("669 instancesDf", instancesDf, showTail=False)

# ---

if "AVERAGE-ACTIVE-SESSIONS" in dataDf:
    dataDf["AVERAGE-ACTIVE-SESSIONS"]["WAIT_CLASS"] = dataDf["AVERAGE-ACTIVE-SESSIONS"][
        "WAIT_CLASS"
    ].str.rstrip()
    dataDf["AVERAGE-ACTIVE-SESSIONS"].loc[
        dataDf["AVERAGE-ACTIVE-SESSIONS"]["WAIT_CLASS"] == "DB CPU", "WAIT_CLASS"
    ] = "CPU"

if "TOP-N-TIMED-EVENTS" in dataDf:
    dataDf["TOP-N-TIMED-EVENTS"]["WAIT_CLASS"] = dataDf["TOP-N-TIMED-EVENTS"][
        "WAIT_CLASS"
    ].str.rstrip()
    dataDf["TOP-N-TIMED-EVENTS"]["EVENT_NAME"] = dataDf["TOP-N-TIMED-EVENTS"][
        "EVENT_NAME"
    ].str.rstrip()

    dataDf["TOP-N-TIMED-EVENTS"].loc[
        dataDf["TOP-N-TIMED-EVENTS"]["WAIT_CLASS"] == "DB CPU", "WAIT_CLASS"
    ] = "CPU"
    dataDf["TOP-N-TIMED-EVENTS"].loc[
        dataDf["TOP-N-TIMED-EVENTS"]["EVENT_NAME"] == "DB CPU", "EVENT_NAME"
    ] = "CPU"

if "MAIN-METRICS" in dataDf:
    snapDf = dataDf["MAIN-METRICS"][
        ["inst", "snap", "end", "dur_m", "WHICH_DB", "snap_id_start", "snap_id_end"]
    ].drop_duplicates()
    #
    #   snapDf will be used in charts below; inst is not needed
    #
    snapDf = dataDf["MAIN-METRICS"][
        ["snap", "end", "dur_m", "WHICH_DB", "snap_id_start", "snap_id_end"]
    ].drop_duplicates()

else:
    snapDf = []

# ---
if len(instancesDf) == 0:
    # All files were excluded for some reason.  Quit.
    lg("All files excluded.  Exiting main loop.")
    error_separated = "All files excluded.  Exiting main loop."
    if len(fatalErrors) > 0:
        lg(
            "\n\n------------------------------------------------------------------------------------------------------------\n"
        )
        lg(
            "The following fatal were encountered in processing your files; the databases are not included in the results"
        )
        error_separated += "Fatal errors: "
        for _ in fatalErrors:
            lg("\nDatabase " + _)
            lg("--------------------------------------------")

            for m in fatalErrors[_]:
                error_separated += f"db: {_} : {m}"
                lg(m)

        lg(
            "\n------------------------------------------------------------------------------------------------------------\n\n"
        )
    # Should be a return, but this in the global scope, so exit.  Don't want to put the next 2k+ lines in a else
    # statement creating a big diff, at least not yet.
    instancesDf = pd.DataFrame(
        columns=["WHICH_DB", "PLATFORM_NAME", "INSTANCE", "HOST"]
    )
    raise_error_when_run_from_api("AWR: ",error_separated.strip())
    sys.exit()

instancesDf = pd.merge(
    left=instancesDf,
    right=dbDf,
    how="left",
    left_on=["WHICH_DB"],
    right_on=["WHICH_DB"],
)
instancesDf.drop_duplicates(inplace=True)

if "HOSTS" in instancesDf:
    instancesDf.rename(columns={"HOSTS": "HOST"}, inplace=True)

instancesDf["cpu_type"] = instancesDf.apply(
    lambda r: getCPUType(r["PLATFORM_NAME"], ""), axis=1
)

cols = ["WHICH_DB", "DB_NAME", "INSTANCE", "HOST", "snap_id_start", "snap_id_end"]

for c in sorted(instancesDf.columns):
    if c not in cols:
        cols.append(c)
instancesDf = instancesDf[cols]

filename = (
    AWR_MINER_PATH
    + os.sep
    + "awr_miner_plots"
    + os.sep
    + "csv"
    + os.sep
    + "00_instances.csv"
)

instancesDf["cwd"] = cwd
instancesDf["platform"] = platformName
instancesDf["create_dttm_utc"] = now
instancesDf["version"] = __version__
occa_storage.to_csv(
    instancesDf.sort_values(["DB_NAME", "snap_id_start", "INSTANCE"]),
    filename,
    index=False,
)

lg("\nWrote instance configuration & summary telemetry to file " + filename)

# ---

if COMPUTE_EFFECTIVE_VCPU:
    _ = instancesDf[instancesDf["cpu_type"].isin(VCPU_REDUCABLE_CPU_TYPES)]

    if len(_) == 0:
        lg(
            "\nThere are no cpu_types that require host utilization-based vCPU reduction"
        )
        COMPUTE_EFFECTIVE_VCPU = False

# ---

if COMPUTE_EFFECTIVE_VCPU:
    hostCPUEffectiveDf = instancesDf[
        [
            "WHICH_DB",
            "INSTANCE",
            "HOST",
            "cpu_type",
            "NUM_CPU_CORES",
            "NUM_CPUS",
            "PLATFORM_NAME",
        ]
    ].drop_duplicates()
    hostCPUEffectiveDf.columns = [
        "WHICH_DB",
        "INSTANCE",
        "host",
        "cpu_type",
        "total_cpu_cores",
        "logical_cpu_count",
        "PLATFORM_NAME",
    ]

    hostCPUEffectiveDf["logical_cpu_count_effective"] = hostCPUEffectiveDf.apply(
        lambda r: logical_cpu_count_effective(
            r["cpu_type"], r["total_cpu_cores"], r["logical_cpu_count"]
        ),
        axis=1,
    )

    # ---
    if "CPU" in occaDf and len(occaDf["CPU"]) > 0:
        hostCPUEffectiveDict = {}
        hostCPUEffectiveDf["host"] = hostCPUEffectiveDf["host"].fillna("NoneHost")
        for index, row in hostCPUEffectiveDf.iterrows():
            hostCPUEffectiveDict[row["WHICH_DB"] + "." + row["host"]] = row[
                "logical_cpu_count_effective"
            ]

        hostMetricsDf = pd.merge(
            left=hostCPUEffectiveDf[
                [
                    "WHICH_DB",
                    "host",
                    "INSTANCE",
                    "cpu_type",
                    "logical_cpu_count",
                    "total_cpu_cores",
                ]
            ],
            right=occaDf["CPU"][["WHICH_DB", "INSTANCE_NUMBER", "end", "os_cpu"]],
            how="inner",
            left_on=["WHICH_DB", "INSTANCE"],
            right_on=["WHICH_DB", "INSTANCE_NUMBER"],
        )

        hostMetricsDf.rename(columns={"os_cpu": "AVERAGE"}, inplace=True)

        hostMetricsDf["AVERAGE_logical_cpu_count"] = round(
            hostMetricsDf["logical_cpu_count"] * (hostMetricsDf["AVERAGE"] / 100),
            PRECISION,
        )

        hostMetricsDf["logical_cpu_count_effective"] = hostMetricsDf.apply(
            lambda r: getEffectivehostCPU(
                hostCPUEffectiveDict,
                r["WHICH_DB"] + "." + r["host"],
                r["AVERAGE_logical_cpu_count"],
            ),
            axis=1,
        )
        hostMetricsDf["logical_cpu_count_effective"] = round(
            hostMetricsDf["logical_cpu_count_effective"], PRECISION
        )

        hostMetricsDf["AVERAGE_logical_cpu_count_floor"] = hostMetricsDf[
            "AVERAGE_logical_cpu_count"
        ].apply(math.floor)
        hostMetricsDf["effective_o_AVERAGE_pct"] = round(
            (
                hostMetricsDf["logical_cpu_count_effective"]
                / hostMetricsDf["AVERAGE_logical_cpu_count"]
            )
            * 100,
            PRECISION,
        )

        # ---

        occaDf["CPU"] = pd.merge(
            left=occaDf["CPU"],
            right=hostMetricsDf[
                [
                    "WHICH_DB",
                    "host",
                    "INSTANCE_NUMBER",
                    "end",
                    "effective_o_AVERAGE_pct",
                ]
            ],
            how="inner",
            left_on=["WHICH_DB", "INSTANCE_NUMBER", "end"],
            right_on=["WHICH_DB", "INSTANCE_NUMBER", "end"],
        )

        occaDf["CPU"]["cpu_per_s_original"] = occaDf["CPU"]["cpu_per_s"]
        occaDf["CPU"].loc[
            occaDf["CPU"]["effective_o_AVERAGE_pct"] < 100, "cpu_per_s"
        ] = round(
            occaDf["CPU"]["cpu_per_s"]
            * (occaDf["CPU"]["effective_o_AVERAGE_pct"] / 100),
            PRECISION,
        )

        if 1 == 0:
            filename = (
                AWR_MINER_PATH
                + os.sep
                + "awr_miner_plots"
                + os.sep
                + "csv"
                + os.sep
                + "00_occa_789.csv"
            )
            to_csv(
                occaDf["CPU"].sort_values(["WHICH_DB", "INSTANCE_NUMBER", "end"]),
                filename,
                index=False,
            )
            lg("\nWrote file " + filename)

        if len(occaDf["CPU"]["effective_o_AVERAGE_pct"] < 100) > 0:
            _ = occaDf["CPU"][occaDf["CPU"]["effective_o_AVERAGE_pct"] < 100][
                ["WHICH_DB", "INSTANCE_NUMBER", "end", "effective_o_AVERAGE_pct"]
            ]

            dataDf["MAIN-METRICS"] = pd.merge(
                left=dataDf["MAIN-METRICS"],
                right=_,
                how="left",
                left_on=["WHICH_DB", "inst", "end"],
                right_on=["WHICH_DB", "INSTANCE_NUMBER", "end"],
            )
            dataDf["MAIN-METRICS"]["effective_o_AVERAGE_pct"] = dataDf["MAIN-METRICS"][
                "effective_o_AVERAGE_pct"
            ].fillna(100)
            dataDf["MAIN-METRICS"].loc[
                dataDf["MAIN-METRICS"]["effective_o_AVERAGE_pct"] < 100, "cpu_per_s"
            ] = round(
                dataDf["MAIN-METRICS"]["cpu_per_s"]
                * dataDf["MAIN-METRICS"]["effective_o_AVERAGE_pct"]
                / 100,
                PRECISION,
            )
            dataDf["MAIN-METRICS"].drop(
                columns=["INSTANCE_NUMBER", "effective_o_AVERAGE_pct"], inplace=True
            )

        # ---

        hostMetricsDf.rename(columns={"end": "ROLLUP_TIMESTAMP_UTC"}, inplace=True)

        hostMetricsDf["host_target_guid"] = (
            hostMetricsDf["WHICH_DB"] + "." + hostMetricsDf["host"]
        )
        hostMetricsDf = hostMetricsDf[
            [
                "host_target_guid",
                "host",
                "cpu_type",
                "total_cpu_cores",
                "logical_cpu_count",
                "ROLLUP_TIMESTAMP_UTC",
                "AVERAGE",
                "AVERAGE_logical_cpu_count",
                "logical_cpu_count_effective",
                "AVERAGE_logical_cpu_count_floor",
                "effective_o_AVERAGE_pct",
            ]
        ]

        hostMetricsDf["cwd"] = cwd
        hostMetricsDf["platform"] = platformName
        hostMetricsDf["extract_dttm_utc"] = now
        hostMetricsDf["create_dttm_utc"] = now
        hostMetricsDf["source"] = SOURCE
        hostMetricsDf["shared_version"] = SHARED_VERSION
        hostMetricsDf["version"] = __version__

        filename = (
            AWR_MINER_PATH
            + os.sep
            + "awr_miner_plots"
            + os.sep
            + "csv"
            + os.sep
            + "00_host_effective_cpu_metrics.csv"
        )
        occa_storage.to_csv(
            hostMetricsDf.sort_values(["host", "ROLLUP_TIMESTAMP_UTC"]),
            filename,
            index=False,
        )
        lg("\nWrote file " + filename)

    hostCPUEffectiveDf = hostCPUEffectiveDf[
        [
            "host",
            "cpu_type",
            "total_cpu_cores",
            "logical_cpu_count",
            "logical_cpu_count_effective",
            "PLATFORM_NAME",
            "WHICH_DB",
        ]
    ]

    hostCPUEffectiveDf["cwd"] = cwd
    hostCPUEffectiveDf["platform"] = platformName
    hostCPUEffectiveDf["extract_dttm_utc"] = now
    hostCPUEffectiveDf["create_dttm_utc"] = now
    hostCPUEffectiveDf["source"] = SOURCE
    hostCPUEffectiveDf["shared_version"] = SHARED_VERSION
    hostCPUEffectiveDf["version"] = __version__

    filename = (
        AWR_MINER_PATH
        + os.sep
        + "awr_miner_plots"
        + os.sep
        + "csv"
        + os.sep
        + "00_host_effective_cpu.csv"
    )
    occa_storage.to_csv(hostCPUEffectiveDf.sort_values(["host"]), filename, index=False)

    lg("\nWrote file " + filename)

# ---

if "MAIN-METRICS" in dataDf and len(dataDf["MAIN-METRICS"]) > 0:
    df = pd.merge(
        left=dataDf["MAIN-METRICS"],
        right=instancesDf[["WHICH_DB", "INSTANCE", "HOST", "cpu_type", "cpu_count"]],
        how="left",
        left_on=["WHICH_DB", "inst"],
        right_on=["WHICH_DB", "INSTANCE"],
    )

    _ = []

    for c in ["os_cpu", "os_cpu_max", "cpu_per_s", "h_cpu_per_s"]:
        if c in df and df[c].dtype != "float64":
            try:
                df[c] = df[c].astype(float)
            except ValueError:
                _.append(c)

    if len(_) > 0:
        lg(
            "\nThe following columns in the MAIN-METRICS section, "
            + str(_)
            + ", have a datatype other than float64."
        )
        lg(
            "A possible cause is the presence of non-US numeric separators in the original awr.out files. Cannot continue."
        )
        error_separated = f"The following columns in the MAIN-METRICS section, ' {str(_)} ', have a datatype other than float64."
        raise_error_when_run_from_api("AWR: ",error_separated.strip())
        quit()

    if ADJUST_IBM_CORES:
        df.loc[(df["cpu_type"] == "IBM"), "os_cpu"] = round(
            df["os_cpu"] * AIX_DEFLATION, PRECISION
        )
        df.loc[(df["cpu_type"] == "IBM"), "os_cpu_max"] = round(
            df["os_cpu_max"] * AIX_DEFLATION, PRECISION
        )
        df.loc[(df["cpu_type"] == "IBM"), "cpu_per_s"] = round(
            df["cpu_per_s"] * AIX_DEFLATION, PRECISION
        )
        df.loc[(df["cpu_type"] == "IBM"), "h_cpu_per_s"] = round(
            df["h_cpu_per_s"] * AIX_DEFLATION, PRECISION
        )

    # ---

    badVCPUDf = df[
        df["cpu_per_s"] > df["cpu_count"] * (1 + (CPU_CAGING_ERROR_BAR_PCT / 100))
    ].copy()

    filename = (
        AWR_MINER_PATH
        + os.sep
        + "awr_miner_plots"
        + os.sep
        + "csv"
        + os.sep
        + "bad_db_vcpu.csv"
    )

    if len(badVCPUDf) > 0:
        badVCPUDf["cpu_per_s_o_cpu_count"] = round(
            badVCPUDf["cpu_per_s"] / df["cpu_count"], PRECISION
        )

        badVCPUDf = badVCPUDf[
            [
                "WHICH_DB",
                "snap",
                "dur_m",
                "end",
                "inst",
                "cpu_type",
                "cpu_per_s",
                "cpu_count",
                "cpu_per_s_o_cpu_count",
                "os_cpu",
                "os_cpu_max",
                "h_cpu_per_s",
            ]
        ]

        badVCPUDf["cwd"] = cwd
        badVCPUDf["platform"] = platformName
        badVCPUDf["create_dttm_utc"] = now
        badVCPUDf["source"] = SOURCE
        badVCPUDf["version"] = __version__

        occa_storage.to_csv(badVCPUDf, filename, index=False)
        lg(
            "\nWrote "
            + str(len(badVCPUDf))
            + " rows with a value of cpu_per_s > instance cpu_count"
        )

        df.loc[df["cpu_per_s"] > df["cpu_count"], "cpu_per_s"] = df["cpu_count"]

        df.drop(columns=["INSTANCE", "HOST", "cpu_type", "cpu_count"], inplace=True)

        dataDf["MAIN-METRICS"] = df.copy()

    elif os.path.exists(filename):
        os.remove(filename)

    # ---

    if (
        (ADJUST_IBM_CORES or len(badVCPUDf) > 0)
        and "CPU" in occaDf
        and len(occaDf["CPU"]) > 0
    ):
        df.rename(
            columns={
                "inst": "INSTANCE_NUMBER",
                "snap": "SNAP_ID",
                "cpu_per_s": "cpu_per_s_new",
            },
            inplace=True,
        )

        occaDf["CPU"] = pd.merge(
            left=occaDf["CPU"],
            right=df[["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID", "cpu_per_s_new"]],
            how="left",
            left_on=["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID"],
            right_on=["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID"],
        )

        occaDf["CPU"]["cpu_per_s_new"] = occaDf["CPU"]["cpu_per_s_new"].fillna(
            occaDf["CPU"]["cpu_per_s"]
        )
        occaDf["CPU"]["cpu_per_s"] = occaDf["CPU"]["cpu_per_s_new"]
        occaDf["CPU"].drop(columns=["cpu_per_s_new"], inplace=True)

    df = []

    if 1 == 0:
        filename = (
            AWR_MINER_PATH
            + os.sep
            + "awr_miner_plots"
            + os.sep
            + "csv"
            + os.sep
            + "00_occa_887.csv"
        )
        occa_storage.to_csv(
            occaDf["CPU"].sort_values(["WHICH_DB", "INSTANCE_NUMBER", "end"]),
            filename,
            index=False,
        )
        lg("\nWrote file " + filename)

# ---

for k in dataDf:
    filename = (
        AWR_MINER_PATH
        + os.sep
        + "awr_miner_plots"
        + os.sep
        + "csv"
        + os.sep
        + k
        + ".csv"
    )

    df = dataDf[k]
    df["cwd"] = cwd
    df["platform"] = platformName
    df["create_dttm_utc"] = now
    df["version"] = __version__

    occa_storage.to_csv(df, filename, index=False)

lg(
    "\nWrote composite sources to files in directory "
    + AWR_MINER_PATH
    + os.sep
    + "awr_miner_plots"
    + os.sep
    + "csv"
    + "\n"
)

# ---
# 444
if "MAIN-METRICS" not in dataDf or len(dataDf["MAIN-METRICS"]) == 0:
    dbTZDf = []

else:
    os.makedirs(AWR_MINER_PATH + os.sep + OCCA_PATH, exist_ok=True)

    dt = datetime.datetime.now(pytz.utc)  # current time in UTC
    offsets = defaultdict(list)
    tzs = {}

    for tz in pytz.common_timezones:
        offsets[
            dt.astimezone(pytz.timezone(tz)).utcoffset().total_seconds() / 60
        ].append(tz.strip())

    def getOffsetForTZ(tz):
        r = tzs[tz] if tz in tzs else ""
        return r

    def getTZForOffset(offset):
        try:
            r = offsets[float(offset)][0] if float(offset) in offsets else ""
        except:
            r = ""
        return r

    filename = AWR_MINER_PATH + os.sep + OCCA_PATH + os.sep + "awr_miner_tz_choices.csv"
    f = open(filename, "w", encoding="UTF-8")
    f.write("MINUTES_DIFF_FROM_UTC,TZ\n")

    for offset, zone in sorted(offsets.items()):
        for _ in zone:
            tzs[_.strip()] = offset
            f.write(str(offset) + "," + _.strip() + "\n")

    f.close()

    lg("Wrote TZ choices file " + filename + "\n")

    # ---

    os.makedirs(
        AWR_MINER_PATH + os.sep + OCCA_PATH + os.sep + "properties", exist_ok=True
    )

    filename = (
        AWR_MINER_PATH
        + os.sep
        + OCCA_PATH
        + os.sep
        + "properties"
        + os.sep
        + "awr_tz_database.csv"
    )
    tzDf = pd.read_csv(filename) if os.path.exists(filename) else []

    if len(tzDf) > 0:
        tzDf = tzDf[~tzDf["TZ"].isnull()]
        tzDf = tzDf[["WHICH_DB", "TZ", "MINUTES_DIFF_FROM_UTC_list"]]

        tzDf.rename(
            columns={
                "MINUTES_DIFF_FROM_UTC_list": "MINUTES_DIFF_FROM_UTC_list_from_file",
                "TZ": "TZ_from_file",
            },
            inplace=True,
        )

    filename = (
        AWR_MINER_PATH
        + os.sep
        + OCCA_PATH
        + os.sep
        + "properties"
        + os.sep
        + "awr_tz_database_original.csv"
    )
    if "SNAP-HISTORY-TZ" not in dataDf or len(dataDf["SNAP-HISTORY-TZ"]) == 0:
        df = pd.merge(
            left=dataDf["MAIN-METRICS"],
            right=dbDf,
            how="left",
            left_on=["WHICH_DB"],
            right_on=["WHICH_DB"],
        )
        df["TZ"] = ""

        df["MINUTES_DIFF_FROM_UTC_list"] = ""
        df["snaps_with_tz_offset_count"] = 0
        df["snaps_missing_tz_offset_count"] = df.groupby(["WHICH_DB"])[
            "inst"
        ].transform("count")
        df = (
            df[
                [
                    "WHICH_DB",
                    "TZ",
                    "MINUTES_DIFF_FROM_UTC_list",
                    "snaps_with_tz_offset_count",
                    "snaps_missing_tz_offset_count",
                ]
            ]
            .drop_duplicates()
            .sort_values(["WHICH_DB"])
        )

        if len(tzDf) > 0:
            df = pd.merge(
                left=df,
                right=tzDf,
                how="left",
                left_on=["WHICH_DB"],
                right_on=["WHICH_DB"],
            )
            df["MINUTES_DIFF_FROM_UTC_list"] = df[
                "MINUTES_DIFF_FROM_UTC_list_from_file"
            ]
            df["TZ"] = df["TZ_from_file"]
            df.drop(
                columns=["MINUTES_DIFF_FROM_UTC_list_from_file", "TZ_from_file"],
                inplace=True,
            )

            df.loc[~df["TZ"].isnull(), "MINUTES_DIFF_FROM_UTC_list"] = df["TZ"].apply(
                getOffsetForTZ
            )

        occa_storage.to_csv(df.sort_values(["WHICH_DB"]), filename, index=False)

        lg("Wrote complete TZ file " + filename + "\n")
        tz_file_message = "Wrote complete TZ file " + filename + "\n"

    else:
        df0 = pd.merge(
            left=dataDf["MAIN-METRICS"],
            right=dbDf,
            how="left",
            left_on=["WHICH_DB"],
            right_on=["WHICH_DB"],
        )
        df1 = pd.merge(
            left=dataDf["SNAP-HISTORY-TZ"],
            right=dbDf,
            how="left",
            left_on=["WHICH_DB"],
            right_on=["WHICH_DB"],
        )

        df = pd.merge(
            left=df0,
            right=df1,
            how="left",
            left_on=["WHICH_DB", "snap", "end", "inst"],
            right_on=["WHICH_DB", "SNAP", "END_TIME", "INST"],
        )
        df["TZ"] = ""

        dfGb = df[["WHICH_DB", "MINUTES_DIFF_FROM_UTC"]].drop_duplicates()
        dfGb = dfGb[~dfGb["MINUTES_DIFF_FROM_UTC"].isnull()]
        dfGb["MINUTES_DIFF_FROM_UTC"] = dfGb["MINUTES_DIFF_FROM_UTC"].astype(str)
        # Changing .agg(lambda x: ','.join(set(x)))  to .tail Just group and grab the last value; .agg makes  the following
        # DB1 - 60.0
        # DB1 - 120.0
        # DB2 - 60.0
        # DB2 - 60.0
        # Resulting in
        # DB1 -120.0,60.0 <- Making this imposible to find a value in mapping
        # DB2- 60.0

        for db, count in (
            dfGb.groupby("WHICH_DB")["MINUTES_DIFF_FROM_UTC"].nunique().items()
        ):
            if count > 1:
                lg(
                    f"Warning: {db} More than 1 value for columns [MINUTES_DIFF_FROM_UTC] grabbing last value."
                )
        dfGb = dfGb.groupby("WHICH_DB", as_index=False).tail(1)
        dfGb.columns = ["WHICH_DB", "MINUTES_DIFF_FROM_UTC_list"]
        df = pd.merge(
            left=df, right=dfGb, how="left", left_on=["WHICH_DB"], right_on=["WHICH_DB"]
        )
        df["snaps_with_tz_offset_count"] = df.groupby(["WHICH_DB"])[
            "MINUTES_DIFF_FROM_UTC"
        ].transform("count")
        df = df[df["MINUTES_DIFF_FROM_UTC"].isnull()]
        df["snaps_missing_tz_offset_count"] = df.groupby(["WHICH_DB"])[
            "inst"
        ].transform("count")
        df = df[
            [
                "WHICH_DB",
                "TZ",
                "MINUTES_DIFF_FROM_UTC_list",
                "snaps_with_tz_offset_count",
                "snaps_missing_tz_offset_count",
            ]
        ].drop_duplicates()

        if len(tzDf) > 0:
            df = pd.merge(
                left=df,
                right=tzDf,
                how="left",
                left_on=["WHICH_DB"],
                right_on=["WHICH_DB"],
            )
            df.loc[df["TZ"] == "", "MINUTES_DIFF_FROM_UTC_list"] = df[
                "MINUTES_DIFF_FROM_UTC_list_from_file"
            ]
            df.loc[df["TZ"] == "", "TZ"] = df["TZ_from_file"]
            df.drop(
                columns=["MINUTES_DIFF_FROM_UTC_list_from_file", "TZ_from_file"],
                inplace=True,
            )

        df.loc[df["TZ"] == "", "TZ"] = df["MINUTES_DIFF_FROM_UTC_list"].apply(
            getTZForOffset
        )

        occa_storage.to_csv(df.sort_values(["WHICH_DB"]), filename, index=False)

        lg("Wrote (possibly) partial TZ file " + filename + "\n")
        tz_file_message = "Wrote (possibly) partial TZ file " + filename + "\n"

    dbTZDf = df.copy()

if args.tz is not None:
    quit()

#
# Need logic here that:
# 1) adds tz offsets  to MAIN-METRICS either because of TZ choice of values in SNAP-HISTORY-TZ
#
# ----------------------------------------------------------------------------------------------------------------------

"""

use code like the following if running in a notebook
whichDBs

whichDBs = whichDBs[0:1]
"""

# ----------------------------------------------------------------------------------------------------------------------
plots_per_db = {}
for whichDB in whichDBs:
    figs = []

    try:
        DB_NAME = dbDf[dbDf["WHICH_DB"] == whichDB]["DB_NAME"].values[0]
    except:
        continue

    # suffix  = ''
    suffix = " - " + str(DB_NAME) + ", v" + __version__ + " @ " + tsDisplay

    if PLOTTING:
        lg("Plotting " + whichDB + "...")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 0 (Summary Tables)
    #

    df = dataDf["OS-INFORMATION"][
        dataDf["OS-INFORMATION"]["WHICH_DB"] == whichDB
    ].copy()
    df.drop(columns=["WHICH_DB"], inplace=True)

    df.rename(columns={"STAT_NAME": "Property", "STAT_VALUE": "Value"}, inplace=True)

    # 3.10 has depricates df.append.  Add columns this way
    df.loc[len(df)] = {"Property": "AWR_PLOT_VER", "Value": __version__}
    df.loc[len(df)] = {"Property": "Generated", "Value": tsDisplay}

    # ---

    if (
        "MAIN-METRICS" in dataDf
        and len(dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB])
        > 0
    ):
        daysShown = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB][
                "end"
            ].max()
            - dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB][
                "end"
            ].min()
        ).total_seconds() / (24 * 60 * 60)

        cols = [
            "dur_m",
            "read_iops",
            "write_iops",
            "read_mb_s",
            "write_mb_s",
            "logons_total",
            "exec_s",
            "commits_s",
            "aas",
        ]

        metricsDf = dataDf["MAIN-METRICS"][
            dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB
        ][["WHICH_DB", "snap", "inst", "end"] + cols].copy()

        occaCols = ["WHICH_DB", "snap", "end", "inst", "read_iops", "write_iops"]
        _ = metricsDf[occaCols].copy()
        _["DB_NAME"] = DB_NAME
        _.rename(columns={"snap": "SNAP_ID", "inst": "INSTANCE_NUMBER"}, inplace=True)
        occaDf["IOPS"] = (
            _
            if "IOPS" not in occaDf
            else pd.concat([occaDf["IOPS"], _], ignore_index=True)
        )

        metricsDf.drop(columns=["WHICH_DB", "snap", "inst"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure.0a.0.csv"
            occa_storage.to_csv(metricsDf, filename, index=False)
        lg(("Wrote file " + filename))

        metricsDf = metricsDf.groupby("end", as_index=False)[cols].sum()
        metricsDf = metricsDf[cols].agg(["min", "max", "mean", "sum"]).T.reset_index()

        metricsDf.rename(
            columns={"index": "metric", "mean": "avg", "sum": "total"}, inplace=True
        )

        metricsDf.loc[metricsDf["metric"] == "dur_m", "metric"] = (
            "max(dur_m i.e. snap.min)"
        )

        metricsDf = pd.concat(
            [
                metricsDf,
                pd.DataFrame(
                    [["days", daysShown, daysShown, daysShown, daysShown]],
                    columns=["metric", "min", "max", "avg", "total"],
                ),
            ],
            ignore_index=True,
        )

        metricsDf = metricsDf[["metric", "max"]]
        metricsDf.rename(columns={"metric": "Property", "max": "Value"}, inplace=True)

        metricsDf = metricsDf.round(2)
        metricsDf["Value"] = metricsDf["Value"].astype(str)

        df = pd.concat([df, metricsDf], ignore_index=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure.0a.1.csv"
            occa_storage.to_csv(df, filename, index=False)
            lg(("Wrote file " + filename))

    # ---

    if (
        "SIZE-ON-DISK" in dataDf
        and len(dataDf["SIZE-ON-DISK"][dataDf["SIZE-ON-DISK"]["WHICH_DB"] == whichDB])
        > 0
    ):
        sources[whichDB].append("SIZE-ON-DISK")

        sizeDf = dataDf["SIZE-ON-DISK"][dataDf["SIZE-ON-DISK"]["WHICH_DB"] == whichDB]

        # This is for the new column in SIZE-ON-DISK section
        # Some extracts are going to be in old version so we'll stick to that version if
        # the new column isn't there
        if "USED_SIZE_GB" in sizeDf.columns:
            occaCols = ["WHICH_DB", "SNAP_ID", "SIZE_GB", "USED_SIZE_GB"]
        else:
            occaCols = ["WHICH_DB", "SNAP_ID", "SIZE_GB"]

        # occaCols          = ['WHICH_DB', 'SNAP_ID', 'SIZE_GB','USED_SIZE_GB']
        _ = sizeDf[occaCols].copy()

        _["DB_NAME"] = DB_NAME
        occaDf["STORAGE"] = (
            _
            if "STORAGE" not in occaDf
            else pd.concat([occaDf["STORAGE"], _], ignore_index=True)
        )

        sizeDf = sizeDf[sizeDf["SNAP_ID"] == sizeDf["SNAP_ID"].max()]

        sizeDf["Property"] = "sizegb"
        # Same behaviour from above
        # sizeDf             = sizeDf[['Property', 'SIZE_GB','USED_SIZE_GB']]
        if "USED_SIZE_GB" in sizeDf.columns:
            sizeDf["used_size_gb"] = "sizegb"
            sizeDf = sizeDf[["Property", "SIZE_GB", "USED_SIZE_GB"]]
        else:
            sizeDf = sizeDf[["Property", "SIZE_GB"]]

        sizeDf.rename(columns={"SIZE_GB": "Value"}, inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure.0b.0.csv"
            occa_storage.to_csv(df, filename, index=False)
            lg(("Wrote file " + filename))

        df = pd.concat([df, sizeDf], ignore_index=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure.0b.1.csv"
            occa_storage.to_csv(df, filename, index=False)
            lg(("Wrote file " + filename))

    # ---

    if not PLOTTING:
        continue

    # ---

    df = df[
        ~df["Property"].isin(
            [
                "HOSTS",
                "NUM_CPUS",
                "NUM_CPU_CORES",
                "NUM_CPU_SOCKETS",
                "PHYSICAL_MEMORY_GB",
            ]
        )
    ]
    df = df[["Property", "Value"]]

    # ---

    headerColor = "grey"
    rowEvenColor = "lightgrey"
    rowOddColor = "white"

    fillColors = [rowEvenColor, rowOddColor] * len(df)

    fig0a = go.Figure(
        data=[
            go.Table(
                columnwidth=[240, 600],
                header=dict(
                    values=list(df.columns),
                    height=30,
                    font={"color": "white", "size": 20},
                    line_color="darkslategray",
                    fill_color=headerColor,
                    align="left",
                ),
                cells=dict(
                    values=[df.Property, df.Value],
                    height=28,
                    font={"color": "darkslategray", "size": 18},
                    fill_color=[fillColors],
                    align="left",
                ),
            )
        ]
    )

    fig0a.update_layout(
        height=HEIGHT * 0.6,
        width=WIDTH,
        title_text="<b>Summary Values"
        + suffix
        + "</b><br>Figure 0a"
        + (
            " : "
            + str(sorted(sources[whichDB]))
            .replace("'", "")
            .replace("[", "")
            .replace("]", "")
            if SHOW_SOURCE_DATA
            else ""
        ),
        title_font_size=24,
    )

    figs.append({"page": 0, "fig": fig0a})

    if SHOW:
        fig0a.show()
    else:
        lg("   Plotted figure 0a")

    # ---

    if (
        "MAIN-METRICS" not in dataDf
        or len(dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB])
        == 0
    ):
        instanceList = []
    else:
        instanceList = sorted(
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB][
                "inst"
            ].unique()
        )

    df = (
        instancesDf[instancesDf["WHICH_DB"] == whichDB]
        .set_index("INSTANCE")
        .T.reset_index()
    )

    if 1 == 0:
        lg("\n\ninstanceList")
        lg("--------------")
        lg(str(instanceList))
        lg("--------------")

        lg("\n\ndf.0")
        lg(str(df.columns))
        lg("-------")
        lg(str(df))
        lg("-------")

    df = df[~df["index"].isin(["DB_NAME", "WHICH_DB"])]

    if 1 == 0:
        lg("\n\ndf.1")
        lg(str(df.columns))
        lg("-------")
        lg(str(df))
        lg("-------")

    cols = ["Property"]
    # Loop through the available database instances and looking for data on each one
    cols += list(df.columns[1:])
    df.columns = cols

    if 1 == 0:
        lg("\n\ndf.2")
        lg(str(df.columns))
        lg("-------")
        lg(str(df))
        lg("-------")

    values, widths = [df.Property], [30]

    for i in df.columns[1:]:
        values.append(df[i])
        widths.append(20)

    headerColor = "grey"
    rowEvenColor = "lightgrey"
    rowOddColor = "white"

    fillColors = [rowEvenColor, rowOddColor] * len(df)

    fig0b = go.Figure(
        data=[
            go.Table(
                columnwidth=widths,
                header=dict(
                    values=list(df.columns),
                    height=30,
                    font={"color": "white", "size": 20},
                    line_color="darkslategray",
                    fill_color=headerColor,
                    align="left",
                ),
                cells=dict(
                    values=values,
                    height=28,
                    font={"color": "darkslategray", "size": 18},
                    fill_color=[fillColors],
                    align="left",
                ),
            )
        ]
    )

    fig0b.update_layout(
        height=HEIGHT * 0.4,
        width=WIDTH,
        title_text="<b>Instance Values"
        + suffix
        + "</b><br>Figure 0b"
        + (
            " (Configuration values are derived from minimum instance number)"
            if "OS-INFORMATION2" not in dataDf
            and len(instancesDf[instancesDf["WHICH_DB"] == whichDB]) > 1
            else ""
        ),
        title_font_size=24,
    )

    figs.append({"page": 0, "fig": fig0b})

    if SHOW:
        fig0b.show()
    else:
        lg("   Plotted figure 0b")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 1
    #

    if (
        "AVERAGE-ACTIVE-SESSIONS" in dataDf
        and len(
            dataDf["AVERAGE-ACTIVE-SESSIONS"][
                dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        total = dataDf["AVERAGE-ACTIVE-SESSIONS"][
            dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
        ]["AVG_SESS"].sum()

        df = dataDf["AVERAGE-ACTIVE-SESSIONS"][
            dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
        ].copy()
        df = df.groupby("WAIT_CLASS", as_index=False)["AVG_SESS"].sum()
        df["AVG_SESS"] = round((df["AVG_SESS"] / total) * 100, 2)

        if DATA:
            filename = DATA_PATH + os.sep + "figure1a.csv"
            occa_storage.to_csv(df[["WAIT_CLASS", "AVG_SESS"]], filename, index=False)
            lg(("Wrote file " + filename))

        fig1a = px.bar(
            df,
            x="WAIT_CLASS",
            y="AVG_SESS",
            color="WAIT_CLASS",
            title="Average Active Sessions (AAS) % by Wait Class - All Snapshots"
            + suffix
            + "<br>Figure 1a"
            + (
                " : AVERAGE-ACTIVE-SESSIONS [AVG_SESS, WAIT_CLASS]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"AVG_SESS": "% of Total(AAS)", "WAIT_CLASS": ""},
            height=HEIGHT / 2,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig1a.update_layout(font={"size": 16})

        for idx in range(len(fig1a.data)):
            fig1a.data[idx].text = fig1a.data[idx]["y"][0]

            if fig1a.data[idx]["legendgroup"] not in WAIT_CLASS_COLORS:
                WAIT_CLASS_COLORS[fig1a.data[idx]["legendgroup"]] = "gold"

            fig1a.data[idx]["marker"]["color"] = WAIT_CLASS_COLORS[
                fig1a.data[idx]["legendgroup"]
            ]
            fig1a.data[idx]["hovertemplate"] = (
                "wait_class=" + fig1a.data[idx]["hovertemplate"][1:]
            )

        figs.append({"page": 1, "fig": fig1a})

        if SHOW:
            fig1a.show()
        else:
            lg("   Plotted figure 1a")

    # ---
    #
    # Page 1b
    #

    if (
        "TOP-N-TIMED-EVENTS" in dataDf
        and len(
            dataDf["TOP-N-TIMED-EVENTS"][
                dataDf["TOP-N-TIMED-EVENTS"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        total = dataDf["TOP-N-TIMED-EVENTS"][
            dataDf["TOP-N-TIMED-EVENTS"]["WHICH_DB"] == whichDB
        ]["TOTAL_TIME_S"].sum()

        df = dataDf["TOP-N-TIMED-EVENTS"][
            dataDf["TOP-N-TIMED-EVENTS"]["WHICH_DB"] == whichDB
        ].copy()
        df = df.groupby(["WAIT_CLASS", "EVENT_NAME"], as_index=False)[
            "TOTAL_TIME_S"
        ].sum()
        df["TOTAL_TIME_S"] = round((df["TOTAL_TIME_S"] / total) * 100, 2)
        df["label"] = df["WAIT_CLASS"] + " - " + df["EVENT_NAME"]

        df.sort_values(["TOTAL_TIME_S"], ascending=[False], inplace=True)
        df.reset_index(drop=True, inplace=True)
        # Trim to max 10 entries if needed
        df = df.iloc[0 : min(10, df.index.max())]

        if DATA:
            filename = DATA_PATH + os.sep + "figure1b.csv"
            occa_storage.to_csv(
                df[["label", "TOTAL_TIME_S", "WAIT_CLASS"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        fig1b = px.bar(
            df,
            x="label",
            y="TOTAL_TIME_S",
            color="WAIT_CLASS",
            title="Top 10 Timed Events by Total Time Aggregated over Snapshot Range"
            + suffix
            + "<br>Figure 1b"
            + (
                " : TOP-N-TIMED-EVENTS [EVENT_NAME, TOTAL_TIME_S, WAIT_CLASS]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"TOTAL_TIME_S": "% of Total(TOTAL_TIME_S)", "label": ""},
            height=HEIGHT / 2,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig1b.update_layout(font={"size": 16})

        for idx in range(len(fig1b.data)):
            fig1b.data[idx].text = fig1b.data[idx]["y"]

            if fig1b.data[idx]["legendgroup"] not in WAIT_CLASS_COLORS:
                WAIT_CLASS_COLORS[fig1b.data[idx]["legendgroup"]] = "gold"

            fig1b.data[idx]["marker"]["color"] = WAIT_CLASS_COLORS[
                fig1b.data[idx]["legendgroup"]
            ]
            fig1b.data[idx]["hovertemplate"] = (
                "wait_class - event_name"
                + fig1b.data[idx]["hovertemplate"][
                    fig1b.data[idx]["hovertemplate"].find("<br>") + 4 :
                ]
            )

        figs.append({"page": 1, "fig": fig1b})

        if SHOW:
            fig1b.show()
        else:
            lg("   Plotted figure 1b")

    # ---
    #
    # Page 1c
    #

    if (
        "MAIN-METRICS" in dataDf
        and len(dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB])
        > 0
    ):
        violinDf = []

        if 1 == 0:
            df = (
                dataDf["AVERAGE-ACTIVE-SESSIONS"]
                .copy()
                .groupby("SNAP_ID", as_index=False)["AVG_SESS"]
                .sum()
            )
            df.rename(columns={"AVG_SESS": "value"}, inplace=True)
            df["facet"] = "Avg Act Sessions"
        else:
            df = (
                dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
                .copy()
                .groupby("snap", as_index=False)["aas"]
                .sum()
            )
            df.rename(columns={"aas": "value"}, inplace=True)
            df["facet"] = "Avg Act Sessions (AAS)"

        violinDf = df

        # ---

        if 1 == 0:
            df = (
                dataDf["AVERAGE-ACTIVE-SESSIONS"][
                    dataDf["AVERAGE-ACTIVE-SESSIONS"]["WAIT_CLASS"] == "CPU"
                ]
                .copy()
                .groupby("SNAP_ID", as_index=False)["AVG_SESS"]
                .sum()
            )
            df.rename(columns={"AVG_SESS": "value"}, inplace=True)
            df["facet"] = "CPU"
        else:
            df = (
                dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
                .copy()
                .groupby("snap", as_index=False)["os_cpu"]
                .sum()
            )
            df.rename(columns={"os_cpu": "value"}, inplace=True)
            df["facet"] = "CPU"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["exec_s"]
            .sum()
        )
        df.rename(columns={"exec_s": "value"}, inplace=True)
        df["facet"] = "Execs / S"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["read_iops"]
            .sum()
        )
        df.rename(columns={"read_iops": "value"}, inplace=True)
        df["facet"] = "Read IOPs"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["read_mb_s"]
            .sum()
        )
        df.rename(columns={"read_mb_s": "value"}, inplace=True)
        df["facet"] = "Read MB / S"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["sql_res_t_cs"]
            .sum()
        )
        df.rename(columns={"sql_res_t_cs": "value"}, inplace=True)
        df["facet"] = "SQL Resp Time (cs)"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["se_sess"]
            .sum()
        )
        df.rename(columns={"se_sess": "value"}, inplace=True)
        df["facet"] = "SE Sessions"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["px_sess"]
            .sum()
        )
        df.rename(columns={"px_sess": "value"}, inplace=True)
        df["facet"] = "PX Sessions"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["write_iops"]
            .sum()
        )
        df.rename(columns={"write_iops": "value"}, inplace=True)
        df["facet"] = "Write IOPs"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        df = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .copy()
            .groupby("snap", as_index=False)["write_mb_s"]
            .sum()
        )
        df.rename(columns={"write_mb_s": "value"}, inplace=True)
        df["facet"] = "Write MB / S"

        violinDf = pd.concat([violinDf, df], ignore_index=True)

        # ---

        if DATA:
            filename = DATA_PATH + os.sep + "figure1c.csv"
            occa_storage.to_csv(violinDf[["value", "facet"]], filename, index=False)
            lg(("Wrote file " + filename))

        violinDf["x"] = "a"  # needed to get violin plots to center in facets

        fig1c = px.violin(
            violinDf,
            y="value",
            color="x",
            facet_col="facet",
            facet_col_wrap=5,
            box=True,
            title="Summary Distributions"
            + suffix
            + "<br>Figure 1c"
            + (
                " : MAIN-METRICS [os_cpu, exec_s, read_iops, read_mb_s, sql_res_t_cs, se_sess, px_sess, write_iops, write_mb_s]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig1c.update_layout(font={"size": 16}, showlegend=False)
        fig1c.update_yaxes(matches=None, showticklabels=True)
        fig1c.update_xaxes(matches=None, showticklabels=False)

        for idx in range(len(fig1c.layout.annotations)):
            fig1c.layout.annotations[idx].text = fig1c.layout.annotations[
                idx
            ].text.split("=")[1]

        for idx in range(len(fig1c.data)):
            fig1c.data[idx]["hovertemplate"] = fig1c.data[idx]["hovertemplate"].replace(
                "x=a<br>facet=", ""
            )

        figs.append({"page": 1.5, "fig": fig1c})

        if SHOW:
            fig1c.show()
        else:
            lg("   Plotted figure 1c")

    # -------------------------------------------------------------------------------------------------------------------
    #
    # Figure 2
    #

    if (
        "AVERAGE-ACTIVE-SESSIONS" in dataDf
        and len(
            dataDf["AVERAGE-ACTIVE-SESSIONS"][
                dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        if len(snapDf) == 0 or len(snapDf[snapDf["WHICH_DB"] == whichDB]) == 0:
            df = dataDf["AVERAGE-ACTIVE-SESSIONS"][
                dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
            ].copy()
            df["end"] = df["SNAP_ID"]
        else:
            df = pd.merge(
                left=dataDf["AVERAGE-ACTIVE-SESSIONS"][
                    dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
                ],
                right=snapDf[snapDf["WHICH_DB"] == whichDB],
                how="left",
                left_on=["SNAP_ID"],
                right_on=["snap"],
            )
        #
        # Force CPU to appear on the bottom of the chart
        #
        df.loc[df["WAIT_CLASS"] == "CPU", "WAIT_CLASS"] = "0CPU"
        df.sort_values(["WAIT_CLASS", "end"], inplace=True)
        df.loc[df["WAIT_CLASS"] == "0CPU", "WAIT_CLASS"] = "CPU"

        if DATA:
            filename = DATA_PATH + os.sep + "figure2.csv"
            occa_storage.to_csv(
                df[["end", "WAIT_CLASS", "AVG_SESS"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        gbDf = df.groupby("end", as_index=False)["AVG_SESS"].sum()
        plotCores = (
            instancesDf[instancesDf["WHICH_DB"] == whichDB].cpu_count.sum()
            <= gbDf.AVG_SESS.max()
            or gbDf.AVG_SESS.max()
            >= float(instancesDf[instancesDf["WHICH_DB"] == whichDB].cpu_count.sum())
            * 0.75
        )

        fig2 = px.area(
            df,
            x="end",
            y="AVG_SESS",
            color="WAIT_CLASS",
            title="Average Active Sessions (AAS)"
            + suffix
            + "<br>Total CPU Threads="
            + str(instancesDf[instancesDf["WHICH_DB"] == whichDB].cpu_count.sum())
            + (" (trace not shown on figure)" if not plotCores else "")
            + "<br>Figure 2"
            + (" : AVERAGE-ACTIVE-SESSIONS [WAIT_CLASS]" if SHOW_SOURCE_DATA else ""),
            labels={"end": "", "AVG_SESS": "AAS"},
            height=HEIGHT / 1.75,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig2.update_layout(font={"size": 16})

        for idx in range(len(fig2.data)):
            if fig2.data[idx]["legendgroup"] not in WAIT_CLASS_COLORS:
                WAIT_CLASS_COLORS[fig2.data[idx]["legendgroup"]] = "gold"

            fig2.data[idx]["line"]["color"] = WAIT_CLASS_COLORS[
                fig2.data[idx]["legendgroup"]
            ]
            fig2.data[idx]["hovertemplate"] = (
                fig2.data[idx]["hovertemplate"]
                .replace("WAIT_CLASS=", "wait_class=")
                .replace("=%{x}", "snap_end=%{x}")
            )
        #
        #   Prevent plotting of cores line it it would wash out the y-axis
        #
        if plotCores:
            fig2.add_trace(
                go.Scatter(
                    x=fig2.data[0].x,
                    y=[instancesDf[instancesDf["WHICH_DB"] == whichDB].cpu_count.sum()]
                    * len(fig2.data[0].x),
                    name="threads",
                    line_color="red",
                )
            )

        figs.append({"page": 2, "fig": fig2})

        if SHOW:
            fig2.show()
        else:
            lg("   Plotted figure 2")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 3
    #

    if (
        "MAIN-METRICS" in dataDf
        and len(dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB])
        > 0
    ):
        df = dataDf["MAIN-METRICS"][
            dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB
        ].copy()
        df = pd.merge(
            left=df,
            right=instancesDf[instancesDf["WHICH_DB"] == whichDB],
            how="left",
            left_on=["inst"],
            right_on=["INSTANCE"],
        )
        df.sort_values(["inst", "end"], inplace=True)
        #
        #       Do not adjust percentages in the plots
        #
        if ADJUST_IBM_CORES:
            df.loc[(df["cpu_type"] == "IBM"), "os_cpu"] = round(
                df["os_cpu"] / AIX_DEFLATION, PRECISION
            )
            df.loc[(df["cpu_type"] == "IBM"), "os_cpu_max"] = round(
                df["os_cpu_max"] / AIX_DEFLATION, PRECISION
            )
            df.loc[(df["cpu_type"] == "IBM"), "cpu_per_s"] = round(
                df["cpu_per_s"] / AIX_DEFLATION, PRECISION
            )
            df.loc[(df["cpu_type"] == "IBM"), "h_cpu_per_s"] = round(
                df["h_cpu_per_s"] / AIX_DEFLATION, PRECISION
            )

        df["cpu_per_s"] = (df["cpu_per_s"] / df["NUM_CPUS"]) * 100
        df.sort_values(["inst", "end"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure3a.csv"
            occa_storage.to_csv(
                df[["end", "inst", "os_cpu", "cpu_per_s", "NUM_CPUS"]],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        fig3a = px.line(
            df,
            x="end",
            y=["os_cpu", "cpu_per_s"],
            facet_row="inst",
            title="OS & Database CPU Utilization %"
            + suffix
            + "<br>Figure 3a"
            + (" : MAIN-METRICS [cpu_per_s, os_cpu]" if SHOW_SOURCE_DATA else ""),
            labels={"value": "CPU %", "end": ""},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig3a.update_layout(font={"size": 16})
        fig3a.update_traces(mode="lines")

        instanceCount = len(fig3a._grid_ref)
        #
        #   Row 1 is the bottom-most i.e. highest instance number
        #
        sl = True

        instanceList = sorted(df["inst"].unique())

        for row_idx, row_figs in enumerate(fig3a._grid_ref):
            instanceDf = df[df["inst"] == instanceCount - row_idx][
                ["end", "cpu_per_s", "os_cpu"]
            ].copy()

            try:
                util95 = round(
                    instanceDf.describe(percentiles=[0.95])
                    .loc["95%"][["os_cpu"]]
                    .values[0]
                )
                instanceDf["util95"] = util95
            except Exception as fc:
                instanceDf["util95"] = 0

                if 1 == 0:
                    lg(
                        "\n\nRaised "
                        + str(fc)
                        + " getting util95.os_cpu for instanceList:"
                        + str(instanceList)
                        + ", instanceCount: "
                        + str(instanceCount)
                        + ", row_idx: "
                        + str(row_idx)
                    )

                    dfFile = (
                        AWR_MINER_PATH
                        + os.sep
                        + "awr_miner_plots"
                        + os.sep
                        + whichDB
                        + ".df.01.csv"
                    )
                    occa_storage.to_csv(df, dfFile, index=False)
                    lg("Wrote file " + dfFile)

                    instanceDfFile = (
                        AWR_MINER_PATH
                        + os.sep
                        + "awr_miner_plots"
                        + os.sep
                        + whichDB
                        + ".instanceDf.01.csv"
                    )
                    occa_storage.to_csv(instanceDf, instanceDfFile, index=False)
                    lg("Wrote file " + instanceDfFile)

            fig3a.add_trace(
                go.Scatter(
                    x=instanceDf["end"],
                    y=instanceDf["util95"],
                    name="95th os_cpu",
                    showlegend=sl,
                    line_width=8,
                    line_color="red",
                ),
                row=row_idx + 1,
                col=1,
            )

            # ---

            try:
                util95 = round(
                    instanceDf.describe(percentiles=[0.95])
                    .loc["95%"][["cpu_per_s"]]
                    .values[0]
                )
                instanceDf["util95"] = util95
            except Exception as fc:
                instanceDf["util95"] = 0

                if 1 == 0:
                    lg(
                        "\n\nRaised "
                        + str(fc)
                        + " getting util95 for cpu_per_s for instanceList:"
                        + str(instanceList)
                        + ", instanceCount: "
                        + str(instanceCount)
                        + ", row_idx: "
                        + str(row_idx)
                    )

                    dfFile = (
                        AWR_MINER_PATH
                        + os.sep
                        + "awr_miner_plots"
                        + os.sep
                        + whichDB
                        + ".df.02.csv"
                    )
                    occa_storage.to_csv(df, dfFile, index=False)
                    lg("Wrote file " + dfFile)

                    instanceDfFile = (
                        AWR_MINER_PATH
                        + os.sep
                        + "awr_miner_plots"
                        + os.sep
                        + whichDB
                        + ".instanceDf.02.csv"
                    )
                    occa_storage.to_csv(instanceDf, instanceDfFile, index=False)
                    lg("Wrote file " + instanceDfFile)

            fig3a.add_trace(
                go.Scatter(
                    x=instanceDf["end"],
                    y=instanceDf["util95"],
                    name="95th cpu_per_s",
                    showlegend=sl,
                    line_width=8,
                    line_color="orange",
                ),
                row=row_idx + 1,
                col=1,
            )

            sl = False

        for idx in range(len(fig3a.layout.annotations)):
            fig3a.layout.annotations[idx].text = fig3a.layout.annotations[
                idx
            ].text.split("=")[1]

        for idx in range(len(fig3a.data)):
            if fig3a.data[idx]["hovertemplate"] is None:
                continue

            fig3a.data[idx]["hovertemplate"] = (
                fig3a.data[idx]["hovertemplate"]
                .replace("variable=", "")
                .replace("=%{x}", "snap_end=%{x}")
            )

        figs.append({"page": 3, "fig": fig3a})

        if SHOW:
            fig3a.show()
        else:
            lg("   Plotted figure 3a")

        # ---
        #
        # Page 3b
        #

        df = dataDf["MAIN-METRICS"][
            dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB
        ].copy()
        df = pd.merge(
            left=df,
            right=instancesDf[instancesDf["WHICH_DB"] == whichDB],
            how="left",
            left_on=["inst"],
            right_on=["INSTANCE"],
        )
        df.sort_values(["inst", "end"], inplace=True)

        df["os_cpu"] = (df["os_cpu"] / 100) * df["NUM_CPUS"]
        df.sort_values(["inst", "end"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure3b.csv"
            occa_storage.to_csv(
                df[["end", "inst", "os_cpu", "cpu_per_s", "NUM_CPUS"]],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        fig3b = px.line(
            df,
            x="end",
            y=["os_cpu", "cpu_per_s"],
            facet_row="inst",
            title="OS & Database Utilization in Threads"
            + suffix
            + "<br>Figure 3b"
            + (" : MAIN-METRICS [cpu_per_s, os_cpu]" if SHOW_SOURCE_DATA else ""),
            labels={"value": "Threads", "end": ""},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig3b.update_layout(font={"size": 16})
        fig3b.update_traces(mode="lines")

        instanceCount = len(fig3b._grid_ref)
        #
        #   Row 1 is the bottom-most i.e. highest instance number
        #
        sl = True

        for row_idx, row_figs in enumerate(fig3b._grid_ref):
            instanceDf = df[df["inst"] == instanceCount - row_idx][
                ["end", "cpu_per_s", "os_cpu"]
            ].copy()

            cores95 = round(
                instanceDf.describe(percentiles=[0.95])
                .loc["95%"][["os_cpu"]]
                .values[0],
                2,
            )
            instanceDf["cores95"] = cores95

            fig3b.add_trace(
                go.Scatter(
                    x=instanceDf["end"],
                    y=instanceDf["cores95"],
                    name="95th os_cpu",
                    showlegend=sl,
                    line_width=8,
                    line_color="red",
                ),
                row=row_idx + 1,
                col=1,
            )

            cores95 = round(
                instanceDf.describe(percentiles=[0.95])
                .loc["95%"][["cpu_per_s"]]
                .values[0],
                2,
            )
            instanceDf["cores95"] = cores95

            fig3b.add_trace(
                go.Scatter(
                    x=instanceDf["end"],
                    y=instanceDf["cores95"],
                    name="95th cpu_per_s",
                    showlegend=sl,
                    line_width=8,
                    line_color="orange",
                ),
                row=row_idx + 1,
                col=1,
            )

            sl = False

        for idx in range(len(fig3b.layout.annotations)):
            fig3b.layout.annotations[idx].text = fig3b.layout.annotations[
                idx
            ].text.split("=")[1]

        for idx in range(len(fig3b.data)):
            if fig3b.data[idx]["hovertemplate"] is None:
                continue

            fig3b.data[idx]["hovertemplate"] = (
                fig3b.data[idx]["hovertemplate"]
                .replace("variable=", "")
                .replace("=%{x}", "snap_end=%{x}")
            )

        figs.append({"page": 3.1, "fig": fig3b})

        if SHOW:
            fig3b.show()
        else:
            lg("   Plotted figure 3b")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 4
    #

    if (
        "MAIN-METRICS" in dataDf
        and len(dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB])
        > 0
    ):
        gbDf = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .groupby(["snap", "end"], as_index=False)
            .sum(numeric_only=True)
        )
        gbDf = pd.melt(
            gbDf[
                [
                    "end",
                    "read_iops",
                    "read_iops_max",
                    "read_mb_s",
                    "read_mb_s_max",
                    "write_iops",
                    "write_iops_max",
                    "write_mb_s",
                    "write_mb_s_max",
                ]
            ],
            id_vars="end",
        )

        if DATA:
            filename = DATA_PATH + os.sep + "figure4.0.csv"
            occa_storage.to_csv(gbDf, filename, index=False)
            lg(("Wrote file " + filename))

        gbDf["facet"] = "Write MB / S"

        gbDf.loc[gbDf["variable"].isin(["read_iops", "read_iops_max"]), "facet"] = (
            "Read IOPs"
        )
        gbDf.loc[gbDf["variable"].isin(["read_mb_s", "read_mb_s_max"]), "facet"] = (
            "Read MB / S"
        )
        gbDf.loc[gbDf["variable"].isin(["write_iops", "write_iops_max"]), "facet"] = (
            "Write IOPs"
        )

        gbDf.loc[gbDf["variable"].str.find("max") > -1, "variable"] = "Max"
        gbDf.loc[gbDf["variable"] != "Max", "variable"] = "Avg"

        gbDf.sort_values(["facet", "end"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure4.1.csv"
            occa_storage.to_csv(
                gbDf[["end", "value", "variable", "facet"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        fig4 = px.line(
            gbDf,
            x="end",
            y="value",
            color="variable",
            facet_row="facet",
            title="IO Avg and Max IO Type"
            + suffix
            + "<br>Figure 4"
            + (
                " : MAIN-METRICS [read_iops, read_iops_max, read_mb_s, read_mb_s_max, write_iops, write_iops_max, write_mb_s, write_mb_s_max]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"value": "", "end": ""},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig4.update_layout(font={"size": 16})
        fig4.update_traces(mode="lines")
        fig4.update_yaxes(matches=None, showticklabels=True)

        for idx in range(len(fig4.layout.annotations)):
            fig4.layout.annotations[idx].text = fig4.layout.annotations[idx].text.split(
                "="
            )[1]

        for idx in range(len(fig4.data)):
            fig4.data[idx]["line"]["color"] = (
                "coral" if fig4.data[idx]["legendgroup"].find("Max") > -1 else "navy"
            )
            fig4.data[idx]["hovertemplate"] = (
                fig4.data[idx]["hovertemplate"]
                .replace("variable=", "")
                .replace("facet=", "I/O type=")
                .replace("=%{y}", "snap_end=%{x}<br>value=%{y}")
            )

        figs.append({"page": 4, "fig": fig4})

        if SHOW:
            fig4.show()
        else:
            lg("   Plotted figure 4")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 5
    #

    if (
        "IO-OBJECT-TYPE" in dataDf
        and len(
            dataDf["IO-OBJECT-TYPE"][dataDf["IO-OBJECT-TYPE"]["WHICH_DB"] == whichDB]
        )
        > 0
    ):
        gbDf = dataDf["IO-OBJECT-TYPE"][dataDf["IO-OBJECT-TYPE"]["WHICH_DB"] == whichDB]
        gbDf = gbDf.groupby(["OBJECT_TYPE"], as_index=False)[
            ["LOGICAL_READ_GB", "PHYSICAL_READ_GB", "PHYSICAL_WRITE_GB", "GB_ADDED"]
        ].sum()
        gbDf = pd.melt(gbDf, id_vars="OBJECT_TYPE")
        gbDf["total"] = gbDf.groupby("variable")["value"].transform("sum")
        gbDf["value"] = round((gbDf["value"] / gbDf["total"]) * 100)

        gbDf.loc[gbDf["variable"] == "GB_ADDED", "variable"] = "Data Growth"
        gbDf.loc[gbDf["variable"] == "LOGICAL_READ_GB", "variable"] = "Logical Reads"
        gbDf.loc[gbDf["variable"] == "PHYSICAL_READ_GB", "variable"] = "Physical Reads"
        gbDf.loc[gbDf["variable"] == "PHYSICAL_WRITE_GB", "variable"] = (
            "Physical Writes"
        )
        gbDf.sort_values(["variable"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure5a.csv"
            occa_storage.to_csv(
                gbDf[["OBJECT_TYPE", "value", "variable"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        if len(gbDf) == 0:
            lg("\nInsufficient data for plotting Figure 5a")
        else:
            fig5a = px.bar(
                gbDf,
                x="OBJECT_TYPE",
                y="value",
                facet_col="variable",
                color="OBJECT_TYPE",
                title="Segment Activity Percent"
                + suffix
                + "<br>Figure 5a"
                + (
                    " : IO-OBJECT-TYPE [GB_ADDED, LOGICAL_READ_GB, PHYSICAL_READ_GB, PHYSICAL_WRITE_GB]"
                    if SHOW_SOURCE_DATA
                    else ""
                ),
                labels={"value": "% of TOTAL(WAIT_COUNT)"},
                height=HEIGHT * 0.33,
                width=WIDTH,
                template=TEMPLATE,
            )
            fig5a.update_layout(font={"size": 16})

            for idx in range(len(fig5a.layout.annotations)):
                fig5a.layout.annotations[idx].text = fig5a.layout.annotations[
                    idx
                ].text.split("=")[1]

            for idx in range(len(fig5a.data)):
                fig5a.data[idx].text = fig5a.data[idx]["y"][0]

                if fig5a.data[idx]["legendgroup"] not in OBJECT_TYPE_COLORS:
                    OBJECT_TYPE_COLORS[fig5a.data[idx]["legendgroup"]] = "gold"

                fig5a.data[idx]["marker"]["color"] = OBJECT_TYPE_COLORS[
                    fig5a.data[idx]["legendgroup"]
                ]
                fig5a.data[idx]["hovertemplate"] = (
                    fig5a.data[idx]["hovertemplate"]
                    .replace("OBJECT_TYPE=", "object_type=")
                    .replace("variable=", "activity_type=")
                )

            figs.append({"page": 5, "fig": fig5a})

            if SHOW:
                fig5a.show()
            else:
                lg("   Plotted figure 5a")

    # ---
    #
    # Page 5b
    #

    if (
        "IO-OBJECT-TYPE" in dataDf
        and len(
            dataDf["IO-OBJECT-TYPE"][dataDf["IO-OBJECT-TYPE"]["WHICH_DB"] == whichDB]
        )
        > 0
    ):
        if len(snapDf) == 0 or len(snapDf[snapDf["WHICH_DB"] == whichDB]) == 0:
            df = dataDf["IO-OBJECT-TYPE"][
                dataDf["IO-OBJECT-TYPE"]["WHICH_DB"] == whichDB
            ].copy()
            df["end"] = df["SNAP_ID"]

        else:
            df = pd.merge(
                left=dataDf["IO-OBJECT-TYPE"][
                    dataDf["IO-OBJECT-TYPE"]["WHICH_DB"] == whichDB
                ],
                right=snapDf[snapDf["WHICH_DB"] == whichDB],
                how="left",
                left_on=["SNAP_ID"],
                right_on=["snap"],
            )

        gbDf = df.groupby(["end", "OBJECT_TYPE"], as_index=False).sum(numeric_only=True)
        gbDf = pd.melt(
            gbDf[
                [
                    "end",
                    "OBJECT_TYPE",
                    "GB_ADDED",
                    "LOGICAL_READ_GB",
                    "PHYSICAL_READ_GB",
                    "PHYSICAL_WRITE_GB",
                ]
            ],
            id_vars=["end", "OBJECT_TYPE"],
        )
        gbDf.loc[gbDf["variable"] == "GB_ADDED", "variable"] = "GB Added"
        gbDf.loc[gbDf["variable"] == "LOGICAL_READ_GB", "variable"] = "Logical Reads GB"
        gbDf.loc[gbDf["variable"] == "PHYSICAL_READ_GB", "variable"] = (
            "Physical Reads GB"
        )
        gbDf.loc[gbDf["variable"] == "PHYSICAL_WRITE_GB", "variable"] = (
            "Physical Writes GB"
        )
        gbDf.sort_values(["variable", "end"], inplace=True)

        if len(gbDf) == 0:
            lg("\nInsufficient data for plotting Figure 5b")
        else:
            if DATA:
                filename = DATA_PATH + os.sep + "figure5b.csv"
                occa_storage.to_csv(
                    gbDf[["end", "value", "variable", "OBJECT_TYPE"]],
                    filename,
                    index=False,
                )
                lg(("Wrote file " + filename))

            fig5b = px.line(
                gbDf,
                x="end",
                y="value",
                color="OBJECT_TYPE",
                facet_row="variable",
                title="Segment Activity"
                + suffix
                + "<br>Figure 5b"
                + (
                    " : IO-OBJECT-TYPE [GB_ADDED, LOGICAL_READ_GB, PHYSICAL_READ_GB, PHYSICAL_WRITE_GB]"
                    if SHOW_SOURCE_DATA
                    else ""
                ),
                labels={"end": ""},
                height=HEIGHT * 0.67,
                width=WIDTH,
                template=TEMPLATE,
            )
            fig5b.update_layout(font={"size": 16})
            fig5b.update_traces(mode="lines")
            fig5b.update_yaxes(matches=None, showticklabels=True)

            for idx in range(len(fig5b.layout.annotations)):
                fig5b.layout.annotations[idx].text = fig5b.layout.annotations[
                    idx
                ].text.split("=")[1]

            for idx in range(len(fig5b.data)):
                if fig5b.data[idx]["legendgroup"] not in OBJECT_TYPE_COLORS:
                    OBJECT_TYPE_COLORS[fig5b.data[idx]["legendgroup"]] = "gold"

                fig5b.data[idx]["line"]["color"] = OBJECT_TYPE_COLORS[
                    fig5b.data[idx]["legendgroup"]
                ]
                fig5b.data[idx]["hovertemplate"] = (
                    fig5b.data[idx]["hovertemplate"]
                    .replace("OBJECT_TYPE=", "object_type=")
                    .replace("variable=", "activity_type=")
                    .replace("=%{x}", "snap_end=%{x}")
                )

            figs.append({"page": 5, "fig": fig5b})

            if SHOW:
                fig5b.show()
            else:
                lg("   Plotted figure 5b")

    # ------------------------------------------------------------------------------------------------------------------
    # Figure 6
    #

    if (
        "IOSTAT-BY-FUNCTION" in dataDf
        and len(
            dataDf["IOSTAT-BY-FUNCTION"][
                dataDf["IOSTAT-BY-FUNCTION"]["WHICH_DB"] == whichDB
            ]
        )
        > 1
        and len(snapDf) > 0
        and len(snapDf[snapDf["WHICH_DB"] == whichDB]) > 0
    ):
        #
        #       > 1 because older files might contain row like the following
        #
        #       'TABLENOTINTHISVERSION'	snap_id_start	snap_id_end
        #       table not in this version	113426	114146
        #
        gbDf = (
            dataDf["IOSTAT-BY-FUNCTION"][
                dataDf["IOSTAT-BY-FUNCTION"]["WHICH_DB"] == whichDB
            ]
            .groupby(["SNAP_ID", "FUNCTION_NAME"], as_index=False)[
                ["SM_R_REQS", "SM_W_REQS", "LG_R_REQS", "LG_W_REQS"]
            ]
            .sum()
        )
        gbDf = pd.melt(gbDf, id_vars=["SNAP_ID", "FUNCTION_NAME"])
        gbDf = pd.merge(
            left=gbDf,
            right=snapDf[snapDf["WHICH_DB"] == whichDB],
            how="left",
            left_on=["SNAP_ID"],
            right_on=["snap"],
        )

        gbDf.loc[gbDf["variable"] == "LG_R_REQS", "variable"] = "Large Read IOPs"
        gbDf.loc[gbDf["variable"] == "LG_W_REQS", "variable"] = "Large Write IOPs"
        gbDf.loc[gbDf["variable"] == "SM_R_REQS", "variable"] = "Small Read IOPs"
        gbDf.loc[gbDf["variable"] == "SM_W_REQS", "variable"] = "Small Write IOPs"
        gbDf["value"] = gbDf["value"] / (gbDf["dur_m"] * 60)

        gbDf.sort_values(["variable", "end", "FUNCTION_NAME"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure6.csv"
            occa_storage.to_csv(
                gbDf[["end", "value", "variable", "FUNCTION_NAME"]],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        # filename=AWR_MINER_PATH + os.sep + 'awr_miner_plots' + os.sep + 'csv' + os.sep + 'gbdf.csv'
        # occa_storage.to_csv(gbDf, filename, index=False)

        fig6 = px.area(
            gbDf,
            x="end",
            y="value",
            color="FUNCTION_NAME",
            facet_row="variable",
            title="I/O Requests by Size by Function"
            + suffix
            + "<br>Figure 6"
            + (
                " : IOSTAT-BY-FUNCTION [LG_R_REQS, LG_W_REQS, SM_R_REQS, SM_W_REQS]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"end": ""},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig6.update_layout(font={"size": 16})
        fig6.update_yaxes(matches=None, showticklabels=True)

        for idx in range(len(fig6.layout.annotations)):
            fig6.layout.annotations[idx].text = fig6.layout.annotations[idx].text.split(
                "="
            )[1]

        for idx in range(len(fig6.data)):
            fig6.data[idx]["hovertemplate"] = (
                fig6.data[idx]["hovertemplate"]
                .replace("FUNCTION_NAME=", "function_name=")
                .replace("variable=", "I/O type=")
                .replace("=%{x}", "snap_end=%{x}")
            )
        figs.append({"page": 6, "fig": fig6})

        if SHOW:
            fig6.show()
        else:
            lg("   Plotted figure 6")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 7
    #
    # The following logic is needed because not all of the events are sampled at the same frequency
    # i.e. the pivot logic below ensures we do not plot areas when values are missing
    #

    if (
        "IO-WAIT-HISTOGRAM" in dataDf
        and len(
            dataDf["IO-WAIT-HISTOGRAM"][
                dataDf["IO-WAIT-HISTOGRAM"]["WHICH_DB"] == whichDB
            ]
        )
        > 1
    ):
        #
        #       > 1 because older files might contain row like the following
        #
        #       'TABLENOTINTHISVERSION'	snap_id_start	snap_id_end
        #       table not in this version	113426	114146
        #
        df = dataDf["IO-WAIT-HISTOGRAM"][
            dataDf["IO-WAIT-HISTOGRAM"]["WHICH_DB"] == whichDB
        ].copy()
        df.loc[df["WAIT_TIME_MILLI"] > 64, "WAIT_TIME_MILLI"] = 64

        if DATA:
            filename = DATA_PATH + os.sep + "figure7a.0.csv"
            occa_storage.to_csv(
                df[
                    [
                        "snap_id_start",
                        "snap_id_end",
                        "WAIT_CLASS",
                        "EVENT_NAME",
                        "WAIT_TIME_MILLI",
                        "WAIT_COUNT",
                    ]
                ],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        gbDf = df.groupby(["EVENT_NAME", "WAIT_TIME_MILLI"], as_index=False)[
            ["WAIT_COUNT"]
        ].sum()
        gbDf["total"] = gbDf.groupby("EVENT_NAME")["WAIT_COUNT"].transform("sum")
        gbDf["WAIT_COUNT"] = round((gbDf["WAIT_COUNT"] / gbDf["total"]) * 100)

        if DATA:
            filename = DATA_PATH + os.sep + "figure7a.1.csv"
            occa_storage.to_csv(gbDf, filename, index=False)
            lg(("Wrote file " + filename))

        waitTimesGT0 = gbDf[gbDf["WAIT_COUNT"] > 0]["WAIT_TIME_MILLI"].unique()
        gbDf = gbDf[gbDf["WAIT_TIME_MILLI"].isin(waitTimesGT0)]

        gbDf.loc[gbDf["WAIT_TIME_MILLI"] > 64, "WAIT_TIME_MILLI"] = 64

        gbDf.sort_values(["WAIT_TIME_MILLI", "EVENT_NAME"], inplace=True)
        gbDf["WAIT_TIME_MILLI"] = gbDf["WAIT_TIME_MILLI"].astype(str)

        gbDf.loc[gbDf["WAIT_TIME_MILLI"] == "64", "WAIT_TIME_MILLI"] = "64+"
        gbDf.loc[gbDf["WAIT_TIME_MILLI"] == "64.0", "WAIT_TIME_MILLI"] = "64.0+"

        if DATA:
            filename = DATA_PATH + os.sep + "figure7a.2.csv"
            occa_storage.to_csv(gbDf, filename, index=False)
            lg(("Wrote file " + filename))

        fig7a = px.bar(
            gbDf,
            x="WAIT_TIME_MILLI",
            y="WAIT_COUNT",
            facet_col="EVENT_NAME",
            color="WAIT_TIME_MILLI",
            title="I/O Wait Event Histogram"
            + suffix
            + "<br>Figure 7a"
            + (
                " : IO-WAIT-HISTOGRAM [EVENT_NAME, WAIT_TIME_MILLI]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"WAIT_COUNT": "% of Total(WAIT_COUNT)"},
            height=HEIGHT * 0.33,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig7a.update_layout(font={"size": 16})

        for idx in range(len(fig7a.layout.annotations)):
            fig7a.layout.annotations[idx].text = fig7a.layout.annotations[
                idx
            ].text.split("=")[1]

        for idx in range(len(fig7a.data)):
            fig7a.data[idx].text = fig7a.data[idx]["y"]
            fig7a.data[idx]["hovertemplate"] = (
                fig7a.data[idx]["hovertemplate"]
                .replace("WAIT_TIME_MILLI=", "wait_time_milli=")
                .replace("EVENT_NAME=", "event_name=")
            )

        figs.append({"page": 7, "fig": fig7a})

        if SHOW:
            fig7a.show()
        else:
            lg("   Plotted figure 7a")

    # ---
    #
    # Page 7b
    #

    if (
        "IO-WAIT-HISTOGRAM" in dataDf
        and len(
            dataDf["IO-WAIT-HISTOGRAM"][
                dataDf["IO-WAIT-HISTOGRAM"]["WHICH_DB"] == whichDB
            ]
        )
        > 1
    ):
        if len(snapDf) == 0 or len(snapDf[snapDf["WHICH_DB"] == whichDB]) == 0:
            df = dataDf["IO-WAIT-HISTOGRAM"][
                dataDf["IO-WAIT-HISTOGRAM"]["WHICH_DB"] == whichDB
            ].copy()
            df["end"] = df["SNAP_ID"]
            df.sort_values(["end"], inplace=True)

        else:
            df = pd.merge(
                left=dataDf["IO-WAIT-HISTOGRAM"][
                    dataDf["IO-WAIT-HISTOGRAM"]["WHICH_DB"] == whichDB
                ],
                right=snapDf[snapDf["WHICH_DB"] == whichDB],
                how="left",
                left_on=["SNAP_ID"],
                right_on=["snap"],
            )

        if DATA:
            filename = DATA_PATH + os.sep + "figure7b.0.csv"
            occa_storage.to_csv(
                df[
                    ["end", "WAIT_CLASS", "EVENT_NAME", "WAIT_TIME_MILLI", "WAIT_COUNT"]
                ],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        df = df[df["WAIT_TIME_MILLI"].isin(waitTimesGT0)]

        df.loc[df["WAIT_TIME_MILLI"] > 64, "WAIT_TIME_MILLI"] = 64
        df["WAIT_TIME_MILLI"] = df["WAIT_TIME_MILLI"].astype(str)
        df["WAIT_TIME_MILLI"] = df["WAIT_TIME_MILLI"].str.rjust(5)

        df = pd.pivot_table(
            df,
            index="end",
            columns=["EVENT_NAME", "WAIT_TIME_MILLI"],
            values="WAIT_COUNT",
        ).fillna(0)
        df.columns = [" ".join(col).strip() for col in df.columns.values]
        df = pd.melt(df.reset_index(), id_vars="end")
        df[["EVENT_NAME", "WAIT_TIME_MILLI"]] = df.apply(
            parseForFigure7, axis=1, result_type="expand"
        )
        df["WAIT_TIME_MILLI"] = df["WAIT_TIME_MILLI"].astype(float)
        df.sort_values(["WAIT_TIME_MILLI", "EVENT_NAME", "end"], inplace=True)

        df["WAIT_TIME_MILLI"] = df["WAIT_TIME_MILLI"].astype(str)
        df.loc[df["WAIT_TIME_MILLI"] == "64", "WAIT_TIME_MILLI"] = "64+"
        df.loc[df["WAIT_TIME_MILLI"] == "64.0", "WAIT_TIME_MILLI"] = "64.0+"

        if DATA:
            filename = DATA_PATH + os.sep + "figure7b.1.csv"
            occa_storage.to_csv(
                df[["end", "value", "WAIT_TIME_MILLI", "EVENT_NAME"]],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        fig7b = px.area(
            df,
            x="end",
            y="value",
            color="WAIT_TIME_MILLI",
            facet_row="EVENT_NAME",
            title="I/O Wait Event Area Chart"
            + suffix
            + "<br>Figure 7b"
            + (
                " : IO-WAIT-HISTOGRAM [EVENT_NAME, WAIT_TIME_MILLI]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"value": "Wait Count", "end": ""},
            height=HEIGHT * 0.67,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig7b.update_layout(font={"size": 16})
        fig7b.update_yaxes(matches=None, showticklabels=True)

        domainX = fig7b.layout.xaxis.domain[1]
        maximumY = fig7b.layout.annotations[len(fig7b.layout.annotations) - 1]["y"]

        for idx in range(len(fig7b.layout.annotations)):
            fig7b.layout.annotations[idx].text = fig7b.layout.annotations[
                idx
            ].text.split("=")[1]
            #
            # The following code plots the labels horizontally
            #
            # fig7b.layout.annotations[idx].textangle=0
            # fig7b.layout.annotations[idx].x=0
            # fig7b.layout.annotations[idx].y=fig7b.layout.annotations[idx].y + ((domainX - maximumY))
            # fig7b.layout.annotations[idx].xanchor= "left"

            if idx % 2 == 1:
                fig7b.layout.annotations[idx].x *= 1.020

        for idx in range(len(fig7b.data)):
            fig7b.data[idx]["hovertemplate"] = (
                fig7b.data[idx]["hovertemplate"]
                .replace("WAIT_TIME_MILLI=", "wait_time_milli=")
                .replace("EVENT_NAME=", "event_name=")
                .replace("=%{x}", "snap_end=%{x}")
            )

        figs.append({"page": 7, "fig": fig7b})

        if SHOW:
            fig7b.show()
        else:
            lg("   Plotted figure 7b")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 8
    #

    if (
        "AVERAGE-ACTIVE-SESSIONS" in dataDf
        and len(
            dataDf["AVERAGE-ACTIVE-SESSIONS"][
                dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
        and len(snapDf) > 0
        and len(snapDf[snapDf["WHICH_DB"] == whichDB]) > 0
    ):
        df = pd.merge(
            left=dataDf["AVERAGE-ACTIVE-SESSIONS"][
                dataDf["AVERAGE-ACTIVE-SESSIONS"]["WHICH_DB"] == whichDB
            ],
            right=snapDf[snapDf["WHICH_DB"] == whichDB],
            how="left",
            left_on=["SNAP_ID"],
            right_on=["snap"],
        )

        df["label"] = "night [8pm-8am)"
        df.loc[(df["end"].dt.hour >= 8) & (df["end"].dt.hour < 20), "label"] = (
            "day [8am-8pm)"
        )

        df["day_of_week"] = df["end"].dt.dayofweek
        df["day_name"] = df["end"].dt.day_name()
        df["hour"] = df["end"].dt.hour

        if DATA:
            filename = DATA_PATH + os.sep + "figure8.0.csv"
            occa_storage.to_csv(
                df[
                    [
                        "end",
                        "WAIT_CLASS",
                        "AVG_SESS",
                        "label",
                        "day_of_week",
                        "day_name",
                        "hour",
                    ]
                ],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        df.loc[(df["label"] == "day [8am-8pm)"), "hour"] = df["hour"] - 8

        df.loc[(df["label"] == "night [8pm-8am)") & (df["hour"] < 20), "hour"] = (
            df["hour"] + 24
        )
        df.loc[(df["label"] == "night [8pm-8am)"), "hour"] = df["hour"] - 20

        df = df.groupby(
            ["label", "day_of_week", "day_name", "hour", "WAIT_CLASS"], as_index=False
        )["AVG_SESS"].mean()
        #
        #       Force CPU to appear on the bottom of the chart
        #
        df.loc[df["WAIT_CLASS"] == "CPU", "WAIT_CLASS"] = "0CPU"
        df.sort_values(["label", "day_of_week", "hour", "WAIT_CLASS"], inplace=True)
        df.loc[df["WAIT_CLASS"] == "0CPU", "WAIT_CLASS"] = "CPU"

        if DATA:
            filename = DATA_PATH + os.sep + "figure8.1.csv"
            occa_storage.to_csv(df, filename, index=False)
            lg(("Wrote file " + filename))

        fig8 = px.bar(
            df,
            x="hour",
            y="AVG_SESS",
            color="WAIT_CLASS",
            facet_col="day_name",
            facet_row="label",
            title="Average Active Sessions (AAS) by Day by Hour"
            + suffix
            + "<br>Figure 8"
            + (" : AVERAGE-ACTIVE-SESSIONS [WAIT_CLASS]" if SHOW_SOURCE_DATA else ""),
            labels={"AVG_SESS": "AAS"},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig8.update_layout(font={"size": 16})

        for idx in range(len(fig8.layout.annotations)):
            fig8.layout.annotations[idx].text = fig8.layout.annotations[idx].text.split(
                "="
            )[1]

        for idx in range(len(fig8.data)):
            if fig8.data[idx]["legendgroup"] not in WAIT_CLASS_COLORS:
                WAIT_CLASS_COLORS[fig8.data[idx]["legendgroup"]] = "gold"

            fig8.data[idx]["marker"]["color"] = WAIT_CLASS_COLORS[
                fig8.data[idx]["legendgroup"]
            ]
            fig8.data[idx]["hovertemplate"] = (
                fig8.data[idx]["hovertemplate"]
                .replace("WAIT_CLASS=", "wait_class=")
                .replace("label=", "hour_range=")
                .replace("day_name=", "day=")
            )

        figs.append({"page": 8, "fig": fig8})

        if SHOW:
            fig8.show()
        else:
            lg("   Plotted figure 8")

    # ----------------------------------------------------------------------------------------------------------------------
    #
    # Figure 9
    #

    if (
        "MAIN-METRICS" in dataDf
        and len(dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB])
        > 0
    ):
        gbDf = (
            dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB]
            .groupby(["snap", "end"], as_index=False)
            .sum(numeric_only=True)
        )
        gbDf = pd.melt(
            gbDf[
                [
                    "end",
                    "commits_s",
                    "exec_s",
                    "hard_p_s",
                    "logons_total",
                    "logons_s",
                    "redo_mb_s",
                    "sql_res_t_cs",
                ]
            ],
            id_vars="end",
        )

        gbDf.loc[gbDf["variable"] == "commits_s", "variable"] = "Commits / S"
        gbDf.loc[gbDf["variable"] == "exec_s", "variable"] = "Execs / S"
        gbDf.loc[gbDf["variable"] == "hard_p_s", "variable"] = "Hard Parses / S"
        gbDf.loc[gbDf["variable"] == "logons_total", "variable"] = "Logons Total"
        gbDf.loc[gbDf["variable"] == "logons_s", "variable"] = "Logons / S"
        gbDf.loc[gbDf["variable"] == "redo_mb_s", "variable"] = "Redo MB / S"
        gbDf.loc[gbDf["variable"] == "sql_res_t_cs", "variable"] = "SQL Resp (cs)"

        gbDf.sort_values(["variable", "end"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure9.csv"
            occa_storage.to_csv(
                gbDf[["end", "value", "variable"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        fig9 = px.line(
            gbDf,
            x="end",
            y="value",
            facet_row="variable",
            title="Main Activity Variable"
            + suffix
            + "<br>Figure 9"
            + (
                " : MAIN-METRICS [commits_s, exec_s, hard_p_s, logons_total, logons_s, redo_mb_s, sql_res_t_cs]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"end": ""},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig9.update_layout(font={"size": 16})
        fig9.update_traces(mode="lines")
        fig9.update_yaxes(matches=None, showticklabels=True)

        for idx in range(len(fig9.layout.annotations)):
            fig9.layout.annotations[idx].text = fig9.layout.annotations[idx].text.split(
                "="
            )[1]

        for idx in range(len(fig9.data)):
            fig9.data[idx]["hovertemplate"] = (
                fig9.data[idx]["hovertemplate"]
                .replace("variable=", "activity_type=")
                .replace("=%{x}", "snap_end=%{x}")
            )

        figs.append({"page": 9, "fig": fig9})

        if SHOW:
            fig9.show()
        else:
            lg("   Plotted figure 9")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 10
    #

    if (
        "MEMORY" in dataDf
        and len(dataDf["MEMORY"][dataDf["MEMORY"]["WHICH_DB"] == whichDB]) > 0
    ):
        if len(snapDf) == 0 or len(snapDf[snapDf["WHICH_DB"] == whichDB]) == 0:
            df = dataDf["MEMORY"][dataDf["MEMORY"]["WHICH_DB"] == whichDB].copy()
            df["end"] = df["SNAP_ID"]
            df.sort_values(["end"], inplace=True)

        else:
            df = pd.merge(
                left=dataDf["MEMORY"][dataDf["MEMORY"]["WHICH_DB"] == whichDB],
                right=snapDf[snapDf["WHICH_DB"] == whichDB],
                how="left",
                left_on=["SNAP_ID"],
                right_on=["snap"],
            )
            df.sort_values(["end"], inplace=True)

        df.drop_duplicates(inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure10.0.csv"
            occa_storage.to_csv(
                df[["end", "INSTANCE_NUMBER", "TOTAL", "SGA", "PGA"]],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        fig10 = px.area(
            df,
            x="end",
            y="TOTAL",
            facet_row="INSTANCE_NUMBER",
            title="Total Memory Used in GB"
            + suffix
            + "<br>Figure 10"
            + (" : MEMORY [PGA, SGA]" if SHOW_SOURCE_DATA else ""),
            labels={"TOTAL": "GB", "end": ""},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig10.update_layout(font={"size": 16})

        if DATA:
            filename = DATA_PATH + os.sep + "figure10.1.csv"
            occa_storage.to_csv(
                df[["end", "INSTANCE_NUMBER", "TOTAL", "SGA", "PGA"]],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        instanceCount = len(fig10._grid_ref)
        instanceStart = df["INSTANCE_NUMBER"].min() - 1

        #
        #   Row 1 is the bottom-most i.e. highest instance number
        #
        sl = True

        for row_idx, row_figs in enumerate(fig10._grid_ref):
            instanceDf = df[
                df["INSTANCE_NUMBER"] == instanceStart + instanceCount - row_idx
            ]

            fig10.add_trace(
                go.Scatter(
                    x=instanceDf["end"],
                    y=instanceDf["SGA"],
                    name="SGA",
                    showlegend=sl,
                    line_width=8,
                    line_color="red",
                ),
                row=row_idx + 1,
                col=1,
            )
            fig10.add_trace(
                go.Scatter(
                    x=instanceDf["end"],
                    y=instanceDf["PGA"],
                    name="PGA",
                    showlegend=sl,
                    line_width=8,
                    line_color="green",
                ),
                row=row_idx + 1,
                col=1,
            )

            sl = False

        for idx in range(len(fig10.layout.annotations)):
            fig10.layout.annotations[idx].text = fig10.layout.annotations[
                idx
            ].text.split("=")[1]

        for idx in range(len(fig10.data)):
            if fig10.data[idx]["hovertemplate"] is None:
                continue

            fig10.data[idx]["hovertemplate"] = (
                fig10.data[idx]["hovertemplate"]
                .replace("INSTANCE_NUMBER=", "inst=")
                .replace("=%{x}", "snap_end=%{x}")
            )

        figs.append({"page": 10, "fig": fig10})

        if SHOW:
            fig10.show()
        else:
            lg("   Plotted figure 10")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 11
    #

    if (
        "MEMORY-SGA-ADVICE" in dataDf
        and len(
            dataDf["MEMORY-SGA-ADVICE"][
                dataDf["MEMORY-SGA-ADVICE"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        #
        #       Use maximum snap id's estimates -- they are based on the longest observation period
        #
        df = dataDf["MEMORY-SGA-ADVICE"][
            dataDf["MEMORY-SGA-ADVICE"]["WHICH_DB"] == whichDB
        ].copy()
        instance_max = df.groupby(["INSTANCE_NUMBER"], as_index=False)["SNAP_ID"].max()
        instance_max = instance_max.rename(columns={"SNAP_ID": "SNAP_ID_MAX"})
        df = pd.merge(df, instance_max, on="INSTANCE_NUMBER")
        df = df[df["SNAP_ID"] == df["SNAP_ID_MAX"]]

        if DATA:
            filename = DATA_PATH + os.sep + "figure11a.0.csv"
            occa_storage.to_csv(df, filename, index=False)
            lg(("Wrote file " + filename))

        baseDf = df[df["SIZE_FACTOR"] == 1].copy()
        baseDf.rename(
            columns={"ESTD_PHYSICAL_READS": "BASELINE_PHYSICAL_READS"}, inplace=True
        )

        df = pd.merge(
            left=df,
            right=baseDf[["INSTANCE_NUMBER", "BASELINE_PHYSICAL_READS"]],
            how="left",
            left_on=["INSTANCE_NUMBER"],
            right_on=["INSTANCE_NUMBER"],
        )
        df["pct"] = (
            (df["ESTD_PHYSICAL_READS"] / df["BASELINE_PHYSICAL_READS"]) - 1
        ) * 100

        df["pct"] = round(df["pct"], 2)
        df.loc[df["pct"] > 200, "pct"] = 200

        df["color"] = "red"
        df.loc[df["pct"] < 0, "color"] = "green"

        df.loc[abs(df["pct"]) <= 1, "pct"] = 0

        df.sort_values(["INSTANCE_NUMBER", "SGA_TARGET_GB"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure11a.1.csv"
            occa_storage.to_csv(
                df[
                    [
                        "INSTANCE_NUMBER",
                        "SGA_TARGET_GB",
                        "ESTD_PHYSICAL_READS",
                        "BASELINE_PHYSICAL_READS",
                        "pct",
                        "color",
                    ]
                ],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        fig11a = px.bar(
            df,
            x="SGA_TARGET_GB",
            y="pct",
            color="color",
            facet_row="INSTANCE_NUMBER",
            title="Average Percent Change in Physical Reads<br>Relative to SGA_TARGET from SGA Target Advisor"
            + suffix
            + "<br>(Values >= 200% are Set to 200%, Negative is Better), Figure 11a"
            + (
                " : MEMORY-SGA-ADVICE [ESTD_PHYSICAL_READS]" if SHOW_SOURCE_DATA else ""
            ),
            labels={"pct": "%"},
            height=HEIGHT / 2,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig11a.update_layout(font={"size": 16})
        fig11a.update_xaxes(matches=None, showticklabels=True, type="category")
        fig11a.update_yaxes(showticklabels=True)
        fig11a.update(layout_showlegend=False)

        for idx in range(len(fig11a.layout.annotations)):
            fig11a.layout.annotations[idx].text = fig11a.layout.annotations[
                idx
            ].text.split("=")[1]

        for idx in range(len(fig11a.data)):
            fig11a.data[idx].text = fig11a.data[idx]["y"]
            fig11a.data[idx]["marker"]["color"] = fig11a.data[idx]["name"]
            fig11a.data[idx]["hovertemplate"] = (
                fig11a.data[idx]["hovertemplate"]
                .replace("INSTANCE_NUMBER=", "inst=")
                .replace("SGA_TARGET_GB=", "sga_target_gb=")
            )

        figs.append({"page": 11, "fig": fig11a})

        if SHOW:
            fig11a.show()
        else:
            lg("   Plotted figure 11a")

    # ---
    #
    # Page 11b
    #

    if (
        "MEMORY-PGA-ADVICE" in dataDf
        and len(
            dataDf["MEMORY-PGA-ADVICE"][
                dataDf["MEMORY-PGA-ADVICE"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        #
        #       Use maximum snap id's estimates -- they are based on the longest observation period
        #
        df = dataDf["MEMORY-PGA-ADVICE"][
            dataDf["MEMORY-PGA-ADVICE"]["WHICH_DB"] == whichDB
        ].copy()
        instance_max = df.groupby(["INSTANCE_NUMBER"], as_index=False)["SNAP_ID"].max()
        instance_max = instance_max.rename(columns={"SNAP_ID": "SNAP_ID_MAX"})
        df = pd.merge(df, instance_max, on="INSTANCE_NUMBER")
        df = df[df["SNAP_ID"] == df["SNAP_ID_MAX"]]

        if "ESTD_EXTRA_MB_RW" in df.columns:
            if DATA:
                filename = DATA_PATH + os.sep + "figure11b.0.csv"
                occa_storage.to_csv(df, filename, index=False)
                lg(("Wrote file " + filename))

            baseDf = df[df["SIZE_FACTOR"] == 1].copy()
            baseDf.rename(
                columns={"ESTD_EXTRA_MB_RW": "BASELINE_EXTRA_MB_RW"}, inplace=True
            )

            df = pd.merge(
                left=df,
                right=baseDf[["INSTANCE_NUMBER", "BASELINE_EXTRA_MB_RW"]],
                how="left",
                left_on=["INSTANCE_NUMBER"],
                right_on=["INSTANCE_NUMBER"],
            )
            df["pct"] = (
                (df["ESTD_EXTRA_MB_RW"] / df["BASELINE_EXTRA_MB_RW"]) - 1
            ) * 100

            df["pct"] = round(df["pct"], 2)
            df.loc[df["pct"] > 200, "pct"] = 200

            df["color"] = "red"
            df.loc[df["pct"] < 0, "color"] = "green"

            df.loc[abs(df["pct"]) <= 1, "pct"] = 0

            df.sort_values(["INSTANCE_NUMBER", "PGA_TARGET_GB"], inplace=True)

            if DATA:
                filename = DATA_PATH + os.sep + "figure11b.1.csv"
                occa_storage.to_csv(
                    df[
                        [
                            "INSTANCE_NUMBER",
                            "PGA_TARGET_GB",
                            "ESTD_EXTRA_MB_RW",
                            "BASELINE_EXTRA_MB_RW",
                            "pct",
                            "color",
                        ]
                    ],
                    filename,
                    index=False,
                )
                lg(("Wrote file " + filename))

            fig11b = px.bar(
                df,
                x="PGA_TARGET_GB",
                y="pct",
                color="color",
                facet_row="INSTANCE_NUMBER",
                title="Average Percent Change in W/A MB Read/Written to Disk<br>Relative to PGA_AGGREGATE_TARGET from PGA Target Advisor"
                + suffix
                + "<br>(Values >= 200% are Set to 200%, Negative is Better), Figure 11b"
                + (
                    " : MEMORY-PGA-ADVICE [ESTD_EXTRA_MB_RW]"
                    if SHOW_SOURCE_DATA
                    else ""
                ),
                labels={"pct": "%"},
                height=HEIGHT / 2,
                width=WIDTH,
                template=TEMPLATE,
            )
            fig11b.update_layout(font={"size": 16})
            fig11b.update_xaxes(matches=None, showticklabels=True, type="category")
            fig11b.update_yaxes(showticklabels=True)
            fig11b.update(layout_showlegend=False)

            for idx in range(len(fig11b.layout.annotations)):
                fig11b.layout.annotations[idx].text = fig11b.layout.annotations[
                    idx
                ].text.split("=")[1]

            for idx in range(len(fig11b.data)):
                fig11b.data[idx].text = fig11b.data[idx]["y"]
                fig11b.data[idx]["marker"]["color"] = fig11b.data[idx]["name"]
                fig11b.data[idx]["hovertemplate"] = (
                    fig11b.data[idx]["hovertemplate"]
                    .replace("INSTANCE_NUMBER=", "inst=")
                    .replace("PGA_TARGET_GB=", "pga_target_gb=")
                )

            figs.append({"page": 11, "fig": fig11b})

            if SHOW:
                fig11b.show()
            else:
                lg("   Plotted figure 11b")
        else:
            lg("    Skipping figure 11b: ESTD_EXTRA_MB_RW row is missing")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 12
    #

    if (
        "TOP-SQL-BY-SNAPID" in dataDf
        and len(
            dataDf["TOP-SQL-BY-SNAPID"][
                dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        gbDf = dataDf["TOP-SQL-BY-SNAPID"][
            dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
        ].copy()

        # Change from astype to to_numeric as it can handle errors better
        gbDf["CPU_T_S"] = pd.to_numeric(gbDf["CPU_T_S"], errors="coerce")
        gbDf["ELAP_S"] = pd.to_numeric(gbDf["ELAP_S"], errors="coerce")
        gbDf["IO_WAIT"] = pd.to_numeric(gbDf["IO_WAIT"], errors="coerce")
        gbDf["EXECS"] = pd.to_numeric(gbDf["EXECS"], errors="coerce")

        if DATA:
            filename = DATA_PATH + os.sep + "figure12a.0.csv"
            occa_storage.to_csv(
                gbDf[
                    [
                        "snap_id_start",
                        "snap_id_end",
                        "PARSING_SCHEMA_NAME",
                        "COMMAND_NAME",
                        "SQL_ID",
                        "EXECS",
                        "IO_WAIT",
                        "CPU_T_S",
                        "ELAP_S",
                    ]
                ],
                filename,
                index=False,
            )
            lg(("Wrote file " + filename))

        gbDf = gbDf[gbDf["ELAP_S"] > 0]
        # Cast 'EXECS' column dtype to float64 instead of int64  since a float will be assigned in the following line
        # (this prevents Pandas warnings)
        gbDf["EXECS"] = gbDf["EXECS"].astype(float)
        # From Tyler's original code: #modify execs from 0 to 0.1 if work was done but not completed
        gbDf.loc[gbDf["EXECS"] == 0, "EXECS"] = 0.1
        gbDf = gbDf.groupby(["COMMAND_NAME"], as_index=False).sum(numeric_only=True)
        gbDf["ELAP_S_PER_EXEC"] = gbDf["ELAP_S"] / gbDf["EXECS"]

        gbDf = pd.melt(
            gbDf[
                [
                    "COMMAND_NAME",
                    "EXECS",
                    "ELAP_S",
                    "IO_WAIT",
                    "CPU_T_S",
                    "ELAP_S_PER_EXEC",
                ]
            ],
            id_vars="COMMAND_NAME",
        )
        gbDf["total"] = gbDf.groupby("variable")["value"].transform("sum")
        gbDf["value"] = round((gbDf["value"] / gbDf["total"]) * 100, 1)

        gbDf.loc[gbDf["variable"] == "EXECS", "variable"] = "Executions"
        gbDf.loc[gbDf["variable"] == "ELAP_S", "variable"] = "Elapsed Time (S)"
        gbDf.loc[gbDf["variable"] == "IO_WAIT", "variable"] = "IO Wait"
        gbDf.loc[gbDf["variable"] == "CPU_T_S", "variable"] = "CPU Time (S)"
        gbDf.loc[gbDf["variable"] == "ELAP_S_PER_EXEC", "variable"] = (
            "Elapsed (S) / Execution"
        )

        if len(gbDf) == 0:
            lg("\nInsufficient data for plotting Figure 12a")
        else:
            if DATA:
                filename = DATA_PATH + os.sep + "figure12a.1.csv"
                occa_storage.to_csv(
                    gbDf[["COMMAND_NAME", "value", "variable"]], filename, index=False
                )
                lg(("Wrote file " + filename))

            fig12a = px.bar(
                gbDf,
                x="COMMAND_NAME",
                y="value",
                facet_row="variable",
                color="COMMAND_NAME",
                title="SQL Percent by Command by Metric (All Schema)"
                + suffix
                + "<br>Figure 12a"
                + (
                    " : TOP-SQL-BY-SNAPID [COMMAND, CPU_T_S, ELAP_S, EXECS, IO_WAIT, PARSING_SCHEMA_NAME]"
                    if SHOW_SOURCE_DATA
                    else ""
                ),
                labels={"value": "%"},
                height=HEIGHT / 2,
                width=WIDTH,
                template=TEMPLATE,
            )
            fig12a.update_layout(font={"size": 16})

            for idx in range(len(fig12a.layout.annotations)):
                fig12a.layout.annotations[idx].text = fig12a.layout.annotations[
                    idx
                ].text.split("=")[1]

            for idx in range(len(fig12a.data)):
                fig12a.data[idx].text = fig12a.data[idx]["y"]
                fig12a.data[idx]["hovertemplate"] = (
                    fig12a.data[idx]["hovertemplate"]
                    .replace("COMMAND_NAME=", "command_name=")
                    .replace("variable=", "metric=")
                )

            figs.append({"page": 12, "fig": fig12a})

            if SHOW:
                fig12a.show()
            else:
                lg("   Plotted figure 12a")

    # ---
    #
    # Page 12b
    #

    if (
        "TOP-SQL-BY-SNAPID" in dataDf
        and len(
            dataDf["TOP-SQL-BY-SNAPID"][
                dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        gbDf = dataDf["TOP-SQL-BY-SNAPID"][
            dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
        ].copy()
        gbDf["ELAP_S"] = pd.to_numeric(gbDf["ELAP_S"], errors="coerce")
        gbDf = gbDf.groupby(["PARSING_SCHEMA_NAME"], as_index=False)[["ELAP_S"]].sum()

        gbDf["rank"] = gbDf["ELAP_S"].rank(method="dense", ascending=False)

        if DATA:
            filename = DATA_PATH + os.sep + "figure12b.0.csv"
            occa_storage.to_csv(
                gbDf[["PARSING_SCHEMA_NAME", "ELAP_S", "rank"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        gbDf = gbDf[gbDf["rank"] <= 10]
        topSchema = gbDf["PARSING_SCHEMA_NAME"].values

        gbDf = dataDf["TOP-SQL-BY-SNAPID"][
            (dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB)
            & (dataDf["TOP-SQL-BY-SNAPID"]["PARSING_SCHEMA_NAME"].isin(topSchema))
        ].copy()

        # Change from astype to to_numeric as it can handle errors better
        gbDf["CPU_T_S"] = pd.to_numeric(gbDf["CPU_T_S"], errors="coerce")
        gbDf["ELAP_S"] = pd.to_numeric(gbDf["ELAP_S"], errors="coerce")
        gbDf["IO_WAIT"] = pd.to_numeric(gbDf["IO_WAIT"], errors="coerce")
        gbDf["EXECS"] = pd.to_numeric(gbDf["EXECS"], errors="coerce")

        gbDf = gbDf[gbDf["ELAP_S"] > 0]
        # Cast 'EXECS' column dtype to float64 instead of int64 since a float will be assigned in the following line
        # (this prevents Pandas warnings)
        gbDf["EXECS"] = gbDf["EXECS"].astype(float)
        # From Tyler's original code: #modify execs from 0 to 0.1 if work was done but not completed
        gbDf.loc[gbDf["EXECS"] == 0, "EXECS"] = 0.1
        gbDf["ELAP_S_PER_EXEC"] = gbDf["ELAP_S"] / gbDf["EXECS"]

        gbDf = gbDf.groupby(["PARSING_SCHEMA_NAME"], as_index=False).sum(
            numeric_only=True
        )

        gbDf = pd.melt(
            gbDf[
                [
                    "PARSING_SCHEMA_NAME",
                    "EXECS",
                    "ELAP_S",
                    "IO_WAIT",
                    "CPU_T_S",
                    "ELAP_S_PER_EXEC",
                ]
            ],
            id_vars="PARSING_SCHEMA_NAME",
        )
        gbDf["total"] = gbDf.groupby("variable")["value"].transform("sum")
        gbDf["value"] = round((gbDf["value"] / gbDf["total"]) * 100, 1)

        gbDf.loc[gbDf["variable"] == "EXECS", "variable"] = "Executions"
        gbDf.loc[gbDf["variable"] == "ELAP_S", "variable"] = "Elapsed Time (S)"
        gbDf.loc[gbDf["variable"] == "IO_WAIT", "variable"] = "IO Wait"
        gbDf.loc[gbDf["variable"] == "CPU_T_S", "variable"] = "CPU Time (S)"
        gbDf.loc[gbDf["variable"] == "ELAP_S_PER_EXEC", "variable"] = (
            "Elapsed (S) / Execution"
        )

        if len(gbDf) == 0:
            lg("\nInsufficient data for plotting Figure 12b")
        else:
            fig12b = px.bar(
                gbDf,
                x="PARSING_SCHEMA_NAME",
                y="value",
                facet_row="variable",
                color="PARSING_SCHEMA_NAME",
                title="SQL Percent by Schema by Metric (Top 10 Schema by Total Elapsed (S))"
                + suffix
                + "<br>Figure 12b"
                + (
                    " : TOP-SQL-BY-SNAPID [COMMAND, CPU_T_S, ELAP_S, EXECS, IO_WAIT, PARSING_SCHEMA_NAME]"
                    if SHOW_SOURCE_DATA
                    else ""
                ),
                labels={"value": "%"},
                height=HEIGHT / 2,
                width=WIDTH,
                template=TEMPLATE,
            )
            fig12b.update_layout(font={"size": 16})

            for idx in range(len(fig12b.layout.annotations)):
                fig12b.layout.annotations[idx].text = fig12b.layout.annotations[
                    idx
                ].text.split("=")[1]

            for idx in range(len(fig12b.data)):
                fig12b.data[idx].text = fig12b.data[idx]["y"]
                fig12b.data[idx]["hovertemplate"] = (
                    fig12b.data[idx]["hovertemplate"]
                    .replace("PARSING_SCHEMA_NAME=", "parsing_schema_name=")
                    .replace("variable=", "metric=")
                )

            figs.append({"page": 12, "fig": fig12b})

            if SHOW:
                fig12b.show()
            else:
                lg("   Plotted figure 12b")

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Figure 13
    #

    if (
        "TOP-SQL-BY-SNAPID" in dataDf
        and len(
            dataDf["TOP-SQL-BY-SNAPID"][
                dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        gbDf = dataDf["TOP-SQL-BY-SNAPID"][
            dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
        ].copy()
        gbDf["ELAP_S"] = pd.to_numeric(gbDf["ELAP_S"], errors="coerce")

        if DATA:
            filename = DATA_PATH + os.sep + "figure13a.0.csv"
            occa_storage.to_csv(gbDf, filename, index=False)
            lg(("Wrote file " + filename))

        gbDf = gbDf.groupby(["PARSING_SCHEMA_NAME"], as_index=False)[["ELAP_S"]].sum()
        gbDf["rank"] = gbDf["ELAP_S"].rank(method="dense", ascending=False)

        if DATA:
            filename = DATA_PATH + os.sep + "figure13a.1.csv"
            occa_storage.to_csv(
                gbDf[["rank", "PARSING_SCHEMA_NAME", "ELAP_S"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        gbDf = gbDf[gbDf["rank"] <= 10]
        topSchema = gbDf["PARSING_SCHEMA_NAME"].values

        # ---

        df0 = dataDf["TOP-SQL-BY-SNAPID"][
            dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
        ].copy()
        # Change from astype to to_numeric as it can handle errors better
        df0["ELAP_S"] = pd.to_numeric(df0["ELAP_S"], errors="coerce")
        df0["EXECS"] = pd.to_numeric(df0["EXECS"], errors="coerce")
        df0 = df0[df0["PARSING_SCHEMA_NAME"].isin(topSchema)]

        df0 = df0[df0["ELAP_S"] > 0]
        # Cast 'EXECS' column dtype to float64 instead of int64 since a float will be assigned in the following line
        # (this prevents Pandas warnings)
        df0["EXECS"] = df0["EXECS"].astype(float)
        # From Tyler's original code: #modify execs from 0 to 0.1 if work was done but not completed
        df0.loc[df0["EXECS"] == 0, "EXECS"] = 0.1
        df0["ELAP_S_PER_EXEC"] = df0["ELAP_S"] / df0["EXECS"]

        df0["bin"] = pd.cut(
            df0["ELAP_S_PER_EXEC"],
            bins=[0, 0.1, 0.25, 1, 10, 60, 600, 3600, 21600, float("inf")],
            labels=[
                "    0.0  -     0.1",
                "    0.1  -     0.25",
                "    0.25 -     1.00",
                "    1.00 -    10.00",
                "   10.00 -    60.00",
                "   60.00 -   600.00",
                "  600.00 -  3600.00",
                " 3600.00 - 21600.00",
                "21600.00+",
            ],
        )

        df = (
            pd.pivot_table(
                df0,
                index=["bin"],
                values="ELAP_S_PER_EXEC",
                aggfunc="count",
                observed=False,
            )
            .fillna(0)
            .reset_index()
        )
        df["total"] = df["ELAP_S_PER_EXEC"].sum()
        df["value"] = round((df["ELAP_S_PER_EXEC"] / df["total"]) * 100)

        df.sort_values(["bin"], inplace=True)
        df["bin"] = df["bin"].astype(str)

        if DATA:
            filename = DATA_PATH + os.sep + "figure13a.2.csv"
            occa_storage.to_csv(df[["bin", "value"]], filename, index=False)
            lg(("Wrote file " + filename))

        fig13a = px.bar(
            df,
            x="bin",
            y="value",
            color="bin",
            title="Histogram of  Aggregate SQL Elapsed Time (S) per Execution (Top 10 Schema by Total Elapsed (S))"
            + suffix
            + "<br>Figure 13a"
            + (" : TOP-SQL-BY-SNAPID [ELAP_S, EXECS]" if SHOW_SOURCE_DATA else ""),
            labels={"bin": "Bins - Time in Seconds", "value": "%"},
            height=HEIGHT * 0.33,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig13a.update_layout(font={"size": 16})

        for idx in range(len(fig13a.data)):
            fig13a.data[idx].text = fig13a.data[idx]["y"]

        figs.append({"page": 13, "fig": fig13a})

        if SHOW:
            fig13a.show()
        else:
            lg("   Plotted figure 13a")

    # ---
    #
    # Page 13b
    #

    if (
        "TOP-SQL-BY-SNAPID" in dataDf
        and len(
            dataDf["TOP-SQL-BY-SNAPID"][
                dataDf["TOP-SQL-BY-SNAPID"]["WHICH_DB"] == whichDB
            ]
        )
        > 0
    ):
        df = df0.copy()
        df["bin"] = df["bin"].astype(str)
        df = (
            pd.pivot_table(
                df,
                index=["PARSING_SCHEMA_NAME"],
                columns=["bin"],
                values="ELAP_S_PER_EXEC",
                aggfunc="count",
            )
            .fillna(0)
            .reset_index()
        )
        df = pd.melt(df, id_vars=["PARSING_SCHEMA_NAME"])

        df["total"] = df.groupby(["PARSING_SCHEMA_NAME"])["value"].transform("sum")
        df["value"] = round((df["value"] / df["total"]) * 100)

        df.sort_values(["PARSING_SCHEMA_NAME", "bin"], inplace=True)

        if len(df) == 0:
            lg("\nInsufficient data for plotting Figure 13b")
        else:
            if DATA:
                filename = DATA_PATH + os.sep + "figure13b.csv"
                occa_storage.to_csv(df[["bin", "value"]], filename, index=False)
                lg(("Wrote file " + filename))

            """
            The following is only if the PARSING_SCHEMA_NAME goes number_rows >= 1(1-desired_spacing)  causing an error in plot
            i.e : of spacing max 1/63-1 <- a case (1/n-1) (63 rows, ) 
            and using the space of 1/62 =  0.016 would result of an really shrinked graph with no clear-visual plot
            facet_row_spacing : it's a proportionso increasing the height wouldn't work.
            """

            # desired_spacing=0.01 #default for plotly is 0.03
            max_facets = 16  # TOP-N Facets to show when schemas>=34 [for space 0.03] (really weird case, but need to be handled)
            n_schemas = df['PARSING_SCHEMA_NAME'].nunique() #number of schemas

            if n_schemas > max_facets:
                delete_facet_label = True

                # Uncoment to grab first 16 - with label
                # top_schemas = (
                #     df.groupby('PARSING_SCHEMA_NAME')['value'].sum()
                #     .nlargest(max_facets).index
                # )
                # df = df[df['PARSING_SCHEMA_NAME'].isin(top_schemas)]
            else:
                delete_facet_label = False

            extra_label = (
                "<br>Faceting-description has been omitted due to excessive row count. "
                "For additional assistance, please contact OCCA Support."
                if delete_facet_label else ""
            )

            fig13b = px.bar(
                df,
                x="bin",
                y="value",
                facet_row=None if  delete_facet_label else  "PARSING_SCHEMA_NAME",
                color="bin",
                title="Histogram of SQL Elapsed Time (S) / Execution (Top 10 Schema by Total Elapsed (S))"
                + suffix + extra_label
                + "<br>Figure 13b"
                + (
                    " : TOP-SQL-BY-SNAPID [ELAP_S, EXECS, PARSING_SCHEMA_NAME]"
                    if SHOW_SOURCE_DATA
                    else ""
                ),
                labels={"bin": "Bins - Time in Seconds", "value": "%"},
                height=HEIGHT * 0.67,
                width=WIDTH,
                template=TEMPLATE,
            )
            fig13b.update_layout(font={"size": 16})

            for idx in range(len(fig13b.layout.annotations)):
                fig13b.layout.annotations[idx].text = fig13b.layout.annotations[
                    idx
                ].text.split("=")[1]

            for idx in range(len(fig13b.data)):
                fig13b.data[idx].text = fig13b.data[idx]["y"]
                fig13b.data[idx]["hovertemplate"] = (
                    fig13b.data[idx]["hovertemplate"]
                    .replace("PARSING_SCHEMA_NAME=", "parsing_schema_name=")
                    .replace("variable=", "metric=")
                )

            figs.append({"page": 13, "fig": fig13b})

            if SHOW:
                fig13b.show()
            else:
                lg("   Plotted figure 13b")

    # ----------------------------------------------------------------------------------------------------------------------
    #
    # Figure 14
    #

    plotChart = False

    if (
        "MAIN-METRICS" in dataDf
        and len(dataDf["MAIN-METRICS"][dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB])
        > 0
    ):
        df = dataDf["MAIN-METRICS"][
            dataDf["MAIN-METRICS"]["WHICH_DB"] == whichDB
        ].copy()

        cols = ["gc_cr_rec_s", "gc_cu_rec_s", "gc_cr_get_cs", "gc_cu_get_cs"]
        totals = df[cols].sum().values

        for i in totals:
            if i > 0:
                plotChart = True
                break

    if plotChart:
        gbDf = pd.melt(df[["end", "inst"] + cols], id_vars=["inst", "end"])

        gbDf.loc[gbDf["variable"] == "gc_cr_rec_s", "variable"] = (
            "GC CR Block Recs / S "
        )
        gbDf.loc[gbDf["variable"] == "gc_cu_rec_s", "variable"] = (
            "GC Current Block Recs / S"
        )
        gbDf.loc[gbDf["variable"] == "gc_cr_get_cs", "variable"] = "GC Avg CR Gets cs"
        gbDf.loc[gbDf["variable"] == "gc_cu_get_cs", "variable"] = (
            "GC Avg Current Gets cs"
        )

        gbDf.sort_values(["variable", "end"], inplace=True)

        if DATA:
            filename = DATA_PATH + os.sep + "figure14.csv"
            occa_storage.to_csv(
                gbDf[["end", "inst", "value", "variable"]], filename, index=False
            )
            lg(("Wrote file " + filename))

        fig14 = px.line(
            gbDf,
            x="end",
            y="value",
            facet_row="variable",
            color="inst",
            title="Global Cache Attributes"
            + suffix
            + "<br>Figure 14"
            + (
                " : MAIN-METRICS [gc_cr_rec_s, gc_cu_rec_s, gc_cr_get_cs, gc_cu_get_cs]"
                if SHOW_SOURCE_DATA
                else ""
            ),
            labels={"end": ""},
            height=HEIGHT,
            width=WIDTH,
            template=TEMPLATE,
        )
        fig14.update_layout(font={"size": 16})
        fig14.update_traces(mode="lines")
        fig14.update_yaxes(matches=None, showticklabels=True)
        fig14.update_yaxes(rangemode="tozero")

        for idx in range(len(fig14.layout.annotations)):
            fig14.layout.annotations[idx].text = fig14.layout.annotations[
                idx
            ].text.split("=")[1]

        for idx in range(len(fig14.data)):
            fig14.data[idx]["hovertemplate"] = (
                fig14.data[idx]["hovertemplate"]
                .replace("variable=", "metric=")
                .replace("=%{x}", "snap_end=%{x}")
            )

        figs.append({"page": 14, "fig": fig14})

        if SHOW:
            fig14.show()
        else:
            lg("   Plotted figure 14")

    # ------------------------------------------------------------------------------------------------------------------

    if 1 == 0:  # in notebook
        po.init_notebook_mode()

    filename = (
        AWR_MINER_PATH
        + os.sep
        + "awr_miner_plots"
        + os.sep
        + "html"
        + os.sep
        + whichDB
        + ".html"
    )

    dashboard = open(filename, "w", encoding="UTF-8")
    dashboard.write(
        "<html><head><title>AWR Miner Plot - " + suffix + "</title></head><body>" + "\n"
    )

    include_plotlyjs = True
    lastPage = 0

    plots_per_db[whichDB] = {"figures": figs, "DB_NAME": DB_NAME}
    for fig in figs:
        if fig["page"] != lastPage:
            dashboard.write('<p style="page-break-before: always"><hr>')
            lastPage = fig["page"]

        inner_html = (
            fig["fig"]
            .to_html(include_plotlyjs=include_plotlyjs)
            .split("<body>")[1]
            .split("</body>")[0]
        )
        dashboard.write(inner_html)

        include_plotlyjs = False

    dashboard.write("</body></html>" + "\n")
    dashboard.close()

    lg("Output written to file " + filename + "\n")


if os.getenv("RUN_FROM_API", "False") == "True":
    import json
    from plotly.io import to_json

    plots_file_path = os.path.join(AWR_MINER_PATH, "plots.json")

    plots_per_db_serializable = {}
    for which_db in plots_per_db:
        plots = plots_per_db[which_db]["figures"]
        DB_NAME = plots_per_db[which_db]["DB_NAME"]
        suffix = " - " + str(DB_NAME) + ", v" + __version__ + " @ " + tsDisplay
        # Removing suffix for the plots in Easy Miner
        for plot in plots:
            current_title = plot["fig"].layout.title.text
            if suffix in current_title:
                new_title = current_title.replace(suffix, "")
                plot["fig"].update_layout(title_text=new_title)

        plots_per_db_serializable[which_db] = [
            {"page": idx, "fig": to_json(plot["fig"]), "DB_NAME": DB_NAME}
            for idx, plot in enumerate(plots)
        ]

    with open(plots_file_path, "w") as f:
        json.dump(plots_per_db_serializable, f)

print("DBs plotted: ", plots_per_db.keys())
if 1 == 0:
    for d in occaDf:
        filename = (
            AWR_MINER_PATH
            + os.sep
            + "awr_miner_plots"
            + os.sep
            + "csv"
            + os.sep
            + "occa_"
            + d
            + ".csv"
        )
        sortCols = ["WHICH_DB", "SNAP_ID"] + (
            ["INSTANCE_NUMBER"] if "INSTANCE_NUMBER" in occaDf[d] else []
        )
        occa_storage.to_csv(occaDf[d].sort_values(sortCols), filename, index=False)

        lg("Wrote file " + filename)

# ---

occaCompositeDf = []

if "CPU" not in occaDf:
    lg(
        "\nMAIN-METRICS was missing for all databases; unable to construct the output needed for further processing by occa."
    )

else:
    occaCompositeDf = occaDf["CPU"].copy()

    if "MEMORY" in occaDf:
        occaCompositeDf = pd.merge(
            left=occaCompositeDf,
            right=occaDf["MEMORY"][
                ["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID", "SGA", "PGA", "SGAPGA"]
            ],
            how="left",
            left_on=["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID"],
            right_on=["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID"],
        )

    if "IOPS" in occaDf:
        occaCompositeDf = pd.merge(
            left=occaCompositeDf,
            right=occaDf["IOPS"][
                ["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID", "read_iops", "write_iops"]
            ],
            how="left",
            left_on=["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID"],
            right_on=["WHICH_DB", "INSTANCE_NUMBER", "SNAP_ID"],
        )
        occaCompositeDf["iops"] = (
            occaCompositeDf["read_iops"] + occaCompositeDf["write_iops"]
        )

    if "STORAGE" in occaDf:
        columns = ["WHICH_DB", "SNAP_ID", "SIZE_GB"]
        if "USED_SIZE_GB" in occaDf["STORAGE"].columns:
            columns.append("USED_SIZE_GB")

        occaCompositeDf = pd.merge(
            left=occaCompositeDf,
            right=occaDf["STORAGE"][columns],
            how="left",
            left_on=["WHICH_DB", "SNAP_ID"],
            right_on=["WHICH_DB", "SNAP_ID"],
        )

    cols = ["WHICH_DB", "DB_NAME", "INSTANCE_NUMBER"]
    if "host" in occaCompositeDf.columns:
        cols.append("host")
    cols += ["end", "SNAP_ID"]

    if "effective_o_AVERAGE_pct" in occaCompositeDf.columns:
        cols.append("effective_o_AVERAGE_pct")
    if "cpu_per_s_original" in occaCompositeDf.columns:
        cols.append("cpu_per_s_original")

    cols = cols + [c for c in occaCompositeDf.columns if c not in cols]
    occaCompositeDf = occaCompositeDf[cols]
    occaCompositeDf.rename(columns={"INSTANCE_NUMBER": "INSTANCE"}, inplace=True)

    occaCompositeDf["cwd"] = cwd
    occaCompositeDf["platform"] = platformName
    occaCompositeDf["create_dttm_utc"] = now
    occaCompositeDf["version"] = __version__

    cols = {}
    for _ in occaCompositeDf:
        if _ in OCCA_ALIASES:
            cols[_] = OCCA_ALIASES[_]
    if len(cols) > 0:
        occaCompositeDf.rename(columns=cols, inplace=True)

    if "DB PGA (MB)" in occaCompositeDf:
        occaCompositeDf["DB PGA (MB)"] *= 1024
    if "DB SGA (MB)" in occaCompositeDf:
        occaCompositeDf["DB SGA (MB)"] *= 1024
    if "DB Memory (MB)" in occaCompositeDf:
        occaCompositeDf["DB Memory (MB)"] *= 1024

    databaseMissingCols = [_ for _ in DATABASE_COLS if _ not in occaCompositeDf]
    instanceMissingCols = [_ for _ in INSTANCE_COLS if _ not in occaCompositeDf]

    for _ in databaseMissingCols:
        occaCompositeDf[_] = np.nan

    for _ in instanceMissingCols:
        occaCompositeDf[_] = np.nan

    occaCompositeDf = occaCompositeDf.round(PRECISION)

    filename = AWR_MINER_PATH + os.sep + OCCA_PATH + os.sep + "occa_composite.csv"
    occa_storage.to_csv(
        occaCompositeDf.sort_values(["DB_NAME", "SNAP_ID", "INSTANCE"]),
        filename,
        index=False,
    )
    lg("\nWrote file " + filename)

    # ---

    if len(DATABASE_COLS) == len(databaseMissingCols):
        dbPercentilesDf = []
        lg(
            "No database metrics present; cannot add database percentile columns to awr_properties_database_original.csv"
        )
    else:
        dbPercentilesDf = (
            occaCompositeDf.groupby(["WHICH_DB"])[DATABASE_COLS]
            .describe(percentiles=PERCENTILES)
            .reset_index()
        )
        dbPercentilesDf.columns = [
            c[0] if c[1] == "" else c[0] + "." + c[1] for c in dbPercentilesDf.columns
        ]
        cols = ["WHICH_DB"] + [j + "." + i for i in PCT_COLS for j in DATABASE_COLS]
        dbPercentilesDf = dbPercentilesDf[cols]
        dbPercentilesDf = dbPercentilesDf.round(PRECISION)

        if 1 == 0:
            filename = (
                AWR_MINER_PATH
                + os.sep
                + OCCA_PATH
                + os.sep
                + "sizing"
                + os.sep
                + "dbPercentiles.csv"
            )
            occa_storage.to_csv(
                dbPercentilesDf.sort_values(["WHICH_DB"]), filename, index=False
            )
            lg("\nWrote file " + filename)

    # ---

    if len(INSTANCE_COLS) == len(instanceMissingCols):
        dbInstancePercentilesDf, instancePercentiles = [], []
        lg(
            "No instance metrics present; cannot add instance percentile columns to awr_properties_instance_original.csv"
        )
    else:
        dbInstancePercentilesDf = occaCompositeDf.groupby(["WHICH_DB", "SNAP_ID"])[
            INSTANCE_COLS
        ].sum()
        dbInstancePercentilesDf = (
            dbInstancePercentilesDf.groupby(["WHICH_DB"])[INSTANCE_COLS]
            .describe(percentiles=PERCENTILES)
            .reset_index()
        )
        dbInstancePercentilesDf.columns = [
            c[0] if c[1] == "" else c[0] + "." + c[1] for c in dbInstancePercentilesDf
        ]
        cols = ["WHICH_DB"] + [j + "." + i for i in PCT_COLS for j in INSTANCE_COLS]
        dbInstancePercentilesDf = dbInstancePercentilesDf[cols]
        dbInstancePercentilesDf = dbInstancePercentilesDf.round(PRECISION)

        dbInstancePercentilesDf["cwd"] = cwd
        dbInstancePercentilesDf["platform"] = platformName
        dbInstancePercentilesDf["create_dttm_utc"] = now
        dbInstancePercentilesDf["version"] = __version__

        if 1 == 0:
            filename = (
                AWR_MINER_PATH
                + os.sep
                + OCCA_PATH
                + os.sep
                + "sizing"
                + os.sep
                + "dbInstancePercentilesDf.csv"
            )
            occa_storage.to_csv(
                dbInstancePercentilesDf.sort_values(["WHICH_DB"]), filename, index=False
            )
            lg("\nWrote file " + filename)

        # ---

        instancePercentilesDf = (
            occaCompositeDf.groupby(["WHICH_DB", "INSTANCE"])[INSTANCE_COLS]
            .describe(percentiles=PERCENTILES)
            .reset_index()
        )

        instancePercentilesDf.columns = [
            c[0] if c[1] == "" else c[0] + "." + c[1]
            for c in instancePercentilesDf.columns
        ]
        cols = ["WHICH_DB", "INSTANCE"] + [
            j + "." + i for i in PCT_COLS for j in INSTANCE_COLS
        ]
        instancePercentilesDf = instancePercentilesDf[cols]
        instancePercentilesDf = instancePercentilesDf.round(PRECISION)

        instancePercentilesDf["cwd"] = cwd
        instancePercentilesDf["platform"] = platformName
        instancePercentilesDf["create_dttm_utc"] = now
        instancePercentilesDf["version"] = __version__

        if 1 == 0:
            filename = (
                AWR_MINER_PATH
                + os.sep
                + OCCA_PATH
                + os.sep
                + "instancePercentilesDf.csv"
            )
            occa_storage.to_csv(
                instancePercentilesDf.sort_values(["WHICH_DB", "INSTANCE"]),
                filename,
                index=False,
            )
            lg("\nWrote file " + filename)

# ---

if len(occaCompositeDf) > 0:
    occaDatabasesDf = occaCompositeDf[["WHICH_DB", "DB_NAME"]].drop_duplicates()
    occaDatabasesDf["Cohort"] = ""
    occaDatabasesDf["cdb"] = ""
    occaDatabasesDf["STOP"] = "STOP"

    for _ in DATABASE_COLS:
        occaDatabasesDf[_] = ""

    if len(dbPercentilesDf) > 0:
        occaDatabasesDf = pd.merge(
            left=occaDatabasesDf,
            right=dbPercentilesDf,
            how="left",
            left_on=["WHICH_DB"],
            right_on=["WHICH_DB"],
        )

    if len(dbInstancePercentilesDf) > 0:
        occaDatabasesDf = pd.merge(
            left=occaDatabasesDf,
            right=dbInstancePercentilesDf,
            how="left",
            left_on=["WHICH_DB"],
            right_on=["WHICH_DB"],
        )

    cols = ["Cohort", "WHICH_DB", "cdb"]

    if INCLUDE_OVERRIDES:
        for _ in DATABASE_COLS:
            cols.append(_)

    cols.append("STOP")
    cols.append("DB_NAME")

    if len(dbPercentilesDf) > 0 and len(dbInstancePercentilesDf) > 0:
        cols += [j + "." + i for i in PCT_COLS for j in DATABASE_COLS + INSTANCE_COLS]
        occaDatabasesDf = occaDatabasesDf[cols]

    occaDatabasesDf["cwd"] = cwd
    occaDatabasesDf["platform"] = platformName
    occaDatabasesDf["create_dttm_utc"] = now
    occaDatabasesDf["version"] = __version__

    filename = (
        AWR_MINER_PATH
        + os.sep
        + OCCA_PATH
        + os.sep
        + "properties"
        + os.sep
        + "awr_properties_database_original.csv"
    )
    occa_storage.to_csv(occaDatabasesDf.sort_values(["DB_NAME"]), filename, index=False)
    lg("\nWrote file " + filename)

    build_analysis_snaps_time()

    lg(tz_file_message)

    # If cohort wizard found - the csv mapped values execute this
    cohort_folder_mapper.process_properties_file()

    # ---

    occaInstancesDf = instancesDf.drop_duplicates()

    occaInstancesDf["Cohort"] = ""
    occaInstancesDf["STOP"] = ""

    for _ in INSTANCE_COLS:
        occaInstancesDf[_] = ""

    occaInstancesDf["HOST"] = (
        occaInstancesDf["HOST"] if "HOST" in occaInstancesDf else ""
    )
    occaInstancesDf["NUM_CPUS"] = (
        occaInstancesDf["NUM_CPUS"] if "NUM_CPUS" in occaInstancesDf else ""
    )
    occaInstancesDf["PHYSICAL_MEMORY_MB"] = (
        (occaInstancesDf["PHYSICAL_MEMORY_GB"] * 1024)
        if "PHYSICAL_MEMORY_GB" in occaInstancesDf
        else ""
    )
    occaInstancesDf["PLATFORM_NAME"] = (
        occaInstancesDf["PLATFORM_NAME"] if "PLATFORM_NAME" in occaInstancesDf else ""
    )
    occaInstancesDf["cpu_count"] = (
        occaInstancesDf["cpu_count"] if "cpu_count" in occaInstancesDf else ""
    )
    occaInstancesDf["cpu_min_count"] = (
        occaInstancesDf["cpu_min_count"] if "cpu_min_count" in occaInstancesDf else ""
    )

    if len(instancePercentilesDf) > 0:
        occaInstancesDf = pd.merge(
            left=occaInstancesDf,
            right=instancePercentilesDf,
            how="left",
            left_on=["WHICH_DB", "INSTANCE"],
            right_on=["WHICH_DB", "INSTANCE"],
        )

    cols = ["Cohort", "WHICH_DB", "INSTANCE"]
    for _ in INSTANCE_COLS:
        cols.append(_)
    cols.append("STOP")
    cols.append("DB_NAME")

    for c in occaInstancesDf.columns:
        if c not in cols:
            cols.append(c)

    occaInstancesDf = occaInstancesDf[cols]

    occaInstancesDf["cwd"] = cwd
    occaInstancesDf["platform"] = platformName
    occaInstancesDf["create_dttm_utc"] = now
    occaInstancesDf["version"] = __version__

    if INCLUDE_OVERRIDES:
        filename = (
            AWR_MINER_PATH
            + os.sep
            + OCCA_PATH
            + os.sep
            + "properties"
            + os.sep
            + "awr_properties_instance_original.csv"
        )
        occa_storage.to_csv(
            occaInstancesDf.sort_values(["WHICH_DB", "INSTANCE"]), filename, index=False
        )
        lg("\nWrote file " + filename)

# ---

if len(fatalErrors) > 0:
    lg(
        "\n\n------------------------------------------------------------------------------------------------------------\n"
    )
    lg(
        "The following fatal were encountered in processing your files; the databases are not included in the results"
    )

    for _ in fatalErrors:
        lg("\nDatabase " + _)
        lg("--------------------------------------------")

        for m in fatalErrors[_]:
            lg(m)

    lg(
        "\n------------------------------------------------------------------------------------------------------------\n\n"
    )

lg("\nTotal running time " + str(round(time.time() - tb, 3)) + "s")
