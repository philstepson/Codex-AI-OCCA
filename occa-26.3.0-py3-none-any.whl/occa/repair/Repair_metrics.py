__version__ = '1.10'

#
# Version History
#
# 2021-03-29    1.10  tmf    Upgrades based on field use cases
# 2020-12-15    1.9   tmf    Added completion message
# 2020-12-02    1.8   tmf    Upgrades based on field use cases
# 2020-11-27    1.7   tmf    Added version moniker
# 2020-11-19    1.6   tmf    Upgraded based on field use cases
# 2020-11-05    1.4   tmf    Enable debugging with environment variable
# 2020-10-26    1.3   tmf    New method for toggling debugging messages
# 2020-09-07    1.2   tmf    Standardized debugging
# 2020-07-25    1.1   tmf    First revision with version stamp

# ----------------------------------------------------------------------------------------------------------------------

import csv
import os

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = os.environ['EMCC_SIZING_DATA_FILES_ROOT_DIR'] if 'EMCC_SIZING_DATA_FILES_ROOT_DIR' in os.environ else '.'
DEBUG   =  True                                          if ('EMCC_SIZING_REPAIR_DEBUG'       in os.environ and os.environ['EMCC_SIZING_REPAIR_DEBUG'].upper() == 'Y') else False

# ----------------------------------------------------------------------------------------------------------------------

inputPath  = ROOT_DIR + os.sep + 'emcc_sizing_extracts_original'
outputPath = ROOT_DIR + os.sep + 'emcc_sizing_extracts'

# ----------------------------------------------------------------------------------------------------------------------

logFile = ''

def lg(t):
    logFile.write(t + '\n')
    print(t)

def unexpectedLength(ctr, nextField, s, rowCtr):
    global logFile
    t = 'Unexpected length: ' + str(len(s)) + ' @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

def unexpectedNextField(ctr, nextField, s, rowCtr):
    global logFile
    t = 'Unexpected nextField @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

# ---

def repair(filename):
    global DEBUG, logFile

    print('\n\nAttempting repair of ' + filename + ' with version ' + __version__)
    print('-------------------------------------------------------------------------------------------------------------')

    b = os.path.getsize(inputPath + os.sep + filename)
    if b == 0:
        print('\nFile ' + filename + ' has 0 length')

        return

    with open(inputPath + os.sep + filename) as f:
        fReader = csv.DictReader(f, delimiter=',')
        header  = [h.strip() for h in fReader.fieldnames]

# ---

    os.makedirs(outputPath, exist_ok=True)

    outputFile   = open(outputPath + os.sep + filename, 'w')
    outputWriter = csv.DictWriter(outputFile, fieldnames=header, lineterminator='\n')
    outputWriter.writeheader()

    logFile = open(outputPath + os.sep + filename.replace('.csv', '.txt'), 'w')

# ---

    if DEBUG: lg(str(header))

    ctr, lineCtr, rowCtr = 0, 0, 0
    d = {}
    nextField = ''

    with open(inputPath + os.sep + filename) as f:
        for line in f:
            lineCtr += 1

            if lineCtr == 1: continue

            ctr += 1

            if ctr == 0: continue

            s = [c.rstrip() for c in line.split(' ') if c != '']

            if DEBUG:
                if ctr == 1: print('\n--------------------------------  lineCtr: ' + str(lineCtr))

                print('l ' + str(lineCtr) + '; ctr ' + str(ctr) + ' : nextField -> ' + nextField + ', len(s): ' + str(len(s)) + ', s: ' + str(s))

# ---

            if ctr == 1:
                if len(s) == 1:
                    d['TARGET_GUID'] = s[0]
                    nextField        = 'TARGET_NAME'

                elif len(s) == 15:
                    d['TARGET_GUID']          = s[0]
                    d['TARGET_NAME']          = s[1]
                    d['TARGET_TYPE']          = s[2]
                    d['METRIC_LABEL']         = s[3]
                    d['COLUMN_LABEL']         = s[4] + ' ' + s[5]
                    d['METRIC_NAME']          = s[6]
                    d['METRIC_COLUMN']        = s[7]
                    d['ROLLUP_TIMESTAMP_UTC'] = s[8] + ' ' + s[9]
                    d['MINIMUM']              = s[10]
                    d['MAXIMUM']              = s[11]
                    d['AVERAGE']              = s[12]
                    d['STANDARD_DEVIATION']   = s[13]
                    d['SAMPLE_COUNT']         = s[14]
                    nextField                 = 'done'

                elif len(s) == 16:
                    d['TARGET_GUID']          = s[0]
                    d['TARGET_NAME']          = s[1]
                    d['TARGET_TYPE']          = s[2]
                    d['METRIC_LABEL']         = s[3] + ' ' + s[4]
                    d['COLUMN_LABEL']         = s[5] + ' ' + s[6]
                    d['METRIC_NAME']          = s[7]
                    d['METRIC_COLUMN']        = s[8]
                    d['ROLLUP_TIMESTAMP_UTC'] = s[9] + ' ' + s[10]
                    d['MINIMUM']              = s[11]
                    d['MAXIMUM']              = s[12]
                    d['AVERAGE']              = s[13]
                    d['STANDARD_DEVIATION']   = s[14]
                    d['SAMPLE_COUNT']         = s[15]
                    nextField                 = 'done'

                elif len(s) == 17:
                    d['TARGET_GUID']          = s[0]
                    d['TARGET_NAME']          = s[1]
                    d['TARGET_TYPE']          = s[2]
                    d['METRIC_LABEL']         = s[3]
                    d['COLUMN_LABEL']         = s[4] + ' ' + s[5] + ' ' + s[6] + ' ' + s[7]
                    d['METRIC_NAME']          = s[8]
                    d['METRIC_COLUMN']        = s[9]
                    d['ROLLUP_TIMESTAMP_UTC'] = s[10] + ' ' + s[11]
                    d['MINIMUM']              = s[12]
                    d['MAXIMUM']              = s[13]
                    d['AVERAGE']              = s[14]
                    d['STANDARD_DEVIATION']   = s[15]
                    d['SAMPLE_COUNT']         = s[16]
                    nextField                 = 'done'

                elif len(s) == 18:
                    d['TARGET_GUID']          = s[0]
                    d['TARGET_NAME']          = s[1]
                    d['TARGET_TYPE']          = s[2]
                    d['METRIC_LABEL']         = s[3]
                    d['COLUMN_LABEL']         = s[4] + ' ' + s[5] + ' ' + s[6] + ' ' + s[7] + ' ' + s[8]
                    d['METRIC_NAME']          = s[9]
                    d['METRIC_COLUMN']        = s[10]
                    d['ROLLUP_TIMESTAMP_UTC'] = s[11] + ' ' + s[12]
                    d['MINIMUM']              = s[13]
                    d['MAXIMUM']              = s[14]
                    d['AVERAGE']              = s[15]
                    d['STANDARD_DEVIATION']   = s[16]
                    d['SAMPLE_COUNT']         = s[17]
                    nextField                 = 'done'

                elif len(s) == 23:
                    d['TARGET_GUID']          = s[0]
                    d['TARGET_NAME']          = s[1]
                    d['TARGET_TYPE']          = s[2]
                    d['METRIC_LABEL']         = s[3] + ' ' + s[4]
                    d['COLUMN_LABEL']         = s[5] + ' ' + s[6] + ' ' + s[7] + ' ' + s[8] + ' ' + s[9] + ' ' + s[10] + ' ' + s[11] + ' ' + s[12] + ' ' + s[13]
                    d['METRIC_NAME']          = s[14]
                    d['METRIC_COLUMN']        = s[15]
                    d['ROLLUP_TIMESTAMP_UTC'] = s[16] + ' ' + s[17]
                    d['MINIMUM']              = s[18]
                    d['MAXIMUM']              = s[19]
                    d['AVERAGE']              = s[20]
                    d['STANDARD_DEVIATION']   = s[21]
                    d['SAMPLE_COUNT']         = s[22]
                    nextField                 = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif ctr == 2:
                if nextField == 'done': pass

                elif nextField == 'TARGET_NAME':
                    if len(s) == 1:
                        d['TARGET_NAME'] = s[0]
                        nextField        = 'TARGET_TYPE'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            elif ctr == 3:
                if nextField == 'done': pass

                elif nextField == 'TARGET_TYPE':
                    if len(s) == 1:
                        d['TARGET_TYPE'] = s[0]
                        nextField        = 'METRIC_LABEL'

                    elif len(s) == 2:
                        d['TARGET_TYPE']  = s[0]
                        d['METRIC_LABEL'] = s[1]
                        nextField         = 'COLUMN_LABEL'

                    elif len(s) == 3:
                        d['TARGET_TYPE'] = s[0]

                        if s[1] == 'CPU' and s[2] == 'Usage':
                            d['METRIC_LABEL'] = s[1] + ' ' + s[2]
                            nextField         = 'COLUMN_LABEL'

                        elif s[1] == 'Database' and s[2] in ['Limits', 'Size']:
                            d['METRIC_LABEL'] = s[1] + ' ' + s[2]
                            nextField         = 'COLUMN_LABEL'

                        elif s[1] == 'Optimal' and s[2] == 'SGA':
                            d['METRIC_LABEL'] = s[1] + ' ' + s[2]
                            nextField         = 'COLUMN_LABEL'

                        elif s[1] == 'PGA' and s[2] == 'Allocated':
                            d['METRIC_LABEL'] = s[1] + ' ' + s[2]
                            nextField         = 'COLUMN_LABEL'

                        elif s[1] == 'Wait' and s[2] == 'Bottlenecks':
                            d['METRIC_LABEL'] = s[1] + ' ' + s[2]
                            nextField         = 'COLUMN_LABEL'

                        else:
                            d['METRIC_LABEL'] = s[1]
                            d['COLUMN_LABEL'] = s[2]
                            nextField         = 'METRIC_NAME'

                    elif len(s) == 5:
                        #lg('ctr==3, len(s)==5 : ' + str(s))

                        d['TARGET_TYPE']  = s[0]
                        d['METRIC_LABEL'] = s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4]
                        nextField         = 'COLUMN_LABEL'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            elif ctr == 4:
                if nextField == 'done': pass

                elif nextField == 'METRIC_LABEL':
                    #lg('nextField: METRIC_LABEL : ctr==4, len(s): ' + str(len(s)) + ', ' + str(s))

                    if   len(s) == 1:
                        d['METRIC_LABEL'] = s[0]
                        nextField         = 'COLUMN_LABEL'

                    elif len(s) == 2:
                        d['METRIC_LABEL'] = s[0] + ' ' + s[1]
                        nextField         = 'COLUMN_LABEL'

                    elif len(s) == 3:
                        if s[0] == 'CPU' and s[1] == 'Usage':
                            d['METRIC_LABEL'] = s[0] + ' ' + s[1]
                            d['COLUMN_LABEL'] = s[2]
                            nextField         = 'METRIC_NAME'

                        elif s[0] == 'Database' and s[1] in ['Limits', 'Size']:
                            d['METRIC_LABEL'] = s[0] + ' ' + s[1]
                            d['COLUMN_LABEL'] = s[2]
                            nextField         = 'METRIC_NAME'

                        elif s[0] == 'Optimal' and s[1] == 'SGA':
                            d['METRIC_LABEL'] = s[0] + ' ' + s[1]
                            d['COLUMN_LABEL'] = s[2]
                            nextField         = 'METRIC_NAME'

                        elif s[0] == 'PGA' and s[1] == 'Allocated':
                            d['METRIC_LABEL'] = s[0] + ' ' + s[1]
                            d['COLUMN_LABEL'] = s[2]
                            nextField         = 'METRIC_NAME'

                        elif s[0] == 'Wait' and s[1] == 'Bottlenecks':
                            d['METRIC_LABEL'] = s[0] + ' ' + s[1]
                            d['COLUMN_LABEL'] = s[2]
                            nextField         = 'METRIC_NAME'

                        else:
                            d['METRIC_LABEL'] = s[0]
                            d['COLUMN_LABEL'] = s[1] + ' ' + s[2]
                            nextField         = 'METRIC_NAME'

                    elif len(s) == 4:
                        #lg('ctr==4, len(s)==4 : ' + str(s))

                        d['METRIC_LABEL'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3]
                        nextField         = 'COLUMN_LABEL'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                elif nextField == 'COLUMN_LABEL':
                    if len(s) == 2:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1]
                        nextField         = 'METRIC_NAME'

                    elif len(s) == 3:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1] + ' ' + s[2]
                        nextField         = 'METRIC_NAME'

                    elif len(s) == 4:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3]
                        nextField         = 'METRIC_NAME'

                    elif len(s) == 9:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4] + ' ' + s[5] + ' ' + s[6] + ' ' + s[7] + ' ' + s[8]
                        nextField         = 'METRIC_NAME'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                elif nextField == 'METRIC_NAME':
                    if len(s) == 2:
                        d['METRIC_NAME'] = s[0] + ' ' + s[1]
                        nextField        = 'METRIC_COLUMN'

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            elif ctr == 5:
                if nextField == 'done': pass

                elif nextField == 'COLUMN_LABEL':
                    if len(s) == 2:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1]
                        nextField         = 'METRIC_NAME'

                    elif len(s) == 3:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1] + ' ' + s[2]
                        nextField         = 'METRIC_NAME'

                    elif len(s) == 4:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3]
                        nextField         = 'METRIC_NAME'

                    elif len(s) == 9:
                        d['COLUMN_LABEL'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4] + ' ' + s[5] + ' ' + s[6] + ' ' + s[7] + ' ' + s[8]
                        nextField         = 'METRIC_NAME'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                elif nextField == 'METRIC_NAME':
                    if len(s) == 7:
                        d['METRIC_NAME']          = s[0]
                        d['METRIC_COLUMN']        = s[1]
                        d['ROLLUP_TIMESTAMP_UTC'] = s[2] + ' ' + s[3]
                        d['MINIMUM']              = s[4]
                        d['MAXIMUM']              = s[5]
                        d['AVERAGE']              = s[6]
                        nextField                 = 'STANDARD_DEVIATION'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                elif nextField == 'METRIC_COLUMN':
                    if len(s) == 7:
                        d['METRIC_COLUMN']        = s[0] + ' ' + s[1]
                        d['ROLLUP_TIMESTAMP_UTC'] = s[2] + ' ' + s[3]
                        d['MINIMUM']              = s[4]
                        d['MAXIMUM']              = s[5]
                        d['AVERAGE']              = s[6]
                        nextField                 = 'STANDARD_DEVIATION'

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            elif ctr == 6:
                if nextField == 'done': pass

                elif nextField == 'METRIC_NAME':
                    if len(s) == 1:
                        d['METRIC_NAME'] = s[0]
                        nextField        = 'METRIC_COLUMN'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                elif nextField == 'STANDARD_DEVIATION':
                    if len(s) == 2:
                        d['STANDARD_DEVIATION'] = s[0]
                        d['SAMPLE_COUNT']       = s[1]
                        nextField               = 'done'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            elif ctr == 7:
                if nextField == 'done': pass

                elif nextField == 'METRIC_COLUMN':
                    if len(s) == 1:
                        d['METRIC_COLUMN'] = s[0]
                        nextField          = 'ROLLUP_TIMESTAMP_UTC'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            elif ctr == 8:
                if nextField == 'done': pass

                elif nextField == 'ROLLUP_TIMESTAMP_UTC':
                    if len(s) == 2:
                        d['ROLLUP_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                        nextField                 = 'MINIMUM'

                    elif len(s) == 4:
                        d['ROLLUP_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                        d['MINIMUM']              = s[2]
                        d['MAXIMUM']              = s[3]
                        nextField                 = 'AVERAGE'

                    elif len(s) == 6:
                        d['ROLLUP_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                        d['MINIMUM']              = s[2]
                        d['MAXIMUM']              = s[3]
                        d['AVERAGE']              = s[4]
                        d['STANDARD_DEVIATION']   = s[5]
                        nextField                 = 'SAMPLE_COUNT'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            elif ctr == 9:
                if nextField == 'done': pass

                elif nextField == 'AVERAGE':
                    if len(s) == 3:
                        d['AVERAGE']            = s[0]
                        d['STANDARD_DEVIATION'] = s[1]
                        d['SAMPLE_COUNT']       = s[2]
                        nextField               = 'done'

                elif nextField == 'MINIMUM':
                    if len(s) == 5:
                        d['MINIMUM']            = s[0]
                        d['MAXIMUM']            = s[1]
                        d['AVERAGE']            = s[2]
                        d['STANDARD_DEVIATION'] = s[3]
                        d['SAMPLE_COUNT']       = s[4]
                        nextField               = 'done'

                elif nextField == 'SAMPLE_COUNT':
                    if len(s) == 1:
                        d['SAMPLE_COUNT'] = s[0]
                        nextField         = 'done'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

            else:
                lg('Unexpected value for ctr: ' + str(ctr))

                for k in d:
                    lg(k + ' -> ' + d[k])

                logFile.close()
                outputFile.close()

                quit()

# ---

            if nextField == 'done':
                nextField = ''

                if DEBUG: print('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

                missing=False

                for k in header:
                    if k not in d.keys():
                        lg(k + '! is missing from d.keys()')
                        missing=True

                for k in d.keys():
                    if k not in header:
                        lg(k + '! is missing from header')
                        missing=True

                if missing:
                    lg('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

                    for k in d:
                        lg(k + ' -> ' + d[k])

                    outputFile.close()
                    logFile.close()

                    quit()

                outputWriter.writerow(d)

                rowCtr += 1
                ctr     = 0 if ctr == 1 else -1
                d       = {}

                #if rowCtr == 77580: DEBUG = True
                #if lineCtr > 100: break

    lg('\n\nWrote ' + str(rowCtr) + ' rows derived from ' + str(lineCtr - 1) + ' original lines to ' + outputPath + os.sep + filename)

    outputFile.close()
    logFile.close()

# ---

os.makedirs(outputPath, exist_ok=True)

# ---

if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_db_hourly_03_months.csv'): repair('emcc_sizing_metrics_db_hourly_03_months.csv')

if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_db_daily_03_months.csv'): repair('emcc_sizing_metrics_db_daily_03_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_db_daily_06_months.csv'): repair('emcc_sizing_metrics_db_daily_06_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_db_daily_09_months.csv'): repair('emcc_sizing_metrics_db_daily_09_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_db_daily_12_months.csv'): repair('emcc_sizing_metrics_db_daily_12_months.csv')

# ---

if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_host_hourly_03_months.csv'): repair('emcc_sizing_metrics_host_hourly_03_months.csv')

if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_host_daily_03_months.csv'): repair('emcc_sizing_metrics_host_daily_03_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_host_daily_06_months.csv'): repair('emcc_sizing_metrics_host_daily_06_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_host_daily_09_months.csv'): repair('emcc_sizing_metrics_host_daily_09_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_host_daily_12_months.csv'): repair('emcc_sizing_metrics_host_daily_12_months.csv')

# ---

if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_pdb_hourly_03_months.csv'): repair('emcc_sizing_metrics_pdb_hourly_03_months.csv')

if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_pdb_daily_03_months.csv'): repair('emcc_sizing_metrics_pdb_daily_03_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_pdb_daily_06_months.csv'): repair('emcc_sizing_metrics_pdb_daily_06_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_pdb_daily_09_months.csv'): repair('emcc_sizing_metrics_pdb_daily_09_months.csv')
if os.path.exists(inputPath + os.sep + 'emcc_sizing_metrics_pdb_daily_12_months.csv'): repair('emcc_sizing_metrics_pdb_daily_12_months.csv')
