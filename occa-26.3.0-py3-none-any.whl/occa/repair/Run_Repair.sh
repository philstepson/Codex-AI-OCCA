#!/bin/sh

#
# Version 1.5
#
# Version History
# 2021-02-22    1.5   tmf     Added host_cpu
# 2020-12-15    1.4   tmf     Added sample debugging line
# 2020-11-15    1.3   tmf     Slight re-factoring of environment variables
# 2020-10-26    1.2   tmf     Added repair script for new version & format of structure_db
# 2020-09-07    1.1   tmf     First version
#

EMCC_SIZING_ROOT=../src

#
# the following is for debugging only
#EMCC_SIZING_ROOT=../../src/emcc_sizing/src
#export EMCC_SIZING_REPAIR_DEBUG=y
#

REPAIR_SRC=$EMCC_SIZING_ROOT/repair

# ######################################################################################################################

python $REPAIR_SRC/Repair_availability_history.py
python $REPAIR_SRC/Repair_metrics.py

python $REPAIR_SRC/Repair_structure_db.py
python $REPAIR_SRC/Repair_structure_db2.py
python $REPAIR_SRC/Repair_structure_db_dr.py
python $REPAIR_SRC/Repair_structure_db_params.py
python $REPAIR_SRC/Repair_structure_db_props.py
python $REPAIR_SRC/Repair_structure_db_sga.py

python $REPAIR_SRC/Repair_structure_host_cpu.py
python $REPAIR_SRC/Repair_structure_host_props.py

python $REPAIR_SRC/Repair_structure_pdb_params.py
python $REPAIR_SRC/Repair_structure_pdb_props.py
python $REPAIR_SRC/Repair_structure_pdb_sga.py
