To run extract file repair scripts:

1) rename directory <<working-dir-customerN>>/emcc_sizing_extracts to <<working-dir-customerN>>/emcc_sizing_extracts_original

2) open a shell and set its current working directory to <<working-dir-customerN>>

3) at the command prompt type, ./Run_Repair.sh

You will see a series of messages as the repair scripts attempt to re-format the
extract files received from the customer as .csv files as shown below.

4) try to initiate the normal sizing workflow in Step 2 : Create_Properties_Files.py


************************************************************************************************************************

Sample repair messages (the row counts you see will depend on the actual row counts in the original files)

************************************************************************************************************************


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_availability_history.csv with version 1.7
-------------------------------------------------------------------------------------------------------------


Wrote 38701 rows dervied from 232206 original lines to ./emcc_sizing_extracts/emcc_sizing_availability_history.csv


Attempting repair of emcc_sizing_metrics_db_hourly_03_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 335837 rows dervied from 3358370 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_db_hourly_03_months.csv


Attempting repair of emcc_sizing_metrics_db_daily_03_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 45328 rows dervied from 453280 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_db_daily_03_months.csv


Attempting repair of emcc_sizing_metrics_db_daily_06_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 45940 rows dervied from 459400 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_db_daily_06_months.csv


Attempting repair of emcc_sizing_metrics_db_daily_09_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 37962 rows dervied from 379620 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_db_daily_09_months.csv


Attempting repair of emcc_sizing_metrics_db_daily_12_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 25047 rows dervied from 250470 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_db_daily_12_months.csv


Attempting repair of emcc_sizing_metrics_host_hourly_03_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 37008 rows dervied from 370080 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_host_hourly_03_months.csv


Attempting repair of emcc_sizing_metrics_host_daily_03_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 4188 rows dervied from 41880 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_host_daily_03_months.csv


Attempting repair of emcc_sizing_metrics_host_daily_06_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 4140 rows dervied from 41400 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_host_daily_06_months.csv


Attempting repair of emcc_sizing_metrics_host_daily_09_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 3780 rows dervied from 37800 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_host_daily_09_months.csv


Attempting repair of emcc_sizing_metrics_host_daily_12_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 3639 rows dervied from 36390 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_host_daily_12_months.csv


Attempting repair of emcc_sizing_metrics_pdb_hourly_03_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_pdb_hourly_03_months.csv


Attempting repair of emcc_sizing_metrics_pdb_daily_03_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_pdb_daily_03_months.csv


Attempting repair of emcc_sizing_metrics_pdb_daily_06_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_pdb_daily_06_months.csv


Attempting repair of emcc_sizing_metrics_pdb_daily_09_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_pdb_daily_09_months.csv


Attempting repair of emcc_sizing_metrics_pdb_daily_12_months.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_metrics_pdb_daily_12_months.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_db.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Wrote 37 rows to ./emcc_sizing_extracts/emcc_sizing_structure_db.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_db.csv with version 1.8
-------------------------------------------------------------------------------------------------------------


Repair_structure_db2.py is not the correct version for file ./emcc_sizing_extracts_original/emcc_sizing_structure_db.csv

Try running Repair_structure_db.py instead




Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_db_dr.csv with version 1.6
-------------------------------------------------------------------------------------------------------------


Wrote 4 rows dervied from 36 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_db_dr.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_db_params.csv with version 1.6
-------------------------------------------------------------------------------------------------------------


Wrote 275 rows dervied from 1925 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_db_params.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_db_props.csv with version 1.6
-------------------------------------------------------------------------------------------------------------


Wrote 124 rows dervied from 868 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_db_props.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_db_sga.csv with version 1.7
-------------------------------------------------------------------------------------------------------------


Wrote 333 rows dervied from 1998 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_db_sga.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_host_props.csv with version 1.6
-------------------------------------------------------------------------------------------------------------


Wrote 16 rows dervied from 112 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_host_props.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_pdb_params.csv with version 1.6
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_pdb_params.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_pdb_props.csv with version 1.6
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_pdb_props.csv


Attempting repair of ./emcc_sizing_extracts_original/emcc_sizing_structure_pdb_sga.csv with version 1.6
-------------------------------------------------------------------------------------------------------------


Wrote 0 rows dervied from 0 original lines to ./emcc_sizing_extracts/emcc_sizing_structure_pdb_sga.csv
