__version__ = '1.2'

#
# Version History
#
# 2021-03-29    1.2   tmf    Upgrades based on field use cases
# 2021-02-22    1.1   tmf    First revision

# ----------------------------------------------------------------------------------------------------------------------

import csv
import os

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = os.environ['EMCC_SIZING_DATA_FILES_ROOT_DIR'] if 'EMCC_SIZING_DATA_FILES_ROOT_DIR' in os.environ else '.'
DEBUG   =  True                                          if ('EMCC_SIZING_REPAIR_DEBUG'       in os.environ and os.environ['EMCC_SIZING_REPAIR_DEBUG'].upper() == 'Y') else False

# ----------------------------------------------------------------------------------------------------------------------

inputFilename  = ROOT_DIR   + os.sep + 'emcc_sizing_extracts_original' + os.sep + 'emcc_sizing_structure_host_cpu.csv'
outputPath     = ROOT_DIR   + os.sep + 'emcc_sizing_extracts'
outputFilename = outputPath + os.sep + 'emcc_sizing_structure_host_cpu.csv'

# ---

print('\n\nAttempting repair of ' + inputFilename + ' with version ' + __version__)
print('-------------------------------------------------------------------------------------------------------------')

if not os.path.exists(inputFilename):
    print('\n\nInput file ' + inputFilename + ' does not exists; exiting')

    quit()

# ----------------------------------------------------------------------------------------------------------------------

with open(inputFilename) as f:
    fReader = csv.DictReader(f, delimiter=',')
    header  = [h.strip() for h in fReader.fieldnames]

if DEBUG: print(str(header))

# ---

os.makedirs(outputPath, exist_ok=True)

outputFile               = open(outputFilename, 'w')
outputWriter             = csv.DictWriter(outputFile, fieldnames=header, lineterminator='\n')
outputWriter.writeheader()

logFile=open(outputPath + os.sep + 'emcc_sizing_structure_host_cpu.txt', 'w')

# ---

def lg(t):
    logFile.write(t + '\n')
    print(t)

def unexpectedLength(ctr, nextField, s, rowCtr):
    t = 'Unexpected length @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

def unexpectedNextField(ctr, nextField, s, rowCtr):
    t = 'Unexpected nextField @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

# ---

ctr, lineCtr, rowCtr = 0, 0, 0
d = {}
nextField = ''

# ---

with open(inputFilename) as f:
    for line in f:
        lineCtr += 1

        if lineCtr == 1: continue

        ctr += 1

        if ctr == 0: continue

        s = [c.rstrip() for c in line.split(' ') if c != '']

        if DEBUG:
            if ctr == 1: print('\n--------------------------------  lineCtr: ' + str(lineCtr))

            print('l ' + str(lineCtr) + '; ctr ' + str(ctr) + ' : nextField -> ' + nextField + ', len(s): ' + str(len(s)) + ', s: ' + str(s))

# ---

        if ctr == 1:
            if len(s) == 7:
                d['target_guid']                   = s[0]
                d['target_name']                   = s[1]
                d['vendor_name']                   = s[2]
                d['freq_in_mhz']                   = s[3]
                d['ecache_in_mb']                  = s[4]
                d['impl']                          = s[5]
                d['revision']                      = s[6]
                d['num_cores']                     = s[7]
                d['is_hyperthread_enabled']        = s[8]
                d['siblings']                      = s[9]
                d['last_collection_timestamp_utc'] = s[10] + ' ' + s[11]
                d['extract_dttm_utc']              = s[12] + ' ' + s[13]
                nextField                          = 'done'
            else:
                d['target_guid'] = s[0]
                nextField        = 'target_name'

# ---

        elif ctr == 2:
            if nextField == 'done': pass

            elif nextField == 'target_name':
                if len(s) == 1:
                    d['target_name'] = s[0]
                    nextField        = 'vendor_name'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 3:
            if nextField == 'done': pass

            elif nextField == 'vendor_name':
                if len(s) == 1:
                    d['vendor_name'] = s[0]
                    nextField        = 'freq_in_mhz'

                elif len(s) == 2:
                    d['vendor_name'] = s[0] + ' ' + s[1]
                    nextField        = 'freq_in_mhz'

                elif len(s) == 3:
                    d['vendor_name']  = s[0]
                    d['freq_in_mhz']  = s[1]
                    d['ecache_in_mb'] = s[2]
                    nextField         = 'impl'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 4:
            if nextField == 'done': pass

            elif nextField == 'impl':
                if len(s) == 1:
                    d['impl'] = s[0]
                    nextField = 'revision'

                elif len(s) == 6:
                    d['impl'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4] + ' ' + s[5]
                    nextField = 'revision'

                elif len(s) == 7:
                    d['impl'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4] + ' ' + s[5] + ' ' + s[6]
                    nextField = 'revision'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'freq_in_mhz':
                if len(s) == 2:
                    d['freq_in_mhz']  = s[0]
                    d['ecache_in_mb'] = s[1]
                    nextField         = 'impl'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 5:
            if nextField == 'done': pass

            elif nextField == 'impl':
                if len(s) == 1:
                    d['impl'] = s[0]
                    nextField = 'revision'

                elif len(s) == 6:
                    d['impl'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4] + ' ' + s[5]
                    nextField = 'revision'

                elif len(s) == 7:
                    d['impl'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4] + ' ' + s[5] + ' ' + s[6]
                    nextField = 'revision'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'revision':
                if len(s) == 1:
                    d['revision'] = s[0]
                    nextField     = 'num_cores'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 6:
            if nextField == 'done': pass

            elif nextField == 'revision':
                if len(s) == 1:
                    d['revision'] = s[0]
                    nextField     = 'num_cores'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'num_cores':
                if len(s) == 7:
                    d['num_cores']                     = s[0]
                    d['is_hyperthread_enabled']        = s[1]
                    d['siblings']                      = s[2]
                    d['last_collection_timestamp_utc'] = s[3] + ' ' + s[4]
                    d['extract_dttm_utc']              = s[5] + ' ' + s[6]
                    nextField                          = 'done'

                else:
                    print('Unexpected length @ ctr 7: ' + str(s))

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 7:
            if nextField == 'done': pass

            elif nextField == 'num_cores':
                if len(s) == 5:
                    d['num_cores']                     = s[0]
                    d['is_hyperthread_enabled']        = s[1]
                    d['siblings']                      = s[2]
                    d['last_collection_timestamp_utc'] = s[3] + ' ' + s[4]
                    nextField                          = 'extract_dttm_utc'

                else:
                    print('Unexpected length @ ctr 7: ' + str(s))

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)
# ---

        elif ctr == 8:
            if nextField == 'done': pass

            elif nextField == 'extract_dttm_utc':
                if len(s) == 2:
                    d['extract_dttm_utc'] = s[0] + ' ' + s[1]
                    nextField             = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        else:
            lg('Unexpected value for ctr: ' + str(ctr))

            for k in d:
                lg(k + ' -> ' + d[k])

            logFile.close()
            outputFile.close()

            quit()

# ---

        # if lineCtr > 100: break

# ---

        if nextField == 'done':
            nextField = ''

            if DEBUG: print('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

            missing=False

            for k in header:
                if k not in d.keys():
                    lg(k + '! is missing from d.keys()')
                    missing=True

            for k in d.keys():
                if k not in header:
                    lg(k + '! is missing from header')
                    missing=True

            if missing:
                lg('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

                for k in d:
                    lg(k + ' -> ' + d[k])

                outputFile.close()
                logFile.close()

                quit()

            outputWriter.writerow(d)

            rowCtr += 1
            ctr     = 0 if ctr == 1 else -1
            d       = {}

            #if rowCtr > 5: DEBUG = True
            #if rowCtr > 5: quit()

lg('\n\nWrote ' + str(rowCtr) + ' rows derived from ' + str(lineCtr - 1) + ' original lines to ' + outputFilename)

outputFile.close()
logFile.close()
