__version__ = '1.10'

#
# Version History
#
# 2021-03-29    1.10  tmf    Normalization of logging
# 2021-02-11    1.9   tmf    Fixed typo in error message
# 2020-12-15    1.8   tmf    Added completion message
# 2020-12-02    1.7   tmf    Upgrades based on field use cases
# 2020-11-27    1.6   tmf    Added version moniker
# 2020-11-05    1.5   tmf    Enable debugging with environment variable
# 2020-10-26    1.4   tmf    New method for toggling debugging messages
# 2020-09-22    1.3   tmf    Added new bad file fomats
# 2020-09-07    1.2   tmf    Standardized debugging
# 2020-07-25    1.1   tmf    First revision with version stamp

# ----------------------------------------------------------------------------------------------------------------------

import csv
import os

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = os.environ['EMCC_SIZING_DATA_FILES_ROOT_DIR'] if 'EMCC_SIZING_DATA_FILES_ROOT_DIR' in os.environ else '.'
DEBUG   =  True                                          if ('EMCC_SIZING_REPAIR_DEBUG'       in os.environ and os.environ['EMCC_SIZING_REPAIR_DEBUG'].upper() == 'Y') else False

# ----------------------------------------------------------------------------------------------------------------------

inputFilename  = ROOT_DIR   + os.sep + 'emcc_sizing_extracts_original' + os.sep + 'emcc_sizing_availability_history.csv'
outputPath     = ROOT_DIR   + os.sep + 'emcc_sizing_extracts'
outputFilename = outputPath + os.sep + 'emcc_sizing_availability_history.csv'

# ---

print('\n\nAttempting repair of ' + inputFilename + ' with version ' + __version__)
print('-------------------------------------------------------------------------------------------------------------')

if not os.path.exists(inputFilename):
    print('\n\nInput file ' + inputFilename + ' does not exists; exiting')

    quit()

# ----------------------------------------------------------------------------------------------------------------------

with open(inputFilename) as f:
    fReader = csv.DictReader(f, delimiter=',')
    header  = [h.strip() for h in fReader.fieldnames]

if DEBUG: print(str(header))

# ---

os.makedirs(outputPath, exist_ok=True)

outputFile               = open(outputFilename, 'w')
outputWriter             = csv.DictWriter(outputFile, fieldnames=header, lineterminator='\n')
outputWriter.writeheader()

logFile=open(outputPath + os.sep + 'emcc_sizing_availability_history.txt', 'w')

# ---

def lg(t):
    logFile.write(t + '\n')
    print(t)

def unexpectedLength(ctr, nextField, s, rowCtr):
    t = 'Unexpected length @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

def unexpectedNextField(ctr, nextField, s, rowCtr):
    t = 'Unexpected nextField @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

# ---

ctr, lineCtr, rowCtr = 0, 0, 0
d = {}
nextField = ''

# ---

with open(inputFilename) as f:
    for line in f:
        lineCtr += 1

        if lineCtr == 1: continue

        ctr += 1

        if ctr == 0: continue

        s = [c.rstrip() for c in line.split(' ') if c != '']

        if DEBUG:
            if ctr == 1: print('\n--------------------------------  lineCtr: ' + str(lineCtr))

            print('l ' + str(lineCtr) + '; ctr ' + str(ctr) + ' : nextField -> ' + nextField + ', len(s): ' + str(len(s)) + ', s: ' + str(s))

# ---

        if ctr == 1:
            if len(s) == 7:
                d['TARGET_GUID']         = s[0]
                d['TARGET_NAME']         = s[1]
                d['TARGET_TYPE']         = s[2]
                d['OWNER']               = s[3]
                d['START_TIMESTAMP_UTC'] = s[4] + ' ' + s[5]
                d['END_TIMESTAMP_UTC']   = ''
                d['AVAILABILITY_STATUS'] = s[6]
                nextField = 'done'

            elif len(s) == 8:
                d['TARGET_GUID']         = s[0]
                d['TARGET_NAME']         = s[1]
                d['TARGET_TYPE']         = s[2]
                d['OWNER']               = s[3]
                d['START_TIMESTAMP_UTC'] = s[4] + ' ' + s[5]
                d['END_TIMESTAMP_UTC']   = ''
                d['AVAILABILITY_STATUS'] = s[6] + ' ' + s[7]
                nextField = 'done'

            elif len(s) == 9:
                d['TARGET_GUID']         = s[0]
                d['TARGET_NAME']         = s[1]
                d['TARGET_TYPE']         = s[2]
                d['OWNER']               = s[3]
                d['START_TIMESTAMP_UTC'] = s[4] + ' ' + s[5]
                d['END_TIMESTAMP_UTC']   = s[6] + ' ' + s[7]
                d['AVAILABILITY_STATUS'] = s[8]
                nextField = 'done'

            elif len(s) == 10:
                d['TARGET_GUID']         = s[0]
                d['TARGET_NAME']         = s[1]
                d['TARGET_TYPE']         = s[2]
                d['OWNER']               = s[3]
                d['START_TIMESTAMP_UTC'] = s[4] + ' ' + s[5]
                d['END_TIMESTAMP_UTC']   = s[6] + ' ' + s[7]
                d['AVAILABILITY_STATUS'] = s[8] + ' ' + s[9]
                nextField = 'done'

            else:
                d['TARGET_GUID'] = s[0]

        elif ctr == 2:
            if nextField == 'done': pass
            else:
                d['TARGET_NAME'] = s[0]

        elif ctr == 3:
            if nextField == 'done': pass
            else:
                d['TARGET_TYPE'] = s[0]

        elif ctr == 4:
            if nextField == 'done': pass
            else:
                d['OWNER']       = s[0]

# ---

        elif ctr == 5:
            if nextField == 'done': pass

            else:
                nextField == 'START_TIMESTAMP_UTC'

                if len(s) == 2:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    nextField                = 'END_TIMESTAMP_UTC'

                elif  len(s) == 3:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = ''
                    d['AVAILABILITY_STATUS'] = s[2]
                    nextField                = 'done'

                elif len(s) == 4:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = ''
                    d['AVAILABILITY_STATUS'] = s[2] + ' ' + s[3]
                    nextField                = 'done'

                elif len(s) == 5:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = s[2] + ' ' + s[3]
                    d['AVAILABILITY_STATUS'] = s[4]
                    nextField                = 'done'

                elif len(s) == 6:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = s[2] + ' ' + s[3]
                    d['AVAILABILITY_STATUS'] = s[4] + ' ' + s[5]
                    nextField                = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 6:
            if nextField == 'done': pass

            elif nextField == 'END_TIMESTAMP_UTC':
                if len(s) == 1:
                    d['END_TIMESTAMP_UTC'] = ''
                    nextField              = 'AVAILABILITY_STATUS'

                elif len(s) == 2:
                    d['END_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    nextField              = 'AVAILABILITY_STATUS'

                elif len(s) == 3:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = ''
                    d['AVAILABILITY_STATUS'] = s[2]
                    nextField                = 'done'

                elif len(s) == 4:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = ''
                    d['AVAILABILITY_STATUS'] = s[2] + ' ' + s[3]
                    nextField                = 'done'

                elif len(s) == 5:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = s[2] + ' ' + s[3]
                    d['AVAILABILITY_STATUS'] = s[4]
                    nextField                = 'done'

                elif len(s) == 6:
                    d['START_TIMESTAMP_UTC'] = s[0] + ' ' + s[1]
                    d['END_TIMESTAMP_UTC']   = s[2] + ' ' + s[3]
                    d['AVAILABILITY_STATUS'] = s[4] + ' ' + s[5]
                    nextField                = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 7:
            if nextField == 'done': pass

            elif nextField == 'AVAILABILITY_STATUS':
                if len(s) == 1:
                    d['AVAILABILITY_STATUS'] = s[0]
                    nextField                = 'done'

                elif len(s) == 2:
                    d['AVAILABILITY_STATUS'] = s[0] + ' ' + s[1]
                    nextField                = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'done':
                pass

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        else:
            lg('Unexpected value for ctr: ' + str(ctr))

            for k in d:
                lg(k + ' -> ' + d[k])

            logFile.close()
            outputFile.close()

            quit()

# ---

        # if lineCtr > 100: break

# ---

        if nextField == 'done':
            nextField = ''

            if DEBUG: print('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

            missing=False

            for k in header:
                if k not in d.keys():
                    lg(k + '! is missing from d.keys()')
                    missing=True

            for k in d.keys():
                if k not in header:
                    lg(k + '! is missing from header')
                    missing=True

            if missing:
                lg('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

                for k in d:
                    lg(k + ' -> ' + d[k])

                outputFile.close()
                logFile.close()

                quit()

            outputWriter.writerow(d)

            rowCtr += 1
            ctr     = 0 if ctr == 1 else -1
            d       = {}

            #if rowCtr > 5: DEBUG = True
            #if rowCtr > 5: quit()

lg('\n\nWrote ' + str(rowCtr) + ' rows derived from ' + str(lineCtr - 1) + ' original lines to ' + outputFilename)

outputFile.close()
logFile.close()
