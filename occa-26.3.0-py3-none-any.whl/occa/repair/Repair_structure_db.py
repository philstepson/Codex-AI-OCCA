__version__ = '1.10'

#
# Version History
#
# 2021-03-29    1.10 tmf     Normalized debugging
# 2021-02-11    1.9  tmf     Fixed typo in error message
# 2020-11-20    1.8  tmf     Upgrades based on field use cases & added version moniker
# 2020-11-05    1.7  tmf     Enable debugging with environment variable
# 2020-10-26    1.6  tmf     New method for toggling debugging messages
# 2020-10-13    1.5  tmf     Added new bad file format
# 2020-09-22    1.4  tmf     Added new bad file format
# 2020-09-07    1.3  tmf     Standardized debugging
# 2020-07-29    1.2  tmf     Simplified repair logic
# 2020-07-25    1.1  tmf     First revision with version stamp

# ----------------------------------------------------------------------------------------------------------------------

import csv
import os

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = os.environ['EMCC_SIZING_DATA_FILES_ROOT_DIR'] if 'EMCC_SIZING_DATA_FILES_ROOT_DIR' in os.environ else '.'
DEBUG   =  True                                          if ('EMCC_SIZING_REPAIR_DEBUG'       in os.environ and os.environ['EMCC_SIZING_REPAIR_DEBUG'].upper() == 'Y') else False

# ----------------------------------------------------------------------------------------------------------------------

inputFilename  = ROOT_DIR + os.sep   + 'emcc_sizing_extracts_original' + os.sep + 'emcc_sizing_structure_db.csv'
outputPath     = ROOT_DIR + os.sep   + 'emcc_sizing_extracts'
outputFilename = outputPath + os.sep + 'emcc_sizing_structure_db.csv'

# ---

print('\n\nAttempting repair of ' + inputFilename + ' with version ' + __version__)
print('-------------------------------------------------------------------------------------------------------------')

if not os.path.exists(inputFilename):
    print('\n\nInput file ' + inputFilename + ' does not exists; exiting')

    quit()

# ---

with open(inputFilename) as f:
    fReader = csv.DictReader(f, delimiter=',')
    header  = [h.strip() for h in fReader.fieldnames]

if DEBUG: print(str(header))

if 'extract_version' in header:
    print('\n\nRepair_structure_db.py is not the correct version for file ' + inputFilename)
    print('\nTry running Repair_structure_db2.py instead\n\n')

    quit()

# ---

os.makedirs(outputPath, exist_ok=True)

outputFile               = open(outputFilename, 'w')
outputWriter             = csv.DictWriter(outputFile, fieldnames=header, lineterminator='\n')
outputWriter.writeheader()

logFile=open(outputPath + os.sep + 'emcc_sizing_structure_db.txt', 'w')

# ---

def lg(t):
    logFile.write(t + '\n')
    print(t)

def unexpectedLength(ctr, nextField, s, rowCtr):
    t = 'Unexpected length @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

def unexpectedNextField(ctr, nextField, s, rowCtr):
    t = 'Unexpected nextField @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

# ---

ctr, lineCtr, rowCtr = 0, 0, 0
d = {}
nextField=''

# ---

with open(inputFilename) as f:
    for line in f:
        lineCtr += 1

        if lineCtr == 1: continue

        ctr += 1

        if ctr == 0: continue

        s = [c.rstrip() for c in line.split(' ') if c != '']

        if DEBUG:
            if ctr == 1: print('\n--------------------------------  lineCtr: ' + str(lineCtr))

            print('l ' + str(lineCtr) + '; ctr ' + str(ctr) + ' : nextField -> ' + nextField + ', s: ' + str(s))

# ---

        if ctr == 1:
            if s[0] == 'DB' and s[1] == 'Machine':
                d['dbmachine'] = s[0] + ' ' + s[1] + ' ' + s[2]
            else:
                d['dbmachine'] = s[0]

        elif ctr == 2: d['dbm']       = s[0]
        elif ctr == 3: d['cluster']   = s[0]
        elif ctr == 4: d['cdb']       = s[0]
        elif ctr == 5: d['cdb_owner'] = s[0]

# ---

        elif ctr == 6:
            nextField = 'cdb_standby_type'

            if len(s) == 1:
                d['cdb_standby_type'] = s[0]
                nextField             = 'cdb_type'

            elif len(s) == 2:
                d['cdb_standby_type'] = s[0] + ' ' + s[1]
                nextField             = 'cdb_type'

            else:
                unexpectedLength(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 7:
            if len(s) == 1:
                d['cdb_type'] = s[0]
                nextField     = 'cdb_status'

            elif len(s) == 2:
                d['cdb_type']   = s[0]
                d['cdb_status'] = s[1]
                nextField       = 'cdb_last_load_time_utc'

            elif len(s) == 3:
                d['cdb_type']   = s[0]
                d['cdb_status'] = s[1] + ' ' + s[2]
                nextField       = 'cdb_last_load_time_utc'

            else:
                unexpectedLength(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 8:
            if nextField == 'cdb_status':
                if len(s) == 4:
                    if s[1] in ['no', 'yes']:
                        d['cdb_status']             = s[0]
                        d['cdb_last_load_time_utc'] = ''
                        d['clustered']              = s[1]
                        d['cdb_instance_count']     = s[2]
                        d['host_instance_count']    = s[3]
                        nextField                   = 'host'

                    else:
                        d['cdb_status']             = s[0]
                        d['cdb_last_load_time_utc'] = s[1]
                        d['clustered']              = s[2]
                        d['cdb_instance_count']     = s[3]
                        nextField                   = 'host_instance_count'

                elif len(s) == 5:
                    if s[0] in ['Blackout', 'Pending/Unknown', 'Unreachable']:
                        d['cdb_status']             = s[0]
                        d['cdb_last_load_time_utc'] = s[1]
                        d['clustered']              = s[2]
                        d['cdb_instance_count']     = s[3]
                        d['host_instance_count']    = s[4]
                        nextField                   = 'host'

                    elif s[0] == 'Metric' and s[1] == 'Error':
                        d['cdb_status']             = s[0] + ' ' +s[1]
                        d['cdb_last_load_time_utc'] = ''
                        d['clustered']              = s[2]
                        d['cdb_instance_count']     = s[3]
                        d['host_instance_count']    = s[4]
                        nextField                   = 'host'

                    else:
                        d['cdb_status']             = s[0] + ' ' +s[1]
                        d['cdb_last_load_time_utc'] = s[2]
                        d['clustered']              = s[3]
                        d['cdb_instance_count']     = s[4]
                        nextField                   = 'host_instance_count'

                elif len(s) == 6:
                    d['cdb_status']             = s[0] + ' ' +s[1]
                    d['cdb_last_load_time_utc'] = s[2]
                    d['clustered']              = s[3]
                    d['cdb_instance_count']     = s[4]
                    d['host_instance_count']    = s[5]
                    nextField                   = 'host'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_last_load_time_utc':
                if len(s) == 4:
                    d['cdb_last_load_time_utc'] = s[0]
                    d['clustered']              = s[1]
                    d['cdb_instance_count']     = s[2]
                    d['host_instance_count']    = s[3]
                    nextField                   = 'host'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 9:
            if nextField == 'host_instance_count':
                if len(s) == 1:
                    d['host_instance_count'] = s[0]
                    nextField                = 'host'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host':
                if len(s) == 1:
                    d['host'] = s[0]
                    nextField = 'host_status'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 10:
            if d['cdb'] == 'none':
                d['host_status']             = ''
                d['host_last_load_time_utc'] = ''
                d['db']                      = ''
                d['db_standby_type']         = ''
                d['db_status']               = ''
                d['db_last_load_time_utc']   = ''
                d['logical_cpu_count']       = ''
                d['physical_cpu_count']      = ''
                d['total_cpu_cores']         = ''
                d['mem_gb']                  = ''
                d['freq']                    = ''
                d['ma']                      = ''
                d['system_config']           = ''
                d['vendor_name']             = ''
                d['dist_version']            = ''
                d['cdb_target_guid']         = ''
                d['db_target_guid']          = ''
                d['host_target_guid']        = ''
                d['cdb_num']                 = ''
                d['cdb_inst_rn']             = ''
                d['db_num']                  = ''
                d['host_num']                = ''
                d['dbmachine_owner']         = ''

            elif nextField == 'host':
                if len(s) == 1:
                    d['host'] = s[0]
                    nextField = 'host_status'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_status':
                if len(s) == 2:
                    d['host_status']             = s[0]
                    d['host_last_load_time_utc'] = s[1]
                    nextField                    = 'db'
                elif len(s) == 3:
                    d['host_status']             = s[0] + ' ' + s[1]
                    d['host_last_load_time_utc'] = s[2]
                    nextField                    = 'db'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 11:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'host_status':
                if len(s) == 2:
                    d['host_status']             = s[0]
                    d['host_last_load_time_utc'] = s[1]
                    nextField                    = 'db'

                elif len(s) == 3:
                    d['host_status']             = s[0] + ' ' + s[1]
                    d['host_last_load_time_utc'] = s[2]
                    nextField                    = 'db'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db':
                if len(s) == 1:
                    d['db']   = s[0]
                    nextField = 'db_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 12:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'db':
                if len(s) == 1:
                    d['db']   = s[0]
                    nextField = 'db_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_standby_type':
                if len(s) == 1:
                    if s[0] in ['Blackout', 'Pending/Unknown', 'Unreachable']:
                        d['db_standby_type'] = ''
                        d['db_status']       = s[0]
                        nextField            = 'db_last_load_time_utc'

                    else:
                        d['db_standby_type'] = s[0]
                        nextField            = 'db_status'

                elif len(s) == 2:
                    if s[0] == 'Target':
                        d['db_standby_type'] = ''
                        d['db_status']       = s[0] + ' ' + s[1]
                        nextField            = 'db_last_load_time_utc'

                    elif s[0] in ['Blackout', 'Pending/Unknown', 'Unreachable']:
                        d['db_standby_type']       = ''
                        d['db_status']             = s[0]
                        d['db_last_load_time_utc'] = s[1]
                        nextField                  = 'logical_cpu_count'

                    else:
                        d['db_standby_type'] = s[0] + ' ' + s[1]
                        nextField            = 'db_status'

                elif len(s) == 3:
                    d['db_standby_type'] = s[0] + ' ' + s[1]
                    d['db_status']       = s[2]
                    nextField            = 'db_last_load_time_utc'

                elif len(s) == 4:
                    if s[2] in ['Blackout', 'Pending/Unknown', 'Unreachable']:
                        d['db_standby_type']       = s[0] + ' ' + s[1]
                        d['db_status']             = s[2]
                        d['db_last_load_time_utc'] = s[3]
                        nextField                  = 'logical_cpu_count'

                    else:
                        d['db_standby_type'] = s[0] + ' ' + s[1]
                        d['db_status']       = s[2] + ' ' + s[3]
                        nextField            = 'db_last_load_time_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 13:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'db_standby_type':
                if len(s) == 1:
                    d['db_standby_type'] = s[0]
                    nextField            = 'db_status'

                elif len(s) == 2:
                    if s[1] in ['Blackout', 'Pending/Unknown', 'Unreachable']:
                        d['db_standby_type'] = s[0]
                        d['db_status']       = s[1]
                        nextField            = 'db_last_load_time_utc'

                    else:
                        d['db_standby_type'] = s[0] + ' ' + s[1]
                        nextField            = 'db_status'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_status':
                if len(s) == 3:
                    if s[0] in ['Blackout', 'Pending/Unknown', 'Unreachable']:
                        d['db_status']             = s[0]
                        d['db_last_load_time_utc'] = ''
                        d['logical_cpu_count']     = s[1]
                        d['physical_cpu_count']    = s[2]
                        nextField                  = 'total_cpu_cores'
                    else:
                        d['db_status']             = s[0] + ' ' + s[1]
                        d['db_last_load_time_utc'] = s[2]
                        nextField                  = 'logical_cpu_count'

                elif len(s) == 4:
                    if s[0] in ['Blackout', 'Pending/Unknown', 'Unreachable']:
                        d['db_status']             = s[0]
                        d['db_last_load_time_utc'] = s[1]
                        d['logical_cpu_count']     = s[2]
                        d['physical_cpu_count']    = s[3]
                        nextField                  = 'total_cpu_cores'

                    else:
                        d['db_status']             = s[0] + ' ' + s[1]
                        d['db_last_load_time_utc'] = ''
                        d['logical_cpu_count']     = s[2]
                        d['physical_cpu_count']    = s[3]
                        nextField                  = 'total_cpu_cores'

                elif len(s) == 5:
                    d['db_status']             = s[0] + ' ' + s[1]
                    d['db_last_load_time_utc'] = s[2]
                    d['logical_cpu_count']     = s[3]
                    d['physical_cpu_count']    = s[4]
                    nextField                  = 'total_cpu_cores'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_last_load_time_utc':
                if len(s) == 5:
                    d['db_last_load_time_utc'] = s[0]
                    d['logical_cpu_count']     = s[1]
                    d['physical_cpu_count']    = s[2]
                    d['total_cpu_cores']       = s[3]
                    d['mem_gb']                = s[4]
                    nextField                  = 'freq'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 14:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'db_status':
                if len(s) == 3:
                    d['db_status']             = s[0]
                    d['db_last_load_time_utc'] = ''
                    d['logical_cpu_count']     = s[1]
                    d['physical_cpu_count']    = s[2]
                    nextField                  = 'total_cpu_cores'

                elif len(s) == 4:
                    d['db_status']             = s[0] + ' ' + s[1]
                    d['db_last_load_time_utc'] = ''
                    d['logical_cpu_count']     = s[2]
                    d['physical_cpu_count']    = s[3]
                    nextField                  = 'total_cpu_cores'

                elif len(s) == 5:
                    d['db_status']             = s[0] + ' ' + s[1]
                    d['db_last_load_time_utc'] = s[2]
                    d['logical_cpu_count']     = s[3]
                    d['physical_cpu_count']    = s[4]
                    nextField                  = 'total_cpu_cores'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'logical_cpu_count':
                if len(s) == 1:
                    d['logical_cpu_count'] = s[0]
                    nextField              = 'physical_cpu_count'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'total_cpu_cores':
                if len(s) == 1:
                    d['total_cpu_cores'] = s[0]
                    nextField            = 'mem_gb'

                elif len(s) == 3:
                    d['total_cpu_cores'] = s[0]
                    d['mem_gb']          = s[1]
                    d['freq']            = s[2]
                    nextField            = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'freq':
                if len(s) == 1:
                    d['freq'] = s[0]
                    nextField = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 15:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'physical_cpu_count':
                if len(s) == 1:
                    d['physical_cpu_count'] = s[0]
                    nextField               = 'total_cpu_cores'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'mem_gb':
                if len(s) == 1:
                    d['mem_gb'] = s[0]
                    nextField   = 'freq'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'total_cpu_cores':
                if len(s) == 3:
                    d['total_cpu_cores'] = s[0]
                    d['mem_gb']          = s[1]
                    d['freq']            = s[2]
                    nextField            = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'ma':
                if len(s) == 1:
                    d['ma']   = s[0]
                    nextField = 'system_config'

                elif len(s) == 2:
                    d['ma']   = s[0] + ' ' + s[1]
                    nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 16:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'total_cpu_cores':
                if len(s) == 1:
                    d['total_cpu_cores'] = s[0]
                    nextField            = 'mem_gb'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'freq':
                if len(s) == 1:
                    d['freq'] = s[0]
                    nextField = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'ma':
                if   len(s) == 1:
                    d['ma']   = s[0]
                    nextField = 'system_config'

                elif len(s) == 2:
                    d['ma']   = s[0] + ' ' + s[1]
                    nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'system_config':
                if len(s) == 1:
                    d['system_config'] = s[0]
                    nextField          = 'vendor_name'

                elif len(s) == 2:
                    d['system_config'] = s[0] + ' ' + s[1]
                    nextField          = 'vendor_name'

                elif len(s) == 3:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField          = 'vendor_name'

                elif len(s) == 4:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3]
                    nextField          = 'vendor_name'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 17:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'mem_gb':
                if len(s) == 1:
                    d['mem_gb'] = s[0]
                    nextField   = 'freq'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'ma':
                if len(s) == 1:
                    d['ma']   = s[0]
                    nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'system_config':
                if   len(s) == 1:
                    d['system_config'] = s[0]
                    nextField          = 'vendor_name'

                elif len(s) == 2:
                    d['system_config'] = s[0] + ' ' + s[1]
                    nextField          = 'vendor_name'

                elif len(s) == 3:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField          = 'vendor_name'

                elif len(s) == 4:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3]
                    nextField          = 'vendor_name'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'vendor_name':
                if   len(s) == 1:
                    d['vendor_name'] = s[0]
                    nextField        = 'dist_version'

                elif len(s) == 2:
                    d['vendor_name'] = s[0] + ' ' + s[1]
                    nextField        = 'dist_version'

                elif len(s) == 3:
                    d['vendor_name'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField        = 'dist_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 18:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'freq':
                if len(s) == 1:
                    d['freq'] = s[0]
                    nextField = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'ma':
                if len(s) == 1:
                    d['ma']   = s[0]
                    nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'system_config':
                if   len(s) == 1:
                    d['system_config'] = s[0]

                    if d['system_config'] == '':
                        d['vendor_name']  = ''
                        d['dist_version'] = ''
                        nextField         = 'cdb_target_guid'
                    else:
                        nextField = 'vendor_name'

                elif len(s) == 2:
                    d['vendor_name'] = s[0] + ' ' + s[1]
                    nextField        = 'dist_version'

                elif len(s) == 3:
                    d['vendor_name'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField        = 'dist_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dist_version':
                if   len(s) == 1:
                    d['dist_version'] = s[0]
                    nextField         = 'cdb_target_guid'

                elif len(s) == 2:
                    d['dist_version'] = s[0] + ' ' + s[1]
                    nextField         = 'cdb_target_guid'

                elif len(s) == 3:
                    d['dist_version'] = s[0] + ' ' + s[1]  + ' ' + s[2]
                    nextField         = 'cdb_target_guid'

                elif len(s) == 4:
                    d['dist_version'] = s[0] + ' ' + s[1]  + ' ' + s[2]   + ' ' + s[3]
                    nextField         = 'cdb_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 19:
            if d['cdb'] == 'none':
                pass

            elif nextField == 'ma':
                if len(s) == 2:
                    if d['freq'] == '':
                        d['ma']              = ''
                        d['system_config']   = ''
                        d['vendor_name']     = ''
                        d['dist_version']    = ''
                        d['cdb_target_guid'] = s[0]
                        d['db_target_guid']  = s[1]
                        nextField            = 'host_target_guid'
                    else:
                        d['ma']   = ''
                        nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dist_version':
                if   len(s) == 1:
                    d['dist_version'] = s[0]
                    nextField         = 'cdb_target_guid'

                elif len(s) == 2:
                    d['dist_version'] = s[0] + ' ' + s[1]
                    nextField         = 'cdb_target_guid'

                elif len(s) == 3:
                    d['dist_version'] = s[0] + ' ' + s[1]  + ' ' + s[2]
                    nextField         = 'cdb_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_target_guid':
                if len(s) == 2:
                    d['cdb_target_guid'] = s[0]
                    d['db_target_guid']  = s[1]

                    if d['system_config'] == '':
                        d['host_target_guid'] = ''
                        nextField             = 'cdb_num'
                    else:
                        nextField = 'host_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 20:
            if d['cdb'] == 'none':
                if len(s) == 4:
                    d['cdb_num']          = s[0]
                    d['cdb_inst_rn']      = s[1]
                    d['db_num']           = s[2]
                    d['host_num']         = s[3]
                    nextField             = 'dbmachine_owner'

            elif nextField == 'cdb_num':
                if len(s) == 4:
                    d['cdb_num']          = s[0]
                    d['cdb_inst_rn']      = s[1]
                    d['db_num']           = s[2]
                    d['host_num']         = s[3]
                    nextField             = 'dbmachine_owner'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_target_guid':
                if len(s) == 2:
                    d['cdb_target_guid'] = s[0]
                    d['db_target_guid']  = s[1]
                    nextField            = 'host_target_guid'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_target_guid':
                if len(s) == 1:
                    d['host_target_guid'] = s[0]
                    nextField             = 'cdb_num'

                elif len(s) == 4:
                    if d['ma'] == '':
                        d['host_target_guid'] = ''
                        d['cdb_num']          = s[0]
                        d['cdb_inst_rn']      = s[1]
                        d['db_num']           = s[2]
                        d['host_num']         = s[3]
                        nextField             = 'dbmachine_owner'
                    else:
                        d['host_target_guid'] = s[0]
                        d['cdb_num']          = s[1]
                        d['cdb_inst_rn']      = s[2]
                        d['db_num']           = s[3]
                        nextField             = 'host_num'

                elif len(s) == 5:
                    d['host_target_guid'] = s[0]
                    d['cdb_num']          = s[1]
                    d['cdb_inst_rn']      = s[2]
                    d['db_num']           = s[3]
                    d['host_num']         = s[4]
                    nextField             = 'dbmachine_owner'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)
# ---

        elif ctr == 21:
            if d['cdb'] == 'none':
                if len(s) == 1:
                    d['dbmachine_owner'] = s[0]

                nextField = 'extract_dttm_utc'

            elif nextField == 'host_target_guid':
                if len(s) == 5:
                    d['host_target_guid'] = s[0]
                    d['cdb_num']          = s[1]
                    d['cdb_inst_rn']      = s[2]
                    d['db_num']           = s[3]
                    d['host_num']         = s[4]
                    nextField             = 'dbmachine_owner'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dbmachine_owner':
                if len(s) == 1:
                    d['dbmachine_owner'] = s[0]
                    nextField            = 'extract_dttm_utc'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 22:
            if nextField == 'dbmachine_owner':
                if len(s) == 1:
                    d['dbmachine_owner'] = s[0]
                    nextField            = 'extract_dttm_utc'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'extract_dttm_utc':
                if len(s) == 2:
                    d['extract_dttm_utc'] = s[0] + ' ' + s[1]
                    nextField             = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 23:
            if nextField == 'extract_dttm_utc':
                if len(s) == 2:
                    d['extract_dttm_utc'] = s[0] + ' ' + s[1]
                    nextField             = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'done':
                pass

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        else:
            lg('\nUnexpected value for ctr: ' + str(ctr))

            for k in d:
                lg(k + ' -> ' + d[k])

            logFile.close()
            outputFile.close()

            quit()

# ---

        #if lineCtr > 100: break

# ---

        if nextField == 'done':
            nextField = ''

            if DEBUG: print('\n-------------------------------- rowCtr: ' + str(rowCtr) + '\n' + str(d))

            missing = False

            for k in header:
                if k not in d.keys():
                    lg(k + '! is missing from d.keys()')
                    missing=True

            for k in d.keys():
                if k not in header:
                    lg(k + '! is missing from header')
                    missing=True

            if missing:
                lg('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

                for k in d:
                    lg(k + ' -> ' + d[k])

                logFile.close()
                outputFile.close()

                quit()

            d['logical_cpu_count']  = 0 if d['logical_cpu_count']  == '' else d['logical_cpu_count']
            d['physical_cpu_count'] = 1 if d['physical_cpu_count'] == '' else d['physical_cpu_count']
            d['total_cpu_cores']    = 0 if d['total_cpu_cores']    == '' else d['total_cpu_cores']
            d['mem_gb']             = 0 if d['mem_gb']             == '' else d['mem_gb']
            d['freq']               = 0 if d['freq']               == '' else d['freq']

            outputWriter.writerow(d)

            rowCtr += 1
            ctr     = -1
            d       = {}

            #if rowCtr > 5: DEBUG = True
            #if rowCtr > 5: quit()

lg('\n\nWrote ' + str(rowCtr) + ' rows to ' + outputFilename)

logFile.close()
outputFile.close()
