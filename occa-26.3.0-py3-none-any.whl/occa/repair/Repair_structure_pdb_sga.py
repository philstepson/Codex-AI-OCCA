__version__ = '1.9'

#
# Version History
#
# 2021-03-29    1.9   tmf    Upgrades based on field use cases
# 2021-02-11    1.8   tmf    Fixed typo in error message
# 2020-12-15    1.7   tmf    Added completion message
# 2020-12-02    1.6   tmf    Upgrades based on field use cases
# 2020-11-27    1.5   tmf    Added version moniker
# 2020-11-05    1.4   tmf    Enable debugging with environment variable
# 2020-10-26    1.3   tmf    New method for toggling debugging messages
# 2020-09-07    1.2   tmf    Standardized debugging
# 2020-07-25    1.1   tmf    First revision with version stamp

# ----------------------------------------------------------------------------------------------------------------------

import csv
import os

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = os.environ['EMCC_SIZING_DATA_FILES_ROOT_DIR'] if 'EMCC_SIZING_DATA_FILES_ROOT_DIR' in os.environ else '.'
DEBUG   =  True                                          if ('EMCC_SIZING_REPAIR_DEBUG'       in os.environ and os.environ['EMCC_SIZING_REPAIR_DEBUG'].upper() == 'Y') else False

# ----------------------------------------------------------------------------------------------------------------------

inputFilename  = ROOT_DIR   + os.sep + 'emcc_sizing_extracts_original' + os.sep + 'emcc_sizing_structure_pdb_sga.csv'
outputPath     = ROOT_DIR   + os.sep + 'emcc_sizing_extracts'
outputFilename = outputPath + os.sep + 'emcc_sizing_structure_pdb_sga.csv'

# ---

print('\n\nAttempting repair of ' + inputFilename + ' with version ' + __version__)
print('-------------------------------------------------------------------------------------------------------------')

if not os.path.exists(inputFilename):
    print('\n\nInput file ' + inputFilename + ' does not exists; exiting')

    quit()

# ----------------------------------------------------------------------------------------------------------------------

with open(inputFilename) as f:
    fReader = csv.DictReader(f, delimiter=',')
    header  = [h.strip() for h in fReader.fieldnames]

if DEBUG: print(str(header))

# ---

os.makedirs(outputPath, exist_ok=True)

outputFile               = open(outputFilename, 'w')
outputWriter             = csv.DictWriter(outputFile, fieldnames=header, lineterminator='\n')
outputWriter.writeheader()

logFile=open(outputPath + os.sep + 'emcc_sizing_structure_pdb_sga.txt', 'w')

# ---

def lg(t):
    logFile.write(t + '\n')
    print(t)

def unexpectedLength(ctr, nextField, s, rowCtr):
    t = 'Unexpected length @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

def unexpectedNextField(ctr, nextField, s, rowCtr):
    t = 'Unexpected nextField @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

# ---

ctr, lineCtr, rowCtr = 0, 0, 0
d = {}
nextField = ''

# ---

with open(inputFilename) as f:
    for line in f:
        lineCtr += 1

        if lineCtr == 1: continue

        ctr += 1

        if ctr == 0: continue

        s = [c.rstrip() for c in line.split(' ') if c != '']

        if DEBUG:
            if ctr == 1: print('\n--------------------------------  lineCtr: ' + str(lineCtr))

            print('l ' + str(lineCtr) + '; ctr ' + str(ctr) + ' : nextField -> ' + nextField + ', len(s): ' + str(len(s)) + ', s: ' + str(s))

# ---

        if ctr == 1:
            if len(s) == 9:
                d['TARGET_GUID']      = s[0]
                d['TARGET_NAME']      = s[1]
                d['TARGET_TYPE']      = s[2]
                d['SGANAME']          = s[3] + ' ' + s[4] + ' ' + s[5]
                d['SGASIZE']          = s[6]
                d['EXTRACT_DTTM_UTC'] = s[7] + ' ' + s[8]
                nextField             = 'done'

            else:
                d['TARGET_GUID'] = s[0]
                nextField        = 'TARGET_NAME'

# ---

        elif ctr == 2:
            if nextField == 'done': pass
            else:
                d['TARGET_NAME'] = s[0]
                nextField        = 'TARGET_TYPE'

# ---

        elif ctr == 3:
            if nextField == 'done': pass
            else:
                d['TARGET_TYPE'] = s[0]
                nextField        = 'SGANAME'

# ---

        elif ctr == 4:
            if nextField == 'done': pass
            else:
                if len(s) == 3:
                    d['SGANAME'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField    = 'SGASIZE'

                elif len(s) == 4:
                    d['SGANAME'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    d['SGASIZE'] = s[3]
                    nextField    = 'EXTRACT_DTTM_UTC'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 5:
            if nextField == 'done': pass
            else:
                if nextField == 'SGASIZE':
                    if len(s) == 3:
                        d['SGASIZE']          = s[0]
                        d['EXTRACT_DTTM_UTC'] = s[1] + ' ' + s[2]
                        nextField             = 'done'
                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                elif nextField == 'EXTRACT_DTTM_UTC':
                    if len(s) == 2:
                        d['EXTRACT_DTTM_UTC'] = s[0] + ' ' + s[1]
                        nextField             = 'done'
                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        else:
            lg('Unexpected value for ctr: ' + str(ctr))

            for k in d:
                lg(k + ' -> ' + d[k])

            logFile.close()
            outputFile.close()

            quit()

# ---

        # if lineCtr > 100: break

# ---

        if nextField == 'done':
            nextField = ''

            if DEBUG: print('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

            missing=False

            for k in header:
                if k not in d.keys():
                    lg(k + '! is missing from d.keys()')
                    missing=True

            for k in d.keys():
                if k not in header:
                    lg(k + '! is missing from header')
                    missing=True

            if missing:
                lg('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

                for k in d:
                    lg(k + ' -> ' + d[k])

                outputFile.close()
                logFile.close()

                quit()

            outputWriter.writerow(d)

            rowCtr += 1
            ctr     = 0 if ctr == 1 else -1
            d       = {}

            #if rowCtr > 5: DEBUG = True
            #if rowCtr > 5: quit()

lg('\n\nWrote ' + str(rowCtr) + ' rows derived from ' + str(lineCtr - 1) + ' original lines to ' + outputFilename)

outputFile.close()
logFile.close()
