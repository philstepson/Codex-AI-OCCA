__version__ = '1.14'

#
# Version History
#
# 2021-06-27    1.14  tmf    Upgrades based on field use cases
# 2021-03-29    1.13  tmf    Upgrades based on field use cases
# 2021-02-12    1.12  tmf    Upgrades based on field use cases
# 2021-02-11    1.11  tmf    Fixed typo in error message
# 2021-02-11    1.10  tmf    Upgrades based on field use cases
# 2020-12-15    1.9   tmf    Added completion message
# 2020-12-02    1.8   tmf    Upgrades based on field use cases
# 2020-11-27    1.7   tmf    Added version moniker
# 2020-11-19    1.6   tmf    Upgraded based on field use cases
# 2020-11-15    1.4   tmf    Error message fix
# 2020-11-05    1.3   tmf    Enable debugging with environment variable
# 2020-11-03    1.2   tmf    Upgrades based on field observation
# 2020-10-26    1.1   tmf    First revision

# ----------------------------------------------------------------------------------------------------------------------

import csv
import os

# ----------------------------------------------------------------------------------------------------------------------

ROOT_DIR = os.environ['EMCC_SIZING_DATA_FILES_ROOT_DIR'] if 'EMCC_SIZING_DATA_FILES_ROOT_DIR' in os.environ else '.'
DEBUG   =  True                                          if ('EMCC_SIZING_REPAIR_DEBUG'       in os.environ and os.environ['EMCC_SIZING_REPAIR_DEBUG'].upper() == 'Y') else False

# ----------------------------------------------------------------------------------------------------------------------

inputFilename  = ROOT_DIR   + os.sep + 'emcc_sizing_extracts_original' + os.sep + 'emcc_sizing_structure_db.csv'
outputPath     = ROOT_DIR   + os.sep + 'emcc_sizing_extracts'
outputFilename = outputPath + os.sep + 'emcc_sizing_structure_db.csv'

# ---

print('\n\nAttempting repair of ' + inputFilename + ' with version ' + __version__)
print('-------------------------------------------------------------------------------------------------------------')

if not os.path.exists(inputFilename):
    print('\n\nInput file ' + inputFilename + ' does not exists; exiting')

    quit()

# ----------------------------------------------------------------------------------------------------------------------

with open(inputFilename) as f:
    fReader = csv.DictReader(f, delimiter=',')
    header  = [h.strip() for h in fReader.fieldnames]

if DEBUG: print(str(header))

if 'extract_version' not in header:
    print('\n\nRepair_structure_db2.py is not the correct version for file ' + inputFilename)
    print('\nTry running Repair_structure_db.py instead\n\n')

    quit()

# ---

os.makedirs(outputPath, exist_ok=True)

outputFile               = open(outputFilename, 'w')
outputWriter             = csv.DictWriter(outputFile, fieldnames=header, lineterminator='\n')
outputWriter.writeheader()

logFile=open(outputPath + os.sep + 'emcc_sizing_structure_db.txt', 'w')

# ---

def lg(t):
    logFile.write(t + '\n')
    print(t)

def unexpectedLength(ctr, nextField, s, rowCtr):
    t = 'Unexpected length @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

def unexpectedNextField(ctr, nextField, s, rowCtr):
    t = 'Unexpected nextField @ ctr ' + str(ctr) + ', nextField: ' + nextField + ', s: ' + str(s) + ', row: ' + str(rowCtr)
    lg(t)

# ---

ctr, lineCtr, rowCtr = 0, 0, 0
d = {}
nextField = ''

# ---

with open(inputFilename) as f:
    for line in f:
        lineCtr += 1

        if lineCtr == 1: continue

        ctr += 1

        if ctr == 0: continue

        s = [c.rstrip() for c in line.split(' ') if c != '']

        if DEBUG:
            if ctr == 1: print('\n--------------------------------  lineCtr: ' + str(lineCtr))

            print('l ' + str(lineCtr) + '; ctr ' + str(ctr) + ' : nextField -> ' + nextField + ', len(s): ' + str(len(s)) + ', s: ' + str(s))

# ---

        if ctr == 1:
            if len(s) == 51:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3]
                d['cluster_last_load_time_utc'] = ''
                d['clustered']                  = s[4]
                d['cdb']                        = s[5]
                d['cdb_type_version']           = s[6]
                d['cdb_type']                   = s[7]
                d['cdb_owner']                  = s[8]
                d['cdb_standby_type']           = ''
                d['cdb_status']                 = s[9]
                d['cdb_last_load_time_utc']     = s[10] + ' ' + s[11]
                d['db']                         = s[12]
                d['db_type_version']            = s[13]
                d['db_type']                    = s[14]
                d['db_owner']                   = s[15]
                d['db_standby_type']            = ''
                d['db_status']                  = s[16]
                d['db_last_load_time_utc']      = s[17] + ' ' + s[18]
                d['host']                       = s[19]
                d['host_type_version']          = s[20]
                d['host_status']                = s[21]
                d['host_last_load_time_utc']    = s[22] + ' ' + s[23]
                d['physical_cpu_count']         = s[24]
                d['total_cpu_cores']            = s[25]
                d['logical_cpu_count']          = s[26]
                d['mem_gb']                     = s[27]
                d['freq']                       = s[28]
                d['ma']                         = s[29] + ' ' + s[30]
                d['system_config']              = s[31]
                d['vendor_name']                = s[32]
                d['dist_version']               = s[33] + ' ' + s[34] + ' ' + s[35]
                d['dup_cdb_cluster_flag']       = s[36]
                d['dup_host_dbmachine_flag']    = s[37]
                d['dbmachine_target_guid']      = ''
                d['cluster_target_guid']        = ''
                d['cdb_target_guid']            = s[38]
                d['db_target_guid']             = s[39]
                d['host_target_guid']           = s[40]
                d['cdb_num']                    = s[41]
                d['cdb_inst_rn']                = s[42]
                d['cdb_instance_count']         = s[43]
                d['db_num']                     = s[44]
                d['host_num']                   = s[45]
                d['host_inst_rn']               = s[46]
                d['host_instance_count']        = s[47]
                d['dup_host_cluster_flag']      = s[48]
                d['extract_dttm_utc']           = s[49] + ' ' + s[50]
                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 52:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3]
                d['cluster_last_load_time_utc'] = ''
                d['clustered']                  = s[4]
                d['cdb']                        = s[5]
                d['cdb_type_version']           = s[6]
                d['cdb_type']                   = s[7]
                d['cdb_owner']                  = s[8]
                d['cdb_standby_type']           = ''
                d['cdb_status']                 = s[9]
                d['cdb_last_load_time_utc']     = s[10] + ' ' + s[11]
                d['db']                         = s[12]
                d['db_type_version']            = s[13]
                d['db_type']                    = s[14]
                d['db_owner']                   = s[15]
                d['db_standby_type']            = ''
                d['db_status']                  = s[16]
                d['db_last_load_time_utc']      = s[17] + ' ' + s[18]
                d['host']                       = s[19]
                d['host_type_version']          = s[20]
                d['host_status']                = s[21]
                d['host_last_load_time_utc']    = s[22] + ' ' + s[23]
                d['physical_cpu_count']         = s[24]
                d['total_cpu_cores']            = s[25]
                d['logical_cpu_count']          = s[26]
                d['mem_gb']                     = s[27]
                d['freq']                       = s[28]
                d['ma']                         = s[29] + ' ' + s[30]
                d['system_config']              = s[31]
                d['vendor_name']                = s[32] + ' ' + s[33]
                d['dist_version']               = s[34] + ' ' + s[35] + ' ' + s[36]
                d['dup_cdb_cluster_flag']       = s[37]
                d['dup_host_dbmachine_flag']    = s[38]
                d['dbmachine_target_guid']      = ''
                d['cluster_target_guid']        = ''
                d['cdb_target_guid']            = s[39]
                d['db_target_guid']             = s[40]
                d['host_target_guid']           = s[41]
                d['cdb_num']                    = s[42]
                d['cdb_inst_rn']                = s[43]
                d['cdb_instance_count']         = s[44]
                d['db_num']                     = s[45]
                d['host_num']                   = s[46]
                d['host_inst_rn']               = s[47]
                d['host_instance_count']        = s[48]
                d['dup_host_cluster_flag']      = s[49]
                d['extract_dttm_utc']           = s[50] + ' ' + s[51]
                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 53:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3]
                d['cluster_last_load_time_utc'] = ''
                d['clustered']                  = s[4]
                d['cdb']                        = s[5]
                d['cdb_type_version']           = s[6]
                d['cdb_type']                   = s[7]
                d['cdb_owner']                  = s[8]
                d['cdb_standby_type']           = ''
                d['cdb_status']                 = s[10] + ' ' + s[10]
                d['cdb_last_load_time_utc']     = s[11] + ' ' + s[12]
                d['db']                         = s[13]
                d['db_type_version']            = s[14]
                d['db_type']                    = s[15]
                d['db_owner']                   = s[16]
                d['db_standby_type']            = ''
                d['db_status']                  = s[17] + ' ' + s[18]
                d['db_last_load_time_utc']      = s[19] + ' ' + s[20]
                d['host']                       = s[21]
                d['host_type_version']          = s[22]
                d['host_status']                = s[23] + ' ' + s[24]
                d['host_last_load_time_utc']    = s[25] + ' ' + s[26]
                d['physical_cpu_count']         = s[27]
                d['total_cpu_cores']            = s[28]
                d['logical_cpu_count']          = s[29]
                d['mem_gb']                     = s[30]
                d['freq']                       = s[31]
                d['ma']                         = s[32] + ' ' + s[33]
                d['system_config']              = s[34]
                d['vendor_name']                = s[35] + ' ' + s[36]
                d['dist_version']               = s[37]
                d['dup_cdb_cluster_flag']       = s[38]
                d['dup_host_dbmachine_flag']    = s[39]
                d['dbmachine_target_guid']      = ''
                d['cluster_target_guid']        = ''
                d['cdb_target_guid']            = s[40]
                d['db_target_guid']             = s[41]
                d['host_target_guid']           = s[42]
                d['cdb_num']                    = s[43]
                d['cdb_inst_rn']                = s[44]
                d['cdb_instance_count']         = s[45]
                d['db_num']                     = s[46]
                d['host_num']                   = s[47]
                d['host_inst_rn']               = s[48]
                d['host_instance_count']        = s[49]
                d['dup_host_cluster_flag']      = s[50]
                d['extract_dttm_utc']           = s[51] + ' ' + s[52]
                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 54:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3]

                if d['cluster_status'] == 'Blackout':
                    d['cluster_last_load_time_utc'] = s[4] + ' ' + s[5]
                    d['clustered']                  = s[6]
                    d['cdb']                        = s[7]
                    d['cdb_type_version']           = s[8]
                    d['cdb_type']                   = s[9]
                    d['cdb_owner']                  = s[10]
                    d['cdb_standby_type']           = ''
                    d['cdb_status']                 = s[11]
                    d['cdb_last_load_time_utc']     = s[12] + ' ' + s[13]
                    d['db']                         = s[14]
                    d['db_type_version']            = s[15]
                    d['db_type']                    = s[16]
                    d['db_owner']                   = s[17]
                    d['db_standby_type']            = ''
                    d['db_status']                  = s[18]
                    d['db_last_load_time_utc']      = s[19] + ' ' + s[20]
                    d['host']                       = s[21]
                    d['host_type_version']          = s[22]
                    d['host_status']                = s[23]
                    d['host_last_load_time_utc']    = s[24] + ' ' + s[25]
                    d['physical_cpu_count']         = s[26]
                    d['total_cpu_cores']            = s[27]
                    d['logical_cpu_count']          = s[28]
                    d['mem_gb']                     = s[29]
                    d['freq']                       = s[30]
                    d['ma']                         = s[31] + ' ' + s[32]
                    d['system_config']              = s[33]
                    d['vendor_name']                = s[34]
                    d['dist_version']               = s[35] + ' ' + s[36] + ' ' + s[37]
                    d['dup_cdb_cluster_flag']       = s[38]
                    d['dup_host_dbmachine_flag']    = s[39]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = s[40]
                    d['cdb_target_guid']            = s[41]
                    d['db_target_guid']             = s[42]
                    d['host_target_guid']           = s[43]
                    d['cdb_num']                    = s[44]
                    d['cdb_inst_rn']                = s[45]
                    d['cdb_instance_count']         = s[46]
                    d['db_num']                     = s[47]
                    d['host_num']                   = s[48]
                    d['host_inst_rn']               = s[49]
                    d['host_instance_count']        = s[50]
                    d['dup_host_cluster_flag']      = s[51]
                    d['extract_dttm_utc']           = s[52] + ' ' + s[53]

                else:
                    d['cluster_last_load_time_utc'] = ''
                    d['clustered']                  = s[4]
                    d['cdb']                        = s[5]
                    d['cdb_type_version']           = s[6]
                    d['cdb_type']                   = s[7]
                    d['cdb_owner']                  = s[8]
                    d['cdb_standby_type']           = ''
                    d['cdb_status']                 = s[9]  + ' ' + s[10]
                    d['cdb_last_load_time_utc']     = s[11] + ' ' + s[12]
                    d['db']                         = s[13]
                    d['db_type_version']            = s[14]
                    d['db_type']                    = s[15]
                    d['db_owner']                   = s[16]
                    d['db_standby_type']            = ''
                    d['db_status']                  = s[17] + ' ' + s[18]
                    d['db_last_load_time_utc']      = s[19] + ' ' + s[20]
                    d['host']                       = s[21]
                    d['host_type_version']          = s[22]
                    d['host_status']                = s[23] + ' ' + s[24]
                    d['host_last_load_time_utc']    = s[25] + ' ' + s[26]
                    d['physical_cpu_count']         = s[27]
                    d['total_cpu_cores']            = s[28]
                    d['logical_cpu_count']          = s[29]
                    d['mem_gb']                     = s[30]
                    d['freq']                       = s[31]
                    d['ma']                         = s[32] + ' ' + s[33]
                    d['system_config']              = s[34]
                    d['vendor_name']                = s[35]
                    d['dist_version']               = s[36] + ' ' + s[37] + ' ' + s[38]
                    d['dup_cdb_cluster_flag']       = s[39]
                    d['dup_host_dbmachine_flag']    = s[40]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = ''
                    d['cdb_target_guid']            = s[41]
                    d['db_target_guid']             = s[42]
                    d['host_target_guid']           = s[43]
                    d['cdb_num']                    = s[44]
                    d['cdb_inst_rn']                = s[45]
                    d['cdb_instance_count']         = s[46]
                    d['db_num']                     = s[47]
                    d['host_num']                   = s[48]
                    d['host_inst_rn']               = s[49]
                    d['host_instance_count']        = s[50]
                    d['dup_host_cluster_flag']      = s[51]
                    d['extract_dttm_utc']           = s[52] + ' ' + s[53]

                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 55:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3]
                d['cluster_last_load_time_utc'] = ''
                d['clustered']                  = s[4]
                d['cdb']                        = s[5]
                d['cdb_type_version']           = s[6]
                d['cdb_type']                   = s[7]
                d['cdb_owner']                  = s[8]
                d['cdb_standby_type']           = ''
                d['cdb_status']                 = s[9]  + ' ' + s[10]
                d['cdb_last_load_time_utc']     = s[11] + ' ' + s[12]
                d['db']                         = s[13]
                d['db_type_version']            = s[14]
                d['db_type']                    = s[15]
                d['db_owner']                   = s[16]
                d['db_standby_type']            = ''
                d['db_status']                  = s[17] + ' ' + s[18]
                d['db_last_load_time_utc']      = s[19] + ' ' + s[20]
                d['host']                       = s[21]
                d['host_type_version']          = s[22]
                d['host_status']                = s[23] + ' ' + s[24]
                d['host_last_load_time_utc']    = s[25] + ' ' + s[26]
                d['physical_cpu_count']         = s[27]
                d['total_cpu_cores']            = s[28]
                d['logical_cpu_count']          = s[29]
                d['mem_gb']                     = s[30]
                d['freq']                       = s[31]
                d['ma']                         = s[32] + ' ' + s[33]
                d['system_config']              = s[34]
                d['vendor_name']                = s[35] + ' ' + s[36]
                d['dist_version']               = s[37] + ' ' + s[38] + ' ' + s[39]
                d['dup_cdb_cluster_flag']       = s[40]
                d['dup_host_dbmachine_flag']    = s[41]
                d['dbmachine_target_guid']      = ''
                d['cluster_target_guid']        = ''
                d['cdb_target_guid']            = s[42]
                d['db_target_guid']             = s[43]
                d['host_target_guid']           = s[44]
                d['cdb_num']                    = s[45]
                d['cdb_inst_rn']                = s[46]
                d['cdb_instance_count']         = s[47]
                d['db_num']                     = s[48]
                d['host_num']                   = s[49]
                d['host_inst_rn']               = s[50]
                d['host_instance_count']        = s[51]
                d['dup_host_cluster_flag']      = s[52]
                d['extract_dttm_utc']           = s[53] + ' ' + s[54]
                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 56:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3]
                d['cluster_last_load_time_utc'] = ''
                d['clustered']                  = s[4]
                d['cdb']                        = s[5]
                d['cdb_type_version']           = s[6]
                d['cdb_type']                   = s[7]
                d['cdb_owner']                  = s[8]
                d['cdb_standby_type']           = s[9]

                if d['cluster_status'] == 'Target':
                    d['cluster_status']             = s[3] + ' ' + s[4]
                    d['cluster_last_load_time_utc'] = s[5] + ' ' + s[6]
                    d['clustered']                  = s[7]
                    d['cdb']                        = s[8]
                    d['cdb_type_version']           = s[9]
                    d['cdb_type']                   = s[10]
                    d['cdb_owner']                  = s[11]
                    d['cdb_standby_type']           = ''
                    d['cdb_status']                 = s[12]
                    d['cdb_last_load_time_utc']     = s[13] + ' ' + s[14]
                    d['db']                         = s[15]
                    d['db_type_version']            = s[16]
                    d['db_type']                    = s[17]
                    d['db_owner']                   = s[18]
                    d['db_standby_type']            = ''
                    d['db_status']                  = s[19]
                    d['db_last_load_time_utc']      = s[20] + ' ' + s[21]
                    d['host']                       = s[22]
                    d['host_type_version']          = s[23]
                    d['host_status']                = s[24] + ' ' + s[25]
                    d['host_last_load_time_utc']    = s[26] + ' ' + s[27]
                    d['physical_cpu_count']         = s[28]
                    d['total_cpu_cores']            = s[29]
                    d['logical_cpu_count']          = s[30]
                    d['mem_gb']                     = s[31]
                    d['freq']                       = s[32]
                    d['ma']                         = s[33] + ' ' + s[34]
                    d['system_config']              = s[35]
                    d['vendor_name']                = s[36]
                    d['dist_version']               = s[37] + ' ' + s[38] + ' ' + s[39]
                    d['dup_cdb_cluster_flag']       = s[40]
                    d['dup_host_dbmachine_flag']    = s[41]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = s[42]
                    d['cdb_target_guid']            = s[43]
                    d['db_target_guid']             = s[44]
                    d['host_target_guid']           = s[45]
                    d['cdb_num']                    = s[46]
                    d['cdb_inst_rn']                = s[47]
                    d['cdb_instance_count']         = s[48]
                    d['db_num']                     = s[49]
                    d['host_num']                   = s[50]
                    d['host_inst_rn']               = s[51]
                    d['host_instance_count']        = s[52]
                    d['dup_host_cluster_flag']      = s[53]
                    d['extract_dttm_utc']           = s[54] + ' ' + s[55]

                elif d['cdb_standby_type'] == 'Target':
                    d['cdb_standby_type']           = ''
                    d['cdb_status']                 = s[9]  + ' ' + s[10]
                    d['cdb_last_load_time_utc']     = s[11] + ' ' + s[12]
                    d['db']                         = s[13]
                    d['db_type_version']            = s[14]
                    d['db_type']                    = s[15]
                    d['db_owner']                   = s[16]
                    d['db_standby_type']            = ''
                    d['db_status']                  = s[17] + ' ' + s[18]
                    d['db_last_load_time_utc']      = s[19] + ' ' + s[20]
                    d['host']                       = s[21]
                    d['host_type_version']          = s[22]
                    d['host_status']                = s[23] + ' ' + s[24]
                    d['host_last_load_time_utc']    = s[25] + ' ' + s[26]
                    d['physical_cpu_count']         = s[27]
                    d['total_cpu_cores']            = s[28]
                    d['logical_cpu_count']          = s[29]
                    d['mem_gb']                     = s[30]
                    d['freq']                       = s[31]
                    d['ma']                         = s[32] + ' ' + s[33]
                    d['system_config']              = s[34]
                    d['vendor_name']                = s[35] + ' ' + s[36] + ' ' + s[37]
                    d['dist_version']               = s[38] + ' ' + s[39] + ' ' + s[40]
                    d['dup_cdb_cluster_flag']       = s[41]
                    d['dup_host_dbmachine_flag']    = s[42]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = ''
                    d['cdb_target_guid']            = s[43]
                    d['db_target_guid']             = s[44]
                    d['host_target_guid']           = s[45]
                    d['cdb_num']                    = s[46]
                    d['cdb_inst_rn']                = s[47]
                    d['cdb_instance_count']         = s[48]
                    d['db_num']                     = s[49]
                    d['host_num']                   = s[50]
                    d['host_inst_rn']               = s[51]
                    d['host_instance_count']        = s[52]
                    d['dup_host_cluster_flag']      = s[53]
                    d['extract_dttm_utc']           = s[54] + ' ' + s[55]

                else:
                    d['cdb_status']                 = s[10] + ' ' + s[11]
                    d['cdb_last_load_time_utc']     = s[12] + ' ' + s[13]
                    d['db']                         = s[14]
                    d['db_type_version']            = s[15]
                    d['db_type']                    = s[16]
                    d['db_owner']                   = s[17]
                    d['db_standby_type']            = s[18]
                    d['db_status']                  = s[19] + ' ' + s[20]
                    d['db_last_load_time_utc']      = s[21] + ' ' + s[22]
                    d['host']                       = s[23]
                    d['host_type_version']          = s[24]
                    d['host_status']                = s[25] + ' ' + s[26]
                    d['host_last_load_time_utc']    = s[27] + ' ' + s[28]
                    d['physical_cpu_count']         = s[29]
                    d['total_cpu_cores']            = s[30]
                    d['logical_cpu_count']          = s[31]
                    d['mem_gb']                     = s[32]
                    d['freq']                       = s[33]
                    d['ma']                         = s[34] + ' ' + s[35]
                    d['system_config']              = s[36]
                    d['vendor_name']                = s[37]
                    d['dist_version']               = s[38] + ' ' + s[39] + ' ' + s[40]
                    d['dup_cdb_cluster_flag']       = s[41]
                    d['dup_host_dbmachine_flag']    = s[42]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = ''
                    d['cdb_target_guid']            = s[43]
                    d['db_target_guid']             = s[44]
                    d['host_target_guid']           = s[45]
                    d['cdb_num']                    = s[46]
                    d['cdb_inst_rn']                = s[47]
                    d['cdb_instance_count']         = s[48]
                    d['db_num']                     = s[49]
                    d['host_num']                   = s[50]
                    d['host_inst_rn']               = s[51]
                    d['host_instance_count']        = s[52]
                    d['dup_host_cluster_flag']      = s[53]
                    d['extract_dttm_utc']           = s[54] + ' ' + s[55]

                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 57:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]

                if d['cluster'] == 'none':
                    d['cluster_owner']              = s[2]
                    d['cluster_status']             = s[3]
                    d['cluster_last_load_time_utc'] = ''
                    d['clustered']                  = s[4]
                    d['cdb']                        = s[5]
                    d['cdb_type_version']           = s[6]
                    d['cdb_type']                   = s[7]
                    d['cdb_owner']                  = s[8]
                    d['cdb_standby_type']           = s[9]
                    d['cdb_status']                 = s[10] + ' ' + s[11]
                    d['cdb_last_load_time_utc']     = s[12] + ' ' + s[13]
                    d['db']                         = s[14]
                    d['db_type_version']            = s[15]
                    d['db_type']                    = s[16]
                    d['db_owner']                   = s[17]
                    d['db_standby_type']            = s[18]
                    d['db_status']                  = s[19] + ' ' + s[20]
                    d['db_last_load_time_utc']      = s[21] + ' ' + s[22]
                    d['host']                       = s[23]
                    d['host_type_version']          = s[24]
                    d['host_status']                = s[25] + ' ' + s[26]
                    d['host_last_load_time_utc']    = s[27] + ' ' + s[28]
                    d['physical_cpu_count']         = s[29]
                    d['total_cpu_cores']            = s[30]
                    d['logical_cpu_count']          = s[31]
                    d['mem_gb']                     = s[32]
                    d['freq']                       = s[33]
                    d['ma']                         = s[34] + ' ' + s[35]
                    d['system_config']              = s[36]
                    d['vendor_name']                = s[37] + ' ' + s[38]
                    d['dist_version']               = s[39] + ' ' + s[40] + s[41]
                    d['dup_cdb_cluster_flag']       = s[42]
                    d['dup_host_dbmachine_flag']    = s[43]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = ''
                    d['cdb_target_guid']            = s[44]
                    d['db_target_guid']             = s[45]
                    d['host_target_guid']           = s[46]
                    d['cdb_num']                    = s[47]
                    d['cdb_inst_rn']                = s[48]
                    d['cdb_instance_count']         = s[49]
                    d['db_num']                     = s[50]
                    d['host_num']                   = s[51]
                    d['host_inst_rn']               = s[52]
                    d['host_instance_count']        = s[53]
                    d['dup_host_cluster_flag']      = s[54]
                    d['extract_dttm_utc']           = s[55] + ' ' + s[56]

                else:
                    d['cluster_owner']              = s[2]
                    d['cluster_status']             = s[3] + ' ' + s[4]
                    d['cluster_last_load_time_utc'] = s[5] + ' ' + s[6]
                    d['clustered']                  = s[7]
                    d['cdb']                        = s[8]
                    d['cdb_type_version']           = s[9]
                    d['cdb_type']                   = s[10]
                    d['cdb_owner']                  = s[11]
                    d['cdb_standby_type']           = ''
                    d['cdb_status']                 = s[12] + ' ' + s[13]
                    d['cdb_last_load_time_utc']     = s[14] + ' ' + s[15]
                    d['db']                         = s[16]
                    d['db_type_version']            = s[17]
                    d['db_type']                    = s[18]
                    d['db_owner']                   = s[19]
                    d['db_standby_type']            = ''
                    d['db_status']                  = s[20]
                    d['db_last_load_time_utc']      = s[21] + ' ' + s[22]
                    d['host']                       = s[23]
                    d['host_type_version']          = s[24]
                    d['host_status']                = s[25] + ' ' + s[26]
                    d['host_last_load_time_utc']    = s[27] + ' ' + s[28]
                    d['physical_cpu_count']         = s[29]
                    d['total_cpu_cores']            = s[30]
                    d['logical_cpu_count']          = s[31]
                    d['mem_gb']                     = s[32]
                    d['freq']                       = s[33]
                    d['ma']                         = s[34] + ' ' + s[35]
                    d['system_config']              = s[36]
                    d['vendor_name']                = s[37]
                    d['dist_version']               = s[38] + ' ' + s[39] + ' ' + s[40]
                    d['dup_cdb_cluster_flag']       = s[41]
                    d['dup_host_dbmachine_flag']    = s[42]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = s[43]
                    d['cdb_target_guid']            = s[44]
                    d['db_target_guid']             = s[45]
                    d['host_target_guid']           = s[46]
                    d['cdb_num']                    = s[47]
                    d['cdb_inst_rn']                = s[48]
                    d['cdb_instance_count']         = s[49]
                    d['db_num']                     = s[50]
                    d['host_num']                   = s[51]
                    d['host_inst_rn']               = s[52]
                    d['host_instance_count']        = s[53]
                    d['dup_host_cluster_flag']      = s[54]
                    d['extract_dttm_utc']           = s[55] + ' ' + s[56]

                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 58:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]

                if d['cluster'] == 'none':
                    d['cluster_owner']              = s[2]
                    d['cluster_status']             = s[3]
                    d['cluster_last_load_time_utc'] = ''
                    d['clustered']                  = s[4]
                    d['cdb']                        = s[5]
                    d['cdb_type_version']           = s[6]
                    d['cdb_type']                   = s[7]
                    d['cdb_owner']                  = s[8]
                    d['cdb_standby_type']           = s[9]  + ' ' + s[10]

                    if d['cdb_standby_type'] == 'Target Up':
                        d['cdb_standby_type']           = ''
                        d['cdb_status']                 = s[9]  + ' ' + s[10]
                        d['cdb_last_load_time_utc']     = s[11] + ' ' + s[12]
                        d['db']                         = s[13]
                        d['db_type_version']            = s[14]
                        d['db_type']                    = s[15]
                        d['db_owner']                   = s[16]
                        d['db_standby_type']            = ''
                        d['db_status']                  = s[17] + ' ' + s[18]
                        d['db_last_load_time_utc']      = s[19] + ' ' + s[20]
                        d['host']                       = s[21]
                        d['host_type_version']          = s[22]
                        d['host_status']                = s[23] + ' ' + s[24]
                        d['host_last_load_time_utc']    = s[25] + ' ' + s[26]
                        d['physical_cpu_count']         = s[27]
                        d['total_cpu_cores']            = s[28]
                        d['logical_cpu_count']          = s[29]
                        d['mem_gb']                     = s[30]
                        d['freq']                       = s[31]
                        d['ma']                         = s[32] + ' ' + s[33]
                        d['system_config']              = s[34]
                        d['vendor_name']                = s[35] + ' ' + s[36] + ' ' + s[37] + ' ' + s[38] + ' ' + s[39]
                        d['dist_version']               = s[40] + ' ' + s[41] + ' ' + s[42]
                        d['dup_cdb_cluster_flag']       = s[43]
                        d['dup_host_dbmachine_flag']    = s[44]
                        d['dbmachine_target_guid']      = ''
                        d['cluster_target_guid']        = ''
                        d['cdb_target_guid']            = s[45]
                        d['db_target_guid']             = s[46]
                        d['host_target_guid']           = s[47]
                        d['cdb_num']                    = s[48]
                        d['cdb_inst_rn']                = s[49]
                        d['cdb_instance_count']         = s[50]
                        d['db_num']                     = s[51]
                        d['host_num']                   = s[52]
                        d['host_inst_rn']               = s[53]
                        d['host_instance_count']        = s[54]
                        d['dup_host_cluster_flag']      = s[55]
                        d['extract_dttm_utc']           = s[56] + ' ' + s[57]

                    else:
                        d['cdb_status']                 = s[11] + ' ' + s[12]
                        d['cdb_last_load_time_utc']     = s[13] + ' ' + s[14]
                        d['db']                         = s[15]
                        d['db_type_version']            = s[16]
                        d['db_type']                    = s[17]
                        d['db_owner']                   = s[18]
                        d['db_standby_type']            = s[19] + ' ' + s[20]
                        d['db_status']                  = s[21] + ' ' + s[22]
                        d['db_last_load_time_utc']      = s[23] + ' ' + s[24]
                        d['host']                       = s[25]
                        d['host_type_version']          = s[26]
                        d['host_status']                = s[27] + ' ' + s[28]
                        d['host_last_load_time_utc']    = s[29] + ' ' + s[30]
                        d['physical_cpu_count']         = s[31]
                        d['total_cpu_cores']            = s[32]
                        d['logical_cpu_count']          = s[33]
                        d['mem_gb']                     = s[34]
                        d['freq']                       = s[35]
                        d['ma']                         = s[36] + ' ' + s[37]
                        d['system_config']              = s[38]
                        d['vendor_name']                = s[39]
                        d['dist_version']               = s[40] + ' ' + s[41] + ' ' + s[42]
                        d['dup_cdb_cluster_flag']       = s[43]
                        d['dup_host_dbmachine_flag']    = s[44]
                        d['dbmachine_target_guid']      = ''
                        d['cluster_target_guid']        = ''
                        d['cdb_target_guid']            = s[45]
                        d['db_target_guid']             = s[46]
                        d['host_target_guid']           = s[47]
                        d['cdb_num']                    = s[48]
                        d['cdb_inst_rn']                = s[49]
                        d['cdb_instance_count']         = s[50]
                        d['db_num']                     = s[51]
                        d['host_num']                   = s[52]
                        d['host_inst_rn']               = s[53]
                        d['host_instance_count']        = s[54]
                        d['dup_host_cluster_flag']      = s[55]
                        d['extract_dttm_utc']           = s[56] + ' ' + s[57]

                else:
                    d['cluster_owner']              = s[2]
                    d['cluster_status']             = s[3] + ' ' + s[4]
                    d['cluster_last_load_time_utc'] = s[5] + ' ' + s[6]
                    d['clustered']                  = s[7]
                    d['cdb']                        = s[8]
                    d['cdb_type_version']           = s[9]
                    d['cdb_type']                   = s[10]
                    d['cdb_owner']                  = s[11]
                    d['cdb_standby_type']           = ''
                    d['cdb_status']                 = s[12] + ' ' + s[13]
                    d['cdb_last_load_time_utc']     = s[14] + ' ' + s[15]
                    d['db']                         = s[16]
                    d['db_type_version']            = s[17]
                    d['db_type']                    = s[18]
                    d['db_owner']                   = s[19]
                    d['db_standby_type']            = ''
                    d['db_status']                  = s[20] + ' ' + s[21]
                    d['db_last_load_time_utc']      = s[22] + ' ' + s[23]
                    d['host']                       = s[24]
                    d['host_type_version']          = s[25]
                    d['host_status']                = s[26] + ' ' + s[27]
                    d['host_last_load_time_utc']    = s[28] + ' ' + s[29]
                    d['physical_cpu_count']         = s[30]
                    d['total_cpu_cores']            = s[31]
                    d['logical_cpu_count']          = s[32]
                    d['mem_gb']                     = s[33]
                    d['freq']                       = s[34]
                    d['ma']                         = s[35] + ' ' + s[36]
                    d['system_config']              = s[37]
                    d['vendor_name']                = s[38]
                    d['dist_version']               = s[39] + ' ' + s[40] + ' ' + s[41]
                    d['dup_cdb_cluster_flag']       = s[42]
                    d['dup_host_dbmachine_flag']    = s[43]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = s[44]
                    d['cdb_target_guid']            = s[45]
                    d['db_target_guid']             = s[46]
                    d['host_target_guid']           = s[47]
                    d['cdb_num']                    = s[48]
                    d['cdb_inst_rn']                = s[49]
                    d['cdb_instance_count']         = s[50]
                    d['db_num']                     = s[51]
                    d['host_num']                   = s[52]
                    d['host_inst_rn']               = s[53]
                    d['host_instance_count']        = s[54]
                    d['dup_host_cluster_flag']      = s[55]
                    d['extract_dttm_utc']           = s[56] + ' ' + s[57]
                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 59:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3]

                if d['cluster_status'] == 'Target':
                    d['cluster_status']             = s[3] + ' ' + s[4]
                    d['cluster_last_load_time_utc'] = s[5] + ' ' + s[6]
                    d['clustered']                  = s[7]
                    d['cdb']                        = s[8]
                    d['cdb_type_version']           = s[9]
                    d['cdb_type']                   = s[10]
                    d['cdb_owner']                  = s[11]
                    d['cdb_standby_type']           = s[12]
                    d['cdb_status']                 = s[13] + ' ' + s[14]
                    d['cdb_last_load_time_utc']     = s[15] + ' ' + s[16]
                    d['db']                         = s[17]
                    d['db_type_version']            = s[18]
                    d['db_type']                    = s[19]
                    d['db_owner']                   = s[20]
                    d['db_standby_type']            = s[21]
                    d['db_status']                  = s[22]
                    d['db_last_load_time_utc']      = s[23] + ' ' + s[24]
                    d['host']                       = s[25]
                    d['host_type_version']          = s[26]
                    d['host_status']                = s[27] + ' ' + s[28]
                    d['host_last_load_time_utc']    = s[29] + ' ' + s[30]
                    d['physical_cpu_count']         = s[31]
                    d['total_cpu_cores']            = s[32]
                    d['logical_cpu_count']          = s[33]
                    d['mem_gb']                     = s[34]
                    d['freq']                       = s[35]
                    d['ma']                         = s[36] + ' ' + s[37]
                    d['system_config']              = s[38]
                    d['vendor_name']                = s[39]
                    d['dist_version']               = s[40] + ' ' + s[41] + ' ' + s[42]
                    d['dup_cdb_cluster_flag']       = s[43]
                    d['dup_host_dbmachine_flag']    = s[44]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = s[45]
                    d['cdb_target_guid']            = s[46]
                    d['db_target_guid']             = s[47]
                    d['host_target_guid']           = s[48]
                    d['cdb_num']                    = s[49]
                    d['cdb_inst_rn']                = s[50]
                    d['cdb_instance_count']         = s[51]
                    d['db_num']                     = s[52]
                    d['host_num']                   = s[53]
                    d['host_inst_rn']               = s[54]
                    d['host_instance_count']        = s[55]
                    d['dup_host_cluster_flag']      = s[56]
                    d['extract_dttm_utc']           = s[57] + ' ' + s[58]

                else:
                    d['cluster_last_load_time_utc'] = ''
                    d['clustered']                  = s[4]
                    d['cdb']                        = s[5]
                    d['cdb_type_version']           = s[6]
                    d['cdb_type']                   = s[7]
                    d['cdb_owner']                  = s[8]
                    d['cdb_standby_type']           = s[9]  + ' ' + s[10]
                    d['cdb_status']                 = s[11] + ' ' + s[12]
                    d['cdb_last_load_time_utc']     = s[13] + ' ' + s[14]
                    d['db']                         = s[15]
                    d['db_type_version']            = s[16]
                    d['db_type']                    = s[17]
                    d['db_owner']                   = s[18]
                    d['db_standby_type']            = s[19] + ' ' + s[20]
                    d['db_status']                  = s[21] + ' ' + s[22]
                    d['db_last_load_time_utc']      = s[23] + ' ' + s[24]
                    d['host']                       = s[25]
                    d['host_type_version']          = s[26]
                    d['host_status']                = s[27] + ' ' + s[28]
                    d['host_last_load_time_utc']    = s[29] + ' ' + s[30]
                    d['physical_cpu_count']         = s[31]
                    d['total_cpu_cores']            = s[32]
                    d['logical_cpu_count']          = s[33]
                    d['mem_gb']                     = s[34]
                    d['freq']                       = s[35]
                    d['ma']                         = s[36] + ' ' + s[37]
                    d['system_config']              = s[38]
                    d['vendor_name']                = s[39] + ' ' + s[40]
                    d['dist_version']               = s[41] + ' ' + s[42] + ' ' + s[43]
                    d['dup_cdb_cluster_flag']       = s[44]
                    d['dup_host_dbmachine_flag']    = s[45]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = ''
                    d['cdb_target_guid']            = s[46]
                    d['db_target_guid']             = s[47]
                    d['host_target_guid']           = s[48]
                    d['cdb_num']                    = s[49]
                    d['cdb_inst_rn']                = s[50]
                    d['cdb_instance_count']         = s[51]
                    d['db_num']                     = s[52]
                    d['host_num']                   = s[53]
                    d['host_inst_rn']               = s[54]
                    d['host_instance_count']        = s[55]
                    d['dup_host_cluster_flag']      = s[56]
                    d['extract_dttm_utc']           = s[57] + ' ' + s[58]

                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 60:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]

                if d['cluster'] == 'none':
                    d['cluster_status']             = s[3]
                    d['cluster_last_load_time_utc'] = ''
                    d['clustered']                  = s[4]
                    d['cdb']                        = s[5]
                    d['cdb_type_version']           = s[6]
                    d['cdb_type']                   = s[7]
                    d['cdb_owner']                  = s[8]
                    d['cdb_standby_type']           = s[9]
                    d['cdb_status']                 = s[10] + ' ' + s[11]
                    d['cdb_last_load_time_utc']     = s[12] + ' ' + s[13]
                    d['db']                         = s[14]
                    d['db_type_version']            = s[15]
                    d['db_type']                    = s[16]
                    d['db_owner']                   = s[17]
                    d['db_standby_type']            = s[18]
                    d['db_status']                  = s[19] + ' ' + s[20]
                    d['db_last_load_time_utc']      = s[21] + ' ' + s[22]
                    d['host']                       = s[23]
                    d['host_type_version']          = s[24]
                    d['host_status']                = s[25] + ' ' + s[26]
                    d['host_last_load_time_utc']    = s[27] + ' ' + s[28]
                    d['physical_cpu_count']         = s[29]
                    d['total_cpu_cores']            = s[30]
                    d['logical_cpu_count']          = s[31]
                    d['mem_gb']                     = s[32]
                    d['freq']                       = s[33]
                    d['ma']                         = s[34] + ' ' + s[35]
                    d['system_config']              = s[36]
                    d['vendor_name']                = s[37] + ' ' + s[38] + ' ' + s[39] + ' ' + s[40] + ' ' + s[41]
                    d['dist_version']               = s[42] + ' ' + s[43] + ' ' + s[44]
                    d['dup_cdb_cluster_flag']       = s[45]
                    d['dup_host_dbmachine_flag']    = s[46]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = ''
                    d['cdb_target_guid']            = s[47]
                    d['db_target_guid']             = s[48]
                    d['host_target_guid']           = s[49]
                    d['cdb_num']                    = s[50]
                    d['cdb_inst_rn']                = s[51]
                    d['cdb_instance_count']         = s[52]
                    d['db_num']                     = s[53]
                    d['host_num']                   = s[54]
                    d['host_inst_rn']               = s[55]
                    d['host_instance_count']        = s[56]
                    d['dup_host_cluster_flag']      = s[57]
                    d['extract_dttm_utc']           = s[58] + ' ' + s[59]

                else:
                    d['cluster_status']             = s[3] + ' ' + s[4]
                    d['cluster_last_load_time_utc'] = s[5] + ' ' + s[6]
                    d['clustered']                  = s[7]
                    d['cdb']                        = s[8]
                    d['cdb_type_version']           = s[9]
                    d['cdb_type']                   = s[10]
                    d['cdb_owner']                  = s[11]
                    d['cdb_standby_type']           = s[12]
                    d['cdb_status']                 = s[13] + ' ' + s[14]
                    d['cdb_last_load_time_utc']     = s[15] + ' ' + s[16]
                    d['db']                         = s[17]
                    d['db_type_version']            = s[18]
                    d['db_type']                    = s[19]
                    d['db_owner']                   = s[20]
                    d['db_standby_type']            = s[21]
                    d['db_status']                  = s[22] + ' ' + s[23]
                    d['db_last_load_time_utc']      = s[24] + ' ' + s[25]
                    d['host']                       = s[26]
                    d['host_type_version']          = s[27]
                    d['host_status']                = s[28] + ' ' + s[29]
                    d['host_last_load_time_utc']    = s[30] + ' ' + s[31]
                    d['physical_cpu_count']         = s[32]
                    d['total_cpu_cores']            = s[33]
                    d['logical_cpu_count']          = s[34]
                    d['mem_gb']                     = s[35]
                    d['freq']                       = s[36]
                    d['ma']                         = s[37] + ' ' + s[38]
                    d['system_config']              = s[39]
                    d['vendor_name']                = s[40]
                    d['dist_version']               = s[41] + ' ' + s[42] + ' ' + s[43]
                    d['dup_cdb_cluster_flag']       = s[44]
                    d['dup_host_dbmachine_flag']    = s[45]
                    d['dbmachine_target_guid']      = ''
                    d['cluster_target_guid']        = s[46]
                    d['cdb_target_guid']            = s[47]
                    d['db_target_guid']             = s[48]
                    d['host_target_guid']           = s[49]
                    d['cdb_num']                    = s[50]
                    d['cdb_inst_rn']                = s[51]
                    d['cdb_instance_count']         = s[52]
                    d['db_num']                     = s[53]
                    d['host_num']                   = s[54]
                    d['host_inst_rn']               = s[55]
                    d['host_instance_count']        = s[56]
                    d['dup_host_cluster_flag']      = s[57]
                    d['extract_dttm_utc']           = s[58] + ' ' + s[59]

                nextField                       = 'done'

                if 1 == 0:
                    for k in d:
                        lg(k + ' -> ' + d[k])

                    quit()

            elif len(s) == 62:
                d['extract_version']            = s[0]
                d['dbmachine']                  = ''
                d['dbmachine']                  = ''
                d['dbmachine_type_version']     = ''
                d['dbmachine_type']             = ''
                d['dbmachine_owner']            = ''
                d['cluster']                    = s[1]
                d['cluster_owner']              = s[2]
                d['cluster_status']             = s[3] + ' ' + s[4]
                d['cluster_last_load_time_utc'] = s[5] + ' ' + s[6]
                d['clustered']                  = s[7]
                d['cdb']                        = s[8]
                d['cdb_type_version']           = s[9]
                d['cdb_type']                   = s[10]
                d['cdb_owner']                  = s[11]
                d['cdb_standby_type']           = s[12] + ' ' + s[13]
                d['cdb_status']                 = s[14] + ' ' + s[15]
                d['cdb_last_load_time_utc']     = s[16] + ' ' + s[17]
                d['db']                         = s[18]
                d['db_type_version']            = s[19]
                d['db_type']                    = s[20]
                d['db_owner']                   = s[21]
                d['db_standby_type']            = s[22] + ' ' + s[23]
                d['db_status']                  = s[24] + ' ' + s[25]
                d['db_last_load_time_utc']      = s[26] + ' ' + s[27]
                d['host']                       = s[28]
                d['host_type_version']          = s[29]
                d['host_status']                = s[30] + ' ' + s[31]
                d['host_last_load_time_utc']    = s[32] + ' ' + s[33]
                d['physical_cpu_count']         = s[34]
                d['total_cpu_cores']            = s[35]
                d['logical_cpu_count']          = s[36]
                d['mem_gb']                     = s[37]
                d['freq']                       = s[38]
                d['ma']                         = s[39] + ' ' + s[40]
                d['system_config']              = s[41]
                d['vendor_name']                = s[42]
                d['dist_version']               = s[43] + ' ' + s[44] + ' ' + s[45]
                d['dup_cdb_cluster_flag']       = s[46]
                d['dup_host_dbmachine_flag']    = s[47]
                d['dbmachine_target_guid']      = ''
                d['cluster_target_guid']        = s[48]
                d['cdb_target_guid']            = s[49]
                d['db_target_guid']             = s[50]
                d['host_target_guid']           = s[51]
                d['cdb_num']                    = s[52]
                d['cdb_inst_rn']                = s[53]
                d['cdb_instance_count']         = s[54]
                d['db_num']                     = s[55]
                d['host_num']                   = s[56]
                d['host_inst_rn']               = s[57]
                d['host_instance_count']        = s[58]
                d['dup_host_cluster_flag']      = s[59]
                d['extract_dttm_utc']           = s[60] + ' ' + s[61]
                nextField                       = 'done'

            else:
                d['extract_version'] = s[0]
                nextField            = 'dbmachine'

# ---

        elif ctr == 2:
            if nextField== 'done': pass

            elif s[0] == '':
                d['dbmachine']              = ''
                d['dbmachine_type_version'] = ''
                d['dbmachine_type']         = ''
                d['dbmachine_owner']        = ''
                nextField                   = 'cluster'

            elif s[0] == 'DB' and s[1] == 'Machine':
                d['dbmachine'] = s[0] + ' ' + s[1] + ' ' + s[2]
                nextField      = 'dbmachine_type_version'

            elif s[0] == 'DBLRA' and s[1] == 'Hardware':
                d['dbmachine'] = s[0] + ' ' + s[1] + ' ' + s[2]
                nextField      = 'dbmachine_type_version'

# ---

        elif ctr == 3:
            if nextField in ['cluster', 'done']: pass

            elif nextField == 'dbmachine_type_version':
                if len(s) == 2:
                    d['dbmachine_type_version'] = s[0]
                    d['dbmachine_type']         = s[1]
                    nextField                   = 'dbmachine_owner'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 4:
            if nextField in ['cluster', 'done']: pass

            elif nextField == 'dbmachine_owner':
                if len(s) == 1:
                    d['dbmachine_owner'] = s[0]
                    nextField            = 'cluster'
                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 5:
            if nextField == 'done': pass

            elif nextField == 'cluster':
                if s[0] != '':
                    if len(s) == 1:
                        d['cluster'] = s[0]

                        nextField = 'cluster_owner'

                    elif d['cluster'] == 'none':
                            d['cluster_owner']               = 'none'
                            d['cluster_status']              = 'none'
                            d[ 'cluster_last_load_time_utc'] = ''
                            d['clustered']                   = 'no'

                            nextField                        = 'cdb'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 6:
            if nextField in ['cdb', 'done'] : pass

            elif nextField == 'cluster':
                if len(s) == 1:
                    d['cluster'] = s[0]
                    nextField    = 'cluster_owner'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cluster_owner':
                if len(s) == 1:
                    d['cluster_owner']  = s[0]
                    nextField = 'cluster_status'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 7:
            if nextField in ['cdb', 'done']: pass

            elif nextField == 'cluster_owner':
                if len(s) == 1:
                    d['cluster_owner'] = s[0]
                    nextField          = 'cluster_status'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cluster_status':
                if len(s) == 2:
                    d['cluster_status']             = s[0]
                    d['cluster_last_load_time_utc'] = ''
                    d['clustered']                  = s[1]
                    nextField                       = 'cdb'

                elif len(s) == 4:
                    d['cluster_status']             = s[0]
                    d['cluster_last_load_time_utc'] = s[1] + ' ' + s[2]
                    d['clustered']                  = s[3]
                    nextField                       = 'cdb'

                elif len(s) == 5:
                    d['cluster_status']             = s[0] + ' ' + s[1]
                    d['cluster_last_load_time_utc'] = s[2] + ' ' + s[3]
                    d['clustered']                  = s[4]
                    nextField                       = 'cdb'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 8:
            if nextField == 'done': pass

            elif nextField == 'cdb':
                if len(s) == 1:
                    d['cdb']  = s[0]
                    nextField = 'cdb_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cluster_status':
                if len(s) == 1:
                    d['cluster_status'] = s[0]
                    nextField           = 'cluster_last_load_time_utc'

                elif len(s) == 2:
                    d['cluster_status'] = s[0] + ' ' + s[0]
                    nextField           = 'cluster_last_load_time_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 9:
            if nextField == 'done': pass

            elif nextField == 'cluster_last_load_time_utc':
                if len(s) == 1:
                    if s[0] in ['yes', 'no']:
                        d['cluster_last_load_time_utc'] = ''
                        d['clustered']                  = s[0]
                        nextField                       = 'cdb'

                    else:
                        unexpectedNextField(ctr, nextField, s, rowCtr)

                elif len(s) == 3:
                    d['cluster_last_load_time_utc'] = s[0] + s[1]
                    d['clustered']                  = s[2]
                    nextField                       = 'cdb'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_type_version':
                if len(s) == 2:
                    d['cdb_type_version'] = s[0]
                    d['cdb_type']         = s[1]
                    nextField             = 'cdb_owner'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 10:
            if nextField == 'done': pass

            elif nextField == 'cdb':
                if len(s) == 1:
                    d['cdb']  = s[0]
                    nextField = 'cdb_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_owner':
                if len(s) == 1:
                    d['cdb_owner'] = s[0]
                    nextField      = 'cdb_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 11:
            if nextField == 'done': pass

            elif nextField == 'cdb_type_version':
                if len(s) == 1:
                    d['cdb_type_version'] = s[0]
                    nextField             = 'cdb_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_standby_type':
                if len(s) == 1:
                    if s[0] in ['Blackout', 'Pending/Unknown']:
                        d['cdb_standby_type'] = ''
                        d['cdb_status']       = s[0]
                        nextField             = 'cdb_last_load_time_utc'

                    else:
                        d['cdb_standby_type'] = s[0]
                        nextField             = 'cdb_status'

                elif len(s) == 2:
                    if s[0] == 'Target':
                        d['cdb_standby_type'] = ''
                        d['cdb_status']       = s[0] + ' ' + s[1]
                        nextField             = 'cdb_last_load_time_utc'

                    elif s[1] in ['Blackout', 'Pending/Unknown']:
                        d['cdb_standby_type'] = s[0]
                        d['cdb_status']       = s[1]
                        nextField             = 'cdb_last_load_time_utc'

                    elif s[0] == 'Metric' and s[1] == 'Error':
                        d['cdb_standby_type'] = ''
                        d['cdb_status']       = s[0] + ' ' + s[1]
                        nextField             = 'cdb_last_load_time_utc'

                    else:
                        d['cdb_standby_type'] = s[0] + ' ' + s[1]
                        nextField             = 'cdb_status'

                elif len(s) == 3:
                    if s[0] == 'Primary':
                        d['cdb_standby_type'] = s[0]
                        d['cdb_status']       = s[1] + ' ' + s[2]
                        nextField             = 'cdb_last_load_time_utc'

                    elif s[0] == 'Blackout':
                        d['cdb_standby_type']       = ''
                        d['cdb_status']             = s[0]
                        d['cdb_last_load_time_utc'] = s[1] + ' ' + s[2]
                        nextField                   = 'db'

                    elif s[0] == 'Pending/Unknown':
                        d['cdb_standby_type']       = ''
                        d['cdb_status']             = s[0]
                        d['cdb_last_load_time_utc'] = s[1] + ' ' + s[2]
                        nextField                   = 'db'

                    else:
                        d['cdb_standby_type'] = s[0] + ' ' + s[1]
                        d['cdb_status']       = s[2]
                        nextField             = 'cdb_last_load_time_utc'

                elif len(s) == 4:
                    if s[0] == 'Target' and s[1] in ['Down', 'Up']:
                        d['cdb_standby_type'] = ''
                        d['cdb_status']             = s[0] + ' ' + s[1]
                        d['cdb_last_load_time_utc'] = s[2] + ' ' + s[3]
                        nextField                   = 'db'

                    elif s[0] == 'Metric' and s[1] == 'Error':
                        d['cdb_standby_type'] = ''
                        d['cdb_status']             = s[0] + ' ' + s[1]
                        d['cdb_last_load_time_utc'] = s[2] + ' ' + s[3]
                        nextField                   = 'db'

                    else:
                        d['cdb_standby_type'] = s[0] + ' ' + s[1]
                        d['cdb_status']       = s[2] + ' ' + s[3]
                        nextField             = 'cdb_last_load_time_utc'

                elif len(s) == 5:
                    d['cdb_standby_type']       = s[0]
                    d['cdb_status']             = s[1] + ' ' + s[2]
                    d['cdb_last_load_time_utc'] = s[3] + ' ' + s[4]
                    d['clustered']              = 'yes'
                    nextField                   = 'db'

                elif len(s) == 6:
                    d['cdb_standby_type']       = s[0] + ' ' + s[1]
                    d['cdb_status']             = s[2] + ' ' + s[3]
                    d['cdb_last_load_time_utc'] = s[4] + ' ' + s[5]
                    d['clustered']              = 'yes'
                    nextField                   = 'db'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 12:
            if nextField == 'done': pass

            elif nextField == 'db':
                if len(s) == 1:
                    d['db']   = s[0]
                    nextField = 'db_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_type':
                if len(s) == 1:
                    d['cdb_type'] = s[0]
                    nextField     = 'cdb_owner'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_status':
                if len(s) == 1:
                    d['cdb_status']             = s[0]
                    nextField                   = 'cdb'

                elif len(s) == 3:
                    d['cdb_status']             = s[0]
                    d['cdb_last_load_time_utc'] = s[1]  + ' ' + s[2]
                    nextField                   = 'db'

                elif len(s) == 4:
                    d['cdb_status']             = s[0]  + ' ' + s[1]
                    d['cdb_last_load_time_utc'] = s[2]  + ' ' + s[3]
                    nextField                   = 'db'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_last_load_time_utc':
                if len(s) == 1:
                    if d['cdb_status'] in ['Metric Error', 'Pending/Unknown']:
                        d['cdb_last_load_time_utc'] = ''
                        d['db']                     = s[0]
                        nextField                   = 'db_type_version'

                    else:
                        unexpectedLength(ctr, nextField, s, rowCtr)

                elif len(s) == 2:
                    d['cdb_last_load_time_utc'] = s[0]  + ' ' + s[1]
                    nextField                   = 'db'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 13:
            if nextField == 'done': pass

            elif nextField == 'cdb':
                if len(s) == 1:
                    d['cdb']  = s[0]
                    nextField = 'cdb_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_owner':
                if len(s) == 1:
                    d['cdb_owner'] = s[0]
                    nextField      = 'cdb_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db':
                if len(s) == 1:
                    d['db']   = s[0]
                    nextField = 'db_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_type_version':
                if len(s) == 2:
                    d['db_type_version'] = s[0]
                    d['db_type']         = s[1]
                    nextField = 'db_owner'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 14:
            if nextField == 'done': pass

            elif nextField == 'cdb_type_version':
                if len(s) == 2:
                    d['cdb_type_version'] = s[0]
                    d['cdb_type']         = s[1]
                    nextField             = 'cdb_owner'

            elif nextField == 'cdb_standby_type':
                if len(s) == 1:
                    d['cdb_standby_type'] = s[0]
                    nextField             = 'cdb_status'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_type_version':
                if len(s) == 2:
                    d['db_type_version'] = s[0]
                    d['db_type']         = s[1]
                    nextField            = 'db_owner'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_owner':
                if len(s) == 1:
                    d['db_owner'] = s[0]
                    nextField     = 'db_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 15:
            if nextField == 'done': pass

            elif nextField == 'cdb_owner':
                if len(s) == 1:
                    d['cdb_owner'] = s[0]
                    nextField      = 'cdb_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_status':
                if len(s) == 1:
                    d['cdb_status'] = s[0]
                    nextField       = 'cdb_last_load_time_utc'

                elif len(s) == 2:
                    d['cdb_status'] = s[0] + ' ' + s[1]
                    nextField       = 'cdb_last_load_time_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_standby_type':
                if len(s) == 5:
                    d['cdb_standby_type']       = s[0]
                    d['cdb_status']             = s[1] + ' ' + s[2]
                    d['cdb_last_load_time_utc'] = s[3] + ' ' + s[4]
                    nextField                   = 'db'

                elif len(s) == 6:
                    d['cdb_standby_type']       = s[0] + ' ' + s[1]
                    d['cdb_status']             = s[2] + ' ' + s[3]
                    d['cdb_last_load_time_utc'] = s[4] + ' ' + s[5]
                    nextField                   = 'db'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_owner':
                if len(s) == 1:
                    d['db_owner'] = s[0]
                    nextField     = 'db_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_standby_type':
                if len(s) == 2:
                    if s[0] == 'Metric' and s[1] == 'Error':
                        d['db_standby_type']       = ''
                        d['db_status']             = s[0] + ' ' + s[1]
                        d['db_last_load_time_utc'] = ''
                        nextField                  = 'host'

                    else:
                        unexpectedNextField(ctr, nextField, s, rowCtr)

                elif len(s) == 3:
                    if s[0] == 'Blackout':
                        d['db_standby_type']       = ''
                        d['db_status']             = s[0]
                        d['db_last_load_time_utc'] = s[1] + ' ' + s[2]
                        nextField                  = 'host'

                    elif s[0] == 'Pending/Unknown':
                        d['db_standby_type']       = ''
                        d['db_status']             = s[0]
                        d['db_last_load_time_utc'] = s[1] + ' ' + s[2]
                        nextField                  = 'host'

                    else:
                        unexpectedNextField(ctr, nextField, s, rowCtr)

                elif len(s) == 4:
                    if s[0] == 'Target' and s[1] in ['Down', 'Up']:
                        d['db_standby_type']       = ''
                        d['db_status']             = s[0] + ' ' + s[1]
                        d['db_last_load_time_utc'] = s[2] + ' ' + s[3]
                        nextField                  = 'host'

                    elif s[0] == 'Metric' and s[1] == 'Error':
                        d['db_standby_type']       = ''
                        d['db_status']             = s[0] + ' ' + s[1]
                        d['db_last_load_time_utc'] = s[2] + ' ' + s[3]
                        nextField                  = 'host'

                    else:
                        d['db_standby_type'] = s[0] + ' ' + s[1]
                        d['db_status']       = s[2] + ' ' + s[3]
                        nextField            = 'db_last_load_time_utc'

                elif len(s) == 5:
                    d['db_standby_type']       = s[0]
                    d['db_status']             = s[1] + ' ' + s[2]
                    d['db_last_load_time_utc'] = s[3] + ' ' + s[4]
                    nextField                  = 'host'

                elif len(s) == 6:
                    d['db_standby_type']       = s[0] + ' ' + s[1]
                    d['db_status']             = s[2] + ' ' + s[3]
                    d['db_last_load_time_utc'] = s[4] + ' ' + s[5]
                    nextField                  = 'host'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 16:
            if nextField == 'done': pass

            elif nextField == 'cdb_standby_type':
                if len(s) == 1:
                    d['cdb_standby_type'] = s[0]
                    nextField            = 'cdb_last_load_time_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_last_load_time_utc':
                if len(s) == 2:
                    d['cdb_last_load_time_utc'] = s[0] + ' ' + s[1]
                    nextField                   = 'db'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_standby_type':
                if len(s) == 1:
                    if s[0] in ['Blackout', 'Unreachable']:
                        d['db_standby_type'] = ''
                        d['db_status']       = s[0]
                        nextField            = 'db_last_load_time_utc'

                    else:
                        d['db_standby_type'] = s[0]
                        nextField            = 'db_status'

                elif len(s) == 2:
                    if s[0] == 'Target':
                        d['db_standby_type'] = ''
                        d['db_status']       = s[0] + ' ' + s[1]
                        nextField            = 'db_last_load_time_utc'

                    elif s[1] == 'Blackout':
                        d['db_standby_type'] = s[0]
                        d['db_status']       = s[1]
                        nextField            = 'db_last_load_time_utc'

                    else:
                        d['db_standby_type'] = s[0] + ' ' + s[1]
                        nextField            = 'db_status'

                elif len(s) == 3:
                    if s[0] == 'Primary':
                        d['db_standby_type'] = s[0]
                        d['db_status']       = s[1] + ' ' + s[2]
                    else:
                        d['db_standby_type'] = s[0] + ' ' + s[1]
                        d['db_status']       = s[2]

                    nextField = 'db_last_load_time_utc'

                elif len(s) == 4:
                    d['db_standby_type'] = s[0] + ' ' + s[1]
                    d['db_status']       = s[2] + ' ' + s[3]
                    nextField            = 'db_last_load_time_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host':
                if len(s) == 1:
                    d['host'] = s[0]
                    nextField = 'host_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 17:
            if nextField == 'done': pass

            elif nextField == 'cdb_last_load_time_utc':
                if len(s) == 1:
                    d['cdb_last_load_time_utc'] = s[0]
                    nextField                   = 'db'

                    if d['cdb_last_load_time_utc'] == 'none' or s[0] == 'Pending/Unknown':
                        d['cdb_last_load_time_utc'] = ''
                        d['db']                     = ''
                        d['db_type']                = ''
                        d['db_type_version']        = ''
                        d['db_owner']               = ''
                        d['db_standby_type']        = ''
                        d['db_status']              = ''
                        d['db_last_load_time_utc']  = ''
                        d['db_target_guid']         = ''
                        nextField                   = 'host'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db':
                if len(s) == 1:
                    d['db']   = s[0]
                    nextField = 'db_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_status':
                if len(s) == 1:
                    d['db_status']             = s[0]

                    if d['db_status'] == 'Pending/Unknown':
                        d['db_last_load_time_utc'] = ''
                        nextField                  = 'host'

                    else:
                        nextField                  = 'db_last_load_time_utc'

                elif len(s) == 3:
                    d['db_status']             = s[0]
                    d['db_last_load_time_utc'] = s[1]  + ' ' + s[2]
                    nextField                  = 'host'

                elif len(s) == 4:
                    if s[0] in ['Metric', 'Target']:
                        d['db_status']             = s[0]  + ' ' + s[1]
                        d['db_last_load_time_utc'] = s[2]  + ' ' + s[3]
                        nextField                  = 'host'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_last_load_time_utc':
                if len(s) == 2:
                    d['db_last_load_time_utc'] = s[0]  + ' ' + s[1]
                    nextField                  = 'host'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_type_version':
                if len(s) == 5:
                    d['host_type_version']       = s[0]
                    d['host_status']             = s[1]
                    d['host_last_load_time_utc'] = s[2] + ' ' + s[3]
                    d['physical_cpu_count']      = s[4]
                    nextField                    = 'total_cpu_cores'

                elif len(s) == 6:
                    if s[1] in ['Blackout', 'Unreachable']:
                        d['host_type_version']       = s[0]
                        d['host_status']             = s[1]
                        d['host_last_load_time_utc'] = s[2] + ' ' + s[3]
                        d['physical_cpu_count']      = s[4]
                        d['total_cpu_cores']         = s[5]
                        nextField                    = 'logical_cpu_count'

                    else:
                        d['host_type_version']       = s[0]
                        d['host_status']             = s[1] + ' ' + s[2]
                        d['host_last_load_time_utc'] = s[3] + ' ' + s[4]
                        d['physical_cpu_count']      = s[5]
                        nextField                    = 'total_cpu_cores'

                elif len(s) == 7:
                    d['host_type_version']       = s[0]
                    d['host_status']             = s[1] + ' ' + s[2]
                    d['host_last_load_time_utc'] = s[3] + ' ' + s[4]
                    d['physical_cpu_count']      = s[5]
                    d['total_cpu_cores']         = s[6]
                    nextField                    = 'logical_cpu_count'

                elif len(s) == 10:
                    d['host_type_version']       = s[0]
                    d['host_status']             = s[1] + ' ' + s[2]
                    d['host_last_load_time_utc'] = s[3] + ' ' + s[4]
                    d['physical_cpu_count']      = s[5]
                    d['total_cpu_cores']         = s[6]
                    d['logical_cpu_count']       = s[7]
                    d['mem_gb']                  = s[8]
                    d['freq']                    = s[9]
                    nextField                    = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 18:
            if nextField == 'done': pass

            elif nextField == 'db_type_version':
                if len(s) == 1:
                    d['db_type_version'] = s[0]
                    nextField            = 'db_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host':
                if len(s) == 1:
                    d['host'] = s[0]
                    nextField = 'host_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'ma':
                if len(s) == 1:
                    d['ma']   = s[0]
                    nextField = 'system_config'

                elif len(s) == 2:
                    d['ma']   = s[0] + ' ' + s[1]
                    nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 19:
            if nextField == 'done': pass

            elif nextField == 'db_type':
                if len(s) == 1:
                    d['db_type'] = s[0]
                    nextField    = 'db_owner'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_type_version':
                if len(s) == 5:
                    d['host_type_version']       = s[0]
                    d['host_status']             = s[1]
                    d['host_last_load_time_utc'] = s[2] + ' ' + s[3]
                    d['physical_cpu_count']      = s[4]
                    nextField                    = 'total_cpu_cores'

                elif len(s) == 6:
                    if s[1] in ['Blackout', 'Unreachable']:
                        d['host_type_version']       = s[0]
                        d['host_status']             = s[1]
                        d['host_last_load_time_utc'] = s[2] + ' ' + s[3]
                        d['physical_cpu_count']      = s[4]
                        d['total_cpu_cores']         = s[5]
                        nextField                    = 'logical_cpu_count'

                    else:
                        d['host_type_version']       = s[0]
                        d['host_status']             = s[1] + ' ' + s[2]
                        d['host_last_load_time_utc'] = s[3] + ' ' + s[4]
                        d['physical_cpu_count']      = s[5]
                        nextField                    = 'total_cpu_cores'

                elif len(s) == 7:
                    d['host_type_version']       = s[0]
                    d['host_status']             = s[1] + ' ' + s[2]
                    d['host_last_load_time_utc'] = s[3] + ' ' + s[4]
                    d['physical_cpu_count']      = s[5]
                    d['total_cpu_cores']         = s[6]
                    nextField                    = 'logical_cpu_count'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'system_config':
                if len(s) == 1:
                    d['system_config'] = s[0]
                    nextField          = 'vendor_name'

                elif len(s) == 2:
                    d['system_config'] = s[0] + ' ' + s[1]
                    nextField          = 'vendor_name'

                elif len(s) == 3:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField          = 'vendor_name'

                elif len(s) == 4:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3]
                    nextField          = 'vendor_name'

                elif len(s) == 5:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4]
                    nextField          = 'vendor_name'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 20:
            if nextField == 'done': pass

            elif nextField == 'db_owner':
                if len(s) == 1:
                    d['db_owner'] = s[0]
                    nextField     = 'db_standby_type'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'total_cpu_cores':
                if len(s) == 3:
                    d['total_cpu_cores']   = s[0]
                    d['logical_cpu_count'] = s[1]
                    d['mem_gb']            = s[2]
                    nextField              = 'freq'

                elif len(s) == 4:
                    d['total_cpu_cores']   = s[0]
                    d['logical_cpu_count'] = s[1]
                    d['mem_gb']            = s[2]
                    d['freq']              = s[3]
                    nextField              = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'logical_cpu_count':
                if len(s) == 3:
                    d['logical_cpu_count'] = s[0]
                    d['mem_gb']            = s[1]
                    d['freq']              = s[2]
                    nextField              = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'vendor_name':
                if   len(s) == 1:
                    d['vendor_name'] = s[0]
                    nextField        = 'dist_version'

                elif len(s) == 2:
                    d['vendor_name'] = s[0] + ' ' + s[1]
                    nextField        = 'dist_version'

                elif len(s) == 3:
                    d['vendor_name'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField        = 'dist_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 21:
            if nextField == 'done': pass

            elif nextField == 'db_standby_type':
                if len(s) == 1:
                    d['db_standby_type'] = s[0]
                    nextField            = 'db_status'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'ma':
                if len(s) == 1:
                    d['ma']   = s[0]
                    nextField = 'system_config'

                elif len(s) == 2:
                    d['ma']   = s[0] + ' ' + s[1]
                    nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dist_version':
                if   len(s) == 1:
                    d['dist_version'] = s[0]
                    nextField         = 'dup_cdb_cluster_flag'

                elif len(s) == 2:
                    d['dist_version'] = s[0] + ' ' + s[1]
                    nextField         = 'dup_cdb_cluster_flag'

                elif len(s) == 3:
                    d['dist_version'] = s[0] + ' ' + s[1]  + ' ' + s[2]
                    nextField         = 'dup_cdb_cluster_flag'

                elif len(s) == 4:
                    d['dist_version'] = s[0] + ' ' + s[1]  + ' ' + s[2] + ' ' + s[3]
                    nextField         = 'dup_cdb_cluster_flag'

                elif len(s) == 5:
                    d['dist_version']            = s[0] + ' ' + s[1]  + ' ' + s[2]
                    d['dup_cdb_cluster_flag']    = s[3]
                    d['dup_host_dbmachine_flag'] = s[4]
                    nextField                    = 'dbmachine_target_guid'

                elif len(s) == 6:
                    d['dist_version']            = s[0] + ' ' + s[1]  + ' ' + s[2]
                    d['dup_cdb_cluster_flag']    = s[3]
                    d['dup_host_dbmachine_flag'] = s[4]
                    d['dbmachine_target_guid']   = s[5]
                    nextField                    = 'cluster_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 22:
            if nextField == 'done': pass

            elif nextField == 'db_status':
                if len(s) == 1:
                    d['db_status'] = s[0]
                    nextField      = 'db_last_load_time_utc'

                elif len(s) == 2:
                    d['db_status'] = s[0] + ' ' + s[1]
                    nextField      = 'db_last_load_time_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'system_config':
                if len(s) == 1:
                    d['system_config'] = s[0]
                    nextField          = 'vendor_name'

                elif len(s) == 2:
                    d['system_config'] = s[0] + ' ' + s[1]
                    nextField          = 'vendor_name'

                elif len(s) == 3:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField          = 'vendor_name'

                elif len(s) == 4:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3]
                    nextField          = 'vendor_name'

                elif len(s) == 5:
                    d['system_config'] = s[0] + ' ' + s[1] + ' ' + s[2] + ' ' + s[3] + ' ' + s[4]
                    nextField          = 'vendor_name'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cluster_target_guid':
                if len(s) == 9:
                    d['cluster_target_guid']   = s[0]
                    d['cdb_target_guid']       = s[1]
                    d['db_target_guid']        = s[2]
                    d['host_target_guid']      = s[3]
                    d['cdb_num']               = s[4]
                    d['cdb_inst_rn']           = s[5]
                    d['cdb_instance_count']    = s[6]
                    d['db_num']                = s[7]
                    d['host_num']              = s[8]

                    nextField                  = 'host_inst_rn'

            elif nextField == 'dbmachine_target_guid':
                if len(s) == 8:
                    d['dbmachine_target_guid'] = ''
                    d['cluster_target_guid']   = ''
                    d['cdb_target_guid']       = s[0]
                    d['db_target_guid']        = s[1]
                    d['host_target_guid']      = s[2]
                    d['cdb_num']               = s[3]
                    d['cdb_inst_rn']           = s[4]
                    d['cdb_instance_count']    = s[5]
                    d['db_num']                = s[6]
                    d['host_num']              = s[7]

                    nextField                  = 'host_inst_rn'

                elif len(s) == 9:
                    d['dbmachine_target_guid'] = ''
                    d['cluster_target_guid']   = s[0]
                    d['cdb_target_guid']       = s[1]
                    d['db_target_guid']        = s[2]
                    d['host_target_guid']      = s[3]
                    d['cdb_num']               = s[4]
                    d['cdb_inst_rn']           = s[5]
                    d['cdb_instance_count']    = s[6]
                    d['db_num']                = s[7]
                    d['host_num']              = s[8]

                    nextField                  = 'host_inst_rn'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_instance_count':
                if len(s) == 5:
                    d['host_instance_count']   = s[0]
                    d['dup_host_cluster_flag'] = s[1]
                    d['extract_dttm_utc']      = s[4] + ' ' + s[5]
                    nextField                  = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 23:
            if nextField == 'done': pass

            elif nextField == 'db_last_load_time_utc':
                if len(s) == 2:
                    d['db_last_load_time_utc'] = s[0] + ' ' + s[1]
                    nextField                  = 'host'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'vendor_name':
                if   len(s) == 1:
                    d['vendor_name'] = s[0]
                    nextField        = 'dist_version'

                elif len(s) == 2:
                    d['vendor_name'] = s[0] + ' ' + s[1]
                    nextField        = 'dist_version'

                elif len(s) == 3:
                    d['vendor_name'] = s[0] + ' ' + s[1] + ' ' + s[2]
                    nextField        = 'dist_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_inst_rn':
                if len(s) == 5:
                    d['host_inst_rn']          = s[0]
                    d['host_instance_count']   = s[1]
                    d['dup_host_cluster_flag'] = s[2]
                    d['extract_dttm_utc']      = s[3] + ' ' + s[4]
                    nextField                  = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 24:
            if nextField == 'done': pass

            elif nextField == 'host':
                if len(s) == 1:
                    d['host'] = s[0]
                    nextField = 'host_type_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dist_version':
                if   len(s) == 1:
                    d['dist_version'] = s[0]
                    nextField         = 'dup_cdb_cluster_flag'

                elif len(s) == 2:
                    d['dist_version'] = s[0] + ' ' + s[1]
                    nextField         = 'dup_cdb_cluster_flag'

                elif len(s) == 3:
                    d['dist_version'] = s[0] + ' ' + s[1]  + ' ' + s[2]
                    nextField         = 'dup_cdb_cluster_flag'

                elif len(s) == 4:
                    d['dist_version'] = s[0] + ' ' + s[1]  + ' ' + s[2]   + ' ' + s[3]
                    nextField         = 'dup_cdb_cluster_flag'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 25:
            if nextField == 'done': pass

            elif nextField == 'host_type_version':
                if len(s) == 2:
                    d['host_type_version'] = s[0]
                    d['host_status']       = s[1]
                    nextField              = 'host_last_load_time_utc'

                elif len(s) == 3:
                    d['host_type_version'] = s[0]
                    d['host_status']       = s[1] + ' ' + s[2]
                    nextField              = 'host_last_load_time_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dup_cdb_cluster_flag':
                if len(s) == 2:
                    d['dup_cdb_cluster_flag']    = s[0]
                    d['dup_host_dbmachine_flag'] = s[1]
                    nextField                    = 'dbmachine_target_guid'

                    if d['dbmachine'] == '':
                        d['dbmachine_target_guid'] = ''
                        nextField                  = 'cluster_target_guid'

                    if d['cluster']   == 'none':
                        d['cluster_target_guid'] = ''
                        nextField                = 'cdb_target_guid'

                elif len(s) == 3:
                    d['dup_cdb_cluster_flag']    = s[0]
                    d['dup_host_dbmachine_flag'] = s[1]

                    if d['dbmachine'] != '':
                        d['dbmachine_target_guid'] = s[2]
                        nextField                  = 'cluster_target_guid'

                    else:
                        d['dbmachine_target_guid'] = ''

                        if d['cluster'] != 'none':
                            d['cluster_target_guid'] = s[2]
                            nextField                = 'cdb_target_guid'

                        else:
                            d['cluster_target_guid'] = ''
                            d['cdb_target_guid']     = s[2]
                            nextField                = 'db_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 26:
            if nextField == 'done': pass

            elif nextField == 'host_last_load_time_utc':
                if len(s) == 3:
                    d['host_last_load_time_utc'] = s[0] + ' ' + s[1]
                    d['physical_cpu_count']      = s[2]
                    nextField                    = 'total_cpu_cores'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dbmachine_target_guid':
                if len(s) == 1:
                    d['dbmachine_target_guid'] = s[0]
                    nextField                  = 'cluster_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cluster_target_guid':
                if len(s) == 1:
                    if d['cluster'] == 'none':
                        d['cluster_target_guid'] = ''
                        d['cdb_target_guid']     = s[0]

                        nextField = 'db_target_guid'

                    else:
                        d['cluster_target_guid'] = s[0]

                        nextField = 'cdb_target_guid'

                elif len(s) == 2:
                    d['cluster_target_guid'] = s[0]
                    d['cdb_target_guid']     = s[1]
                    nextField                = 'db_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_target_guid':
                if len(s) == 1:
                    if d['cdb'] == 'none':
                        d['cdb_target_guid'] = ''

                    else:
                        d['cdb_target_guid'] = s[0]

                    nextField            = 'db_target_guid'

                elif len(s) == 2:
                    d['cdb_target_guid']  = s[0]
                    d['host_target_guid'] = s[1]
                    nextField             = 'host_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 27:
            if nextField == 'done': pass

            elif nextField == 'cdb_target_guid':
                if len(s) == 2:
                    if d['cdb'] == 'none':
                        d['cdb_target_guid'] = ''
                    else:
                        d['cdb_target_guid'] = s[0]

                    if d['db']  == 'none':
                        d['db_target_guid']  = ''
                    else:
                        d['db_target_guid'] = s[1]

                    d['host_target_guid'] = s[0]
                    d['cdb_num']          = s[1]

                    nextField             = 'cdb_inst_rn'

                elif len(s) == 3:
                    if d['cdb'] == 'none': d['cdb_target_guid'] = ''
                    if d['db']  == 'none': d['db_target_guid']  = ''

                    d['host_target_guid'] = s[0]
                    d['cdb_num']          = s[1]
                    d['cdb_inst_rn']      = s[2]

                    nextField             = 'cdb_instance_count'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'total_cpu_cores':
                if len(s) == 4:
                    d['total_cpu_cores']   = s[0]
                    d['logical_cpu_count'] = s[1]
                    d['mem_gb']            = s[2]
                    d['freq']              = s[3]
                    nextField              = 'ma'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'db_target_guid':
                if len(s) == 2:
                    d['db_target_guid']   = s[0]
                    d['host_target_guid'] = s[1]
                    nextField             = 'cdb_num'

                elif len(s) == 3:
                    d['db_target_guid']   = s[0]
                    d['host_target_guid'] = s[1]
                    d['cdb_num']          = s[2]
                    nextField             = 'cdb_inst_rn'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 28:
            if nextField == 'done': pass

            elif nextField == 'ma':
                if len(s) == 2:
                    d['ma']   = s[0] +  ' ' + s[1]
                    nextField = 'system_config'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'cdb_inst_rn':
                if len(s) == 5:
                    d['cdb_inst_rn']        = s[0]
                    d['cdb_instance_count'] = s[1]
                    d['db_num']             = s[2]
                    d['host_num']           = s[3]
                    d['host_inst_rn']       = s[4]

                    nextField               = 'host_instance_count'

            elif nextField == 'cdb_instance_count':
                if len(s) == 5:
                    d['cdb_instance_count']  = s[0]
                    d['db_num']              = s[1]
                    d['host_num']            = s[2]
                    d['host_inst_rn']        = s[3]
                    d['host_instance_count'] = s[4]

                    nextField                = 'dup_host_cluster_flag'

            elif nextField == 'cdb_num':
                if len(s) == 5:
                    d['cdb_num']            = s[0]
                    d['cdb_inst_rn']        = s[1]
                    d['cdb_instance_count'] = s[2]
                    d['db_num']             = s[3]
                    d['host_num']           = s[4]

                    nextField               = 'host_inst_rn'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 29:
            if nextField == 'done': pass

            elif nextField == 'system_config':
                if len(s) == 2:
                    d['system_config'] = s[0] +  ' ' + s[1]
                    nextField          = 'vendor_name'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_instance_count':
                if len(s) == 4:
                    d['host_instance_count']   = s[0]
                    d['dup_host_cluster_flag'] = s[1]
                    d['extract_dttm_utc']      = s[2] + ' ' + s[3]

                    nextField                  = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'host_inst_rn':
                if len(s) == 4:
                    d['host_inst_rn']          = s[0]
                    d['host_instance_count']   = s[1]
                    d['dup_host_cluster_flag'] = 0
                    d['extract_dttm_utc']      = s[2] + ' ' + s[3]

                    nextField                  = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            elif nextField == 'dup_host_cluster_flag':
                if len(s) == 4:
                    d['dup_host_cluster_flag'] = s[1]
                    d['extract_dttm_utc']      = s[2] + ' ' + s[3]

                    nextField                  = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 30:
            if nextField == 'done': pass

            elif nextField == 'vendor_name':
                if len(s) == 2:
                    d['vendor_name'] = s[0] +  ' ' + s[1]
                    nextField        = 'dist_version'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)
# ---

        elif ctr == 31:
            if nextField == 'done': pass

            elif nextField == 'dist_version':
                if len(s) == 1:
                    d['dist_version'] = s[0]
                    nextField         = 'dup_cdb_cluster_flag'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 32:
            if nextField == 'done': pass

            elif nextField == 'dup_cdb_cluster_flag':
                if len(s) == 2:
                    d['dup_cdb_cluster_flag']    = s[0]
                    d['dup_host_dbmachine_flag'] = s[1]
                    nextField                    = 'dbmachine_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 33:
            if nextField == 'done': pass

            elif nextField == 'dbmachine_target_guid':
                if len(s) == 1:
                    d['dbmachine_target_guid'] = s[0]
                    nextField                  = 'cluster_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)
# ---

        elif ctr == 34:
            if nextField == 'done': pass

            elif nextField == 'cluster_target_guid':
                if len(s) == 1:
                    d['cluster_target_guid'] = s[0]
                    nextField                = 'cdb_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 35:
            if nextField == 'done': pass

            elif nextField == 'cdb_target_guid':
                if len(s) == 1:
                    d['cdb_target_guid'] = s[0]
                    nextField            = 'db_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)
# ---

        elif ctr == 36:
            if nextField == 'done': pass

            elif nextField == 'db_target_guid':
                if len(s) == 1:
                    d['db_target_guid'] = s[0]
                    nextField           = 'host_target_guid'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 37:
            if nextField == 'done': pass

            elif nextField == 'host_target_guid':
                if len(s) == 1:
                    d['host_target_guid'] = s[0]
                    nextField             = 'cdb_num'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 38:
            if nextField == 'done': pass

            elif nextField == 'cdb_num':
                if len(s) == 6:
                    d['cdb_num']            = s[0]
                    d['cdb_inst_rn']        = s[1]
                    d['cdb_instance_count'] = s[2]
                    d['db_num']             = s[3]
                    d['host_num']           = s[4]
                    d['host_inst_rn']       = s[5]
                    nextField               = 'host_instance_count'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 39:
            if nextField == 'done': pass

            elif nextField == 'host_instance_count':
                if len(s) == 2:
                    d['host_instance_count']   = s[0]
                    d['dup_host_cluster_flag'] = s[1]
                    nextField                  = 'extract_dttm_utc'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        elif ctr == 40:
            if nextField == 'done': pass

            elif nextField == 'extract_dttm_utc':
                if len(s) == 2:
                    d['extract_dttm_utc'] = s[0] + ' ' + s[1]
                    nextField             = 'done'

                else:
                    unexpectedLength(ctr, nextField, s, rowCtr)

            else:
                unexpectedNextField(ctr, nextField, s, rowCtr)

# ---

        else:
            lg('Unexpected value for ctr: ' + str(ctr))

            for k in d:
                lg(k + ' -> ' + d[k])

            logFile.close()
            outputFile.close()

            quit()

# ---

        # if lineCtr > 100: break

# ---

        if nextField == 'done':
            if 1 == 0 and d['mem_gb'] == '19:08:01':

                print('len(s): ' + str(len(s)))
                for k in d:
                    lg(k + ' -> ' + d[k])

                quit()

            nextField = ''

            if DEBUG: print('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

            missing=False

            for k in header:
                if k not in d.keys():
                    lg(k + '! is missing from d.keys()')
                    missing=True

            for k in d.keys():
                if k not in header:
                    lg(k + '! is missing from header')
                    missing=True

            if missing:
                lg('\n-------------------------------- lineCtr: ' + str(lineCtr) + ', rowCtr: ' + str(rowCtr) + '\n' + str(d))

                for k in d:
                    lg(k + ' -> ' + d[k])

                outputFile.close()
                logFile.close()

                quit()

            outputWriter.writerow(d)

            rowCtr += 1
            ctr     = 0 if ctr == 1 else -1
            d       = {}

            #if rowCtr > 5: DEBUG = True
            #if rowCtr > 5: quit()

lg('\n\nWrote ' + str(rowCtr) + ' rows derived from ' + str(lineCtr - 1) + ' original lines to ' + outputFilename)

outputFile.close()
logFile.close()
